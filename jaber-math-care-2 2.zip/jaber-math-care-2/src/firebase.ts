import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { initializeFirestore, memoryLocalCache, getFirestore, getDocFromServer, doc } from 'firebase/firestore';

// Fallback to local JSON config if environment variables are not present
// This allows local development and Cloud Run deployment to work as before
import localConfig from '../firebase-applet-config.json';

const firebaseConfig = {
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || localConfig.projectId,
  appId: import.meta.env.VITE_FIREBASE_APP_ID || localConfig.appId,
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || localConfig.apiKey,
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || localConfig.authDomain,
  firestoreDatabaseId: import.meta.env.VITE_FIREBASE_FIRESTORE_DATABASE_ID || localConfig.firestoreDatabaseId,
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || localConfig.storageBucket,
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || localConfig.messagingSenderId,
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || localConfig.measurementId,
};

const app = initializeApp(firebaseConfig);
export const secondaryApp = initializeApp(firebaseConfig, "Secondary");
export const auth = getAuth(app);
export const secondaryAuth = getAuth(secondaryApp);

// Force local memory cache to prevent sandboxed iframes from getting stuck offline due to IndexedDB policies
const dbId = firebaseConfig.firestoreDatabaseId === "(default)" ? undefined : firebaseConfig.firestoreDatabaseId;
export const db = initializeFirestore(app, {
  localCache: memoryLocalCache(),
}, dbId);

export let isFirebaseOffline = false;
export const setFirebaseOffline = (val: boolean) => { isFirebaseOffline = val; };

export { firebaseConfig };

// Connection test
async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log("Firestore connection successful.");
    setFirebaseOffline(false);
  } catch (error) {
    if (error instanceof Error) {
      console.warn("[Firebase] Initial connection check warning:", error.message);
      // Soft log of offline status without throwing fatal events on page load
      setFirebaseOffline(true);
    }
  }
}
testConnection();
