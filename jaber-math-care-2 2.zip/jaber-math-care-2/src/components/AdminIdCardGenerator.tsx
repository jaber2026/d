import React, { useState } from "react";
import { createPortal } from "react-dom";
import { Printer, Users, School, CreditCard, ChevronDown, Sparkles } from "lucide-react";
import { QRCodeCanvas } from "qrcode.react";

export const AdminIdCardGenerator = ({ students, programs, batches, settings }: any) => {
  const [selectedProgram, setSelectedProgram] = useState("");
  const [selectedBatch, setSelectedBatch] = useState("");
  const [generatedStudents, setGeneratedStudents] = useState<any[]>([]);

  const handleGenerate = () => {
    if (!selectedBatch) {
      alert("Please select a batch first.");
      return;
    }

    const filtered = students.filter((s: any) => {
      if (s.status === "rejected") return false;
      const isOnline = s.student_type === "online" || !!s.course_id || (Array.isArray(s.enrolled_courses) && s.enrolled_courses.length > 0);
      if (isOnline) return false; // offline/physical center students only
      if (String(s.batch_id) !== String(selectedBatch) && String(s.batch_id_2) !== String(selectedBatch)) return false;
      return true;
    });

    setGeneratedStudents(filtered);
  };

  const activePrograms = programs.filter((p: any) => p.status !== "inactive");
  const filteredBatches = batches.filter((b: any) => !selectedProgram || String(b.program_id) === String(selectedProgram));

  // High-performance print trigger
  const triggerPrint = () => {
    window.print();
  };

  const PrintablePortalGrid = () => {
    if (generatedStudents.length === 0) return null;

    const logoSrc = settings?.logo_url || "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff";

    return (
      <div className="print-wrapper">
        <div className="card-grid">
          {generatedStudents.map((user: any, idx: number) => {
            const batchName = batches.find((b: any) => String(b.id) === String(user.batch_id))?.name || user.batch_name || "N/A";
            const picSrc = user.profile_pic || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=ffedd5&color=ea580c`;
            const qrValue = `JABER-MATH-${String(user.batch_id || '0').replace(/\s+/g, '_')}-${String(user.current_class || user.class || '0').replace(/\s+/g, '_')}-${user.roll_number || user.id}`;

            return (
              <div 
                key={`print-card-${user.id}-${idx}`} 
                className="idcard-print-wrapper relative bg-white border-2 border-orange-100 flex flex-col overflow-hidden text-left shadow-none" 
                style={{ width: '320px', height: '650px', borderRadius: '2rem', pageBreakInside: 'avoid', breakInside: 'avoid' }}
              >
                  {/* Top Decorative Background Segment */}
                  <div className="top-decorator absolute top-0 left-0 right-0 h-40 bg-gradient-to-br from-orange-600 via-orange-500 to-amber-500 z-0" style={{ background: 'linear-gradient(to bottom right, #ea580c, #f59e0b)' }}>
                     <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" />
                     {/* Subdued curve to break the straight line */}
                     <svg className="absolute bottom-[-1px] left-0 w-full text-white" viewBox="0 0 1440 320" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                       <path d="M0,256L48,229.3C96,203,192,149,288,154.7C384,160,480,224,576,218.7C672,213,768,139,864,128C960,117,1056,171,1152,197.3C1248,224,1344,224,1392,224L1440,224L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
                     </svg>
                  </div>

                  {/* Header Layer */}
                  <div className="relative pt-6 px-4 flex flex-col items-center justify-center gap-1 z-20 text-white w-full">
                    <div className="flex items-center gap-3">
                      <img src={logoSrc} alt="Logo" className="w-10 h-10 object-contain bg-white p-1 rounded-xl shrink-0 border border-white/20 shadow-sm" />
                      <h2 className="text-xl font-black tracking-tighter uppercase leading-none text-white">{(settings?.site_name || "JABER MATH CARE").toUpperCase()}</h2>
                    </div>
                    <p className="text-[7.5px] font-bold uppercase tracking-[0.1em] mt-1 opacity-95 text-orange-50 text-center">THE FUTURE OF MATH EDUCATION</p>
                  </div>

                  {/* Profile Picture centered overlapping the curve */}
                  <div className="relative mt-8 flex justify-center z-20">
                    <div className="w-28 h-28 bg-white rounded-full border-4 border-white shadow-[0_10px_25px_-5px_rgba(234,88,12,0.4)] overflow-hidden z-20 relative">
                       <div className="w-full h-full rounded-full overflow-hidden bg-orange-50 flex items-center justify-center relative">
                          <img src={picSrc} alt={user.name} className="w-full h-full object-cover" />
                       </div>
                    </div>
                  </div>

                  {/* Student Name Box */}
                  <div className="relative mt-3 px-6 z-20 text-center">
                     <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight truncate leading-tight">{user.name}</h3>
                     <p className="info-badge text-[10px] font-bold text-orange-500 uppercase tracking-widest mt-1 bg-orange-50 inline-block px-3 py-1 rounded-full border border-orange-100">STUDENT ID</p>
                  </div>

                  {/* Info Rows */}
                  <div className="relative mt-5 px-6 space-y-2.5 z-20 flex-1 w-full mx-auto max-w-[260px]">
                    {[
                      { label: 'Class', value: user.current_class || user.class || 'HSC 27' },
                      { label: 'Batch Name', value: batchName },
                      { label: 'Roll No', value: user.roll_number || '---' },
                      { label: 'Blood Grp', value: user.blood_group || 'N/A' },
                      { label: 'Phone No', value: user.phone || '01XXXXXXXXX' }
                    ].map((item, idxx) => (
                      <div key={idxx} className="flex items-center justify-between border-b border-slate-100 pb-1.5 last:border-b-0">
                         <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">{item.label}</span>
                         <span className="text-[10px] font-black text-slate-800 uppercase text-right max-w-[140px] truncate">
                           {item.value}
                         </span>
                      </div>
                    ))}
                  </div>

                  {/* Footer QR code */}
                  <div className="relative mt-auto z-20 flex flex-col items-center justify-end pb-8">
                     <div className="bg-white p-3 rounded-2xl border-[3px] border-orange-100 shadow-md inline-block z-20 mt-4">
                        <QRCodeCanvas 
                           value={qrValue}
                           size={110}
                           level="H"
                           includeMargin={false}
                           fgColor="#ea580c"
                        />
                     </div>
                     <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em] text-center mt-2.5 bg-slate-50 px-4 py-1.5 rounded-full border border-slate-100 shadow-sm z-20">Scan For Official Auth</p>
                  </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-550 text-left">
      {/* Top Banner & Header Section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pb-2 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-2 text-orange-600 bg-orange-50 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider w-fit">
            <Sparkles className="h-3.5 w-3.5" /> High Quality A4 Grid Print
          </div>
          <h2 className="text-3xl md:text-4xl font-black text-slate-900 tracking-tight flex items-center gap-3 mt-2.5">
            <CreditCard className="h-9 w-9 text-orange-600 animate-pulse" /> Bulk ID Card Generator
          </h2>
          <p className="text-sm text-slate-500 font-semibold mt-1">
            Generate and print bulk identity cards for offline student batches. Perfectly aligned for standard A4 printable sheets.
          </p>
        </div>
        <button
          onClick={triggerPrint}
          disabled={generatedStudents.length === 0}
          className="bg-slate-950 text-white hover:bg-slate-800 px-7 py-4 rounded-[1.25rem] font-black uppercase tracking-widest text-xs disabled:opacity-50 flex items-center gap-2.5 shadow-xl disabled:cursor-not-allowed transform hover:scale-[1.02] active:scale-[0.98] transition-all cursor-pointer"
        >
          <Printer className="h-4.5 w-4.5" /> Print A4 Sheet
        </button>
      </div>

      {/* Controls Form with Premium UI Styling */}
      <div className="glass p-8 md:p-10 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40 backdrop-blur-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-orange-500/5 rounded-full blur-[80px] -mr-40 -mt-40 pointer-events-none" />
        
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-3 gap-6 items-end">
          <div className="space-y-2.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-1.5">
              <School className="h-3.5 w-3.5 text-orange-500" /> Filter by Program
            </label>
            <div className="relative">
              <select
                value={selectedProgram}
                onChange={(e) => {
                  setSelectedProgram(e.target.value);
                  setSelectedBatch("");
                }}
                className="w-full bg-white/80 font-bold text-slate-700 text-sm h-13 rounded-2xl px-5 border-2 border-slate-100 hover:border-slate-200 outline-none focus:border-orange-500 transition-all cursor-pointer appearance-none shadow-sm"
              >
                <option value="">All Programs</option>
                {activePrograms.map((p: any) => (
                  <option key={p.id} value={p.id}>{p.title}</option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                <ChevronDown className="h-4 w-4" />
              </div>
            </div>
          </div>

          <div className="space-y-2.5">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1 flex items-center gap-1.5">
              <Users className="h-3.5 w-3.5 text-orange-500" /> Select Target Batch <span className="text-red-500 font-bold">*</span>
            </label>
            <div className="relative">
              <select
                value={selectedBatch}
                onChange={(e) => setSelectedBatch(e.target.value)}
                className="w-full bg-white font-bold text-slate-800 text-sm h-13 rounded-2xl px-5 border-2 border-orange-200/80 outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500/20 transition-all cursor-pointer appearance-none shadow-md"
              >
                <option value="">-- Choose Batch --</option>
                {filteredBatches.map((b: any) => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
              <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-orange-600">
                <ChevronDown className="h-4 w-4" />
              </div>
            </div>
          </div>

          <div>
            <button
              onClick={handleGenerate}
              className="w-full h-13 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg hover:shadow-orange-500/20 active:scale-95 cursor-pointer flex items-center justify-center gap-2 text-center"
            >
              Generate Cards
            </button>
          </div>
        </div>
      </div>

      {/* Screen Preview Workspace (Dashboard mode) */}
      <div className="p-8 bg-slate-50 border border-slate-100 rounded-[2.5rem] relative">
         <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-black text-slate-800 tracking-tight uppercase flex items-center gap-2">
              <div className="w-2 h-6 bg-orange-500 rounded-full" />
              Generator Work Space 
            </h3>
            {generatedStudents.length > 0 && (
               <span className="text-xs bg-orange-100 text-orange-700 px-3 py-1.5 rounded-full font-black uppercase tracking-wider">
                 A4 Preview Active ({generatedStudents.length} Students)
               </span>
            )}
         </div>

         {generatedStudents.length === 0 ? (
           <div className="text-center py-20 text-slate-400 font-black uppercase tracking-wider text-[11px]">
              No preview generated yet. Select a batch and click "Generate Cards".
           </div>
         ) : (
           <div className="flex flex-wrap gap-8 justify-center">
              {generatedStudents.map((user: any, idx: number) => {
                 const batchName = batches.find((b: any) => String(b.id) === String(user.batch_id))?.name || user.batch_name || "N/A";
                 const logoSrc = settings?.logo_url || "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff";
                 const picSrc = user.profile_pic || `https://ui-avatars.com/api/?name=${encodeURIComponent(user.name)}&background=ffedd5&color=ea580c`;
                 const qrValue = `JABER-MATH-${String(user.batch_id || '0').replace(/\s+/g, '_')}-${String(user.current_class || user.class || '0').replace(/\s+/g, '_')}-${user.roll_number || user.id}`;

                 return (
                    <div 
                      key={`preview-card-${user.id}-${idx}`} 
                      className="relative bg-white shadow-[0_20px_60px_-15px_rgba(234,88,12,0.3)] overflow-hidden rounded-[2rem] border-2 border-orange-100 flex flex-col uppercase text-left group transition-all duration-300 hover:shadow-2xl hover:border-orange-300" 
                      style={{ width: '320px', height: '650px' }}
                    >
                        {/* Top Decorative Background Segment */}
                        <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-br from-orange-600 via-orange-500 to-amber-500 z-0">
                           <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" />
                           {/* Subdued curve to break the straight line */}
                           <svg className="absolute bottom-[-1px] left-0 w-full text-white" viewBox="0 0 1440 320" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                             <path d="M0,256L48,229.3C96,203,192,149,288,154.7C384,160,480,224,576,218.7C672,213,768,139,864,128C960,117,1056,171,1152,197.3C1248,224,1344,224,1392,224L1440,224L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
                           </svg>
                        </div>

                        {/* Card Header Layer */}
                        <div className="relative pt-6 px-4 flex flex-col items-center justify-center gap-1 z-20 text-white w-full">
                          <div className="flex items-center gap-3">
                            <img src={logoSrc} alt="Logo" className="w-10 h-10 object-contain bg-white p-1 rounded-xl shrink-0 border border-white/20 shadow-sm" />
                            <h2 className="text-xl font-black tracking-tighter drop-shadow-md leading-none text-white">{(settings?.site_name || "JABER MATH CARE").toUpperCase()}</h2>
                          </div>
                          <p className="text-[7.5px] font-bold uppercase tracking-[0.1em] mt-1 opacity-95 text-orange-50 text-center">THE FUTURE OF MATH EDUCATION</p>
                        </div>

                        {/* Profile Picture overlapping top curve */}
                        <div className="relative mt-8 flex justify-center z-20">
                          <div className="w-28 h-28 bg-white rounded-full border-4 border-white shadow-[0_10px_25px_-5px_rgba(234,88,12,0.4)] overflow-hidden z-20 relative">
                             <div className="w-full h-full rounded-full overflow-hidden bg-orange-50 flex items-center justify-center relative">
                                <img src={picSrc} alt={user.name} className="w-full h-full object-cover" />
                             </div>
                          </div>
                        </div>

                        {/* Student Name */}
                        <div className="relative mt-3 px-6 z-20 text-center">
                           <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight truncate leading-tight">{user.name}</h3>
                           <p className="text-[10px] font-bold text-orange-500 uppercase tracking-widest mt-1 bg-orange-50 inline-block px-3 py-1 rounded-full border border-orange-100">STUDENT ID</p>
                        </div>

                        {/* Info rows */}
                        <div className="relative mt-5 px-6 space-y-2.5 z-20 flex-1 w-full mx-auto max-w-[260px]">
                          {[
                            { label: 'Class', value: user.current_class || user.class || 'HSC 27' },
                            { label: 'Batch Name', value: batchName },
                            { label: 'Roll No', value: user.roll_number || '---' },
                            { label: 'Blood Grp', value: user.blood_group || 'N/A' },
                            { label: 'Phone No', value: user.phone || '01XXXXXXXXX' }
                          ].map((item, idxx) => (
                            <div key={idxx} className="flex items-center justify-between border-b border-slate-100 pb-1.5 last:border-b-0">
                               <span className="text-[9px] font-bold text-slate-450 uppercase tracking-wider">{item.label}</span>
                               <span className="text-[10px] font-black text-slate-800 uppercase text-right max-w-[140px] truncate">
                                 {item.value}
                               </span>
                            </div>
                          ))}
                        </div>

                        {/* QR Code Footer */}
                        <div className="relative mt-auto z-20 flex flex-col items-center justify-end pb-8">
                           <div className="bg-white p-3 rounded-2xl border-[3px] border-orange-100 shadow-md z-20 inline-block mt-4">
                              <QRCodeCanvas 
                                 value={qrValue}
                                 size={110}
                                 level="H"
                                 includeMargin={false}
                                 fgColor="#ea580c"
                              />
                           </div>
                           <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em] text-center mt-2.5 bg-slate-50 px-4 py-1.5 rounded-full border border-slate-100 shadow-sm z-20">Scan For Official Auth</p>
                        </div>

                        <div className="absolute right-0 bottom-1/4 scale-150 opacity-[0.02] pointer-events-none rotate-90 z-0 select-none">
                          <School className="w-64 h-64 text-orange-900" />
                        </div>
                    </div>
                 );
              })}
           </div>
         )}
      </div>

      {/* Global CSS Styles injected into dynamic print media */}
      <style dangerouslySetInnerHTML={{__html: `
        @media screen {
          .print-wrapper {
            display: none !important;
          }
        }
        @media print {
          /* Hide EVERYTHING inside the body / root node */
          body > * {
            display: none !important;
          }
          #root {
            display: none !important;
          }
          /* Bring back ONLY the print-wrapper */
          .print-wrapper {
            display: block !important;
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 210mm !important;
            min-height: 297mm !important;
            background-color: white !important;
            margin: 0 !important;
            padding: 10mm !important;
            box-sizing: border-box !important;
          }
          .card-grid {
            display: grid !important;
            grid-template-columns: repeat(2, 320px) !important;
            grid-column-gap: 30px !important;
            grid-row-gap: 30px !important;
            justify-content: center !important;
            margin: 0 auto !important;
            width: 100% !important;
          }
          .idcard-print-wrapper {
            width: 320px !important;
            height: 650px !important;
            border: 2px solid #ea580c !important;
            border-radius: 2rem !important;
            background-color: white !important;
            page-break-inside: avoid !important;
            break-inside: avoid !important;
            position: relative !important;
            overflow: hidden !important;
            display: flex !important;
            flex-direction: column !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          .top-decorator {
            background: linear-gradient(135deg, #ea580c 0%, #f59e0b 100%) !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
          .info-badge {
            background-color: #fff7ed !important;
            border-color: #ffedd5 !important;
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
        }
      `}} />

      {/* Render the actual printable layout outer sibling using Portal direct to document.body */}
      {typeof document !== "undefined" && createPortal(<PrintablePortalGrid />, document.body)}
    </div>
  );
};
