import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Mic, MicOff, Video, VideoOff, MonitorUp, 
  MessageSquare, Users, Hand, PhoneOff, 
  Settings, Maximize, Minimize, LayoutDashboard,
  Radio, RadioTower, Send, ShieldCheck, Activity,
  Volume2, VolumeX, Play, Pause, X,
  Smile, Heart, ThumbsUp, Zap, Award, BarChart2,
  ExternalLink, PlayCircle, MonitorPlay
} from 'lucide-react';
// import { JitsiMeeting } from '@jitsi/react-sdk';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { safeJson } from '../utils/api';
import { db } from '../firebase';
import { collection, query, where, onSnapshot, orderBy, addDoc, serverTimestamp, doc, updateDoc, setDoc, deleteDoc } from 'firebase/firestore';
import AgoraRTC, { IAgoraRTCClient, ICameraVideoTrack, IMicrophoneAudioTrack } from "agora-rtc-sdk-ng";

export default function CustomLivePortal() {
  const { roomId } = useParams();
  const navigate = useNavigate();
  const { user, token } = useAuth();
  
  // Custom UI States
  const [isAudioMuted, setIsAudioMuted] = useState(true);
  const [isVideoMuted, setIsVideoMuted] = useState(true);
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [isParticipantsOpen, setIsParticipantsOpen] = useState(false);
  const [isPollsOpen, setIsPollsOpen] = useState(false);
  const [participantCount, setParticipantCount] = useState(24);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const [isFullScreen, setIsFullScreen] = useState(false);
  const [messages, setMessages] = useState<any[]>([]);
  const [polls, setPolls] = useState<any[]>([]);
  const [reactions, setReactions] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isVolumeMuted, setIsVolumeMuted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMutedByAdmin, setIsMutedByAdmin] = useState(false);
  const [isVideoOffByAdmin, setIsVideoOffByAdmin] = useState(false);
  const [participants, setParticipants] = useState<any[]>([]);
  const videoContainerRef = useRef<HTMLDivElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const remoteVideoRef = useRef<HTMLDivElement>(null);
  
  // Agora States
  const agoraClient = useRef<IAgoraRTCClient | null>(null);
  const localAudioTrack = useRef<IMicrophoneAudioTrack | null>(null);
  const localVideoTrack = useRef<ICameraVideoTrack | null>(null);
  const localVideoRef = useRef<HTMLDivElement>(null);
  const appId = import.meta.env.VITE_AGORA_APP_ID;
  const [isRemoteVideoActive, setIsRemoteVideoActive] = useState(false);

  const [classData, setClassData] = useState<any>(null);

  useEffect(() => {
    if (!roomId || !appId) return;

    const initAgora = async () => {
      console.log("Initializing Agora Student with App ID:", appId);
      agoraClient.current = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
      
      agoraClient.current.on("user-published", async (user, mediaType) => {
        console.log("Remote user published:", user.uid, mediaType);
        await agoraClient.current?.subscribe(user, mediaType);
        if (mediaType === "video" && remoteVideoRef.current) {
          user.videoTrack?.play(remoteVideoRef.current, { fit: "cover" });
          setIsRemoteVideoActive(true);
        }
        if (mediaType === "audio") {
          user.audioTrack?.play();
        }
      });

      agoraClient.current.on("user-unpublished", (user, mediaType) => {
        console.log("Remote user unpublished:", user.uid, mediaType);
        if (mediaType === "video") {
          user.videoTrack?.stop();
          setIsRemoteVideoActive(false);
        }
        if (mediaType === "audio") {
          user.audioTrack?.stop();
        }
      });

      try {
        console.log("Joining Agora channel:", roomId);
        await agoraClient.current.join(appId, roomId, null, user?.id || `student_${Math.random().toString(36).substring(7)}`);
      } catch (e) {
        console.error("Failed to join Agora channel", e);
        alert("Agora Join Error: " + (e instanceof Error ? e.message : String(e)));
      }
    };

    initAgora();

    return () => {
      localAudioTrack.current?.close();
      localVideoTrack.current?.close();
      agoraClient.current?.leave();
    };
  }, [roomId, appId, user?.id]);

  const toggleVideo = async () => {
    if (isVideoOffByAdmin) {
      alert("Admin has disabled video for all participants.");
      return;
    }
    if (isVideoMuted) {
      try {
        if (!localVideoTrack.current) {
          localVideoTrack.current = await AgoraRTC.createCameraVideoTrack();
        }
        await agoraClient.current?.publish(localVideoTrack.current);
        if (localVideoRef.current) {
          localVideoTrack.current.play(localVideoRef.current, { fit: "cover" });
        }
        setIsVideoMuted(false);
      } catch (err) {
        console.error("Error accessing camera:", err);
        alert("Could not access camera. Please check permissions.");
      }
    } else {
      if (localVideoTrack.current) {
        await agoraClient.current?.unpublish(localVideoTrack.current);
        localVideoTrack.current.stop();
      }
      setIsVideoMuted(true);
    }
  };

  const toggleAudio = async () => {
    if (isMutedByAdmin) {
      alert("Admin has muted all participants.");
      return;
    }
    if (isAudioMuted) {
      try {
        if (!localAudioTrack.current) {
          localAudioTrack.current = await AgoraRTC.createMicrophoneAudioTrack();
        }
        await agoraClient.current?.publish(localAudioTrack.current);
        setIsAudioMuted(false);
      } catch (err) {
        console.error("Error accessing microphone:", err);
        alert("Could not access microphone. Please check permissions.");
      }
    } else {
      if (localAudioTrack.current) {
        await agoraClient.current?.unpublish(localAudioTrack.current);
      }
      setIsAudioMuted(true);
    }
  };

  useEffect(() => {
    if (!roomId) return;

    // Real-time Chat
    const chatQuery = query(
      collection(db, 'live-chat-messages'),
      where('class_id', '==', roomId),
      orderBy('created_at', 'asc')
    );
    const unsubscribeChat = onSnapshot(chatQuery, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setMessages(msgs);
    });

    // Real-time Polls
    const pollsQuery = query(
      collection(db, 'live-polls'),
      where('class_id', '==', roomId)
    );
    const unsubscribePolls = onSnapshot(pollsQuery, (snapshot) => {
      const p = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setPolls(p);
    });

    // Real-time Reactions
    const reactionsQuery = query(
      collection(db, 'live-reactions'),
      where('class_id', '==', roomId)
    );
    const unsubscribeReactions = onSnapshot(reactionsQuery, (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === "added") {
          const reaction = { id: change.doc.id, ...change.doc.data() } as any;
          setReactions(prev => [...prev, { ...reaction, x: Math.random() * 80 + 10 }]);
          setTimeout(() => {
            setReactions(prev => prev.filter(r => r.id !== change.doc.id));
          }, 3000);
        }
      });
    });

    // Real-time Participants
    const participantsQuery = query(
      collection(db, 'live-participants'),
      where('class_id', '==', roomId)
    );
    const unsubscribeParticipants = onSnapshot(participantsQuery, (snapshot) => {
      const p = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setParticipants(p);
      setParticipantCount(p.length);
    });

    // Add self to participants
    const participantId = user?.id || `student_${Math.random().toString(36).substring(7)}`;
    const participantRef = doc(db, 'live-participants', participantId);
    setDoc(participantRef, {
      class_id: roomId,
      name: user?.name || 'Student',
      isMuted: isAudioMuted,
      isVideoOff: isVideoMuted,
      isHandRaised: isHandRaised,
      role: 'student',
      joined_at: serverTimestamp()
    });

    // Fetch class data immediately
    fetch(`/api/live-classes/${roomId}?t=${Date.now()}`, {
      headers: { Authorization: `Bearer ${token}` }
    }).then(res => res.json()).then(data => {
      setClassData(data);
    }).catch(e => console.error('Error fetching class data:', e));

    // Real-time Class State
    const unsubscribeClass = onSnapshot(doc(db, 'live_classes', roomId), (docSnap) => {
      if (docSnap.exists()) {
        const classData = docSnap.data();
        
        // Check if student is kicked
        if (classData.kicked_students?.includes(user?.id || 'student')) {
          alert('You have been removed from this class by the instructor.');
          navigate('/dashboard');
          return;
        }

        setIsMutedByAdmin(!!classData.is_muted_all);
        setIsVideoOffByAdmin(!!classData.is_video_off_all);
        
        if (classData.is_muted_all) setIsAudioMuted(true);
        if (classData.is_video_off_all) setIsVideoMuted(true);
      }
    });

    return () => {
      unsubscribeChat();
      unsubscribePolls();
      unsubscribeReactions();
      unsubscribeParticipants();
      unsubscribeClass();
      deleteDoc(participantRef);
    };
  }, [roomId, user?.id]);

  useEffect(() => {
    // Update participant state when local state changes
    if (!roomId) return;
    const participantId = user?.id || `student_${Math.random().toString(36).substring(7)}`;
    const participantRef = doc(db, 'live-participants', participantId);
    updateDoc(participantRef, {
      isMuted: isAudioMuted,
      isVideoOff: isVideoMuted,
      isHandRaised: isHandRaised
    }).catch(() => {});
  }, [isAudioMuted, isVideoMuted, isHandRaised, roomId, user?.id]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    try {
      await addDoc(collection(db, 'live-chat-messages'), {
        class_id: roomId,
        user_id: user?.id || 'student',
        user_name: user?.name || 'Student',
        content: newMessage,
        role: 'student',
        created_at: serverTimestamp()
      });
      setNewMessage('');
    } catch (error) {
      console.error('Failed to send message', error);
    }
  };

  const hangup = () => {
    navigate('/dashboard');
  };

  const sendReaction = async (emoji: string) => {
    try {
      await addDoc(collection(db, 'live-reactions'), {
        class_id: roomId,
        emoji,
        created_at: serverTimestamp()
      });
    } catch (error) {
      console.error('Failed to send reaction', error);
    }
  };

  const handleVote = async (pollId: string, optionIndex: number) => {
    try {
      const poll = polls.find(p => p.id === pollId);
      if (!poll) return;
      
      const newOptions = [...poll.options];
      newOptions[optionIndex].votes = (newOptions[optionIndex].votes || 0) + 1;
      
      await updateDoc(doc(db, 'live-polls', pollId), {
        options: newOptions
      });
      
      setPolls(prev => prev.map(p => p.id === pollId ? { ...p, options: newOptions, hasVoted: true } : p));
    } catch (error) {
      console.error('Failed to vote', error);
    }
  };

  const toggleFullScreen = () => {
    if (!videoContainerRef.current) return;

    if (!document.fullscreenElement) {
      videoContainerRef.current.requestFullscreen().catch(err => {
        console.error(`Error attempting to enable full-screen mode: ${err.message}`);
      });
      setIsFullScreen(true);
    } else {
      document.exitFullscreen();
      setIsFullScreen(false);
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullScreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  return (
    <div className="h-screen w-full bg-slate-950 flex flex-col overflow-hidden font-sans text-white">
      {/* Custom Header */}
      <header className="h-16 bg-slate-900 border-b border-white/10 flex items-center justify-between px-6 shrink-0 z-30">
        <div className="flex items-center gap-4">
          <div className="h-10 w-10 bg-gradient-to-br from-orange-500 to-rose-500 rounded-xl flex items-center justify-center shadow-lg shadow-orange-500/20">
            <Radio className="h-5 w-5 text-white" />
          </div>
          <div>
            <h1 className="text-white font-black text-sm uppercase tracking-widest leading-tight">Jaber Math Care Live</h1>
            <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest">
              <span className="flex items-center gap-1 text-emerald-400 bg-emerald-400/10 px-2 py-0.5 rounded-full">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Live
              </span>
              <span className="text-slate-500">Studio: {roomId}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-slate-800 px-3 py-1.5 rounded-lg border border-white/5">
            <Users className="h-4 w-4 text-slate-400" />
            <span className="text-white font-bold text-xs">{participantCount}</span>
          </div>
          <div className="h-8 w-8 rounded-full bg-orange-600 flex items-center justify-center text-white font-bold text-xs border-2 border-slate-900 ring-2 ring-orange-500/50">
            {user?.name?.charAt(0) || 'U'}
          </div>
        </div>
      </header>

      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        {/* Main Video Area */}
        <main className="flex-1 relative bg-black flex flex-col min-w-0" ref={videoContainerRef}>
          <div className="flex-1 relative group">
            {/* Jitsi Meeting or Simulated Video Player */}
            <div className="absolute inset-0 bg-slate-950 flex items-center justify-center">
              {/* Floating Reactions Layer */}
              <div className="absolute inset-0 pointer-events-none z-40">
                <AnimatePresence>
                  {reactions.map(r => (
                    <motion.div
                      key={r.id}
                      initial={{ y: '100%', opacity: 0, x: `${r.x}%` }}
                      animate={{ y: '-20%', opacity: [0, 1, 1, 0] }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 3, ease: "easeOut" }}
                      className="absolute text-4xl"
                    >
                      {r.emoji}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {isVideoOffByAdmin ? (
                <div className="flex flex-col items-center gap-6">
                  <div className="w-24 h-24 bg-slate-900 rounded-full flex items-center justify-center border border-white/10 shadow-2xl">
                    <VideoOff className="h-10 w-10 text-slate-500" />
                  </div>
                  <div className="text-center">
                    <h2 className="text-xl font-black uppercase tracking-widest mb-2 text-white">Instructor Camera Off</h2>
                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em]">The host has disabled video for everyone</p>
                  </div>
                </div>
              ) : (
                <div className="w-full h-full relative overflow-hidden group">
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-slate-950/40 z-10 pointer-events-none" />
                  
                  {/* Agora Remote Video Container */}
                  <div 
                    ref={remoteVideoRef} 
                    className="w-full h-full object-cover bg-slate-900"
                  />
                  
                  {/* Local Video Stream (Picture-in-Picture) */}
                  <AnimatePresence>
                    {!isVideoMuted && (
                      <motion.div 
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.8 }}
                        className="absolute top-4 right-4 w-32 h-48 md:w-48 md:h-64 bg-slate-800 rounded-2xl overflow-hidden border-2 border-white/10 shadow-2xl z-20"
                      >
                        <div 
                          ref={localVideoRef}
                          className="w-full h-full object-cover"
                        />
                        <div className="absolute bottom-2 left-2 bg-black/50 px-2 py-1 rounded text-[10px] font-bold text-white">
                          You
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Join Overlay */}
                  {!isRemoteVideoActive && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center z-20">
                    <motion.div 
                      initial={{ scale: 0.9, opacity: 0 }}
                      animate={{ scale: 1, opacity: 1 }}
                      className="w-24 h-24 bg-orange-600/20 rounded-[2.5rem] flex items-center justify-center mb-8 border border-orange-500/30 shadow-2xl backdrop-blur-xl"
                    >
                      <RadioTower className="h-10 w-10 text-orange-500 animate-pulse" />
                    </motion.div>
                    
                    <h2 className="text-4xl font-black uppercase tracking-tight mb-4 text-white drop-shadow-2xl">
                      {classData?.title || 'Live Session'}
                    </h2>
                    <p className="text-slate-300 text-sm font-bold mb-10 max-w-md leading-relaxed uppercase tracking-widest opacity-80">
                      Broadcasting Live from {classData?.coaching_name || 'Jaber Math Care'}
                    </p>
                    
                    <div className="flex flex-col sm:flex-row gap-4 w-full justify-center max-w-md">
                      {classData?.zoom_link ? (
                        <>
                          <a 
                            href={classData.zoom_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex-1 bg-orange-600 hover:bg-orange-700 text-white px-8 py-5 rounded-[2rem] font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-3 transition-all shadow-2xl shadow-orange-900/40 hover:scale-105 active:scale-95 group"
                          >
                            <ExternalLink className="h-4 w-4 group-hover:rotate-12 transition-transform" />
                            Join in App
                          </a>
                          {classData.zoom_link.includes('zoom.us') && (
                            <button 
                              onClick={() => navigate(`/dashboard/zoom/${roomId}`)}
                              className="flex-1 bg-white/10 hover:bg-white/20 text-white px-8 py-5 rounded-[2rem] font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-3 transition-all backdrop-blur-xl border border-white/10 hover:scale-105 active:scale-95"
                            >
                              <MonitorPlay className="h-4 w-4" />
                              Join in Web
                            </button>
                          )}
                        </>
                      ) : (
                        <div className="bg-white/5 px-8 py-5 rounded-[2rem] border border-white/10 text-slate-500 font-bold uppercase tracking-widest text-[10px]">
                          Waiting for link...
                        </div>
                      )}
                    </div>

                    {/* Instructor Info Floating */}
                    <div className="absolute bottom-12 left-12 flex items-center gap-5 bg-white/5 p-4 rounded-3xl backdrop-blur-2xl border border-white/10">
                      <div className="w-14 h-14 rounded-2xl bg-orange-600 flex items-center justify-center shadow-2xl border border-white/20">
                        <Users className="h-7 w-7 text-white" />
                      </div>
                      <div className="text-left">
                        <h3 className="text-sm font-black uppercase tracking-widest text-white">Instructor</h3>
                        <p className="text-[10px] text-orange-500 font-black uppercase tracking-[0.2em] animate-pulse">Broadcasting Live</p>
                      </div>
                    </div>
                    </div>
                  )}

                  {/* Video Controls Overlay (Simulated) */}
                  <div className="absolute bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-30 pointer-events-none">
                    <div className="flex items-center justify-between pointer-events-auto">
                      <div className="flex items-center gap-6">
                        <button className="text-white/80 hover:text-white transition-colors">
                          <PlayCircle className="h-8 w-8" />
                        </button>
                        <div className="h-1 w-48 bg-white/20 rounded-full overflow-hidden">
                          <div className="h-full w-1/3 bg-orange-600" />
                        </div>
                        <span className="text-white/60 text-[10px] font-black uppercase tracking-widest">Live</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <button onClick={toggleFullScreen} className="text-white/80 hover:text-white transition-colors">
                          <Maximize className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Player Controls Overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-40 pointer-events-none">
              <div className="flex items-center justify-between pointer-events-auto">
                <div className="flex items-center gap-4">
                  <button onClick={() => setIsPlaying(!isPlaying)} className="text-white hover:text-orange-500 transition-colors">
                    {isPlaying ? <Pause className="h-6 w-6" /> : <Play className="h-6 w-6" />}
                  </button>
                  <button onClick={() => setIsVolumeMuted(!isVolumeMuted)} className="text-white hover:text-orange-500 transition-colors">
                    {isVolumeMuted ? <VolumeX className="h-6 w-6" /> : <Volume2 className="h-6 w-6" />}
                  </button>
                  <div className="text-xs font-mono text-white/80">Live • 00:42:15</div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-white/60">
                    <Activity className="h-3 w-3 text-emerald-500" />
                    1080p HD
                  </div>
                  <button onClick={toggleFullScreen} className="text-white hover:text-orange-500 transition-colors">
                    {isFullScreen ? <Minimize className="h-5 w-5" /> : <Maximize className="h-5 w-5" />}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Student Controls Bar */}
          <footer className="h-20 bg-slate-900 border-t border-white/10 flex items-center justify-center gap-1.5 md:gap-3 px-2 md:px-6 shrink-0 z-50 overflow-x-auto scrollbar-hide">
            <div className="relative group">
              <button 
                onClick={toggleAudio}
                disabled={isMutedByAdmin}
                className={`h-10 w-10 md:h-12 md:w-12 rounded-xl md:rounded-2xl flex items-center justify-center transition-all duration-300 ${
                  isAudioMuted 
                    ? 'bg-rose-500/10 text-rose-500 hover:bg-rose-500/20' 
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                } ${isMutedByAdmin ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {isAudioMuted ? <MicOff className="h-4 w-4 md:h-5 md:w-5" /> : <Mic className="h-4 w-4 md:h-5 md:w-5" />}
              </button>
              {isMutedByAdmin && (
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1 bg-red-600 text-white text-[8px] font-black uppercase tracking-widest rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                  Muted by Admin
                </div>
              )}
            </div>

            <div className="relative group">
              <button 
                onClick={toggleVideo}
                disabled={isVideoOffByAdmin}
                className={`h-10 w-10 md:h-12 md:w-12 rounded-xl md:rounded-2xl flex items-center justify-center transition-all duration-300 ${
                  isVideoMuted 
                    ? 'bg-rose-500/10 text-rose-500 hover:bg-rose-500/20' 
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
                } ${isVideoOffByAdmin ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {isVideoMuted ? <VideoOff className="h-4 w-4 md:h-5 md:w-5" /> : <Video className="h-4 w-4 md:h-5 md:w-5" />}
              </button>
              {isVideoOffByAdmin && (
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-1 bg-red-600 text-white text-[8px] font-black uppercase tracking-widest rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                  Video Disabled by Admin
                </div>
              )}
            </div>

            <div className="w-px h-8 bg-white/10 mx-2"></div>

            <button 
              onClick={() => setIsHandRaised(!isHandRaised)}
              className={`h-10 w-10 md:h-12 md:w-12 rounded-xl md:rounded-2xl flex items-center justify-center transition-all duration-300 ${
                isHandRaised
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
            >
              <Hand className="h-4 w-4 md:h-5 md:w-5" />
            </button>

            <button 
              onClick={() => setIsChatOpen(!isChatOpen)}
              className={`h-10 w-10 md:h-12 md:w-12 rounded-xl md:rounded-2xl flex items-center justify-center transition-all duration-300 ${
                isChatOpen
                  ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
            >
              <MessageSquare className="h-4 w-4 md:h-5 md:w-5" />
            </button>

            <button 
              onClick={() => setIsParticipantsOpen(!isParticipantsOpen)}
              className={`h-10 w-10 md:h-12 md:w-12 rounded-xl md:rounded-2xl flex items-center justify-center transition-all duration-300 ${
                isParticipantsOpen
                  ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
            >
              <Users className="h-4 w-4 md:h-5 md:w-5" />
            </button>

            <button 
              onClick={() => setIsPollsOpen(!isPollsOpen)}
              className={`h-10 w-10 md:h-12 md:w-12 rounded-xl md:rounded-2xl flex items-center justify-center transition-all duration-300 ${
                isPollsOpen
                  ? 'bg-purple-500/20 text-purple-400 border border-purple-500/30'
                  : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
              }`}
            >
              <BarChart2 className="h-4 w-4 md:h-5 md:w-5" />
            </button>

            <div className="w-px h-8 bg-white/10 mx-2"></div>

            <button 
              onClick={hangup}
              className="h-10 md:h-12 px-3 md:px-6 rounded-xl md:rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-black uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-rose-600/20 transition-all duration-300 hover:scale-105 text-[10px] md:text-xs"
            >
              <PhoneOff className="h-3 w-3 md:h-4 md:w-4" />
              <span className="hidden sm:inline">Leave Class</span>
              <span className="sm:hidden">Leave</span>
            </button>
          </footer>
        </main>

        {/* Reactions Layer */}
        <div className="absolute inset-0 pointer-events-none z-40">
          <AnimatePresence>
            {reactions.map(r => (
              <motion.div
                key={r.id}
                initial={{ y: '100%', opacity: 0, x: `${r.x}%` }}
                animate={{ y: '-20%', opacity: [0, 1, 1, 0] }}
                exit={{ opacity: 0 }}
                transition={{ duration: 3, ease: "easeOut" }}
                className="absolute text-4xl"
              >
                {r.emoji}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {/* Reaction Bar */}
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 flex gap-2 bg-slate-900/80 backdrop-blur-xl p-2 rounded-2xl border border-white/10 z-50 md:opacity-0 md:hover:opacity-100 transition-opacity">
          {['❤️', '👏', '🔥', '😂', '😮', '🎉'].map(emoji => (
            <button
              key={emoji}
              onClick={() => sendReaction(emoji)}
              className="w-10 h-10 flex items-center justify-center hover:bg-white/10 rounded-xl transition-colors text-xl"
            >
              {emoji}
            </button>
          ))}
        </div>

        {/* Chat Sidebar */}
        <AnimatePresence>
          {isChatOpen && (
            <motion.aside 
              initial={{ x: '100%', opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: '100%', opacity: 0 }}
              className="fixed md:relative right-0 top-0 bottom-0 w-full md:w-96 bg-slate-900 border-l border-white/10 flex flex-col shadow-2xl z-[60] md:z-20"
            >
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-orange-500/10 p-2 rounded-lg">
                    <MessageSquare className="h-5 w-5 text-orange-500" />
                  </div>
                  <h2 className="font-black text-sm uppercase tracking-widest">Live Chat</h2>
                </div>
                <button onClick={() => setIsChatOpen(false)} className="p-1 hover:bg-white/5 rounded-lg text-slate-500">
                  <X className="h-4 w-4" />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-hide">
                {messages.map((msg, i) => (
                  <div key={i} className={`flex flex-col ${msg.role === 'admin' ? 'items-start' : 'items-end'}`}>
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-[10px] font-black uppercase tracking-widest ${msg.role === 'admin' ? 'text-orange-500' : 'text-slate-400'}`}>
                        {msg.user_name}
                      </span>
                      <span className="text-[8px] text-slate-600">
                        {msg.created_at ? new Date(msg.created_at?.toDate ? msg.created_at.toDate() : msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '...'}
                      </span>
                    </div>
                    <div className={`px-4 py-2.5 rounded-2xl text-sm font-medium ${
                      msg.role === 'admin' ? 'bg-slate-800 text-slate-200 rounded-tl-sm' : 'bg-orange-600 text-white rounded-tr-sm'
                    }`}>
                      {msg.content}
                    </div>
                  </div>
                ))}
                <div ref={chatEndRef} />
              </div>

              <form onSubmit={handleSendMessage} className="p-6 border-t border-white/5 bg-slate-900/50">
                <div className="relative">
                  <input 
                    type="text"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder="Type a message..."
                    className="w-full bg-slate-950 border border-white/10 rounded-2xl pl-4 pr-12 py-4 text-sm focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                  />
                  <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-orange-500 hover:text-orange-400">
                    <Send className="h-5 w-5" />
                  </button>
                </div>
              </form>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Participants Sidebar */}
        <AnimatePresence>
          {isParticipantsOpen && (
            <motion.aside 
              initial={{ x: '100%', opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: '100%', opacity: 0 }}
              className="fixed md:relative right-0 top-0 bottom-0 w-full md:w-80 bg-slate-900 border-l border-white/10 flex flex-col shadow-2xl z-[60] md:z-20"
            >
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-emerald-500/10 p-2 rounded-lg">
                    <Users className="h-5 w-5 text-emerald-500" />
                  </div>
                  <h2 className="font-black text-sm uppercase tracking-widest">Participants</h2>
                </div>
                <button onClick={() => setIsParticipantsOpen(false)} className="p-1 hover:bg-white/5 rounded-lg text-slate-500">
                  <X className="h-4 w-4" />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 space-y-2">
                {participants.map(p => (
                  <div key={p.id} className="flex items-center justify-between p-3 bg-slate-800/50 rounded-xl border border-white/5">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center text-[10px] font-bold ${p.role === 'admin' ? 'bg-orange-600' : 'bg-slate-700'}`}>
                        {p.name.charAt(0)}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold whitespace-nowrap">{p.name}</span>
                        {p.role === 'admin' && <span className="text-[8px] text-orange-500 font-black uppercase bg-orange-500/10 px-1.5 py-0.5 rounded">Host</span>}
                        {p.isHandRaised && <span className="text-[8px] text-amber-500 font-black uppercase bg-amber-500/10 px-1.5 py-0.5 rounded">Hand</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {p.isMuted ? <MicOff className="h-3 w-3 text-rose-500" /> : <Mic className="h-3 w-3 text-slate-500" />}
                      {p.isVideoOff ? <VideoOff className="h-3 w-3 text-rose-500" /> : <Video className="h-3 w-3 text-slate-500" />}
                    </div>
                  </div>
                ))}
              </div>
            </motion.aside>
          )}
        </AnimatePresence>

        {/* Polls Sidebar */}
        <AnimatePresence>
          {isPollsOpen && (
            <motion.aside 
              initial={{ x: '100%', opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: '100%', opacity: 0 }}
              className="fixed md:relative right-0 top-0 bottom-0 w-full md:w-80 bg-slate-900 border-l border-white/10 flex flex-col shadow-2xl z-[60] md:z-20"
            >
              <div className="p-6 border-b border-white/5 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="bg-purple-500/10 p-2 rounded-lg">
                    <BarChart2 className="h-5 w-5 text-purple-500" />
                  </div>
                  <h2 className="font-black text-sm uppercase tracking-widest">Live Polls</h2>
                </div>
                <button onClick={() => setIsPollsOpen(false)} className="p-1 hover:bg-white/5 rounded-lg text-slate-500">
                  <X className="h-4 w-4" />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                {polls.length === 0 ? (
                  <div className="text-center py-12">
                    <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mx-auto mb-4">
                      <BarChart2 className="h-6 w-6 text-slate-600" />
                    </div>
                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">No active polls</p>
                  </div>
                ) : (
                  polls.map(poll => (
                    <div key={poll.id} className="bg-slate-800/50 rounded-2xl p-4 border border-white/5">
                      <h3 className="text-sm font-bold mb-4">{poll.question}</h3>
                      <div className="space-y-3">
                        {poll.options.map((opt: any, idx: number) => {
                          const totalVotes = poll.options.reduce((acc: number, o: any) => acc + (o.votes || 0), 0);
                          const percentage = totalVotes > 0 ? Math.round(((opt.votes || 0) / totalVotes) * 100) : 0;
                          
                          return (
                            <button
                              key={idx}
                              onClick={() => !poll.hasVoted && handleVote(poll.id, idx)}
                              disabled={poll.hasVoted}
                              className="w-full relative group overflow-hidden"
                            >
                              <div className="relative z-10 flex items-center justify-between p-3 text-xs font-bold">
                                <span>{opt.text}</span>
                                <span>{percentage}%</span>
                              </div>
                              <div 
                                className="absolute inset-0 bg-orange-600/20 transition-all duration-500"
                                style={{ width: `${percentage}%` }}
                              />
                              <div className="absolute inset-0 border border-white/10 rounded-xl group-hover:border-orange-500/50 transition-colors" />
                            </button>
                          );
                        })}
                      </div>
                      <p className="mt-4 text-[8px] text-slate-500 font-black uppercase tracking-widest">
                        {poll.options.reduce((acc: number, o: any) => acc + (o.votes || 0), 0)} Total Votes
                      </p>
                    </div>
                  ))
                )}
              </div>
            </motion.aside>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
