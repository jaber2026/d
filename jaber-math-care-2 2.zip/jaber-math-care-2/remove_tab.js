import fs from 'fs';
import path from 'path';

const filePath = path.join(process.cwd(), 'src/pages/AdminDashboard.tsx');
let content = fs.readFileSync(filePath, 'utf8');

const startStr = '{/* Student Recorded Classes Tab */}';
const endStr = '{activeTab === "notices"';

const startIndex = content.indexOf(startStr);
const endIndex = content.indexOf(endStr, startIndex);

if (startIndex !== -1 && endIndex !== -1) {
  content = content.slice(0, startIndex) + content.slice(endIndex);
  fs.writeFileSync(filePath, content);
  console.log('Removed tab content successfully');
} else {
  console.log('Could not find tab content bounds');
}
