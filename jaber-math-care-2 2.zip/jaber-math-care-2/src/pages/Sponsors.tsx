import React, { useEffect, useRef } from 'react';
import { useRealtimeCollection } from '../hooks/useRealtime';
import { where, orderBy } from 'firebase/firestore';
import { motion } from 'motion/react';
import { ArrowLeft, ExternalLink, Globe, Heart, ShieldCheck, Sparkles, Star } from 'lucide-react';
import { Link } from 'react-router-dom';
import LoadingSpinner from '../components/LoadingSpinner';

const CompactHTMLAdRenderer = ({ htmlCode }: { htmlCode: string }) => {
  const iframeRef = useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (iframeRef.current && htmlCode) {
      const doc = iframeRef.current.contentDocument || iframeRef.current.contentWindow?.document;
      if (doc) {
        doc.open();
        doc.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="utf-8">
              <style>
                body {
                  margin: 0;
                  padding: 0;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  background-color: transparent;
                  overflow: hidden;
                }
              </style>
            </head>
            <body>
              ${htmlCode}
            </body>
          </html>
        `);
        doc.close();
      }
    }
  }, [htmlCode]);

  return (
    <div className="w-full h-full flex justify-center items-center">
      <iframe
        ref={iframeRef}
        title="Sponsor Banner ad"
        className="w-full h-[90px] border-0"
        style={{ width: "100%", height: "100%", border: "none" }}
        sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-same-origin"
      />
    </div>
  );
};

const Sponsors = () => {
  const { data: sponsors, loading } = useRealtimeCollection('sponsorships', [
    where('status', '==', 'active'),
    orderBy('order_index', 'asc')
  ]);

  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-20 overflow-hidden relative">
      {/* Background elements */}
      <div className="absolute top-0 left-0 w-full h-96 bg-gradient-to-b from-orange-50 to-transparent pointer-events-none" />
      <div className="absolute top-40 -left-20 w-80 h-80 bg-orange-100 rounded-full blur-[100px] opacity-40 pointer-events-none" />
      <div className="absolute bottom-20 -right-20 w-80 h-80 bg-rose-100 rounded-full blur-[100px] opacity-40 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="text-center mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-100 text-orange-600 rounded-full text-[10px] font-black uppercase tracking-widest mb-2">
            <Heart className="h-3.5 w-3.5 fill-current" /> Our Pride
          </div>
          <h1 className="text-4xl md:text-5xl font-black text-orange-600 tracking-tighter uppercase mb-2">OUR SPONSORS</h1>
          <p className="text-slate-400 font-bold max-w-xl mx-auto uppercase tracking-widest text-[10px]">Honoring the brands that support the future of mathematics excellence</p>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <LoadingSpinner />
          </div>
        ) : sponsors.length === 0 ? (
          <div className="glass p-16 rounded-[4rem] text-center border-white bg-white/40 shadow-2xl max-w-2xl mx-auto border-2">
             <Star className="h-12 w-12 text-slate-200 mx-auto mb-4" />
             <p className="text-slate-400 font-black uppercase tracking-widest text-xs">No active sponsors at this moment.</p>
             <Link to="/sponsorship" className="inline-block mt-6 px-6 py-3 bg-orange-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl hover:bg-orange-700 transition-all">
               Become Our First Sponsor
             </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {sponsors.map((sponsor, i) => {
              const isAdsterra = ((sponsor.brand_name || '').toLowerCase().includes('adsterra')) || 
                                 ((sponsor.html_code || '').toLowerCase().includes('adsterra')) ||
                                 ((sponsor.image_url || '').toLowerCase().includes('adsterra'));

              return (
                <motion.div
                  key={sponsor.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  whileHover={{ y: -10 }}
                  className="glass rounded-[3rem] overflow-hidden flex flex-col group border-white shadow-2xl bg-white/40 backdrop-blur-3xl h-full border-2 transition-all duration-500"
                >
                  <div className={`p-8 flex flex-col items-center flex-1 ${isAdsterra ? 'justify-center' : ''}`}>
                     <div className={`w-full ${isAdsterra ? 'h-full flex-1' : 'h-48 mb-8'} bg-white/60 rounded-[2.5rem] border border-white p-6 flex items-center justify-center shadow-inner overflow-hidden relative group-hover:bg-white transition-colors duration-500`}>
                       <div className="absolute inset-0 bg-gradient-to-tr from-orange-500/5 to-rose-500/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                       {sponsor.banner_type === 'html' && sponsor.html_code ? (
                         <div className="w-full h-full flex items-center justify-center z-10"><CompactHTMLAdRenderer htmlCode={sponsor.html_code} /></div>
                       ) : sponsor.image_url ? (
                         <img 
                           src={sponsor.image_url} 
                           alt={sponsor.brand_name} 
                           className="max-h-full max-w-full object-contain group-hover:scale-105 transition-transform duration-700 z-10" 
                           referrerPolicy="no-referrer"
                         />
                       ) : (
                         <Globe className="h-16 w-16 text-orange-200 z-10" />
                       )}
                     </div>
                     
                     {!isAdsterra && (
                       <div className="text-center space-y-4 w-full flex-1 flex flex-col pt-4">
                          <div className="space-y-1">
                            <div className="flex items-center justify-center gap-2 mb-1">
                              <ShieldCheck className="h-4 w-4 text-emerald-500" />
                              <span className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-600">Official Partner</span>
                            </div>
                            <h3 className="text-2xl font-black text-slate-900 tracking-tight group-hover:text-orange-600 transition-colors">{sponsor.brand_name}</h3>
                          </div>
                          
                          {sponsor.details && (
                            <div className="bg-white/40 p-5 rounded-[2rem] border border-white/60 group-hover:bg-white/80 transition-colors flex-1 mt-4">
                              <p className="text-[11px] text-slate-500 font-bold leading-relaxed line-clamp-4">
                                {sponsor.details}
                              </p>
                            </div>
                          )}
                          
                          {sponsor.contact_email && (
                            <div className="pt-4 mt-auto">
                               <div className="flex items-center justify-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                 {sponsor.contact_email}
                               </div>
                            </div>
                          )}
                       </div>
                     )}
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}

        {/* Call to action */}
        <div className="mt-20 text-center">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            className="glass p-8 md:p-12 rounded-[4rem] border-white bg-gradient-to-br from-orange-600 to-orange-500 text-white shadow-2xl relative overflow-hidden inline-block w-full max-w-4xl"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8">
              <div className="text-center md:text-left space-y-2">
                <h3 className="text-2xl md:text-3xl font-black tracking-tight">Want to be featured here?</h3>
                <p className="text-orange-100 font-bold uppercase tracking-widest text-xs">Join our ecosystem as a supporting partner</p>
              </div>
              <Link 
                to="/sponsorship" 
                className="px-8 py-4 bg-white text-orange-600 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl hover:bg-orange-50 transition-all active:scale-95 whitespace-nowrap flex items-center gap-3 group"
              >
                Explore Pricing <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </motion.div>
        </div>

        {/* Back to Home Moved to Bottom */}
        <div className="text-center mt-20">
          <Link to="/" className="inline-flex items-center gap-2 px-8 py-3 bg-orange-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-orange-700 hover:-translate-y-1 transition-all shadow-xl">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Home Page
          </Link>
        </div>
      </div>
    </div>
  );
};

const ArrowRight = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" className={className}><path d="M5 12h14m-7-7 7 7-7 7"/></svg>
);

export default Sponsors;
