import nodemailer from "nodemailer";

export const sendSmtpEmail = async (options: any) => {
  try {
    const toEmail = options.to;
    if (toEmail && typeof toEmail === 'string') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(toEmail)) {
        console.log(`[sendSmtpEmail] Skipping invalid email address: ${toEmail}`);
        return { success: false, error: "Invalid email format" };
      }
    }

    const db = options.db;
    let gatewayType = options.email_gateway_type;
    let settings: any = {};

    // Load configurations from firestore if DB is provided
    if (db) {
      try {
        const settingsSnap = await db.collection("settings").get();
        settingsSnap.forEach((doc: any) => {
          settings[doc.id] = doc.data().value;
        });
      } catch (err: any) {
        console.error("Error loading email settings from firestore:", err);
      }
    }

    if (!gatewayType) {
      gatewayType = settings.email_gateway_type || "smtp";
    }

    if (gatewayType === "emailjs") {
      const serviceId = options.emailjs_service_id || settings.emailjs_service_id;
      const templateId = options.emailjs_template_id || settings.emailjs_template_id;
      const publicKey = options.emailjs_public_key || settings.emailjs_public_key;
      const privateKey = options.emailjs_private_key || settings.emailjs_private_key;

      if (!serviceId || !templateId || !publicKey) {
        return { 
          success: false, 
          error: "EmailJS parameters are incomplete. Please set them in admin settings." 
        };
      }

      // Send to EmailJS REST Endpoint
      const response = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          service_id: serviceId,
          template_id: templateId,
          user_id: publicKey,
          accessToken: privateKey,
          template_params: {
            to_email: options.to,
            bcc: options.bcc || "",
            subject: options.subject,
            message: options.html,
            html_message: options.html,
            html: options.html
          }
        })
      });

      if (!response.ok) {
        const errText = await response.text();
        return { 
          success: false, 
          error: `EmailJS API error: ${response.status} - ${errText}` 
        };
      }

      return { success: true, error: null };
    } else {
      // SMTP Implementation
      const smtp_email = options.smtp_email || settings.smtp_email;
      const smtp_password = options.smtp_password || settings.smtp_password;
      const smtp_host = options.smtp_host || settings.smtp_host || "smtp.gmail.com";
      const smtp_port = Number(options.smtp_port || settings.smtp_port || 465);
      const smtp_secure = options.smtp_secure !== undefined 
        ? (options.smtp_secure === "true" || options.smtp_secure === true) 
        : (settings.smtp_secure !== undefined ? (settings.smtp_secure === "true" || settings.smtp_secure === true) : (smtp_port === 465));

      if (!smtp_email || !smtp_password) {
        return { 
          success: false, 
          error: "SMTP Email or Password is not set. Please configure them in admin settings." 
        };
      }

      const transporter = nodemailer.createTransport({
        host: smtp_host,
        port: smtp_port,
        secure: smtp_secure,
        auth: {
          user: smtp_email,
          pass: smtp_password,
        },
        tls: {
          rejectUnauthorized: false
        }
      });

      const mailOptions: any = {
        from: `"Jaber Math Care" <${smtp_email}>`,
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.html ? options.html.replace(/<[^>]*>?/gm, '') : '',
        replyTo: smtp_email,
        headers: {
          'X-Priority': '3',
          'X-Mailer': 'Nodemailer/JaberMathCare',
        }
      };

      if (options.bcc) {
        mailOptions.bcc = options.bcc;
      }

      const info = await transporter.sendMail(mailOptions);
      console.log("Email sent successfully via SMTP:", info.messageId);
      return { success: true, error: null };
    }
  } catch (error: any) {
    console.error("Error in sendSmtpEmail helper:", error);
    return { success: false, error: error.message || String(error) };
  }
};

export const sendAutosms = async (phone: string, message: string, db: any) => {
  try {
    if (!phone) return { success: false, error: "Phone number is required." };
    if (!message) return { success: false, error: "SMS message is required." };

    let cleanPhone = phone.trim();
    let digits = cleanPhone.replace(/[^\d]/g, '');

    if (digits.startsWith('880') && digits.length === 13) {
      cleanPhone = digits;
    } else if (digits.startsWith('0') && digits.length === 11) {
      cleanPhone = '88' + digits;
    } else if (digits.startsWith('1') && digits.length === 10) {
      cleanPhone = '880' + digits;
    } else if (digits.length === 11 && digits.startsWith('01')) {
      cleanPhone = '88' + digits;
    } else {
      console.log(`[sendAutosms] Skipping invalid phone number format: ${digits}`);
      return { success: false, error: "Invalid phone format" };
    }

    let settings: any = {};
    if (db) {
      const settingsSnap = await db.collection("settings").get();
      settingsSnap.forEach((doc: any) => {
        settings[doc.id] = doc.data().value;
      });
    }

    const apiUrltemp = settings.sms_api_url || "";
    let apiUrl = "https://api.sms.net.bd/sendsms";
    let apiKey = settings.sms_api_key || "zP8kOgQerj1oqFC6Bl7mmX0G173r28cVmINkOVg7";
    let senderId = settings.sms_sender_id || "";

    if (apiUrltemp && apiUrltemp.trim()) {
      apiUrl = apiUrltemp.trim();
    }

    const lowerUrl = apiUrl.toLowerCase();
    let method = 'POST';
    let contentType = 'application/x-www-form-urlencoded';
    const params = new URLSearchParams();

    // Determine unicode vs text
    const hasBangla = /[অ-ঞত-নপ-ময-রলশ-হড়ঢ়য়ৎংঃঁািীুূৃেৈোৌ্ৗ]/.test(message);
    const typeVal = hasBangla ? 'unicode' : 'text';

    if (lowerUrl.includes("sms.net.bd")) {
      method = 'POST';
      contentType = 'application/x-www-form-urlencoded';
      params.append('api_key', apiKey);
      params.append('msg', message);
      params.append('to', cleanPhone);
      if (senderId) params.append('sender_id', senderId);
    } else if (lowerUrl.includes("greenweb")) {
      method = 'GET';
      params.append('token', apiKey);
      params.append('to', cleanPhone);
      params.append('message', message);
    } else if (lowerUrl.includes("elitbuzz") || lowerUrl.includes("elitebuzz")) {
      method = 'GET';
      params.append('api_key', apiKey);
      params.append('contacts', cleanPhone);
      params.append('msg', message);
      params.append('senderid', senderId);
      params.append('type', typeVal);
    } else if (lowerUrl.includes("mimsms") || lowerUrl.includes("mim")) {
      method = 'GET';
      params.append('api_key', apiKey);
      params.append('contacts', cleanPhone);
      params.append('msg', message);
      params.append('senderid', senderId);
      params.append('type', typeVal);
    } else if (lowerUrl.includes("bulksmsbd")) {
      method = 'GET';
      params.append('api_key', apiKey);
      params.append('number', cleanPhone);
      params.append('message', message);
      params.append('senderid', senderId);
      params.append('type', typeVal);
    } else {
      // UNIVERSAL fallback pattern supporting both GET and POST with all potential keys
      method = 'GET';
      params.append('api_key', apiKey);
      params.append('apiKey', apiKey);
      params.append('token', apiKey);
      params.append('api_token', apiKey);

      params.append('to', cleanPhone);
      params.append('number', cleanPhone);
      params.append('contacts', cleanPhone);
      params.append('mobile', cleanPhone);

      params.append('msg', message);
      params.append('message', message);
      params.append('text', message);

      if (senderId) {
        params.append('sender_id', senderId);
        params.append('senderid', senderId);
        params.append('senderId', senderId);
      }
      params.append('type', typeVal);
    }

    let responseText = "";
    if (method === 'POST') {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': contentType
        },
        body: params
      });
      responseText = await response.text();
    } else {
      // Build dynamic URL with params
      const urlObj = new URL(apiUrl);
      params.forEach((val, key) => {
        urlObj.searchParams.set(key, val);
      });
      const response = await fetch(urlObj.toString());
      responseText = await response.text();
    }

    console.log(`[sendAutosms Universal] Gateway Response: ${responseText}`);
    return { success: true, response: responseText };
  } catch (error: any) {
    console.error("Error in sendAutosms:", error);
    return { success: false, error: error.message || String(error) };
  }
};
