import * as fs from 'fs';

function diffFiles(file1: string, file2: string) {
  const c1 = fs.readFileSync(file1, 'utf-8').split('\n');
  const c2 = fs.readFileSync(file2, 'utf-8').split('\n');
  console.log(`--- ${file1}`);
  console.log(`+++ ${file2}`);
  const max = Math.max(c1.length, c2.length);
  for (let i = 0; i < max; i++) {
    if (c1[i] !== c2[i]) {
      console.log(`L${i+1}`);
      console.log(`  Orig: ${c1[i] || '<EOF>'}`);
      console.log(`  Ext:  ${c2[i] || '<EOF>'}`);
    }
  }
}

const args = process.argv.slice(2);
if (args.length === 2) {
  diffFiles(args[0], args[1]);
} else {
  console.log('Provide two file paths');
}
