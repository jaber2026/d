import React, { useState, useEffect } from 'react';
import { db } from '../firebase';
import { collection, query, where, onSnapshot, addDoc, orderBy } from 'firebase/firestore';
import { motion, AnimatePresence } from 'motion/react';
import { Check, ArrowLeft, Send, Zap, Trophy, Crown, X, Sparkles, Heart, ArrowRight } from 'lucide-react';
import { Link, useSearchParams } from 'react-router-dom';
import LoadingSpinner from '../components/LoadingSpinner';
import { showAlert } from '../utils/alert';

interface PricingPlan {
  id: string;
  title: string;
  price: string;
  duration: string;
  features: string[];
  is_active: boolean;
  order: number;
}

const Sponsorship = () => {
  const [plans, setPlans] = useState<PricingPlan[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<PricingPlan | null>(null);
  const [searchParams] = useSearchParams();

  // Form states
  const [brandName, setBrandName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [duration, setDuration] = useState('');
  const [budget, setBudget] = useState('');
  const [bannerType, setBannerType] = useState('Sidebar Banner');
  const [details, setDetails] = useState('');
  const [brandImage, setBrandImage] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('bKash');
  const [senderNumber, setSenderNumber] = useState('');
  const [transactionId, setTransactionId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [settings, setSettings] = useState<any>({});

  // Scroll Lock effect
  useEffect(() => {
    if (showForm) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [showForm]);

  useEffect(() => {
    const unsubPlans = onSnapshot(
      query(collection(db, 'pricing_plans'), where('is_active', '==', true), orderBy('order', 'asc')),
      (snapshot) => {
        setPlans(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as PricingPlan)));
        setIsLoading(false);
      }
    );
    const fetchSettings = async () => {
      try {
        const res = await fetch('/api/public/settings');
        const data = await res.json();
        if (data && typeof data === 'object') {
           setSettings(data);
        }
      } catch (e) {
        console.error(e);
      }
    };
    fetchSettings();
    return () => unsubPlans();
  }, []);

  useEffect(() => {
    const amount = searchParams.get('amount');
    const planTitle = searchParams.get('plan');
    if (amount || planTitle) {
      setBudget(amount || '');
      setDuration(planTitle || '');
      setShowForm(true);
    }
  }, [searchParams]);

  const handlePlanSelection = (plan: PricingPlan) => {
    setSelectedPlan(plan);
    setBudget(String(plan.price).replace(/[^0-9]/g, ''));
    setDuration(`${plan.title} (${plan.duration})`);
    setShowForm(true);
  };

  const handleSubmitProposal = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      const proposalPayload = {
        brand_name: brandName,
        contact_email: contactEmail,
        banner_type: bannerType,
        duration,
        budget,
        details,
        image_url: brandImage,
        payment_method: paymentMethod,
        sender_number: senderNumber,
        transaction_id: transactionId,
        status: 'pending',
        created_at: new Date().toISOString()
      };

      await addDoc(collection(db, 'sponsorships'), proposalPayload);
      showAlert("Proposal Submitted! We will contact you via email.", "success");
      setShowForm(false);
      resetForm();
    } catch (err: any) {
      showAlert("Failed to submit proposal. Please try again.", "error");
    } finally {
      setIsSubmitting(false);
    }
  };

  const resetForm = () => {
    setBrandName('');
    setContactEmail('');
    setBudget('');
    setDuration('');
    setDetails('');
    setBrandImage('');
    setPaymentMethod('bKash');
    setSenderNumber('');
    setTransactionId('');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <LoadingSpinner />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-20 overflow-x-hidden">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header - Simple & Clean */}
        <div className="text-center mb-16 space-y-4">
          <h1 className="text-4xl md:text-6xl font-black text-orange-600 tracking-tighter uppercase mb-2">SPONSOR PRICING</h1>
          <p className="text-slate-400 font-bold max-w-xl mx-auto uppercase tracking-widest text-[10px]">Premium brand placement & partnership opportunities</p>
        </div>

        {/* View All Verified Sponsors Section */}
        <div className="mb-16">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[3rem] p-8 md:p-12 border-2 border-orange-100 shadow-xl overflow-hidden relative group"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
            <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-100 text-orange-600 rounded-full text-[10px] font-black uppercase tracking-widest mb-2">
                  <Heart className="h-3.5 w-3.5 fill-current" /> Community Support
                </div>
                <h2 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight">Our Verified Partners</h2>
                <p className="text-slate-500 text-sm font-medium max-w-xl">Curious about who is already supporting our mission? View our full directory of active sponsors and partners.</p>
              </div>
              <Link 
                to="/sponsors" 
                className="px-10 py-5 bg-orange-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl hover:bg-orange-700 transition-all active:scale-95 whitespace-nowrap flex items-center gap-3 group"
              >
                View All Sponsors <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </motion.div>
        </div>

        {plans.length === 0 ? (
          <div className="bg-white p-12 rounded-[3.5rem] text-center border-2 border-slate-100 shadow-sm max-w-2xl mx-auto">
             <Trophy className="h-12 w-12 text-slate-200 mx-auto mb-4" />
             <p className="text-slate-400 font-black uppercase tracking-widest text-xs">No active plans found.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 max-w-6xl mx-auto items-center">
            {plans.map((plan, i) => (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`bg-white rounded-[3rem] p-10 border-4 transition-all duration-500 relative group flex flex-col h-full ${
                  i === 1 ? 'border-orange-600 shadow-2xl scale-105 z-10' : 'border-slate-50 shadow-xl hover:border-orange-100'
                }`}
              >
                {i === 1 && (
                  <div className="absolute -top-5 left-1/2 -translate-x-1/2 bg-orange-600 text-white text-[10px] font-black uppercase tracking-widest px-6 py-2 rounded-full shadow-lg">
                    Most Popular
                  </div>
                )}
                
                <div className="mb-8 flex justify-between items-start">
                  <div className="space-y-1">
                    <h3 className="text-2xl font-black text-slate-900 tracking-tight">{plan.title}</h3>
                    <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Pricing Plan</p>
                  </div>
                  <div className={`p-4 rounded-3xl ${i === 1 ? 'bg-orange-50 text-orange-600' : 'bg-slate-50 text-slate-400'}`}>
                    {i === 0 ? <Zap className="h-7 w-7" /> : i === 1 ? <Trophy className="h-7 w-7" /> : <Crown className="h-7 w-7" />}
                  </div>
                </div>

                <div className="flex items-baseline gap-1 mb-10">
                  <span className="text-5xl font-black text-slate-900">৳{plan.price}</span>
                  <span className="text-slate-400 text-xs font-black uppercase tracking-widest">/ {plan.duration}</span>
                </div>

                <div className="space-y-4 mb-12 flex-1">
                  <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest border-b border-slate-50 pb-2">Includes:</p>
                  {plan.features?.map((feature, idx) => (
                    <div key={idx} className="flex gap-3 text-xs font-bold text-slate-500 leading-tight">
                      <Check className="h-4 w-4 text-emerald-500 shrink-0" />
                      {feature}
                    </div>
                  ))}
                </div>

                <button
                  onClick={() => handlePlanSelection(plan)}
                  className="w-full py-4.5 bg-orange-600 text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest transition-all hover:bg-orange-700 active:scale-[0.98] shadow-lg shadow-orange-600/10"
                >
                  Choose plan
                </button>
              </motion.div>
            ))}
          </div>
        )}

        {/* Back to Home Moved to Bottom */}
        <div className="text-center mt-20">
          <Link to="/" className="inline-flex items-center gap-2 px-8 py-3 bg-orange-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-orange-700 hover:-translate-y-1 transition-all shadow-xl">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Home Page
          </Link>
        </div>
      </div>

      {/* Proposal Modal */}
      <AnimatePresence>
        {showForm && (
          <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowForm(false)}
              className="absolute inset-0 bg-slate-900/80 backdrop-blur-2xl"
            />
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              className="bg-white rounded-[2.5rem] md:rounded-[3.5rem] w-full max-w-2xl relative shadow-2xl overflow-hidden border border-white/20 max-h-[85vh] flex flex-col z-10"
            >
               <button 
                 onClick={() => setShowForm(false)}
                 className="absolute top-6 right-6 md:top-8 md:right-8 p-3 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-2xl transition-all z-[2030]"
               >
                 <X className="h-5 w-5" />
               </button>

               <div className="p-6 md:p-14 overflow-y-auto scrollbar-hide relative z-10 pt-16 md:pt-20 flex-1">
                  <div className="text-center mb-10 md:mb-12 space-y-3">
                    <div className="w-16 h-16 md:w-20 md:h-20 bg-orange-50 rounded-[1.8rem] md:rounded-[2rem] flex items-center justify-center mx-auto mb-6 transform rotate-12">
                       <Send className="h-8 w-8 md:h-9 md:h-9 text-orange-600" />
                    </div>
                    <span className="text-[10px] font-black text-orange-600 uppercase tracking-widest bg-orange-50 px-4 py-1.5 rounded-full">Partnership Gate</span>
                    <h2 className="text-2xl md:text-3xl lg:text-4xl font-black text-slate-900 tracking-tight">Sponsorship Form</h2>
                    <p className="text-slate-400 text-sm font-semibold max-w-md mx-auto">Selected Plan: <span className="text-orange-600">{selectedPlan?.title || duration}</span></p>
                  </div>

                  <form onSubmit={handleSubmitProposal} className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Brand/Sponsor Name</label>
                      <input type="text" placeholder="e.g., Apple Inc" className="glass-input w-full rounded-2xl" value={brandName} onChange={e => setBrandName(e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Contact Email</label>
                      <input type="email" placeholder="partner@brand.com" className="glass-input w-full rounded-2xl" value={contactEmail} onChange={e => setContactEmail(e.target.value)} required />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Banner Alignment</label>
                      <select className="glass-input w-full rounded-2xl" value={bannerType} onChange={e => setBannerType(e.target.value)}>
                        <option>Sidebar Banner</option>
                        <option>App Header Spotlight</option>
                        <option>Course Material Ad</option>
                        <option>Result Portal Exclusive</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Budget (BDT)</label>
                      <input type="number" placeholder="0" className="glass-input w-full rounded-2xl" value={budget} onChange={e => setBudget(e.target.value)} required />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Tell us about your brand</label>
                      <textarea placeholder="Brief summary of your organization..." className="glass-input w-full min-h-[100px] rounded-2xl" value={details} onChange={e => setDetails(e.target.value)} />
                    </div>
                    <div className="space-y-2 md:col-span-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Brand Logo Image Link (Optional)</label>
                      <input type="url" placeholder="https://example.com/logo.png" className="glass-input w-full rounded-2xl" value={brandImage} onChange={e => setBrandImage(e.target.value)} />
                    </div>

                    <div className="md:col-span-2 pt-2 border-t border-slate-100">
                      <div className="bg-slate-50 border border-indigo-100 rounded-2xl p-5 mb-4">
                        <h4 className="text-sm font-black text-slate-800 mb-2">Payment Instruction</h4>
                        <p className="text-xs text-slate-500 mb-4">
                          Please send exactly <strong className="text-orange-600">৳{budget || "0"}</strong> to one of the following numbers.
                        </p>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs mb-4">
                          {settings.bkash_number && <div><span className="font-bold text-pink-600">bKash:</span> {settings.bkash_number}</div>}
                          {settings.nagad_number && <div><span className="font-bold text-orange-600">Nagad:</span> {settings.nagad_number}</div>}
                          {settings.rocket_number && <div><span className="font-bold text-purple-600">Rocket:</span> {settings.rocket_number}</div>}
                          {!settings.bkash_number && !settings.nagad_number && !settings.rocket_number && <div className="text-slate-400 italic">Please contact admin for payment details.</div>}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Payment Method</label>
                          <select className="glass-input w-full rounded-2xl" value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)}>
                            <option value="bKash">bKash</option>
                            <option value="Nagad">Nagad</option>
                            <option value="Rocket">Rocket</option>
                          </select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Sender Number</label>
                          <input type="text" placeholder="017..." className="glass-input w-full rounded-2xl" value={senderNumber} onChange={e => setSenderNumber(e.target.value)} required />
                        </div>
                        <div className="space-y-2">
                          <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Transaction ID</label>
                          <input type="text" placeholder="TrxID" className="glass-input w-full rounded-2xl" value={transactionId} onChange={e => setTransactionId(e.target.value)} required />
                        </div>
                      </div>
                    </div>

                    <div className="md:col-span-2 pt-4">
                      <button 
                        type="submit" 
                        disabled={isSubmitting}
                        className="w-full py-5 bg-orange-600 text-white rounded-[1.5rem] font-black text-xs uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl active:scale-[0.98] disabled:opacity-50 flex items-center justify-center gap-3"
                      >
                        {isSubmitting ? <LoadingSpinner size="sm" /> : <><Send className="h-4 w-4" /> Submit Proposal</>}
                      </button>
                    </div>
                  </form>
               </div>
               
               {/* Accent decoration */}
               <div className="absolute bottom-0 right-0 w-40 h-40 bg-orange-500/5 blur-3xl rounded-full" />
               <div className="absolute top-0 left-0 w-40 h-40 bg-orange-500/5 blur-3xl rounded-full" />
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Sponsorship;
