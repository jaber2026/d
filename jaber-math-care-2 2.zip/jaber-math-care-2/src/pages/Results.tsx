import { db } from '../firebase';
import { collection, onSnapshot } from 'firebase/firestore';
import LoadingSpinner from '../components/LoadingSpinner';
import { showAlert } from '../utils/alert';
import React, { useState, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, User, Users, Filter, Award, Trophy, Star, RefreshCw, FileText, Calendar, AlertTriangle, X } from 'lucide-react';

const Results = () => {
  const [exams, setExams] = useState<any[]>([]);
  const [results, setResults] = useState<any[]>([]);
  const [programs, setPrograms] = useState<any[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'your' | 'full'>('your');
  
  // Filters
  const [selectedProgram, setSelectedProgram] = useState('');
  const [selectedClass, setSelectedClass] = useState('');
  const [selectedBatch, setSelectedBatch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedExamType, setSelectedExamType] = useState('');
  const [rollNumber, setRollNumber] = useState('');

  // Tab State: Roll Search
  const [hasSearched, setHasSearched] = useState(false);

  // Selected Exam for viewing results
  const [activeExam, setActiveExam] = useState<any | null>(null);
  
  // Custom Modal State
  const [showNoResultModal, setShowNoResultModal] = useState(false);
  const [missingRoll, setMissingRoll] = useState('');

  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    setLoading(true);
    const unsubscribes: (() => void)[] = [];

    const unsubUsers = onSnapshot(collection(db, 'users'), (s) => {
      setUsers(s.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (error) => console.warn('Users fetch error:', error.message));
    unsubscribes.push(unsubUsers);

    const unsubExams = onSnapshot(collection(db, 'exams'), (s) => {
      setExams(s.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (error) => console.warn('Exams fetch error:', error.message));
    unsubscribes.push(unsubExams);

    const unsubResults = onSnapshot(collection(db, 'results'), (s) => {
      setResults(s.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (error) => console.warn('Results fetch error:', error.message));
    unsubscribes.push(unsubResults);

    const unsubPrograms = onSnapshot(collection(db, 'programs'), (s) => {
      setPrograms(s.docs.map(d => ({ id: d.id, ...d.data() })));
    }, (error) => console.warn('Programs fetch error:', error.message));
    unsubscribes.push(unsubPrograms);

    const unsubBatches = onSnapshot(collection(db, 'batches'), (s) => {
      setBatches(s.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    }, (error) => {
      console.warn('Batches fetch error:', error.message);
      setLoading(false);
    });
    unsubscribes.push(unsubBatches);

    return () => unsubscribes.forEach(unsub => unsub());
  }, []);

  const refreshData = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 600);
  };

  const mappedResults = useMemo(() => {
    return results.map(r => {
      let roll_number = r.roll_number;
      let student_name = r.student_name;
      let exam_category = r.exam_category;
      let batch_id = r.batch_id;
      let program_id = r.program_id;
      let student_class = r.student_class || r.class;
      
      const user = r.student_id 
        ? users.find(u => u.id === r.student_id)
        : (roll_number ? users.find(u => String(u.roll_number).trim() === String(roll_number).trim()) : null);
        
      if (user) {
        roll_number = roll_number || user.roll_number;
        student_name = student_name || user.name;
        batch_id = batch_id || user.batch_id || user.batch_id_2;
        program_id = program_id || user.program_id || (batches.find(b => String(b.id) === String(user.batch_id) || String(b.id) === String(user.batch_id_2))?.program_id);
        student_class = student_class || user.current_class || user.class;
      }
      
      if (!exam_category && r.exam_id) {
        const exam = exams.find(e => e.id === r.exam_id);
        if (exam) {
          exam_category = exam.category;
        }
      } else if (!exam_category && r.exam_name) {
        const exam = exams.find(e => e.exam_name === r.exam_name);
        if (exam) {
          exam_category = exam.category;
        }
      }
      
      return { ...r, roll_number, student_name, exam_category, batch_id, program_id, student_class };
    });
  }, [results, users, exams, batches]);

  // Filter exams that are published and match selected program/class/batch/category/type
  const filteredExams = useMemo(() => {
    let list = exams.filter(e => e.published);

    if (selectedProgram) {
      list = list.filter(e => !e.program_id || e.program_id === 'all' || e.program_id === selectedProgram);
    }
    if (selectedBatch) {
      list = list.filter(e => !e.batch_id || e.batch_id === 'all' || e.batch_id === selectedBatch || String(e.batch_id).includes(selectedBatch));
    }
    if (selectedCategory) {
      list = list.filter(e => e.category === selectedCategory);
    }
    if (selectedExamType) {
      list = list.filter(e => e.exam_type === selectedExamType);
    }
    
    return list.sort((a, b) => new Date(b.exam_date || b.created_at || 0).getTime() - new Date(a.exam_date || a.created_at || 0).getTime());
  }, [exams, selectedProgram, selectedBatch, selectedCategory, selectedExamType]);

  const uniqueCategories = useMemo(() => {
    return Array.from(new Set(exams.filter(e => e.published).map(e => e.category).filter(Boolean)));
  }, [exams]);

  const uniqueTypes = useMemo(() => {
    return Array.from(new Set(exams.filter(e => e.published).map(e => e.exam_type).filter(Boolean)));
  }, [exams]);

  const uniqueClasses = useMemo(() => {
    const list = selectedProgram ? batches.filter(b => b.program_id?.toString() === selectedProgram) : batches;
    return Array.from(new Set(list.map(b => b.class || b.class_name || b.batch_class).filter(Boolean)));
  }, [batches, selectedProgram]);

  const uniqueBatches = useMemo(() => {
    let list = batches;
    if (selectedProgram) {
      list = list.filter(b => b.program_id?.toString() === selectedProgram);
    }
    if (selectedClass) {
      list = list.filter(b => (b.class || b.class_name || b.batch_class) === selectedClass);
    }
    return list;
  }, [batches, selectedProgram, selectedClass]);

  // Exams specific to the searched roll number
  const userSpecificExams = useMemo(() => {
    if (activeTab !== 'your' || !hasSearched || !rollNumber.trim()) return [];
    const searchRoll = rollNumber.trim();
    return filteredExams.filter(exam => {
      return mappedResults.some(r => 
        (r.exam_name === exam.exam_name || r.exam_id === exam.id) &&
        String(r.roll_number).trim() === searchRoll
      );
    });
  }, [filteredExams, mappedResults, rollNumber, hasSearched, activeTab]);

  // Click on Apply Filters resets activeExam so they select a new one
  const handleApplyFilters = () => {
    setActiveExam(null);
    if (activeTab === 'your') {
      // Re-run searching if they applied filters with roll number already entered
      if (hasSearched && rollNumber.trim()) {
        handleSearchRoll();
      } else {
        showAlert('Please enter your roll number first and click Search.');
      }
    } else {
      if (filteredExams.length === 0) {
        showAlert('No exams found matching your selection criteria.');
      }
    }
  };

  // Perform Roll Search
  const handleSearchRoll = () => {
    if (!rollNumber || !rollNumber.trim()) {
      showAlert('Please enter your roll number first.', 'error');
      return;
    }
    const searchRoll = rollNumber.trim();
    
    // Check if there are any results recorded for this roll
    const matchingData = mappedResults.filter(r => 
      String(r.roll_number).trim() === searchRoll
    );

    if (matchingData.length === 0) {
      setMissingRoll(searchRoll);
      setShowNoResultModal(true);
      setHasSearched(false);
      setActiveExam(null);
    } else {
      setHasSearched(true);
      setActiveExam(null); // Clear selected exam to show list of matching sheets
    }
  };

  // Click "VIEW RESULTS" on an Exam Card
  const handleViewResults = (exam: any) => {
    if (activeTab === 'your') {
      if (!rollNumber || !rollNumber.trim()) {
        showAlert('Please enter your roll number first.', 'error');
        return;
      }
      
      const searchRoll = rollNumber.trim();
      const resultsForThisExam = mappedResults.filter(r => 
        r.exam_name === exam.exam_name || r.exam_id === exam.id
      );
      
      const studentResult = resultsForThisExam.find(r => 
        String(r.roll_number).trim() === searchRoll
      );

      if (!studentResult) {
        setMissingRoll(searchRoll);
        setShowNoResultModal(true);
        setActiveExam(null);
      } else {
        // Calculate dynamic merit position if missing
        let calcResult = { ...studentResult };
        if (!calcResult.merit_position) {
          const sorted = [...resultsForThisExam].sort((a, b) => (Number(b.marks) || 0) - (Number(a.marks) || 0));
          const index = sorted.findIndex(r => r.id === calcResult.id);
          calcResult.calculated_merit = index !== -1 ? index + 1 : 'N/A';
        }
        setActiveExam({ exam, studentResult: calcResult });
      }
    } else {
      // FULL RESULT Tab
      const resultsForThisExam = mappedResults.filter(r => 
        r.exam_name === exam.exam_name || r.exam_id === exam.id
      ).sort((a, b) => (Number(b.marks) || 0) - (Number(a.marks) || 0));

      setActiveExam({ exam, fullResults: resultsForThisExam });
    }
  };

  return (
    <div className="min-h-screen pt-4 md:pt-[45px] pb-20 px-4 sm:px-6 lg:px-8 bg-[#F8FAFC]">
      <div className="max-w-[1140px] mx-auto space-y-8">
        
        {/* Page Title */}
        <motion.div 
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8 relative"
        >
          <h1 className="text-4xl md:text-5xl font-black text-orange-600 tracking-tight flex items-center justify-center gap-2 md:gap-3">
            <Award className="h-10 w-10 md:h-12 md:w-12 text-orange-600" />
            Exam Results
          </h1>
          <p className="text-slate-500 mt-2 text-sm md:text-base font-semibold">
            Check your performance, obtain marks & merit position.
          </p>
          <div className="absolute top-0 right-0 max-sm:relative max-sm:mt-4 flex justify-center">
            <motion.button
              whileHover={{ rotate: 180 }}
              whileTap={{ scale: 0.9 }}
              onClick={refreshData}
              className="p-3 bg-white rounded-2xl border border-slate-100 shadow-sm text-slate-400 hover:text-orange-600 transition-colors"
              title="Refresh Results"
            >
              <RefreshCw className={`h-5 w-5 ${loading ? 'animate-spin' : ''}`} />
            </motion.button>
          </div>
        </motion.div>

        {/* Filters Card */}
        <motion.div 
          initial={{ opacity: 0, y: 25 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ type: "spring", damping: 25 }}
          className="bg-white rounded-[32px] p-6 md:p-8 border border-white shadow-xl relative"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 mb-6">
            
            {/* Program */}
            <div className="relative group">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Program</label>
              <select 
                className="w-full bg-[#f8fafc] border border-slate-200 rounded-2xl px-4 py-3.5 text-slate-800 font-bold appearance-none focus:border-orange-500 transition-all outline-none"
                value={selectedProgram}
                onChange={(e) => {
                  setSelectedProgram(e.target.value);
                  setSelectedClass('');
                  setSelectedBatch('');
                }}
              >
                <option value="">All Programs</option>
                {programs.map(p => (
                  <option key={p.id} value={p.id}>{p.title || p.name || 'Unknown Program'}</option>
                ))}
              </select>
            </div>

            {/* Class */}
            <div className="relative group">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Class</label>
              <select 
                className="w-full bg-[#f8fafc] border border-slate-200 rounded-2xl px-4 py-3.5 text-slate-800 font-bold appearance-none focus:border-orange-500 transition-all outline-none"
                value={selectedClass}
                onChange={(e) => {
                  setSelectedClass(e.target.value);
                  setSelectedBatch('');
                }}
              >
                <option value="">All Classes</option>
                {uniqueClasses.map(c => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            {/* Batch */}
            <div className="relative group">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Batch</label>
              <select 
                className="w-full bg-[#f8fafc] border border-slate-200 rounded-2xl px-4 py-3.5 text-slate-800 font-bold appearance-none focus:border-orange-500 transition-all outline-none"
                value={selectedBatch}
                onChange={(e) => setSelectedBatch(e.target.value)}
              >
                <option value="">Select Batch</option>
                {uniqueBatches.map(b => (
                  <option key={b.id} value={b.id}>{b.name || b.batch_name || 'Unknown Batch'}</option>
                ))}
              </select>
            </div>

            {/* Exam Type */}
            <div className="relative group">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Exam Type</label>
              <select 
                className="w-full bg-[#f8fafc] border border-slate-200 rounded-2xl px-4 py-3.5 text-slate-800 font-bold appearance-none focus:border-orange-500 transition-all outline-none"
                value={selectedExamType}
                onChange={(e) => setSelectedExamType(e.target.value)}
              >
                <option value="">All Types</option>
                {uniqueTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>

            {/* Category */}
            <div className="relative group">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Category</label>
              <select 
                className="w-full bg-[#f8fafc] border border-slate-200 rounded-2xl px-4 py-3.5 text-slate-800 font-bold appearance-none focus:border-orange-500 transition-all outline-none"
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
              >
                <option value="">All Categories</option>
                {uniqueCategories.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

          </div>

          <div className="flex justify-end pt-2">
            <motion.button 
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={handleApplyFilters}
              className="bg-orange-600 hover:bg-orange-700 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all inline-flex items-center gap-2 shadow-lg shadow-orange-600/15 cursor-pointer"
            >
              <Filter className="h-4 w-4" /> APPLY FILTERS
            </motion.button>
          </div>
        </motion.div>

        {/* Segmented Tabs & Operational Controls */}
        <div className="bg-white rounded-[32px] p-6 md:p-8 border border-white shadow-xl space-y-6">
          
          <div className="flex bg-slate-100 rounded-2xl p-1 mb-2">
            <button 
              onClick={() => {
                setActiveTab('your');
                setActiveExam(null);
              }}
              className={`flex-1 py-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all cursor-pointer ${activeTab === 'your' ? 'bg-orange-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <User className="h-4 w-4" /> YOUR RESULT
            </button>
            <button 
              onClick={() => {
                setActiveTab('full');
                setActiveExam(null);
                setHasSearched(false);
              }}
              className={`flex-1 py-4 rounded-xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 transition-all cursor-pointer ${activeTab === 'full' ? 'bg-orange-600 text-white shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
            >
              <Users className="h-4 w-4" /> FULL RESULT
            </button>
          </div>

          {/* Roll Number Search input (YOUR RESULT tab) */}
          {activeTab === 'your' && (
            <div className="max-w-md mx-auto mb-4">
              <div className="relative flex items-center gap-3">
                <div className="relative flex-1 flex items-center">
                  <Search className="absolute left-4 h-5 w-5 text-slate-400" />
                  <input 
                    type="number" 
                    placeholder="Enter Roll Number"
                    className="w-full bg-[#f8fafc] border border-slate-200 rounded-2xl pl-12 pr-4 py-3.5 text-slate-800 font-bold outline-none focus:border-orange-500 transition-all text-sm md:text-base cursor-text"
                    value={rollNumber}
                    onChange={(e) => {
                      setRollNumber(e.target.value);
                      if (!e.target.value) {
                        setHasSearched(false);
                        setActiveExam(null); // Clean visual states when deleted
                      }
                    }}
                    onKeyDown={(e) => {
                      if (['e', 'E', '+', '-', '.'].includes(e.key)) {
                        e.preventDefault();
                      }
                      if (e.key === 'Enter') {
                        handleSearchRoll();
                      }
                    }}
                  />
                </div>
                <button
                  onClick={handleSearchRoll}
                  className="bg-orange-600 hover:bg-orange-700 text-white px-6 py-3.5 rounded-2xl font-black text-xs md:text-sm uppercase tracking-widest transition-all active:scale-95 shadow-lg shadow-orange-600/10 cursor-pointer text-center shrink-0"
                >
                  Search
                </button>
              </div>
            </div>
          )}

          {/* Output List matching tab specific layouts */}
          <div className="space-y-4 pt-2">
            {activeTab === 'your' ? (
              // YOUR RESULT rendering logic
              !hasSearched ? (
                /* Static placeholder prompt until user enters their roll number and clicks Search */
                <div className="text-center py-16 bg-slate-50/50 rounded-[2.5rem] border border-dashed border-slate-200 p-6">
                  <div className="w-16 h-16 bg-orange-50 text-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="h-8 w-8" />
                  </div>
                  <h4 className="text-lg font-black text-slate-800">Search Your Results</h4>
                  <p className="text-slate-400 text-sm max-w-sm font-semibold mx-auto mt-2">
                    Please key in your Roll Number above and click the Search button to discover matching exam result sheets.
                  </p>
                </div>
              ) : (
                <>
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2 border-b pb-2">Your Published Results Found</h3>
                  {loading ? (
                    <div className="py-8 text-center text-slate-400">Loading exams data...</div>
                  ) : userSpecificExams.length > 0 ? (
                    <div className="space-y-3">
                      {userSpecificExams.map((exam) => (
                        <div 
                          key={exam.id} 
                          className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-5 bg-[#f8fafc] rounded-2xl border border-slate-100 hover:border-slate-200 transition-all gap-4"
                        >
                          <div>
                            <h4 className="font-extrabold text-orange-600 text-base md:text-lg leading-tight hover:underline cursor-pointer" onClick={() => handleViewResults(exam)}>
                              {exam.exam_name}
                            </h4>
                            <p className="text-xs text-slate-500 font-medium mt-1">
                              Type: <span className="font-bold text-slate-700">{exam.exam_type || 'CQ'}</span> 
                              <span className="mx-2">|</span> 
                              Date: <span className="font-bold text-slate-700">{exam.exam_date || (exam.created_at ? new Date(exam.created_at).toLocaleDateString() : 'N/A')}</span>
                              {exam.category && (
                                <>
                                  <span className="mx-2">|</span>
                                  Category: <span className="font-bold text-slate-700">{exam.category}</span>
                                </>
                              )}
                            </p>
                          </div>
                          <button
                            onClick={() => handleViewResults(exam)}
                            className="bg-orange-600 hover:bg-orange-700 text-white px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-colors active:scale-95 shrink-0 cursor-pointer"
                          >
                            VIEW RESULTS
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-12 text-slate-400 font-semibold bg-slate-50 rounded-2xl border">
                      No matching results found for this selection criteria and your roll number.
                    </div>
                  )}
                </>
              )
            ) : (
              // FULL RESULT rendering logic
              <>
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-2 border-b pb-2">Matching Published Exams</h3>
                {loading ? (
                  <div className="py-8 text-center text-slate-400">Loading exams data...</div>
                ) : filteredExams.length > 0 ? (
                  <div className="space-y-3">
                    {filteredExams.map((exam) => (
                      <div 
                        key={exam.id} 
                        className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-5 bg-[#f8fafc] rounded-2xl border border-slate-100 hover:border-slate-200 transition-all gap-4"
                      >
                        <div>
                          <h4 className="font-extrabold text-orange-600 text-base md:text-lg leading-tight hover:underline cursor-pointer" onClick={() => handleViewResults(exam)}>
                            {exam.exam_name}
                          </h4>
                          <p className="text-xs text-slate-500 font-medium mt-1">
                            Type: <span className="font-bold text-slate-700">{exam.exam_type || 'CQ'}</span> 
                            <span className="mx-2">|</span> 
                            Date: <span className="font-bold text-slate-700">{exam.exam_date || (exam.created_at ? new Date(exam.created_at).toLocaleDateString() : 'N/A')}</span>
                            {exam.category && (
                              <>
                                <span className="mx-2">|</span>
                                Category: <span className="font-bold text-slate-700">{exam.category}</span>
                              </>
                            )}
                          </p>
                        </div>
                        <button
                          onClick={() => handleViewResults(exam)}
                          className="bg-orange-600 hover:bg-orange-700 text-white px-5 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-colors active:scale-95 shrink-0 cursor-pointer"
                        >
                          VIEW RESULTS
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-slate-400 font-medium bg-slate-50 rounded-xl">
                    No active/published exams found matching current filters.
                  </div>
                )}
              </>
            )}
          </div>

        </div>

        {/* Display Results Output Section */}
        {activeExam && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-[32px] p-6 md:p-8 border border-white shadow-xl space-y-6"
          >
            <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b pb-4 gap-2">
              <div>
                <span className="text-[10px] font-black text-orange-600 uppercase tracking-widest">Selected Result Sheet</span>
                <h2 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight">{activeExam.exam.exam_name}</h2>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs font-black text-slate-400 uppercase tracking-widest bg-slate-100 px-3 py-1.5 rounded-lg flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5 text-slate-500" />
                  Date: {activeExam.exam.exam_date || 'N/A'}
                </span>
                <button 
                  onClick={() => setActiveExam(null)}
                  className="p-1 px-2.5 rounded-lg border border-slate-200 hover:bg-slate-50 font-bold text-slate-400 text-xs hover:text-slate-600 transition-all cursor-pointer"
                >
                  Clear Info
                </button>
              </div>
            </div>

            {/* Under Tab: YOUR RESULT */}
            {activeTab === 'your' && activeExam.studentResult && (
              <>
                {/* Desktop View */}
                <div className="hidden md:block overflow-x-auto">
                  <table className="w-full text-left border-collapse rounded-2xl overflow-hidden shadow-sm table-fixed min-w-[600px]">
                    <thead>
                      <tr className="bg-orange-600 text-white">
                        <th className="px-6 py-4 text-xs font-black uppercase tracking-wider w-[20%] text-center">Roll</th>
                        <th className="px-6 py-4 text-xs font-black uppercase tracking-wider w-[35%]">Name</th>
                        <th className="px-6 py-4 text-xs font-black uppercase tracking-wider w-[15%] text-center">Obtained Marks</th>
                        <th className="px-6 py-4 text-xs font-black uppercase tracking-wider w-[15%] text-center">Highest Marks</th>
                        <th className="px-6 py-4 text-xs font-black uppercase tracking-wider w-[15%] text-center">Merit Position</th>
                      </tr>
                    </thead>
                    <tbody className="bg-[#f8fafc] divide-y divide-slate-100">
                      <tr className="hover:bg-slate-50 text-slate-800 transition-colors">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-extrabold text-slate-900 text-center">{activeExam.studentResult.roll_number}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-extrabold text-slate-900">{activeExam.studentResult.student_name}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-black text-emerald-600 text-center">{Number(activeExam.studentResult.marks ?? 0).toFixed(2)}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-orange-600 text-center">{Number(activeExam.studentResult.highest_marks ?? activeExam.studentResult.total_marks ?? activeExam.exam.highest_marks ?? 0).toFixed(2)}</td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-black text-rose-500 text-center">
                          {activeExam.studentResult.merit_position || activeExam.studentResult.calculated_merit}
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>

                {/* Mobile View Card */}
                <div className="block md:hidden space-y-4">
                  <div className="bg-slate-50 border border-slate-150 rounded-2xl p-5 space-y-3.5 shadow-sm">
                    <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                      <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Roll</span>
                      <span className="text-sm font-extrabold text-slate-900 bg-white px-3 py-1.5 rounded-lg border border-slate-250 shadow-sm">{activeExam.studentResult.roll_number}</span>
                    </div>
                    <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                      <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Name</span>
                      <span className="text-sm font-extrabold text-slate-900">{activeExam.studentResult.student_name}</span>
                    </div>
                    <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                      <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Obtained Marks</span>
                      <span className="text-sm font-black text-emerald-600">{Number(activeExam.studentResult.marks ?? 0).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                      <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Highest Marks</span>
                      <span className="text-sm font-bold text-orange-600">{Number(activeExam.studentResult.highest_marks ?? activeExam.studentResult.total_marks ?? activeExam.exam.highest_marks ?? 0).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center pt-1">
                      <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Merit Position</span>
                      <span className="text-sm font-black text-rose-500 bg-rose-50 px-3 py-1 rounded-lg">#{activeExam.studentResult.merit_position || activeExam.studentResult.calculated_merit}</span>
                    </div>
                  </div>
                </div>
              </>
            )}

            {/* Under Tab: FULL RESULT */}
            {activeTab === 'full' && activeExam.fullResults && (
              <div className="space-y-4">
                {activeExam.fullResults.length > 0 ? (
                  <>
                    {/* Desktop View Table */}
                    <div className="hidden md:block overflow-x-auto">
                      <table className="w-full text-left border-collapse rounded-2xl overflow-hidden shadow-sm min-w-[700px]">
                        <thead>
                          <tr className="bg-orange-600 text-white">
                            <th className="px-6 py-4 text-xs font-black uppercase tracking-wider w-[15%] text-center">Roll</th>
                            <th className="px-6 py-4 text-xs font-black uppercase tracking-wider w-[35%]">Name</th>
                            <th className="px-6 py-4 text-xs font-black uppercase tracking-wider w-[15%] text-center">Obtained Marks</th>
                            <th className="px-6 py-4 text-xs font-black uppercase tracking-wider w-[15%] text-center">Highest Marks</th>
                            <th className="px-6 py-4 text-xs font-black uppercase tracking-wider w-[15%] text-center">Merit Position</th>
                          </tr>
                        </thead>
                        <tbody className="bg-[#f8fafc] divide-y divide-slate-100">
                          {activeExam.fullResults.map((result: any, index: number) => (
                            <tr key={result.id || index} className="hover:bg-slate-50 text-slate-700 transition-colors">
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-extrabold text-slate-900 text-center">{result.roll_number}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-slate-800">{result.student_name}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-black text-emerald-600 text-center">{Number(result.marks ?? 0).toFixed(2)}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-orange-600 text-center">{Number(result.highest_marks ?? result.total_marks ?? activeExam.exam.highest_marks ?? 0).toFixed(2)}</td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-black text-rose-500 text-center">{result.merit_position || (index + 1)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Mobile View Card List */}
                    <div className="block md:hidden space-y-4">
                      {activeExam.fullResults.map((result: any, index: number) => (
                        <div key={result.id || index} className="bg-slate-50 border border-slate-150 rounded-2xl p-5 space-y-3 shadow-sm">
                          <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Roll</span>
                            <span className="text-sm font-extrabold text-slate-900 bg-white px-3 py-1 rounded-lg border border-slate-200">{result.roll_number}</span>
                          </div>
                          <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Name</span>
                            <span className="text-sm font-bold text-slate-800 text-right max-w-[180px] break-words">{result.student_name}</span>
                          </div>
                          <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Obtained Marks</span>
                            <span className="text-sm font-black text-emerald-600">{Number(result.marks ?? 0).toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Highest Marks</span>
                            <span className="text-sm font-bold text-orange-600">{Number(result.highest_marks ?? result.total_marks ?? activeExam.exam.highest_marks ?? 0).toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between items-center pt-1">
                            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Merit Position</span>
                            <span className="text-sm font-black text-rose-500 bg-rose-50 px-3 py-1 rounded-lg">#{result.merit_position || (index + 1)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8 text-slate-400 font-medium">No results recorded on this exam yet.</div>
                )}
              </div>
            )}

          </motion.div>
        )}

        {/* Custom Warn Popup Modal (Image 2 design) */}
        <AnimatePresence>
          {showNoResultModal && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
              <motion.div 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-white rounded-[24px] w-full max-w-sm overflow-hidden p-6 text-center shadow-2xl relative border border-slate-100"
              >
                {/* Warning Yellow Icon in Circle */}
                <div className="w-16 h-16 bg-amber-50 rounded-full border border-amber-200 flex items-center justify-center mx-auto mb-5 text-amber-500">
                  <AlertTriangle className="h-8 w-8" />
                </div>

                <h3 className="text-xl font-bold text-slate-900 mb-2">No Results Found</h3>
                <p className="text-sm font-medium text-slate-500 mb-6 font-semibold">
                  No results found for roll number: <span className="font-extrabold text-slate-800">{missingRoll}</span>.
                </p>

                {/* Close action */}
                <button 
                  onClick={() => setShowNoResultModal(false)}
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white py-3.5 rounded-xl font-extrabold text-sm uppercase tracking-wider transition-all duration-200 active:scale-95 shadow-md shadow-orange-600/10 cursor-pointer text-center"
                >
                  OK
                </button>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
};

export default Results;
