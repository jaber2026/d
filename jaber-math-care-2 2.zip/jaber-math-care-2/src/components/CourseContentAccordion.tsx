import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronDown, PlayCircle, BookOpen, Play } from 'lucide-react';

interface CourseContentProps {
  courseId: string;
  videos: any[];
  activeVideoId?: string;
  onVideoSelect?: (video: any) => void;
}

const CourseContentAccordion: React.FC<CourseContentProps> = ({ courseId, videos, activeVideoId, onVideoSelect }) => {
  const [openSubjects, setOpenSubjects] = useState<string[]>([]);

  // Group videos by playlist (subject)
  const subjects = videos.reduce((acc: any, video) => {
    const subjectName = video.playlist || 'General Videos';
    if (!acc[subjectName]) acc[subjectName] = [];
    acc[subjectName].push(video);
    return acc;
  }, {});

  const toggleSubject = (subject: string) => {
    setOpenSubjects(prev => 
      prev.includes(subject) ? prev.filter(s => s !== subject) : [...prev, subject]
    );
  };

  if (Object.keys(subjects).length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-2xl border border-slate-200">
         <BookOpen className="h-12 w-12 text-slate-300 mx-auto mb-3" />
         <p className="text-slate-500 font-medium">No contents uploaded for this course yet.</p>
      </div>
    );
  }

  return (
    <div className="bg-white border text-left border-slate-200 rounded-2xl overflow-hidden shadow-sm">
      <div className="bg-gradient-to-r from-orange-500 via-orange-600 to-amber-500 p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
         <div className="flex items-center gap-3">
           <div className="p-3 bg-white/20 rounded-xl backdrop-blur-sm">
             <BookOpen className="h-6 w-6 text-white" />
           </div>
           <div>
             <h2 className="text-xl font-black text-white font-sans">কোর্স কন্টেন্ট</h2>
             <p className="text-orange-50/80 text-xs font-bold mt-1">মোট {videos.length} টি ক্লাস যুক্ত করা হয়েছে</p>
           </div>
         </div>
      </div>
      
      <div className="p-0">
        {Object.entries(subjects).map(([subjectName, subjectVideos]: [string, any], index) => {
          const isOpen = openSubjects.includes(subjectName);
          return (
            <div key={subjectName} className="border-b border-slate-100 last:border-b-0">
              <button
                onClick={() => toggleSubject(subjectName)}
                className={`w-full px-5 py-4 flex items-center justify-between text-left transition-colors ${isOpen ? 'bg-orange-50/50' : 'hover:bg-slate-50'}`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-orange-100 text-orange-700 flex items-center justify-center font-black text-xs shrink-0">
                    {String(index + 1).padStart(2, '0')}
                  </div>
                  <div>
                    <span className="font-black text-slate-800 text-sm md:text-base">{subjectName}</span>
                  </div>
                </div>
                <ChevronDown className={`h-5 w-5 text-slate-400 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
              </button>
              
              <AnimatePresence>
                {isOpen && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden bg-slate-50/50 border-t border-slate-100"
                  >
                    <div className="px-5 py-3 space-y-2">
                      {subjectVideos.map((video: any) => {
                        const isCurrentPlaying = activeVideoId === video.id;
                        return (
                        <button 
                          key={video.id} 
                          onClick={() => {
                            if (onVideoSelect) {
                              onVideoSelect(video);
                            } else {
                              window.open(video.url || `https://youtube.com/watch?v=${video.youtube_id}`, '_blank');
                            }
                          }}
                          className={`w-full flex items-center justify-between p-3 rounded-xl border border-slate-100 text-left transition-all ${
                            isCurrentPlaying ? 'border-orange-500 bg-orange-50/30' : 'bg-white hover:border-orange-300'
                          }`}
                        >
                           <div className="flex items-center gap-3 min-w-0">
                             <div className="h-8 w-8 rounded-full bg-rose-100 text-rose-600 flex items-center justify-center shrink-0">
                               <Play className="h-3.5 w-3.5 fill-current" />
                             </div>
                             <div className="min-w-0 pr-2">
                               <span className="font-bold text-slate-800 text-sm block truncate hover:text-orange-600 transition-colors">
                                 {video.title}
                               </span>
                             </div>
                           </div>
                        </button>
                      )})}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default CourseContentAccordion;
