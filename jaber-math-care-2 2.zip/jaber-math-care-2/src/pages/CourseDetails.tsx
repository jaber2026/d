import React, { useState, useEffect, useMemo } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useRealtimeCollection } from '../hooks/useRealtime';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { db } from '../firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { 
  PlayCircle, UserPlus, ArrowLeft, Clock, Play, FileText, Lock, User, 
  ChevronDown, CheckCircle, Info, Calendar, CreditCard, Tag, 
  Phone, AlertCircle, X, Send, Users, ExternalLink, HelpCircle, BookOpen, Facebook
} from 'lucide-react';
import { showAlert } from '../utils/alert';

const CourseDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, token } = useAuth() as any;
  const { settings } = useSettings();
  
  // Realtime Collections
  const { data: courses, loading: coursesLoading } = useRealtimeCollection('courses');
  const { data: chapters } = useRealtimeCollection('chapters');
  const { data: webRecordedClasses } = useRealtimeCollection('web_recorded_classes');
  const { data: studyMaterials } = useRealtimeCollection('study_materials');

  const [course, setCourse] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'demo' | 'support'>('overview');
  const [openChapters, setOpenChapters] = useState<string[]>(['default']);
  const [activeVideo, setActiveVideo] = useState<any>(null);

  // Enrollment State Listener
  const [userEnrollment, setUserEnrollment] = useState<any>(null);
  const [checkingEnrollment, setCheckingEnrollment] = useState(true);

  // Local state for direct enrollment modal
  const [showEnrollModal, setShowEnrollModal] = useState(false);
  const [couponCode, setCouponCode] = useState('');
  const [discount, setDiscount] = useState(0);
  const [validatingCoupon, setValidatingCoupon] = useState(false);
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  const currentMonthName = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][new Date().getMonth()];

  const [formData, setFormData] = useState({
    name: (() => {
      try { return localStorage.getItem('student_saved_name') || ''; } catch { return ''; }
    })(),
    phone: (() => {
      try { return localStorage.getItem('student_saved_phone') || ''; } catch { return ''; }
    })(),
    gmail: (() => {
      try { return localStorage.getItem('student_saved_gmail') || ''; } catch { return ''; }
    })(),
    password: (() => {
      try { return localStorage.getItem('student_saved_password') || ''; } catch { return ''; }
    })(),
    transaction_id: '',
    payment_number: '',
    payment_method: '',
    admission_month: currentMonthName,
    extra_payment: '0',
    address: (() => {
      try { return localStorage.getItem('student_saved_address') || ''; } catch { return ''; }
    })(),
    profile_pic: (() => {
      try { return localStorage.getItem('student_saved_profile_pic') || ''; } catch { return ''; }
    })()
  });

  // Prevent background scrolling when modal is open
  useEffect(() => {
    if (showEnrollModal) {
      document.body.style.overflow = 'hidden';
      document.documentElement.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
    };
  }, [showEnrollModal]);

  // Auto-fill logged in user info
  useEffect(() => {
    if (user) {
      setFormData(prev => ({
        ...prev,
        name: prev.name || user.displayName || (user as any).name || (user as any).student_name || '',
        gmail: prev.gmail || user.email || (user as any).gmail || (user as any).email_address || '',
        phone: prev.phone || user.phoneNumber || (user as any).phone || '',
        address: prev.address || (user as any).address || '',
        password: prev.password || (user as any).password || '',
        profile_pic: prev.profile_pic || user.photoURL || (user as any).profile_pic || ''
      }));
    }
  }, [user]);

  // Track enrollment status dynamically via secure API
  useEffect(() => {
    if (!user || !id) {
      setCheckingEnrollment(false);
      return;
    }
    
    let isMounted = true;
    const fetchStatus = async () => {
      if (!token) return;
      try {
        const res = await fetch(`/api/my-enrollments?t=${Date.now()}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        const data = await res.json();
        if (isMounted && !data.error && Array.isArray(data)) {
          const found = data.find((e: any) => 
            String(e.course_id) === String(id)
          );
          setUserEnrollment(found || null);
          setCheckingEnrollment(false);
        }
      } catch (error) {
        console.error("Error reading enrollment:", error);
      } finally {
        if (isMounted) {
          setCheckingEnrollment(false);
        }
      }
    };

    fetchStatus();

    // Poll to keep status updated in case admin approved in another tab
    const interval = setInterval(fetchStatus, 5000);

    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [user, id, token]);

  useEffect(() => {
    if (!coursesLoading && courses.length > 0) {
      const found = courses.find((c: any) => String(c.id) === String(id));
      if (found) {
        setCourse(found);
      } else {
        navigate('/online-courses');
      }
    }
  }, [coursesLoading, courses, id, navigate]);

  const isApproved = userEnrollment?.status === 'approved' || userEnrollment?.status === 'contacted' || user?.role === 'admin';
  const isPending = userEnrollment?.status === 'pending';

  // Extract YouTube ID safely
  const getYoutubeId = (url: string) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  // Group lectures by syllabus content
  const mappedChapters = useMemo(() => {
    if (!id) return [];
    const courseChapters = chapters.filter((c: any) => String(c.course_id) === String(id));
    const courseVideos = webRecordedClasses.filter((v: any) => String(v.course_id) === String(id));
    const courseMaterials = studyMaterials.filter((m: any) => String(m.course_id) === String(id));

    if (courseChapters.length === 0) {
      return [{
        id: 'default',
        title: 'অফিসিয়াল সিলেবাস ক্লাস ও নোটস',
        videos: courseVideos,
        materials: courseMaterials
      }];
    }

    const unassignedVideos = courseVideos.filter((v: any) => !v.chapter_id);
    const unassignedMaterials = courseMaterials.filter((m: any) => !m.chapter_id);

    const mapped = courseChapters.map((ch: any) => ({
      ...ch,
      videos: courseVideos.filter((v: any) => String(v.chapter_id) === String(ch.id)),
      materials: courseMaterials.filter((m: any) => String(m.chapter_id) === String(ch.id))
    }));

    if (unassignedVideos.length > 0 || unassignedMaterials.length > 0) {
      mapped.push({
        id: 'other',
        title: 'অন্যান্য ক্লাস ও কোর্স মেটেরিয়াল',
        videos: unassignedVideos,
        materials: unassignedMaterials
      });
    }

    return mapped;
  }, [chapters, webRecordedClasses, studyMaterials, id]);

  const totalLectures = useMemo(() => {
    if (!id) return 0;
    const courseVideos = webRecordedClasses.filter((v: any) => String(v.course_id) === String(id));
    return courseVideos.length;
  }, [webRecordedClasses, id]);

  const toggleChapter = (chapterId: string) => {
    setOpenChapters(prev => 
      prev.includes(chapterId) ? prev.filter(cid => cid !== chapterId) : [...prev, chapterId]
    );
  };

  const handleApplyCoupon = async () => {
    if (!couponCode) return;
    try {
      setValidatingCoupon(true);
      const res = await fetch("/api/validate-coupon", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: couponCode, amount: course?.price || 0 })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Invalid coupon code");
      }
      const data = await res.json();
      setDiscount(data.discount);
      showAlert(`Coupon applied! You saved ৳${data.discount}`, "success");
    } catch (e: any) {
      setDiscount(0);
      showAlert(e.message, "error");
    } finally {
      setValidatingCoupon(false);
    }
  };

  const handleEnroll = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isEnrolling) return;
    setIsEnrolling(true);
    try {
      const enrollmentFee = Math.max(0, (course?.price || 0) - discount);

      const res = await fetch('/api/enrollments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          course_id: course.id,
          course_title: course.title,
          student_type: 'online', 
          current_class: course.target_audience || course.class || "",
          class: course.target_audience || course.class || "",
          fee: enrollmentFee,
          discount_amount: discount,
          coupon_code: couponCode,
          status: 'pending'
        })
      });
      if (res.ok) {
        setIsSuccess(true);
        try {
          if (formData.name) localStorage.setItem('student_saved_name', formData.name);
          if (formData.phone) localStorage.setItem('student_saved_phone', formData.phone);
          if (formData.gmail) localStorage.setItem('student_saved_gmail', formData.gmail);
          if (formData.password) localStorage.setItem('student_saved_password', formData.password);
          if (formData.address) localStorage.setItem('student_saved_address', formData.address);
          if (formData.profile_pic) localStorage.setItem('student_saved_profile_pic', formData.profile_pic);
        } catch (storageErr) {
          console.warn("localStorage persistence failed:", storageErr);
        }
        setTimeout(() => {
          setIsSuccess(false);
          setShowEnrollModal(false);
          setFormData({ 
            name: localStorage.getItem('student_saved_name') || '', 
            phone: localStorage.getItem('student_saved_phone') || '', 
            gmail: localStorage.getItem('student_saved_gmail') || '', 
            password: localStorage.getItem('student_saved_password') || '', 
            transaction_id: '', 
            payment_number: '', 
            payment_method: '',
            admission_month: currentMonthName, 
            extra_payment: '0', 
            address: localStorage.getItem('student_saved_address') || '',
            profile_pic: localStorage.getItem('student_saved_profile_pic') || '' 
          });
        }, 1000);
      } else {
        const err = await res.json();
        showAlert(err.error || 'Failed to submit enrollment.');
      }
    } catch (error) {
      console.error(error);
      showAlert('An error occurred. Please try again.');
    } finally {
      setIsEnrolling(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 500000) { 
        showAlert('Image size should be less than 500KB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, profile_pic: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  if (coursesLoading || !course || checkingEnrollment) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-8">
        <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  const activeVideoYoutubeId = activeVideo 
    ? (activeVideo.youtube_id || getYoutubeId(activeVideo.url))
    : null;
  const demoVideoYoutubeId = course.demo_video_url ? getYoutubeId(course.demo_video_url) : null;

  return (
    <div className="min-h-screen bg-slate-50 pt-8 md:pt-16 pb-20">
      <div className="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Link */}
        <Link to="/online-courses" className="inline-flex items-center gap-2 text-orange-600 hover:text-orange-700 font-bold mb-8 transition-transform hover:-translate-x-1">
          <ArrowLeft className="h-4 w-4" /> Back to Courses
        </Link>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT 2 COLUMNS: Media Player & Description Panel */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Visual Header / Actual Player */}
            {isApproved && activeVideoYoutubeId ? (
              <div className="bg-white rounded-3xl border border-slate-250 overflow-hidden shadow-sm p-4 md:p-6">
                {/* Enrolled Approved Classroom View */}
                <div className="space-y-4">
                  <div className="relative aspect-video rounded-2xl bg-black overflow-hidden shadow-md">
                    <iframe
                      src={`https://www.youtube.com/embed/${activeVideoYoutubeId}?autoplay=1`}
                      title={activeVideo?.title}
                      className="absolute inset-0 w-full h-full"
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    ></iframe>
                  </div>
                  <div className="p-2">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-green-50 text-green-700 border border-green-200">
                      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
                      Classroom Player
                    </span>
                    <h2 className="text-2xl font-black text-slate-900 mt-2 tracking-tight">{activeVideo?.title}</h2>
                    {activeVideo?.description && (
                      <p className="text-slate-600 font-medium text-sm mt-1 whitespace-pre-wrap leading-relaxed">{activeVideo?.description}</p>
                    )}
                  </div>
                </div>
              </div>
            ) : null}

            {/* Middle Section Panel Tabs */}
            <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
              <div className="flex border-b border-slate-200 bg-white">
                <button 
                  onClick={() => setActiveTab('overview')}
                  className={`flex-1 py-4 flex flex-col items-center justify-center gap-1 border-b-2 transition-all ${activeTab === 'overview' ? 'border-orange-600 text-orange-600 bg-orange-50/20' : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50'}`}
                >
                  <BookOpen className="h-5 w-5" />
                  <span className="text-xs font-bold mt-1">কোর্স ওভারভিউ</span>
                </button>
                <button 
                  onClick={() => setActiveTab('demo')}
                  className={`flex-1 py-4 flex flex-col items-center justify-center gap-1 border-b-2 transition-all ${activeTab === 'demo' ? 'border-orange-600 text-orange-600 bg-orange-50/20' : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50'}`}
                >
                  <Play className="h-5 w-5" />
                  <span className="text-xs font-bold mt-1">ডেমো ক্লাস</span>
                </button>
                <button 
                  onClick={() => setActiveTab('support')}
                  className={`flex-1 py-4 flex flex-col items-center justify-center gap-1 border-b-2 transition-all ${activeTab === 'support' ? 'border-orange-600 text-orange-600 bg-orange-50/20' : 'border-transparent text-slate-500 hover:text-slate-800 hover:bg-slate-50'}`}
                >
                  <Facebook className="h-5 w-5" />
                  <span className="text-xs font-bold mt-1">Facebook Group</span>
                </button>
              </div>

              <div className="p-6 md:p-8">
                {activeTab === 'overview' && (
                  <div className="space-y-8">
                    <div>
                      <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2 border-b pb-2">
                        <span className="w-1.5 h-6 bg-orange-600 rounded"></span> ইন্সট্রাক্টর প্যানেল (Instructors)
                      </h3>
                      <div className="flex flex-wrap gap-4 items-center">
                        {(() => {
                          const instructors = (course.instructor || "").split(",").map(i => i.trim()).filter(Boolean);
                          const photos = (course.instructor_photo || "").split(",").map(p => p.trim()).filter(Boolean);
                          
                          if (instructors.length === 0) return (
                            <div className="flex items-center gap-3 bg-white border border-slate-100 shadow-sm p-4 rounded-2xl w-full sm:w-auto hover:border-orange-200 transition-colors">
                              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-orange-400 bg-orange-50 flex items-center justify-center">
                                <User className="h-6 w-6 text-orange-600" />
                              </div>
                              <div>
                                <span className="block text-sm font-black text-slate-800 leading-tight">Course Instructor</span>
                                <span className="text-[10px] uppercase font-bold tracking-wider text-orange-600">Head Mentor</span>
                              </div>
                            </div>
                          );

                          return instructors.map((name, idx) => (
                            <div key={idx} className="flex items-center gap-3 bg-white border border-slate-100 shadow-sm p-4 rounded-2xl w-full sm:w-auto hover:border-orange-200 transition-colors">
                              <div className="w-12 h-12 rounded-full overflow-hidden border-2 border-orange-400 bg-orange-50 shrink-0">
                                {photos[idx] ? (
                                  <img src={photos[idx]} alt={name} className="w-full h-full object-cover" />
                                ) : (
                                  <img src={`https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=ffedd5&color=ea580c`} alt={name} className="w-full h-full object-cover" />
                                )}
                              </div>
                              <div>
                                <span className="block text-sm font-black text-slate-800 leading-tight">{name}</span>
                                <span className="text-[10px] uppercase font-bold tracking-wider text-orange-600">Mentor</span>
                              </div>
                            </div>
                          ));
                        })()}
                      </div>
                    </div>

                    <div>
                      <h3 className="text-lg font-black text-slate-900 mb-4 flex items-center gap-2 border-b pb-2">
                        <span className="w-1.5 h-6 bg-orange-600 rounded"></span> কোর্স সম্পর্কে (Description)
                      </h3>
                      <div className="text-slate-600 font-medium whitespace-pre-wrap leading-relaxed text-sm md:text-base">
                        {course.description || "No description has been provided for this course."}
                      </div>
                    </div>

                    {course.demo_video_url && (
                        <div className="bg-orange-50 border border-orange-200 p-4 rounded-xl mt-6">
                            <p className="text-sm font-black text-orange-800 mb-2">বি.দ্র. কেনার পূর্বে অবশ্যই এই ভিডিওটি দেখে নাও :</p>
                            <a href={course.demo_video_url} target="_blank" rel="noreferrer" className="text-orange-600 underline font-bold text-xs break-all hover:text-orange-800">{course.demo_video_url}</a>
                        </div>
                    )}
                  </div>
                )}

                {activeTab === 'demo' && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                      <span className="w-1.5 h-6 bg-orange-600 rounded"></span> Trial / Demo Class Player
                    </h3>
                    {demoVideoYoutubeId ? (
                      <div className="space-y-4">
                        <div className="bg-black border text-center rounded-xl overflow-hidden shadow-sm aspect-video">
                          <iframe 
                            className="w-full h-full"
                            src={`https://www.youtube.com/embed/${demoVideoYoutubeId}`}
                            title="Demo Class"
                            frameBorder="0"
                            allowFullScreen>
                          </iframe>
                        </div>
                      </div>
                    ) : course.demo_video_url ? (
                      <div className="bg-orange-50 text-orange-850 font-bold p-4 rounded-xl border border-orange-100 flex items-center gap-2">
                        <Info className="h-4 w-4 shrink-0" />
                        <a href={course.demo_video_url} target="_blank" rel="noreferrer" className="underline break-all block h-auto">{course.demo_video_url}</a>
                      </div>
                    ) : (
                      <div className="text-center py-8 text-slate-400">
                        <HelpCircle className="h-12 w-12 mx-auto mb-2 text-slate-300" />
                        No demo video has been configured yet.
                      </div>
                    )}


                  </div>
                )}

                {activeTab === 'support' && (
                  <div className="space-y-6">
                    <h3 className="text-lg font-black text-slate-900 flex items-center gap-2">
                       Support Facebook Group
                    </h3>
                    <div className="bg-orange-50 border border-orange-200 p-6 rounded-2xl flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-xs">
                        <div className="flex gap-4 items-start md:items-center">
                          <div className="p-4 bg-orange-100 text-orange-600 rounded-xl">
                            <Facebook className="h-8 w-8" />
                          </div>
                          <div>
                            <span className="block text-base font-black text-slate-800">Official Student Support Group</span>
                            <span className="text-xs text-slate-500 font-medium font-sans">Join the private Facebook student community to receive notices, daily routines, exams and specialized solve sheets.</span>
                          </div>
                        </div>
                        <a 
                            href={course.fb_group_url || settings.facebook_group_url || "https://facebook.com"} 
                            target="_blank" 
                            rel="noreferrer" 
                            className="bg-orange-600 hover:bg-orange-700 text-white font-black px-6 py-4 rounded-xl text-sm flex items-center justify-center gap-2 shadow-lg shadow-orange-600/35 transition-all text-center self-start md:self-auto"
                        >
                            Join Group <ExternalLink className="h-4 w-4" />
                        </a>
                      </div>
                  </div>
                )}
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: Course Banner Card & Checkout Block */}
          <div className="lg:col-span-1 space-y-6">
            
            <div className="bg-white rounded-3xl p-4 md:p-5 border border-slate-200 text-center shadow-sm relative sticky top-24">
                
                {/* 1. Original Banner Image inside sticky section */}
                <div className="rounded-2xl overflow-hidden aspect-[16/9.5] border border-slate-200 shadow-sm relative group bg-slate-50 mb-6">
                    <img 
                    src={course.image_url || `https://picsum.photos/seed/${course.id}/1200/805`} 
                    alt={course.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                    referrerPolicy="no-referrer"
                    />
                </div>

                {/* 2. Price Details */}
                <div className="flex flex-col items-center justify-center mb-6">
                    <div className="flex items-end justify-center gap-3">
                        <span className="text-[2.25rem] leading-none font-black text-orange-600">৳{course.price || "Free"}</span>
                        {course.original_price && (
                            <span className="text-lg font-bold text-slate-400 line-through mb-1">৳{course.original_price}</span>
                        )}
                    </div>
                    {course.original_price && course.price && (
                        <div className="inline-block mt-3 px-3 py-1 bg-green-100 text-green-700 font-black text-xs rounded-lg uppercase tracking-wider">
                            {Math.round(((Number(course.original_price) - Number(course.price)) / Number(course.original_price)) * 100)}% ছাড়!
                        </div>
                    )}
                </div>

                {/* 3. Action Buttons */}
                <div className="space-y-3">
                    <button className="w-full text-center py-3.5 border border-slate-200 hover:bg-slate-50 text-orange-600 font-bold rounded-xl transition-all text-sm flex items-center justify-center gap-2 shadow-sm">
                        <div className="bg-orange-100 p-1 rounded-md"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 12H3"/><path d="M16 6H3"/><path d="M16 18H3"/><path d="M20 12h-5"/></svg></div>
                        Have Coupon Code?
                    </button>

                    {isApproved ? (
                        <div className="bg-emerald-50 text-emerald-800 border border-emerald-200 p-3.5 rounded-xl text-center font-black flex items-center justify-center gap-2">
                        <CheckCircle className="h-5 w-5 fill-current text-emerald-600" />
                        Your Course is Active!
                        </div>
                    ) : isPending ? (
                        <div className="bg-yellow-50 text-yellow-800 border border-yellow-200 p-3.5 rounded-xl text-center font-bold flex gap-2 items-center justify-center text-sm shadow-inner">
                        <Clock className="h-5 w-5 text-yellow-600 animate-spin" />
                        Enrollment Pending
                        </div>
                    ) : (
                        <button 
                        onClick={() => setShowEnrollModal(true)}
                        className="w-full text-center py-4 bg-orange-600 hover:bg-orange-700 text-white font-black rounded-xl shadow-lg shadow-orange-600/30 transition-all active:scale-95 text-lg flex items-center justify-center gap-2"
                        >
                        Enroll Now
                        </button>
                    )}
                </div>

                {/* 4. Stats */}
                <div className="mt-6 space-y-3 border-t border-slate-100 pt-5 text-left text-sm font-bold text-slate-700">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2"><div className="w-8 h-8 rounded-full bg-orange-50 flex items-center justify-center"><Users className="h-4 w-4 text-orange-600" /></div> Students Enrolled</div>
                        <span>{course.student_count || "0"}</span>
                    </div>
                </div>
            </div>

          </div>
        </div>
      </div>
{/* DIRECT IN-PAGE ENROLLMENT MODAL */}
      {showEnrollModal && (
        <div className="fixed inset-0 z-[100000] flex items-center justify-center p-4 bg-slate-900/45 backdrop-blur-[3px] overflow-hidden" onClick={() => setShowEnrollModal(false)}>
          <div 
            className="bg-white w-full max-w-xl rounded-[2rem] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col border border-slate-100"
            onClick={(e) => e.stopPropagation()}
          >
            {isSuccess ? (
              <div className="p-10 text-center space-y-6 overflow-y-auto">
                <div className="w-20 h-20 bg-green-150 text-green-600 rounded-full flex items-center justify-center mx-auto">
                  <CheckCircle className="h-14 w-14 fill-current text-green-500" />
                </div>
                <div>
                  <h2 className="text-2xl font-black text-slate-900 mb-2">Admission Submitted Successfully!</h2>
                  <p className="text-slate-600 text-sm font-medium">Your request is checking. The course will be activated very soon after verification. Thank you for choosing us!</p>
                </div>
              </div>
            ) : (
              <>
                <div className="p-5 md:p-6 border-b border-slate-100 flex justify-between items-center bg-orange-50/20 flex-shrink-0">
                  <div>
                    <h2 className="text-xl font-black text-slate-800">Online Admission Form</h2>
                    <p className="text-xs text-orange-600 font-bold mt-1">Course: {course.title}</p>
                  </div>
                  <button onClick={() => setShowEnrollModal(false)} className="p-2 bg-slate-100 hover:bg-rose-100 text-slate-500 hover:text-rose-600 rounded-full transition-colors">
                    <X className="h-5 w-5" />
                  </button>
                </div>

                <form onSubmit={handleEnroll} className="p-5 md:p-6 space-y-4 overflow-y-auto scrollbar-hide flex-1 bg-white text-left">
                  
                  {/* Upload Avatar */}
                  <div className="flex flex-col items-center mb-6">
                    <div className="w-20 h-20 bg-slate-50 rounded-full overflow-hidden mb-2 border border-slate-200 relative group cursor-pointer" onClick={() => document.getElementById('details-profile-pic-upload')?.click()}>
                      {formData.profile_pic ? (
                        <img src={formData.profile_pic} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center bg-orange-50">
                          <Users className="h-8 w-8 text-orange-300" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <span className="text-white text-[10px] font-bold">Change</span>
                      </div>
                    </div>
                    <label className="text-[11px] font-bold text-orange-600 cursor-pointer hover:text-orange-700 tracking-wider">
                      Upload Photo (Max 500KB)
                      <input id="details-profile-pic-upload" type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                    </label>
                  </div>

                  <div className="space-y-4">
                    
                    {/* section: personal info */}
                    <div className="border-b border-slate-150 pb-1.5">
                      <span className="text-xs uppercase font-black text-slate-500 tracking-wider">Personal Information</span>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Full Name *</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. Muntasir Rahman"
                          className="w-full px-4 py-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:border-orange-500 outline-none text-sm font-medium transition-all"
                          value={formData.name}
                          onChange={(e) => setFormData({...formData, name: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Mobile Number *</label>
                        <input 
                          type="number" 
                          required
                          placeholder="e.g. 01XXXXXXXXX"
                          className="w-full px-4 py-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:border-orange-500 outline-none text-sm font-medium transition-all"
                          value={formData.phone}
                          onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Email / Gmail Address *</label>
                        <input 
                          type="email" 
                          required
                          placeholder="student@gmail.com"
                          className="w-full px-4 py-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:border-orange-500 outline-none text-sm font-medium transition-all"
                          value={formData.gmail}
                          onChange={(e) => setFormData({...formData, gmail: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Password *</label>
                        <input 
                          type="password" 
                          required
                          placeholder="6+ Character Password"
                          className="w-full px-4 py-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:border-orange-500 outline-none text-sm font-medium transition-all"
                          value={formData.password}
                          onChange={(e) => setFormData({...formData, password: e.target.value})}
                        />
                      </div>
                    </div>

                    {/* Address & admission month */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Address / Area-District *</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. Mirpur, Dhaka"
                          className="w-full px-4 py-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:border-orange-500 outline-none text-sm font-medium transition-all"
                          value={formData.address}
                          onChange={(e) => setFormData({...formData, address: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Admission Month *</label>
                        <select 
                          required
                          className="w-full px-4 py-3 bg-slate-50 hover:bg-slate-100/50 text-slate-800 border border-slate-200 rounded-xl focus:border-orange-500 focus:bg-white outline-none text-sm font-bold transition-all appearance-none cursor-pointer bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2020%2020%22%2520fill%3D%22none%22%3E%3Cpath%20d%3D%22M7%209l3%203%203-3%22%20stroke%3D%22%23EA580C%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%2F%3E%3C%2Fsvg%3E')] bg-[length:1.25rem_1.25rem] bg-[right_1rem_center] bg-no-repeat pr-12 focus:ring-4 focus:ring-orange-500/10"
                          value={formData.admission_month}
                          onChange={(e) => setFormData({...formData, admission_month: e.target.value})}
                        >
                          {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(m => (
                            <option key={m} value={m} className="font-bold text-slate-850 p-2">{m}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* section: Coupon code */}
                    <div className="border-b border-slate-150 pb-1.5 pt-2">
                      <span className="text-xs uppercase font-black text-slate-500 tracking-wider">Use Coupon Code (Optional)</span>
                    </div>
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        placeholder="Enter discount coupon"
                        className="flex-1 px-4 py-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:border-orange-500 outline-none text-sm font-medium transition-all"
                        value={couponCode}
                        onChange={(e) => setCouponCode(e.target.value)}
                      />
                      <button 
                        type="button"
                        onClick={handleApplyCoupon}
                        disabled={validatingCoupon || !couponCode}
                        className="px-5 py-3 bg-orange-600 hover:bg-orange-700 disabled:bg-slate-200 text-white font-bold text-sm rounded-xl transition-all"
                      >
                        {validatingCoupon ? "Validating..." : "Apply Coupon"}
                      </button>
                    </div>

                    {/* section: Payment Info */}
                    <div className="border-b border-slate-150 pb-1.5 pt-2">
                      <span className="text-xs uppercase font-black text-slate-500 tracking-wider">Payment Details</span>
                    </div>

                    {/* Bkash payment manual instruct details */}
                    <div className="bg-orange-50/50 p-4 border border-orange-100 rounded-2xl space-y-2 text-xs md:text-sm text-slate-700">
                      <p className="font-bold text-orange-850 font-sans">Payment Instructions:</p>
                      <p>Kindly complete the course payment below or send money to any of the accounts.</p>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-bold pt-1.5">
                        {settings.bkash_number && (
                          <div className="bg-white px-3 py-2 border rounded-lg border-rose-150 text-rose-700 flex items-center justify-between">
                            <span>bKash Personal:</span>
                            <span>{settings.bkash_number}</span>
                          </div>
                        )}
                        {settings.nagad_number && (
                          <div className="bg-white px-3 py-2 border rounded-lg border-orange-150 text-orange-700 flex items-center justify-between">
                            <span>Nagad Personal:</span>
                            <span>{settings.nagad_number}</span>
                          </div>
                        )}
                        {settings.rocket_number && (
                          <div className="bg-white px-3 py-2 border rounded-lg border-indigo-150 text-indigo-700 flex items-center justify-between">
                            <span>Rocket Personal:</span>
                            <span>{settings.rocket_number}</span>
                          </div>
                        )}
                      </div>

                      <div className="text-[11px] text-slate-500 font-bold bg-white/75 p-2.5 rounded-lg border border-slate-150/50 mt-2">
                        Total Payable Course Fee:
                        <span className="text-sm font-black text-orange-600 ml-1">৳{Math.max(0, (course?.price || 0) - discount)}</span>
                        {discount > 0 && <span className="text-[10px] text-green-600 font-bold ml-1">({discount} Taka discount applied)</span>}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Payment Method *</label>
                        <select 
                          required
                          className="w-full px-4 py-3 bg-slate-50 hover:bg-slate-100/50 text-slate-800 border border-slate-200 rounded-xl focus:border-orange-500 focus:bg-white outline-none text-sm font-bold transition-all appearance-none cursor-pointer bg-[url('data:image/svg+xml;charset=utf-8,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20viewBox%3D%220%200%2020%2020%22%2520fill%3D%22none%22%3E%3Cpath%20d%3D%22M7%209l3%203%203-3%22%20stroke%3D%22%23EA580C%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%2F%3E%3C%2Fsvg%3E')] bg-[length:1.25rem_1.25rem] bg-[right_1rem_center] bg-no-repeat pr-12 focus:ring-4 focus:ring-orange-500/10"
                          value={formData.payment_method}
                          onChange={(e) => setFormData({...formData, payment_method: e.target.value})}
                        >
                          <option value="" className="font-bold text-slate-400">Select Method</option>
                          <option value="bkash" className="font-bold text-slate-850">bKash</option>
                          <option value="nagad" className="font-bold text-slate-850">Nagad</option>
                          <option value="rocket" className="font-bold text-slate-850">Rocket</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Sender Mobile Number *</label>
                        <input 
                          type="number" 
                          required
                          placeholder="Number sent from"
                          className="w-full px-4 py-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:border-orange-500 outline-none text-sm font-medium transition-all"
                          value={formData.payment_number}
                          onChange={(e) => setFormData({...formData, payment_number: e.target.value})}
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">Transaction ID (TrxID) *</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. AMK9JS82KS"
                          className="w-full px-4 py-3 bg-slate-50 text-slate-800 border border-slate-200 rounded-xl focus:border-orange-500 outline-none text-sm font-medium transition-all"
                          value={formData.transaction_id}
                          onChange={(e) => setFormData({...formData, transaction_id: e.target.value})}
                        />
                      </div>
                    </div>

                  </div>

                  <div className="bg-orange-50/40 p-4 rounded-xl border border-orange-100/60 mt-4">
                    <label className="flex items-start gap-2.5 cursor-pointer">
                      <input type="checkbox" required className="mt-1 rounded text-orange-600 focus:ring-orange-500 h-4 w-4" />
                      <span className="text-[11px] text-slate-650 leading-relaxed font-bold">
                        I declare that all the information I have supplied is correct and I agree to join Jaber Math Care in accordance with course rules.
                      </span>
                    </label>
                  </div>

                  <div className="pt-4 flex gap-3">
                    <button 
                      type="button" 
                      onClick={() => setShowEnrollModal(false)}
                      className="flex-1 bg-slate-100 text-slate-600 font-bold py-3.5 rounded-xl hover:bg-slate-200 transition-colors text-sm"
                    >
                      Cancel
                    </button>
                    <button 
                      type="submit" 
                      disabled={isEnrolling}
                      className="flex-1 bg-gradient-to-r from-orange-600 to-amber-500 text-white font-black py-3.5 rounded-xl transition-all shadow-lg shadow-orange-600/25 flex items-center justify-center gap-2 text-sm"
                    >
                      {isEnrolling ? 'Submitting...' : <><Send className="h-4.5 w-4.5" /> Submit Admission Info</>}
                    </button>
                  </div>
                </form>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CourseDetails;
