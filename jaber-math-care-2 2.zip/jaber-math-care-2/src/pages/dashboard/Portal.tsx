import { db } from '../../firebase';
import { collection, onSnapshot } from 'firebase/firestore';
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Video, ArrowRight, MonitorPlay, Users, Clock } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import SmallLoadingSpinner from '../../components/SmallLoadingSpinner';

export default function Portal() {
  const { token, user } = useAuth();
  const navigate = useNavigate();
  const [activeClasses, setActiveClasses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token) return;

    const unsub = onSnapshot(collection(db, 'live_classes'), (snapshot) => {
      const data = snapshot.docs.map(d => ({ ...d.data(), id: d.id }));
      // Filter for Jitsi classes (often branded/custom linked classes)
      const jitsiClasses = data.filter((lc: any) => 
        lc.zoom_link && (lc.zoom_link.includes('meet.jit.si') || lc.zoom_link.includes('8x8.vc') || lc.is_custom)
      );
      setActiveClasses(jitsiClasses);
      setLoading(false);
    }, (error) => {
      console.error('Portal live classes error:', error);
      setLoading(false);
    });

    return () => unsub();
  }, [token]);

  const joinPortal = (id: string) => {
    navigate(`/portal/${id}`);
  };

  if (loading) return <SmallLoadingSpinner />;

  return (
    <div className="space-y-10">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <div className="p-2 bg-orange-100 rounded-xl">
              <MonitorPlay className="h-6 w-6 text-orange-600" />
            </div>
            Custom Live Portal
          </h1>
          <p className="text-slate-500 mt-1 text-sm font-medium">Enter the branded Jaber Math Care live experience.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {activeClasses.length > 0 ? (
          activeClasses.map((lc) => {
            const roomName = lc.zoom_link.split('/').pop();
            return (
              <div key={lc.id} className="glass p-8 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40 hover:bg-white/60 transition-all group relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full -mr-16 -mt-16 blur-3xl group-hover:bg-orange-500/10 transition-colors" />
                
                <div className="flex flex-col h-full relative z-10">
                  <div className="flex justify-between items-start mb-8">
                    <div className="flex items-center gap-5">
                      <div className="bg-orange-600 p-4 rounded-2xl shadow-xl shadow-orange-200 group-hover:scale-110 transition-transform duration-500">
                        <Video className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-black text-slate-900 tracking-tight group-hover:text-orange-600 transition-colors">{lc.title}</h3>
                        <p className="text-[10px] text-orange-500 font-black uppercase tracking-widest mt-1">Active Portal Session</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 bg-emerald-500 text-white px-4 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-100 animate-pulse">
                      Live
                    </div>
                  </div>

                  <button 
                    onClick={() => joinPortal(lc.id)}
                    className="w-full bg-slate-900 text-white px-8 py-5 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-slate-800 transition-all shadow-xl shadow-slate-200 active:scale-95"
                  >
                    Enter Portal
                    <ArrowRight className="h-5 w-5" />
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="col-span-full glass p-16 rounded-[3rem] border border-white/60 shadow-xl bg-white/40 text-center max-w-2xl mx-auto">
            <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
              <MonitorPlay className="h-12 w-12 text-slate-200" />
            </div>
            <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tight">No Active Portal Sessions</h2>
            <p className="text-slate-500 text-lg mb-10 font-medium leading-relaxed">
              There are no custom portal sessions currently active. 
              You can still enter a general room if you have a room name.
            </p>
            
            <div className="max-w-sm mx-auto">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Enter Room Name" 
                  className="w-full bg-white/50 border border-slate-200 rounded-2xl py-4 px-6 text-sm focus:outline-none focus:border-orange-500 transition-all"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      joinPortal((e.target as HTMLInputElement).value);
                    }
                  }}
                />
                <button 
                  onClick={(e) => {
                    const input = e.currentTarget.previousSibling as HTMLInputElement;
                    if (input.value) joinPortal(input.value);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-orange-600 text-white p-2 rounded-xl hover:bg-orange-700 transition-colors"
                >
                  <ArrowRight className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-16">
        <div className="glass p-8 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40">
          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-orange-100 rounded-xl text-orange-600">
              <Users className="h-6 w-6" />
            </div>
            <h4 className="font-black text-slate-900 text-lg tracking-tight">Collaborative Experience</h4>
          </div>
          <p className="text-sm text-slate-500 font-medium leading-relaxed">
            Our custom portal is designed for high-quality interaction, screen sharing, and real-time collaboration without any third-party branding.
          </p>
        </div>
        <div className="glass p-8 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40">
          <div className="flex items-center gap-4 mb-6">
            <div className="p-3 bg-emerald-100 rounded-xl text-emerald-600">
              <Clock className="h-6 w-6" />
            </div>
            <h4 className="font-black text-slate-900 text-lg tracking-tight">Always Available</h4>
          </div>
          <p className="text-sm text-slate-500 font-medium leading-relaxed">
            The portal is available 24/7. Even if no class is scheduled, you can use general rooms for group study or discussions.
          </p>
        </div>
      </div>
    </div>
  );
}
