import React, { useRef, useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useSettings } from '../../context/SettingsContext';
import { QRCodeCanvas } from 'qrcode.react';
import { Download, X, CheckCircle2, CreditCard, CheckCircle, ShieldCheck, Mail, Phone, Calendar, School, Printer, Image as ImageIcon } from 'lucide-react';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { motion } from 'motion/react';
import { db } from '../../firebase';
import { collection, query, where, orderBy, getDocs, doc, getDoc } from 'firebase/firestore';

const IDCard = () => {
  const { user } = useAuth();
  const { settings } = useSettings();
  const cardRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState(false);
  const [fallbackImage, setFallbackImage] = useState<string | null>(null);
  const [profilePicDataUrl, setProfilePicDataUrl] = useState<string | null>(null);
  const [logoDataUrl, setLogoDataUrl] = useState<string | null>(null);
  const [realBatchName, setRealBatchName] = useState<string>('Not Assigned');
  const [payments, setPayments] = useState<any[]>([]);
  const [paymentStatusLoading, setPaymentStatusLoading] = useState(true);

  useEffect(() => {
    const fetchPayments = async () => {
      const uId = user?.id;
      if (!uId) {
        setPaymentStatusLoading(false);
        return;
      }
      try {
        const qSnap = await getDocs(query(collection(db, "payments"), where("student_id", "==", uId)));
        const list = qSnap.docs.map(doc => doc.data());
        setPayments(list);
      } catch (err) {
        console.error("Error fetching payments for ID card:", err);
      } finally {
        setPaymentStatusLoading(false);
      }
    };
    fetchPayments();
  }, [user]);

  const checkCurrentMonthPayment = () => {
    if (paymentStatusLoading) return { month: 'Loading', isPaid: false, statusLabel: 'LOADING...' };
    
    const d = new Date();
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const currentMonth = monthNames[d.getMonth()];
    const currentYear = d.getFullYear();

    const isPaid = payments.some(
      (p: any) =>
        (p.type === "monthly" || p.type === "admission") && 
        p.month && 
        p.month.toLowerCase() === currentMonth.toLowerCase() &&
        String(p.year || (p.date ? new Date(p.date).getFullYear() : "")) === String(currentYear)
    );

    return {
      month: currentMonth,
      isPaid,
      statusLabel: isPaid ? "PAID" : "UNPAID"
    };
  };

  const getPaidMonthsList = () => {
    if (paymentStatusLoading) return [];
    const paid = payments
      .filter((p: any) => p.type === 'monthly' || p.type === 'admission')
      .map((p: any) => p.month)
      .filter(Boolean);
    const uniqueMonths = Array.from(new Set(paid)).map((m: string) => {
      return m.charAt(0).toUpperCase() + m.slice(1).toLowerCase();
    });
    return uniqueMonths;
  };

  useEffect(() => {
    const fetchBatchName = async () => {
      if (!user?.batch_id) {
        setRealBatchName('Not Assigned');
        return;
      }
      try {
        const batchIdStr = String(user.batch_id);
        const batchDoc = await getDoc(doc(db, 'batches', batchIdStr));
        if (batchDoc.exists()) {
          setRealBatchName(String(batchDoc.data()?.name || batchIdStr));
        } else {
          setRealBatchName(String(user.batch_name || user.batch_id_2 || batchIdStr));
        }
      } catch (err) {
        console.error("Error fetching batch name:", err);
        setRealBatchName(String(user.batch_name || user.batch_id));
      }
    };
    fetchBatchName();
  }, [user?.batch_id, user?.batch_name]);

  useEffect(() => {
    const convertToBase64 = async (url: string, setter: (val: string | null) => void) => {
      try {
        const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(url)}`;
        const response = await fetch(proxyUrl);
        if (!response.ok) throw new Error("Proxy fetch failed");
        const blob = await response.blob();
        const reader = new FileReader();
        reader.onloadend = () => {
          setter(reader.result as string);
        };
        reader.readAsDataURL(blob);
      } catch (err) {
        console.error("Error converting profile picture to base64:", err);
        setter(null); // Fallback to initials to prevent image taint failures
      }
    };

    if (user?.profile_pic) {
      if (user.profile_pic.startsWith('data:')) {
        setProfilePicDataUrl(user.profile_pic);
      } else {
        convertToBase64(user.profile_pic, setProfilePicDataUrl);
      }
    } else {
      setProfilePicDataUrl(null);
    }
  }, [user?.profile_pic]);

  useEffect(() => {
    const convertToBase64 = async (url: string, setter: (val: string | null) => void) => {
      try {
        const proxyUrl = `/api/proxy-image?url=${encodeURIComponent(url)}`;
        const response = await fetch(proxyUrl);
        if (!response.ok) throw new Error("Proxy fetch failed");
        const blob = await response.blob();
        const reader = new FileReader();
        reader.onloadend = () => {
          setter(reader.result as string);
        };
        reader.readAsDataURL(blob);
      } catch (err) {
        console.error("Error converting logo to base64:", err);
        setter(null); // Fallback to icon to avoid image taint failures
      }
    };

    if (settings?.logo_url) {
      if (settings.logo_url.startsWith('data:')) {
        setLogoDataUrl(settings.logo_url);
      } else {
        convertToBase64(settings.logo_url, setLogoDataUrl);
      }
    } else {
      setLogoDataUrl(null);
    }
  }, [settings?.logo_url]);

  const handleDownloadPDF = async () => {
    if (cardRef.current) {
      setDownloading(true);
      try {
        await new Promise(resolve => setTimeout(resolve, 250));
        
        const canvas = await html2canvas(cardRef.current, {
          useCORS: true,
          allowTaint: false, // Set to false to avoid tainting and ensure toDataURL succeeds
          scale: 2,
          backgroundColor: '#ffffff',
          logging: false,
          onclone: (clonedDoc) => {
            const images = clonedDoc.getElementsByTagName('img');
            for (let i = 0; i < images.length; i++) {
              images[i].crossOrigin = "anonymous";
            }
          }
        });
        
        const imgData = canvas.toDataURL('image/png', 1.0);
        const pdf = new jsPDF({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4'
        });
        
        // A4 standard width is 210mm, height is 297mm
        const a4Width = 210;
        const a4Height = 297;
        
        // Define card width as 85mm (Standard identity card size) and calculate proportional height
        const cardWidthMM = 85;
        const cardHeightMM = cardWidthMM * (canvas.height / canvas.width);
        
        // Center the card on the standard A4 document
        const xPos = (a4Width - cardWidthMM) / 2;
        const yPos = (a4Height - cardHeightMM) / 2;
        
        pdf.addImage(imgData, 'PNG', xPos, yPos, cardWidthMM, cardHeightMM);
        
        const blob = pdf.output('blob');
        const blobUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = blobUrl;
        link.download = `ID_${user?.roll_number || 'STUDENT'}_${Date.now()}.pdf`;
        
        // Firefox requires the link to be in the body
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        setTimeout(() => {
          URL.revokeObjectURL(blobUrl);
        }, 1000);
      } catch (err) {
        console.error("PDF download failed", err);
        // Robust fallback: open card in clean in-app modal view
        try {
          if (cardRef.current) {
            const canvas = await html2canvas(cardRef.current, { useCORS: true, allowTaint: false, scale: 2 });
            const imgData = canvas.toDataURL('image/png');
            setFallbackImage(imgData);
          }
        } catch (e) {
          alert("Could not generate ID. If downloading fails, try opening the site in a new tab.");
        }
      } finally {
        setDownloading(false);
      }
    }
  };

  const handleDownloadImage = async () => {
    if (cardRef.current) {
      setDownloading(true);
      try {
        await new Promise(resolve => setTimeout(resolve, 250));

        const canvas = await html2canvas(cardRef.current, {
          useCORS: true,
          allowTaint: false,
          scale: 2.5,
          backgroundColor: '#ffffff',
          logging: false
        });
        
        try {
          const imgData = canvas.toDataURL('image/png', 1.0);
          setFallbackImage(imgData);
          
          const link = document.createElement('a');
          link.download = `ID_${user?.roll_number || 'STUDENT'}_${Date.now()}.png`;
          link.href = imgData;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        } catch (taintErr) {
          console.warn("Direct trigger download failed, displaying in fallback modal:", taintErr);
          const imgUrl = canvas.toDataURL('image/png');
          setFallbackImage(imgUrl);
        }
      } catch (err) {
        console.error("Image download failed", err);
        alert("Could not generate ID. If downloading fails, try opening the site in a new tab.");
      } finally {
        setDownloading(false);
      }
    }
  };

  if (!user) return null;

  const getBatchName = () => {
    return realBatchName;
  };

  return (
    <div className="space-y-10 animate-fade-in pb-20">
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div>
          <h1 className="text-3xl lg:text-4xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <CreditCard className="h-10 w-10 text-orange-600" />
            Student ID Card
          </h1>
          <p className="text-slate-500 mt-2 font-semibold tracker-tight">Official Identity documentation for {(settings.site_name || "Jaber Math Care")}</p>
        </div>
        
        <div className="flex flex-wrap gap-4 w-full lg:w-auto">
          <button
            onClick={handleDownloadPDF}
            disabled={downloading}
            className="flex-1 lg:flex-none bg-slate-900 text-white px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-slate-950/20 hover:bg-slate-800 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2.5 disabled:opacity-50 disabled:cursor-not-allowed group"
          >
            <Printer className="h-4 w-4 group-hover:rotate-12 transition-transform" />
            {downloading ? "Processing..." : "Download PDF"}
          </button>
          <button
            onClick={handleDownloadImage}
            disabled={downloading}
            className="flex-1 lg:flex-none bg-orange-600 text-white px-6 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-orange-600/20 hover:bg-orange-700 hover:scale-105 active:scale-95 transition-all flex items-center justify-center gap-2.5 disabled:opacity-50 disabled:cursor-not-allowed group"
          >
            <ImageIcon className="h-4 w-4 group-hover:-translate-y-0.5 transition-transform" />
            {downloading ? "Processing..." : "Save Image"}
          </button>
        </div>
      </div>

      <div className="flex justify-center pt-4 lg:pt-8 overflow-x-auto max-w-full pb-4 px-2">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          ref={cardRef}
          className="relative bg-white shadow-[0_20px_60px_-15px_rgba(234,88,12,0.3)] overflow-hidden rounded-[2rem] border-2 border-orange-100 flex flex-col group p-0 select-none text-left"
          style={{ width: '320px', height: '650px' }}
        >
          {/* Top Decorative Background Segment */}
          <div className="absolute top-0 left-0 right-0 h-40 bg-gradient-to-br from-orange-600 via-orange-500 to-amber-500 z-0">
             <div className="absolute inset-0 opacity-20 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" />
             {/* Subdued curve to break the straight line */}
             <svg className="absolute bottom-[-1px] left-0 w-full text-white" viewBox="0 0 1440 320" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
               <path d="M0,256L48,229.3C96,203,192,149,288,154.7C384,160,480,224,576,218.7C672,213,768,139,864,128C960,117,1056,171,1152,197.3C1248,224,1344,224,1392,224L1440,224L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
             </svg>
          </div>

          {/* Header Layer */}
          <div className="relative pt-6 px-4 flex flex-col items-center justify-center gap-1 z-20 text-white w-full">
            <div className="flex items-center gap-3">
              {(logoDataUrl || settings.logo_url) ? (
                <img src={logoDataUrl || settings.logo_url} alt="Logo" className="w-10 h-10 object-contain drop-shadow-md bg-white/20 p-1 rounded-xl backdrop-blur-md border border-white/20 shrink-0" crossOrigin="anonymous" referrerPolicy="no-referrer" />
              ) : (
                <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md border border-white/20 shadow-sm shrink-0">
                  <School className="h-6 w-6 text-white" />
                </div>
              )}
              <h2 className="text-xl font-black tracking-tighter drop-shadow-md leading-none">{(settings.site_name || "JABER MATH CARE").toUpperCase()}</h2>
            </div>
            <p className="text-[7.5px] font-bold uppercase tracking-[0.1em] mt-1 opacity-95 drop-shadow-sm text-orange-50 text-center">THE FUTURE OF MATH EDUCATION</p>
          </div>

          {/* Profile Picture centered overlapping the curve */}
          <div className="relative mt-8 flex justify-center z-20">
            <div className="w-28 h-28 bg-white rounded-full border-4 border-white shadow-[0_10px_25px_-5px_rgba(234,88,12,0.4)] overflow-hidden z-20 relative">
               <div className="w-full h-full rounded-full overflow-hidden bg-orange-50 flex items-center justify-center relative">
                  {(profilePicDataUrl || user.profile_pic) ? (
                    <img src={profilePicDataUrl || user.profile_pic} alt={user.name} className="w-full h-full object-cover" crossOrigin="anonymous" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="text-4xl font-black text-orange-300 uppercase">
                      {user.name?.charAt(0)}
                    </div>
                  )}
               </div>
            </div>
          </div>

          {/* Student Name Box */}
          <div className="relative mt-3 px-6 z-20 text-center">
             <h3 className="text-xl font-black text-slate-800 uppercase tracking-tight truncate drop-shadow-sm">{user.name}</h3>
             <p className="text-[10px] font-bold text-orange-500 uppercase tracking-widest mt-1 bg-orange-50 inline-block px-3 py-1 rounded-full border border-orange-100">STUDENT ID</p>
          </div>

          {/* Info Rows */}
          <div className="relative mt-5 px-6 space-y-2.5 z-20 flex-1 w-full mx-auto max-w-[260px]">
            {[
              { label: 'Class', value: user.current_class || user.class || 'HSC 27' },
              { label: 'Batch Name', value: getBatchName() },
              { label: 'Roll No', value: user.roll_number || '---' },
              { label: 'Blood Grp', value: user.blood_group || 'N/A' },
              { label: 'Phone No', value: user.phone || '01XXXXXXXXX' }
            ].map((item, idx) => (
              <div key={idx} className="flex items-center justify-between border-b border-slate-100 pb-1.5 last:border-b-0">
                 <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">{item.label}</span>
                 <span className="text-[10px] font-black text-slate-800 uppercase text-right max-w-[140px] truncate">
                   {item.value}
                 </span>
              </div>
            ))}
          </div>

          {/* QR Footer */}
          <div className="relative mt-auto z-20 flex flex-col items-center justify-end pb-8">
             <div className="bg-white p-3 rounded-2xl border-[3px] border-orange-100 shadow-md transform hover:scale-105 transition-transform z-20 mt-4">
                <QRCodeCanvas 
                   value={`JABER-MATH-${String(user.batch_id || '0').replace(/\s+/g, '_')}-${String(user.current_class || user.class || '0').replace(/\s+/g, '_')}-${user.roll_number || user.id}`}
                   size={110}
                   level="H"
                   includeMargin={false}
                   fgColor="#ea580c"
                />
             </div>
             <p className="text-[8px] font-black text-slate-400 uppercase tracking-[0.2em] text-center mt-2.5 bg-slate-50 px-4 py-1.5 rounded-full border border-slate-100 shadow-sm z-20">Scan For Official Auth</p>
          </div>
          
          <div className="absolute right-0 bottom-1/4 scale-150 opacity-[0.03] pointer-events-none rotate-90 z-0 select-none">
            <School className="w-64 h-64 text-orange-900" />
          </div>
        </motion.div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
        <div className="glass p-6 rounded-3xl border border-white/60 shadow-lg group hover:bg-white transition-colors">
          <div className="flex gap-4">
            <div className="bg-orange-100 p-3 rounded-2xl shrink-0">
               <ShieldCheck className="h-6 w-6 text-orange-600" />
            </div>
            <div>
               <h4 className="text-base font-black text-slate-900 mb-1">Official ID Security</h4>
               <p className="text-xs text-slate-500 font-medium leading-relaxed">
                 এটি আপনার ডিজিটাল পরিচয়। আপনার বারকোডটি স্ক্যান করে যেকোনো সময় আপনার উপস্থিতি নিশ্চিত করা যাবে।
               </p>
            </div>
          </div>
        </div>
        <div className="glass p-6 rounded-3xl border border-white/60 shadow-lg group hover:bg-white transition-colors">
          <div className="flex gap-4">
            <div className="bg-slate-100 p-3 rounded-2xl shrink-0">
               <Printer className="h-6 w-6 text-slate-600" />
            </div>
            <div>
               <h4 className="text-base font-black text-slate-900 mb-1">Printing Support</h4>
               <p className="text-xs text-slate-500 font-medium leading-relaxed">
                 কার্ডটি পিডিএফ অথবা ইমেজ হিসেবে ডাউনলোড করে প্রিন্ট করে আপনার সাথে সংরক্ষণ করতে পারেন।
               </p>
            </div>
          </div>
        </div>
      
      {/* Fallback Image Modal */}
      {fallbackImage && (
        <div className="fixed inset-0 z-[99999] bg-slate-900/90 flex flex-col items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white p-6 rounded-3xl max-w-sm w-full flex flex-col items-center gap-4 text-center shadow-2xl relative">
            <button onClick={() => setFallbackImage(null)} className="absolute right-4 top-4 bg-slate-100 p-2 rounded-full text-slate-500 hover:text-slate-800">
              <X className="w-5 h-5" />
            </button>
            <div className="text-orange-600 bg-orange-50 p-3 rounded-full mb-2">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="font-black text-xl text-slate-800 tracking-tight">ID Card Ready!</h3>
            <p className="text-sm text-slate-600 leading-relaxed">
              Due to browser restrictions, direct download was blocked. 
              <br/><br/>
              <b>Mobile:</b> Long-press the image below to "Save Image".<br/>
              <b>PC:</b> Right-click to "Save Image As...".
            </p>
            <div className="mt-4 border-4 border-slate-100 rounded-2xl overflow-hidden shadow-lg">
              <img src={fallbackImage} alt="ID Card Fallback" className="w-full h-auto object-contain" />
            </div>
          </div>
        </div>
      )}

    </div>
    </div>
  );
};

export default IDCard;
