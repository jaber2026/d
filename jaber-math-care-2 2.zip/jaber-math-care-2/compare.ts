import * as fs from 'fs';
import * as path from 'path';

function getFiles(dir: string): string[] {
  let results: string[] = [];
  const list = fs.readdirSync(dir);
  list.forEach((file) => {
    const filePath = path.join(dir, file);
    const stat = fs.statSync(filePath);
    if (stat && stat.isDirectory()) {
      results = results.concat(getFiles(filePath));
    } else {
      results.push(filePath);
    }
  });
  return results;
}

const originalFiles = getFiles('src').map(p => path.relative('src', p));
const extractedFiles = getFiles('temp_extracted/src').map(p => path.relative('temp_extracted/src', p));

console.log('Comparing files...');
const commonFiles = originalFiles.filter(f => extractedFiles.includes(f));

for (const file of commonFiles) {
  const origContent = fs.readFileSync(path.join('src', file), 'utf-8');
  const extContent = fs.readFileSync(path.join('temp_extracted/src', file), 'utf-8');
  if (origContent !== extContent) {
    console.log(`DIFFERENCE IN: ${file}`);
  }
}

const onlyInOrig = originalFiles.filter(f => !extractedFiles.includes(f));
const onlyInExt = extractedFiles.filter(f => !originalFiles.includes(f));

console.log('Only in original project:', onlyInOrig);
console.log('Only in extracted project:', onlyInExt);
