import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Database, TrendingUp, TrendingDown, Clock, Activity, Zap } from 'lucide-react';

interface FirebaseActivityLog {
  id: number;
  type: 'read' | 'write' | 'sync';
  details: string;
  timestamp: string;
  count: number;
}

interface FirebaseMonitorProps {
  reads: number;
  writes: number;
  logs: FirebaseActivityLog[];
}

export const FirebaseMonitor: React.FC<FirebaseMonitorProps> = ({ reads, writes, logs }) => {
  return (
    <div className="glass p-8 rounded-[2.5rem] border border-white/60 bg-white/30 backdrop-blur-xl shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-orange-500/5 rounded-full blur-[80px] -mr-32 -mt-32"></div>
      
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-10 relative z-10">
        <div>
          <h3 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-3">
            <div className="p-2.5 bg-orange-100 rounded-2xl text-orange-600">
              <Database className="h-6 w-6" />
            </div>
            Firebase Real-time Sync Monitor
          </h3>
          <p className="text-xs font-black text-slate-400 uppercase tracking-widest mt-1 ml-14">
            Live Traffic Analysis • Session Activity Tracking
          </p>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="px-4 py-2 bg-emerald-50 border border-emerald-100 rounded-2xl flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></div>
            <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Live Gateway</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 relative z-10">
        {/* Read Stats */}
        <div className="p-6 rounded-[2rem] bg-indigo-50/50 border border-indigo-100 relative group transition-all hover:shadow-lg">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-black text-indigo-400 uppercase tracking-widest mb-1">Total Reads</p>
              <h4 className="text-4xl font-black text-indigo-600 tracking-tighter tabular-nums">
                {reads.toLocaleString()}
              </h4>
            </div>
            <div className="p-3 bg-white rounded-2xl shadow-sm text-indigo-500 group-hover:scale-110 transition-transform">
              <TrendingUp className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2">
            <span className="text-[10px] font-black text-indigo-400/60 uppercase">Documents Synced</span>
            <div className="h-1 flex-1 bg-indigo-100 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-indigo-500"
                initial={{ width: 0 }}
                animate={{ width: '65%' }}
              />
            </div>
          </div>
        </div>

        {/* Write Stats */}
        <div className="p-6 rounded-[2rem] bg-orange-50/50 border border-orange-100 relative group transition-all hover:shadow-lg">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-black text-orange-400 uppercase tracking-widest mb-1">Total Writes</p>
              <h4 className="text-4xl font-black text-orange-600 tracking-tighter tabular-nums">
                {writes.toLocaleString()}
              </h4>
            </div>
            <div className="p-3 bg-white rounded-2xl shadow-sm text-orange-500 group-hover:scale-110 transition-transform">
              <Zap className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2">
            <span className="text-[10px] font-black text-orange-400/60 uppercase">Ops Captured</span>
            <div className="h-1 flex-1 bg-orange-100 rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-orange-500"
                initial={{ width: 0 }}
                animate={{ width: '40%' }}
              />
            </div>
          </div>
        </div>

        {/* Health Stats */}
        <div className="p-6 rounded-[2rem] bg-emerald-50/50 border border-emerald-100 relative group transition-all hover:shadow-lg">
          <div className="flex justify-between items-start">
            <div>
              <p className="text-[10px] font-black text-emerald-400 uppercase tracking-widest mb-1">Latency Hub</p>
              <h4 className="text-4xl font-black text-emerald-600 tracking-tighter tabular-nums">
                8ms
              </h4>
            </div>
            <div className="p-3 bg-white rounded-2xl shadow-sm text-emerald-500 group-hover:scale-110 transition-transform">
              <Activity className="h-5 w-5" />
            </div>
          </div>
          <div className="mt-4 flex items-center gap-2">
            <span className="text-[10px] font-black text-emerald-400/60 uppercase">System Status</span>
            <span className="text-[10px] font-black text-emerald-600 uppercase bg-white px-2 py-0.5 rounded-full border border-emerald-100">Optimal</span>
          </div>
        </div>
      </div>

      <div className="mt-10 relative z-10">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-2 bg-slate-900 rounded-xl text-white">
            <Clock className="h-4 w-4" />
          </div>
          <h4 className="text-sm font-black text-slate-800 uppercase tracking-widest">Real-time Activity Stream</h4>
        </div>

        <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 scrollbar-hide font-mono text-[11px]">
          <AnimatePresence mode="popLayout" initial={false}>
            {logs.length === 0 ? (
              <div className="p-10 text-center border-2 border-dashed border-slate-100 rounded-3xl text-slate-400 italic">
                Awaiting incoming WebSocket packets...
              </div>
            ) : (
              logs.map((log) => (
                <motion.div
                  key={log.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="flex items-center justify-between p-4 bg-white border border-slate-100 rounded-[1.5rem] shadow-sm hover:border-orange-200 transition-colors group"
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-2 h-2 rounded-full ${
                      log.type === 'write' ? 'bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.6)]' : 
                      log.type === 'read' ? 'bg-indigo-500 shadow-[0_0_8px_rgba(79,70,229,0.6)]' : 
                      'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]'
                    }`} />
                    <span className="text-slate-400 font-bold w-16">{log.timestamp}</span>
                    <span className={`font-black uppercase tracking-widest text-[9px] px-2 py-0.5 rounded-md ${
                      log.type === 'write' ? 'bg-orange-50 text-orange-600' : 
                      log.type === 'read' ? 'bg-indigo-50 text-indigo-600' : 
                      'bg-emerald-50 text-emerald-600'
                    }`}>
                      {log.type}
                    </span>
                    <span className="text-slate-600 font-bold group-hover:text-slate-900 transition-colors uppercase">{log.details}</span>
                  </div>
                  <div className="bg-slate-50 px-3 py-1 rounded-full border border-slate-100 text-slate-400 font-black">
                    +{log.count} docs
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
        
        <div className="mt-6 p-4 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-between">
           <div className="flex items-center gap-3">
             <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
             <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                Firebase Web SDK Stream (v9.x) • Authored by AI Agent
             </p>
           </div>
           <p className="text-[10px] font-mono font-black text-emerald-500">
             CONNECTED_ID: {Math.random().toString(36).substring(7).toUpperCase()}
           </p>
        </div>
      </div>
    </div>
  );
};
