# Deployment Guide

This application is a full-stack React app with a Firebase Firestore backend. It uses a custom Express server to serve the frontend and handle routing.

## Prerequisites

-   **Firebase Project**: You must have a Firebase project set up with Firestore and Authentication enabled.
-   **Environment Variables**: Ensure all required environment variables are set in your hosting provider's dashboard.

## Deployment Options

### 1. Vercel / Netlify (Recommended)

Since this app uses Firebase Firestore for its database, it is fully compatible with serverless platforms like Vercel or Netlify.

**Build Settings:**
-   **Build Command**: `npm run build`
-   **Output Directory**: `dist`
-   **Install Command**: `npm install`

**Environment Variables:**
-   Ensure `GOOGLE_MAPS_PLATFORM_KEY` is set if you are using Google Maps features.
-   Firebase configuration is handled via `firebase-applet-config.json`. Ensure this file is included in your repository or its contents are correctly managed.

### 2. Render / Railway / DigitalOcean

You can also deploy this app as a standard Node.js application.

**Build Settings:**
-   **Build Command**: `npm run build`
-   **Start Command**: `npm start`

## Troubleshooting

-   **Firebase Errors**: If you see "Missing or insufficient permissions," check your Firestore Security Rules.
-   **Google Maps**: If maps are not loading, verify your `GOOGLE_MAPS_PLATFORM_KEY` is valid and has the necessary APIs enabled.
