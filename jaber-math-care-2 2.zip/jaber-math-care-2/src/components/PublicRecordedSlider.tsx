import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { Play, Youtube, ArrowRight, Calendar, Bookmark } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useRealtimeCollection } from '../hooks/useRealtime';

const PublicRecordedSlider = () => {
  const { data: webClassesRaw } = useRealtimeCollection('web_recorded_classes');

  const webClasses = useMemo(() => {
    const getMs = (val: any) => {
      if (!val) return 0;
      if (typeof val === 'object' && val.seconds !== undefined) return val.seconds * 1000;
      if (typeof val === 'string') return new Date(val).getTime();
      if (val instanceof Date) return val.getTime();
      if (typeof val === 'number') return val;
      return 0;
    };
    return [...(webClassesRaw || [])]
      .sort((a: any, b: any) => {
        return getMs(b.created_at || b.createdAt) - getMs(a.created_at || a.createdAt);
      })
      .slice(0, 3); // Display the 3 most recent classes on the home page
  }, [webClassesRaw]);

  const getYoutubeThumbnail = (url: string) => {
    if (!url) return 'fallback';
    let videoId = '';
    const regExp = /(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/;
    const match = url.match(regExp);
    if (match && match[1]) {
      videoId = match[1];
    }
    if (videoId) {
      return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
    }
    return 'fallback';
  };

  const formatDate = (val: any) => {
    if (!val) return 'Recently';
    let date: Date;
    if (typeof val === 'object' && val.seconds !== undefined) {
      date = new Date(val.seconds * 1000);
    } else if (typeof val === 'string') {
      date = new Date(val);
    } else if (val instanceof Date) {
      date = val;
    } else if (typeof val === 'number') {
      date = new Date(val);
    } else {
      return 'Recently';
    }
    return isNaN(date.getTime()) ? 'Recently' : date.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
  };

  if (webClasses.length === 0) return null;

  return (
    <div className="bg-slate-50 pt-16 pb-20 px-4 md:px-8 relative overflow-hidden border-t border-slate-200/60 animate-fade-in">
      <div className="max-w-7xl mx-auto">
        <div className="text-center max-w-3xl mx-auto mb-12 relative z-10 space-y-4">
          <span className="inline-block px-4 py-1.5 rounded-full bg-orange-100 text-orange-600 font-bold text-xs uppercase tracking-widest border border-orange-200">
            Free Live Classes
          </span>
          <h2 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tight flex items-center justify-center gap-3">
            <Youtube className="w-8 h-8 md:w-10 md:h-10 text-orange-600 fill-orange-600 shrink-0" />
            Free Recorded Classes
          </h2>
          <p className="text-slate-500 font-medium text-base md:text-lg">
            Syllabus-wise concept clear recorded classes to strengthen your math foundation.
          </p>
        </div>

        {/* 3-Column Grid Showing Free Recorded Classes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12 z-10 relative">
          {webClasses.map((video: any, idx: number) => {
            const thumbnail = getYoutubeThumbnail(video.url);
            return (
              <motion.div
                key={video.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="bg-white rounded-[2rem] overflow-hidden border border-slate-100 shadow-xl shadow-slate-200/30 flex flex-col group hover:-translate-y-2 transition-all duration-300"
              >
                <a 
                  href={video.url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="block relative aspect-video bg-slate-950 overflow-hidden"
                >
                  {thumbnail === 'fallback' ? (
                    <div className="w-full h-full bg-slate-900 flex items-center justify-center">
                      <Youtube className="h-16 w-16 text-slate-700" />
                    </div>
                  ) : (
                    <img 
                      src={thumbnail} 
                      alt={video.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-90 group-hover:opacity-100" 
                      referrerPolicy="no-referrer"
                    />
                  )}
                  <div className="absolute inset-0 bg-black/10 group-hover:bg-black/40 transition-colors duration-300" />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 bg-orange-600 hover:bg-orange-700 text-white rounded-full flex items-center justify-center shadow-lg shadow-orange-600/30 transform group-hover:scale-110 transition-all duration-300">
                      <Play className="h-5 w-5 ml-0.5 fill-current" />
                    </div>
                  </div>
                </a>

                <div className="p-6 flex flex-col flex-1 justify-between">
                  <div>
                    {video.playlist && (
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-orange-50 text-orange-600 text-[10px] font-black uppercase tracking-widest rounded-full mb-3 border border-orange-100">
                        <Bookmark className="w-3 h-3 text-orange-500" />
                        {video.playlist}
                      </span>
                    )}
                    <a 
                      href={video.url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="block group"
                    >
                      <h3 className="text-lg font-black text-slate-900 line-clamp-2 leading-snug group-hover:text-orange-600 transition-colors mb-4">
                        {video.title}
                      </h3>
                    </a>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-slate-50 text-slate-400">
                    <div className="flex items-center gap-2">
                      <Calendar className="h-4 w-4 text-slate-400" />
                      <span className="text-xs font-bold">{formatDate(video.created_at)}</span>
                    </div>
                    <a 
                      href={video.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-orange-600 font-extrabold text-xs uppercase tracking-widest flex items-center gap-1 group-hover:gap-2 transition-all"
                    >
                      Watch <ArrowRight className="h-4 w-4" />
                    </a>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Navigation Button */}
        <div className="flex justify-center z-10 relative">
          <Link
            to="/recorded-classes"
            className="px-10 py-4.5 bg-orange-600 hover:bg-neutral-900 text-white font-black text-xs uppercase tracking-widest rounded-2xl shadow-xl shadow-orange-600/10 hover:shadow-neutral-900/10 transition-all duration-300 active:scale-95 flex items-center gap-3 group"
          >
            Watch All Recorded Classes 
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default PublicRecordedSlider;
