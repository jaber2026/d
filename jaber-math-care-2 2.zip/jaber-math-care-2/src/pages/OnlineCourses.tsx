import { useRealtimeCollection } from '../hooks/useRealtime';
import { useSettings } from '../context/SettingsContext';
import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { motion, AnimatePresence } from 'motion/react';
import { useLocation, Link } from 'react-router-dom';
import { BookOpen, CheckCircle2, X, Send, Copy, Clock, PlayCircle, UserPlus, Share2 } from 'lucide-react';
import { showAlert, copyToClipboard } from '../utils/alert';

const OnlineCourses = () => {
  const { data: courses, loading: coursesLoading } = useRealtimeCollection('courses');
  const { data: batches } = useRealtimeCollection('batches');
  const { data: recordedClasses } = useRealtimeCollection('web_recorded_classes');
  const { settings } = useSettings();
  const location = useLocation();

  const loading = coursesLoading;
  const [selectedCourse, setSelectedCourse] = useState<any>(null);
  const [selectedCourseIdForDesc, setSelectedCourseIdForDesc] = useState<string[]>([]);
  const [isEnrolling, setIsEnrolling] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [couponCode, setCouponCode] = useState("");
  const [discount, setDiscount] = useState(0);
  const [validatingCoupon, setValidatingCoupon] = useState(false);
  const currentMonthName = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][new Date().getMonth()];

  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    gmail: '',
    password: '',
    transaction_id: '',
    payment_number: '',
    payment_method: '',
    admission_month: currentMonthName,
    extra_payment: '0',
    address: '',
    profile_pic: ''
  });

  useEffect(() => {
    const searchParams = new URLSearchParams(location.search);
    const courseIdMap = searchParams.get('course');
    if (courseIdMap && courses.length > 0) {
      const c = courses.find((course) => String(course.id) === String(courseIdMap));
      if (c) {
        setSelectedCourse(c);
      }
    }
  }, [location.search, courses]);

  useEffect(() => {
    if (selectedCourse) {
      const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
      document.body.style.paddingRight = `${scrollbarWidth}px`;
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
      document.body.style.paddingRight = '0px';
    }
    return () => {
      document.body.style.overflow = 'unset';
      document.body.style.paddingRight = '0px';
    };
  }, [selectedCourse]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 500000) { // 500KB limit
        showAlert('Image size should be less than 500KB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData({ ...formData, profile_pic: reader.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const getCourseClassCount = (courseId: string) => {
    return recordedClasses.filter(c => c.course_id === courseId).length;
  };

  const handleApplyCoupon = async () => {
    if (!couponCode) return;
    try {
      setValidatingCoupon(true);
      const res = await fetch("/api/validate-coupon", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: couponCode, amount: selectedCourse?.price || 0 })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || "Invalid coupon code");
      }
      const data = await res.json();
      setDiscount(data.discount);
      showAlert(`Coupon applied! You saved ৳${data.discount}`, "success");
    } catch (e: any) {
      setDiscount(0);
      showAlert(e.message, "error");
    } finally {
      setValidatingCoupon(false);
    }
  };

  const handleEnroll = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isEnrolling) return;
    setIsEnrolling(true);
    try {
      const enrollmentfee = Math.max(0, (selectedCourse?.price || 0) - discount);

      const res = await fetch('/api/enrollments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          course_id: selectedCourse.id,
          course_title: selectedCourse.title,
          student_type: 'online', // Mark as online student
          current_class: selectedCourse.target_audience || selectedCourse.class || "",
          class: selectedCourse.target_audience || selectedCourse.class || "",
          fee: enrollmentfee,
          discount_amount: discount,
          coupon_code: couponCode,
          status: 'pending'
        })
      });
      if (res.ok) {
        setIsSuccess(true);
        setTimeout(() => {
          setIsSuccess(false);
          setSelectedCourse(null);
          setFormData({ 
            name: '', 
            phone: '', 
            gmail: '', 
            password: '', 
            transaction_id: '', 
            payment_number: '', 
            payment_method: '',
            admission_month: currentMonthName, 
            extra_payment: '0', 
            address: '',
            profile_pic: '' 
          });
        }, 1000);
      } else {
        const err = await res.json();
        showAlert(err.error || 'Failed to submit enrollment. Please try again.');
      }
    } catch (error) {
      console.error(error);
      showAlert('An error occurred. Please try again.');
    } finally {
      setIsEnrolling(false);
    }
  };

  if (loading) return (
    <div className="min-h-screen bg-slate-50 pt-4 md:pt-8 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="h-10 w-64 bg-slate-200 rounded-lg mx-auto mb-4 animate-pulse"></div>
          <div className="h-4 w-96 bg-slate-200 rounded-lg mx-auto animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[1, 2, 3].map((i) => (
            <div key={i} className="glass rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/60 bg-white h-96 animate-pulse">
              <div className="h-48 bg-slate-200/50"></div>
              <div className="p-6 space-y-4">
                <div className="h-6 bg-slate-200 rounded w-3/4"></div>
                <div className="h-4 bg-slate-200 rounded w-full"></div>
                <div className="h-12 bg-slate-200 rounded w-full"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-50 pt-12 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="section-title">Online Courses</h1>
          <p className="section-subtitle">
            Learn from anywhere with our premium recorded and live courses.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <motion.div 
              key={course.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5 }}
              className="glass rounded-[2.5rem] shadow-2xl overflow-hidden border border-white/60 bg-white group"
            >
              <div className="h-48 bg-slate-200 relative overflow-hidden">
                <img 
                  src={course.image_url || `https://picsum.photos/seed/course${course.id}/800/600`} 
                  alt={course.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute top-4 left-4 glass bg-white/60 backdrop-blur-md text-slate-800 text-xs font-black h-8 w-8 flex items-center justify-center rounded-full shadow-lg border border-white/60">
                  {String(index + 1).padStart(2, '0')}
                </div>
                <div className="absolute top-4 right-4 bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-lg border border-orange-400/50">
                  PREMIUM
                </div>
              </div>
              <div className="p-8">
                <h3 className="text-xl font-black text-slate-900 mb-3 tracking-tight">{course.title}</h3>
                <div className="relative">
                  <div className={`text-slate-600 text-sm mb-6 whitespace-pre-wrap leading-relaxed ${!selectedCourseIdForDesc.includes(course.id) ? 'line-clamp-3' : ''}`}>
                    {course.description}
                  </div>
                  {course.description && course.description.length > 100 && (
                    <button 
                      onClick={() => {
                        if (selectedCourseIdForDesc.includes(course.id)) {
                          setSelectedCourseIdForDesc(selectedCourseIdForDesc.filter(id => id !== course.id));
                        } else {
                          setSelectedCourseIdForDesc([...selectedCourseIdForDesc, course.id]);
                        }
                      }}
                      className="text-orange-600 text-[10px] font-black uppercase tracking-widest hover:underline mb-4 block"
                    >
                      {selectedCourseIdForDesc.includes(course.id) ? 'Show Less' : 'See More'}
                    </button>
                  )}
                </div>
                
                <div className="flex items-center gap-4 mb-8 bg-white/40 backdrop-blur-sm p-4 rounded-2xl border border-white/60 shadow-inner">
                  <div className="flex items-center gap-3 text-slate-600 flex-1">
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-orange-600 shadow-sm border border-white/60">
                      <Clock className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="text-sm font-black text-slate-800">{course.duration || 'N/A'}</div>
                      <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Duration</div>
                    </div>
                  </div>
                  <div className="w-px h-10 bg-slate-200/60"></div>
                  <div className="flex items-center gap-3 text-slate-600 flex-1 justify-end">
                    <div className="text-right">
                      <div className="text-sm font-black text-slate-800">{course.lecture_count || getCourseClassCount(course.id)}</div>
                      <div className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Lectures</div>
                    </div>
                    <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-orange-600 shadow-sm border border-white/60">
                      <PlayCircle className="h-5 w-5" />
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between mb-8">
                  <div className="flex flex-col">
                    <div className="flex items-baseline gap-2">
                      <div className="text-emerald-600 font-black text-3xl tracking-tight">
                        {course.price && Number(course.price) > 0 ? `৳${course.price}` : 'Free'}
                      </div>
                      {course.original_price && Number(course.original_price) > 0 && Number(course.original_price) !== Number(course.price) && (
                        <div className="text-slate-400 font-bold text-sm line-through">
                          ৳{course.original_price}
                        </div>
                      )}
                    </div>
                    <div className="text-slate-400 text-[10px] font-bold uppercase tracking-widest">
                      Course Fee
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      const url = `${window.location.origin}/online-courses?course=${course.id}`;
                      copyToClipboard(url);
                      showAlert("Course link copied to clipboard!", "success");
                    }}
                    className="p-3 bg-slate-100 hover:bg-orange-100 text-slate-500 hover:text-orange-600 rounded-xl transition-colors shadow-sm"
                    title="Share Course"
                  >
                    <Share2 className="w-5 h-5" />
                  </button>
                </div>
                {settings.admission_open === "true" ? (
                  <Link 
                    to={`/course/${course.id}`}
                    className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-black py-4 rounded-xl transition-all shadow-lg shadow-orange-500/30 active:scale-95 flex items-center justify-center gap-2 uppercase tracking-widest text-xs"
                  >
                    View Details
                  </Link>
                ) : (
                  <div className="w-full bg-slate-100 text-slate-500 font-black py-4 rounded-xl text-center flex items-center justify-center gap-2 uppercase tracking-widest text-xs">
                    Admission Closed
                  </div>
                )}
              </div>
            </motion.div>
          ))}
          
          {courses.length === 0 && (
            <div className="col-span-full text-center py-20 text-slate-500">
              <BookOpen className="h-16 w-16 mx-auto text-slate-300 mb-4" />
              <p className="text-xl">New courses are coming soon.</p>
            </div>
          )}
        </div>
      </div>

      {/* Enrollment Modal */}
      {createPortal(
        <AnimatePresence>
          {selectedCourse && (
            <div 
              className="fixed inset-0 z-[100000] flex items-center justify-center p-4 bg-slate-950/40 backdrop-blur-[3px] overflow-hidden"
              onClick={() => setSelectedCourse(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="bg-white w-full max-w-xl rounded-2xl md:rounded-[2.5rem] shadow-2xl overflow-hidden max-h-[90vh] flex flex-col border border-slate-200"
                onClick={(e) => e.stopPropagation()}
              >
                {isSuccess ? (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.8 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-12 text-center space-y-6 overflow-y-auto"
                  >
                    <motion.div 
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ type: "spring", stiffness: 200, damping: 15, delay: 0.1 }}
                      className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto"
                    >
                      <CheckCircle2 className="h-14 w-14" />
                    </motion.div>
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3 }}
                    >
                      <h2 className="text-3xl font-bold text-slate-900 mb-2">Registration Successful!</h2>
                      <p className="text-slate-600 text-lg">We will contact you shortly for further details.</p>
                    </motion.div>
                  </motion.div>
                ) : (
                  <>
                    <div className="p-4 md:p-6 border-b border-slate-100 flex justify-between items-center flex-shrink-0">
                      <h2 className="text-xl font-bold text-slate-800">Enrollment Form</h2>
                      <button onClick={() => { console.log('Selected Course:', selectedCourse); setSelectedCourse(null); }} className="text-slate-400 hover:text-slate-600">
                        <X className="h-6 w-6" />
                      </button>
                    </div>
                    <form onSubmit={handleEnroll} className="p-5 md:p-6 space-y-4 overflow-y-auto scrollbar-hide flex-1">
                      <div className="flex flex-col items-center mb-6">
                        <div className="w-24 h-24 bg-slate-100 rounded-full overflow-hidden mb-2 border-2 border-orange-500 relative group cursor-pointer" onClick={() => document.getElementById('profile-pic-upload')?.click()}>
                          {formData.profile_pic ? (
                            <img src={formData.profile_pic} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-400 bg-slate-100">
                              <BookOpen className="h-10 w-10 text-orange-300" />
                            </div>
                          )}
                          <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                            <span className="text-white text-[10px] font-bold uppercase transition-transform scale-90 group-hover:scale-100">Change</span>
                          </div>
                        </div>
                        <label className="text-xs font-bold text-orange-600 cursor-pointer hover:text-orange-700 uppercase tracking-wider">
                          Upload Profile Picture
                          <input id="profile-pic-upload" type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                        </label>
                      </div>
                      <div className="space-y-6">
                        <div className="border-b border-slate-100 pb-2">
                          <h3 className="text-lg font-bold text-slate-800">Personal Information</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-1">Full Name</label>
                            <input 
                              type="text" 
                              required
                              placeholder="Enter your full name"
                              className="glass-input"
                              value={formData.name}
                              onChange={(e) => setFormData({...formData, name: e.target.value})}
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-1">Mobile Number</label>
                            <input 
                              type="tel" 
                              required
                              placeholder="01XXXXXXXXX"
                              className="glass-input"
                              value={formData.phone}
                              onChange={(e) => setFormData({...formData, phone: e.target.value.replace(/\D/g, '')})}
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-1">Gmail</label>
                            <input 
                              type="email" 
                              required
                              placeholder="Enter your Gmail address"
                              className="glass-input"
                              value={formData.gmail}
                              onChange={(e) => setFormData({...formData, gmail: e.target.value})}
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-1">Login Password</label>
                            <input 
                              type="password" 
                              required
                              placeholder="Create a password"
                              className="glass-input"
                              value={formData.password}
                              onChange={(e) => setFormData({...formData, password: e.target.value})}
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-1">Class</label>
                            <input 
                              type="text" 
                              readOnly
                              value={selectedCourse.target_audience || selectedCourse.class || "Not Specified"}
                              className="glass-input bg-slate-100 text-slate-500 cursor-not-allowed"
                            />
                          </div>
                        </div>
                      </div>
  
                      <div className="space-y-4">
                        <div className="border-b border-slate-100 pb-2">
                           <h3 className="text-lg font-bold text-slate-800">Coupon Code</h3>
                           <p className="text-xs text-slate-500 mt-1">Have a coupon code? Apply it for a discount.</p>
                        </div>
                        <div className="flex gap-2">
                          <input 
                            type="text" 
                            placeholder="Enter Code" 
                            className="glass-input uppercase" 
                            value={couponCode} 
                            onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                          />
                          <button 
                            type="button" 
                            onClick={handleApplyCoupon}
                            disabled={validatingCoupon || !couponCode}
                            className="bg-slate-800 text-white px-6 rounded-xl font-bold hover:bg-slate-900 transition-all disabled:opacity-50"
                          >
                            {validatingCoupon ? "..." : "Apply"}
                          </button>
                        </div>
                        {discount > 0 && (
                          <div className="text-sm font-bold text-emerald-600 bg-emerald-50 p-2 rounded-lg border border-emerald-100 flex justify-between">
                            <span>Discount Applied:</span>
                            <span>-৳{discount}</span>
                          </div>
                        )}
                      </div>

                      <div className="space-y-6">
                        <div className="border-b border-slate-100 pb-2">
                          <h3 className="text-lg font-bold text-slate-800">Payment Details</h3>
                          <p className="text-sm text-slate-500 mt-1">Please pay the course fee of <span className="font-bold text-orange-600">৳{Math.max(0, (selectedCourse.price || 0) - discount)}</span> to one of the following numbers and provide the details below.</p>
                          <div className="mt-3 space-y-1 text-sm font-medium text-slate-700 bg-orange-50 p-3 rounded-lg border border-orange-100">
                            {settings.bkash_number && <div><span className="font-bold text-pink-600">bKash:</span> {settings.bkash_number}</div>}
                            {settings.nagad_number && <div><span className="font-bold text-orange-600">Nagad:</span> {settings.nagad_number}</div>}
                            {settings.rocket_number && <div><span className="font-bold text-purple-600">Rocket:</span> {settings.rocket_number}</div>}
                            {!settings.bkash_number && !settings.nagad_number && !settings.rocket_number && <div>Please contact admin for payment details.</div>}
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-1">Payment Method</label>
                            <select 
                              required
                              className="glass-select shadow-sm"
                              value={formData.payment_method}
                              onChange={(e) => setFormData({...formData, payment_method: e.target.value})}
                            >
                              <option value="">Select Method</option>
                              <option value="Bkash">Bkash</option>
                              <option value="Nagad">Nagad</option>
                              <option value="Rocket">Rocket</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-1">Payment Number</label>
                            <input 
                              type="tel" 
                              required
                              placeholder="Number you paid from"
                              className="glass-input"
                              value={formData.payment_number}
                              onChange={(e) => setFormData({...formData, payment_number: e.target.value.replace(/\D/g, '')})}
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-1">Transaction ID</label>
                            <input 
                              type="text" 
                              required
                              placeholder="Enter transaction ID"
                              className="glass-input"
                              value={formData.transaction_id}
                              onChange={(e) => setFormData({...formData, transaction_id: e.target.value})}
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-slate-700 mb-1">Admission Month</label>
                            <select 
                              required
                              className="glass-select shadow-sm"
                              value={formData.admission_month}
                              onChange={(e) => setFormData({...formData, admission_month: e.target.value})}
                            >
                              <option value="">Select Month</option>
                              {['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'].map(m => (
                                <option key={m} value={m}>{m}</option>
                              ))}
                            </select>
                          </div>
                        </div>
                        <div className="space-y-1">
                          <label className="block text-sm font-semibold text-slate-700 mb-1">Address</label>
                          <input 
                            type="text" 
                            required
                            placeholder="Town/City, District"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-slate-800 outline-none focus:border-orange-500 transition-colors shadow-sm"
                            value={formData.address || ""}
                            onChange={(e) => setFormData({...formData, address: e.target.value})}
                          />
                        </div>
                      </div>
                      <div className="bg-orange-50 p-4 rounded-xl border border-orange-100 mt-2">
                        <label className="flex items-start gap-3 cursor-pointer">
                          <input type="checkbox" required className="mt-1 rounded text-orange-600 focus:ring-orange-500 h-4 w-4" />
                          <span className="text-xs text-slate-600 leading-relaxed font-medium">
                            I read and agree to the <Link to="/terms" className="text-orange-600 font-bold hover:underline">Terms & Conditions</Link>, <Link to="/privacy" className="text-orange-600 font-bold hover:underline">Privacy Policy</Link>, and <Link to="/refund-policy" className="text-orange-600 font-bold hover:underline">Refund Policy</Link>. After admin approval, I will be able to log in using the provided Gmail address.
                          </span>
                        </label>
                      </div>
                      <div className="pt-4 flex gap-3">
                        <motion.button 
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                          type="button"
                          onClick={() => setSelectedCourse(null)}
                          className="flex-1 bg-slate-100 text-slate-600 font-bold py-3 md:py-4 rounded-xl md:rounded-2xl hover:bg-slate-200 transition-colors text-sm md:text-base shadow-sm"
                        >
                          Cancel
                        </motion.button>
                        <motion.button 
                          whileHover={{ scale: 1.02, backgroundColor: '#15803d' }}
                          whileTap={{ scale: 0.98 }}
                          type="submit"
                          disabled={isEnrolling}
                          className="flex-1 bg-green-600 text-white font-bold py-3 md:py-4 rounded-xl md:rounded-2xl transition-all shadow-lg shadow-green-600/20 flex items-center justify-center gap-2 text-sm md:text-base"
                        >
                          {isEnrolling ? 'Submitting...' : <><Send className="h-5 w-5" /> Submit Application</>}
                        </motion.button>
                      </div>
                    </form>
                  </>
                )}
              </motion.div>
            </div>
          )}
        </AnimatePresence>,
        document.body
      )}
    </div>
  );
};

export default OnlineCourses;
