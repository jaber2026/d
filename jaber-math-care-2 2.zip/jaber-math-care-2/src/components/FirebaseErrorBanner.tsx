import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ShieldAlert, RefreshCw, Trash2 } from 'lucide-react';

const FirebaseErrorBanner: React.FC = () => {
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleOffline = (e: any) => {
      setError(e.detail || "Firebase is offline. Check your configuration.");
    };
    window.addEventListener('firebase-offline', handleOffline);
    return () => window.removeEventListener('firebase-offline', handleOffline);
  }, []);

  const handleReset = () => {
    localStorage.removeItem("app_firebase_settings");
    window.location.reload();
  };

  if (!error) return null;

  return (
    <AnimatePresence>
      <motion.div 
        initial={{ opacity: 0, y: 50, scale: 0.9 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 20, scale: 0.95 }}
        className="fixed bottom-6 right-6 z-[9999] bg-slate-900 border border-slate-800 text-white p-5 rounded-2xl shadow-2xl max-w-sm flex flex-col gap-4"
      >
        <div className="flex items-start gap-3">
          <ShieldAlert className="h-5 w-5 text-red-500 shrink-0 mt-0.5" />
          <div className="text-xs">
            <span className="font-black block uppercase tracking-wider text-[10px] text-red-400 mb-1">Network Alert</span>
            <span className="font-medium text-slate-200 leading-relaxed">{error}</span>
          </div>
        </div>
        
        <div className="flex gap-2 justify-end pt-2 border-t border-slate-800/60">
          <button 
            onClick={handleReset}
            className="hover:bg-slate-800 text-slate-400 hover:text-white px-3 py-1.5 rounded-lg text-[10px] font-bold transition flex items-center gap-1.5 border border-slate-800"
          >
            <Trash2 className="h-3 w-3" /> Reset
          </button>
          <button 
            onClick={() => window.location.reload()}
            className="bg-red-600 text-white px-3 py-1.5 rounded-lg text-[10px] font-bold hover:bg-red-700 transition flex items-center gap-1.5 shadow-lg shadow-red-600/10"
          >
            <RefreshCw className="h-3 w-3 animate-spin-slow" /> Retry
          </button>
          <button 
            onClick={() => setError(null)}
            className="text-slate-500 hover:text-slate-300 px-2 py-1 text-[10px] font-bold transition"
          >
            Dismiss
          </button>
        </div>
      </motion.div>
    </AnimatePresence>
  );
};

export default FirebaseErrorBanner;
