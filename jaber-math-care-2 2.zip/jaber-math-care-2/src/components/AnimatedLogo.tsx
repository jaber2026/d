import React from 'react';
import { motion } from 'motion/react';
import { useSettings } from '../context/SettingsContext';

const AnimatedLogo = () => {
  const { settings } = useSettings();
  
  return (
    <motion.div
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
      className="fixed top-24 left-4 z-40 flex items-center gap-2 bg-white/80 backdrop-blur-md px-4 py-2 rounded-full shadow-lg border border-orange-100"
    >
      <motion.img
        animate={{ rotate: [0, 10, -10, 0] }}
        transition={{ duration: 2, repeat: Infinity, repeatDelay: 5 }}
        src={settings.logo_url || "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512"}
        alt="Logo"
        className="h-8 w-8 rounded-lg object-contain bg-white p-0.5 border border-orange-100 shadow-sm"
      />
      <span className="font-black text-orange-600 text-sm tracking-tight">{settings.site_name || "App Name"}</span>
    </motion.div>
  );
};

export default AnimatedLogo;
