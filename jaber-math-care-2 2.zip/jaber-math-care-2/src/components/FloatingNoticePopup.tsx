import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Calendar } from "lucide-react";
import { useRealtimeCollection } from "../hooks/useRealtime";
import { useNavigate } from "react-router-dom";

const FloatingNoticePopup = () => {
  const { data: notices } = useRealtimeCollection("notices");
  const [isVisible, setIsVisible] = useState(false);
  const [latestNotice, setLatestNotice] = useState<any>(null);
  const navigate = useNavigate();

  // Helper to resolve timestamp milliseconds correctly (supports Firebase Timestamp seconds, ISO strings, etc.)
  const getNoticeTime = (notice: any) => {
    const val = notice.created_at || notice.createdAt || notice.date;
    if (!val) return 0;
    if (typeof val === "object" && val.seconds !== undefined) {
      return val.seconds * 1000;
    }
    const d = new Date(val);
    return isNaN(d.getTime()) ? 0 : d.getTime();
  };

  // Helper to format notice date dynamically
  const formatNoticeDate = (notice: any) => {
    const val = notice.created_at || notice.createdAt || notice.date;
    if (!val) return "";
    try {
      if (typeof val === "object" && val.seconds !== undefined) {
        return new Date(val.seconds * 1000).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      }
      const d = new Date(val);
      if (isNaN(d.getTime())) return "";
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
    } catch (e) {
      return "";
    }
  };

  useEffect(() => {
    if (notices && notices.length > 0) {
      // Sort to get the most recent notice
      const sortedNotices = [...notices].sort((a: any, b: any) => {
        return getNoticeTime(b) - getNoticeTime(a);
      });

      const topNotice = sortedNotices[0];
      if (!topNotice) return;

      setLatestNotice(topNotice);
      // Wait slightly after page load so it transitions in gracefully immediately
      const timer = setTimeout(() => setIsVisible(true), 100);
      return () => clearTimeout(timer);
    }
  }, [notices]);

  const handleClose = () => {
    setIsVisible(false);
  };

  const handleViewAll = () => {
    setIsVisible(false);
    navigate("/notices");
  };

  // Lock window background scroll when the popup modal is open
  useEffect(() => {
    if (isVisible) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [isVisible]);

  if (!latestNotice) return null;

  return (
    <AnimatePresence>
      {isVisible && (
        <>
          {/* Full-screen Backdrop (strictly transparent/clear styled overlay) */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={handleClose}
            className="fixed inset-0 bg-slate-950/[0.08] backdrop-blur-[2px] z-[9998] cursor-pointer"
          />

          {/* Modal Container to position the card at bottom-right corner on desktop, bottom-centered on mobile */}
          <div 
            id="floating-notice-panel"
            className="fixed inset-0 z-[9999] flex items-end justify-center sm:items-end sm:justify-end p-4 sm:p-8 pointer-events-none"
          >
            {/* Modal Content - Corner/Bottom Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 35 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 35 }}
              transition={{ type: "spring", stiffness: 350, damping: 28 }}
              className="relative bg-white/95 backdrop-blur-3xl border-2 border-orange-200/60 rounded-[2rem] shadow-[0_25px_60px_rgba(234,88,12,0.18)] p-6 sm:p-7 flex flex-col overflow-hidden w-[92vw] sm:w-[380px] pointer-events-auto"
            >
              {/* Background elements inside the card */}
              <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-orange-500/[0.05] pointer-events-none animate-morph-blob-1" />
              <div className="absolute -left-6 -top-6 w-24 h-24 bg-amber-500/[0.04] pointer-events-none animate-morph-blob-2" />

              {/* Minimal Close button on top-right */}
              <button
                onClick={handleClose}
                className="absolute top-4 right-4 text-slate-400 hover:text-orange-600 hover:bg-orange-50 rounded-full p-1 transition-colors duration-200"
                aria-label="Close notice"
              >
                <X className="h-4 w-4 font-black" />
              </button>
   
              {/* Header Title (Centered) */}
              <div className="text-center mb-3 pr-4">
                {latestNotice.type === 'alert' && (
                  <div className="mb-2 inline-flex items-center gap-1.5 px-3 py-1 bg-red-50 rounded-full border border-red-100 shadow-sm">
                    <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                    <span className="text-[10px] text-red-600 font-black uppercase tracking-widest">Urgent Announcement</span>
                  </div>
                )}
                <h3 className={`text-base sm:text-lg font-black tracking-tight font-sans leading-tight ${latestNotice.type === 'alert' ? 'text-red-600' : 'text-orange-600'}`}>
                  {latestNotice.title}
                </h3>
                
                {/* Date with calendar icon */}
                <div className="flex items-center justify-center gap-1.5 text-slate-400 text-[10px] font-bold uppercase tracking-wider mt-1 font-sans">
                  <Calendar className="h-3.5 w-3.5 text-slate-400 animate-pulse" />
                  {formatNoticeDate(latestNotice)}
                </div>
              </div>
              
              {/* Description with the stylish Bengali typography & right vertical ORANGE border - No scroll or overflow, truncated content */}
              <div className="flex-1 overflow-hidden px-0.5 py-1">
                <div className="border-r-[2.5px] border-orange-500 pr-3.5 text-left text-slate-700 text-xs sm:text-sm font-bold leading-relaxed whitespace-pre-wrap font-sans">
                  {latestNotice.content && latestNotice.content.length > 250
                    ? latestNotice.content.slice(0, 250).trim() + "..."
                    : latestNotice.content}
                </div>
              </div>
   
              {/* Action Buttons styled orange in exact match to system theme */}
              <div className="mt-4 flex items-center justify-center gap-3 pt-3 border-t border-slate-100/60">
                <button
                  onClick={handleViewAll}
                  className="px-5 py-2.5 bg-orange-600 text-white hover:bg-orange-700 font-black text-[11px] uppercase tracking-wide rounded-xl transition-all shadow-md shadow-orange-600/20 active:scale-95 flex items-center justify-center"
                >
                  View All
                </button>
                <button
                  onClick={handleClose}
                  className="px-5 py-2.5 bg-slate-500 text-white hover:bg-slate-600 font-black text-[11px] uppercase tracking-wide rounded-xl transition-all shadow-md active:scale-95 flex items-center justify-center"
                >
                  Dismiss
                </button>
              </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
};

export default FloatingNoticePopup;
