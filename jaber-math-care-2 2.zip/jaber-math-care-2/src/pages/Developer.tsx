import { motion } from 'motion/react';
import { useSettings } from '../context/SettingsContext';
import { Facebook, Instagram, Globe, Mail, Phone, MapPin, ChevronLeft, Atom, Github, Linkedin, Coffee } from 'lucide-react';
import { Link } from 'react-router-dom';

const Developer = () => {
  const { settings } = useSettings();
  const socialLinks = [
    { icon: Facebook, url: "https://www.facebook.com/md.jaber.bin.razzak", label: "Facebook", color: "bg-gradient-to-r from-blue-600 to-blue-700 shadow-blue-500/10 hover:shadow-blue-500/30" },
    { icon: Instagram, url: "https://www.instagram.com/her_jaber/", label: "Instagram", color: "bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 shadow-pink-500/10 hover:shadow-pink-500/30" },
    { icon: Globe, url: "https://jaber2026.github.io/jaber/", label: "Portfolio", color: "bg-gradient-to-r from-emerald-500 to-teal-600 shadow-emerald-500/10 hover:shadow-emerald-500/30" },
    { icon: Github, url: "#", label: "GitHub", color: "bg-gradient-to-r from-slate-800 to-slate-950 shadow-slate-900/10 hover:shadow-slate-900/30" },
    { icon: Linkedin, url: "https://bd.linkedin.com/in/mohammed-jaber-bin-razzak-ba099a398", label: "LinkedIn", color: "bg-gradient-to-r from-blue-700 to-sky-700 shadow-blue-700/10 hover:shadow-blue-700/30" }
  ];

  const coffeeUrl = settings.developer_coffee_url || "https://buymeacoffee.com/jaberbhai";

  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-12 px-4 relative overflow-hidden">
      {/* Decorative background shapes */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-orange-200/20 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-amber-200/20 rounded-full blur-3xl translate-x-1/2 translate-y-1/2 pointer-events-none" />

      <div className="max-w-5xl mx-auto relative z-10">
        <Link to="/" className="inline-flex items-center gap-2 text-orange-600 font-extrabold mb-8 hover:gap-3 transition-all">
          <ChevronLeft className="h-5 w-5" /> Back to Home
        </Link>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="bg-white rounded-[3.5rem] shadow-[0_20px_50px_rgba(234,88,12,0.08)] overflow-hidden border border-slate-100"
        >
          {/* Cover Banner */}
          <div className="relative h-64 bg-gradient-to-r from-orange-500 via-orange-600 to-amber-500">
            <div className="absolute inset-0 opacity-10 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white via-orange-100 to-orange-850 rounded-t-[3.5rem]" />
            <div className="absolute -bottom-24 left-1/2 -translate-x-1/2 z-10">
              <motion.div 
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.2, duration: 0.5, type: "spring" }}
                className="relative"
              >
                <img 
                  src={settings.developer_photo_url || "https://ui-avatars.com/api/?name=Mohammad+Jaber+Bin+Razzak&background=ea580c&color=fff"} 
                  alt={settings.developer_name || "Mohammad Jaber Bin Razzak"} 
                  className="w-48 h-48 md:w-56 md:h-56 rounded-[2.5rem] border-8 border-white shadow-2xl object-cover hover:rotate-3 transition-all duration-500"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
            </div>
          </div>

          <div className="pt-28 pb-12 px-6 sm:px-12 text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-3xl sm:text-4.5xl font-black text-slate-900 mb-2 tracking-tight"
            >
              {settings.developer_name || "Mohammad Jaber Bin Razzak"}
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="text-orange-600 font-black uppercase tracking-widest text-xs sm:text-sm mb-6 bg-orange-50 inline-block px-4 py-1.5 rounded-full"
            >
              Full Stack React Developer & UI Designer
            </motion.p>
            
            <motion.div 
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.45 }}
              className="max-w-2xl mx-auto mb-10"
            >
              <p className="text-slate-600 leading-relaxed font-medium">
                {settings.developer_bio || "Assalamu Alaikum! I am Mohammad Jaber Bin Razzak, a passionate developer. I specialize in building modern, high-performance web applications that provide seamless user experiences. This platform was crafted with dedication to help students excel in their journey."}
              </p>
            </motion.div>

            {/* Social Links List */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-4 mb-12">
              {socialLinks.map((social, i) => (
                <motion.a
                  key={i}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ y: -6, scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  transition={{ type: "spring", stiffness: 300, damping: 15 }}
                  className={`${social.color} p-4 sm:p-5 rounded-[1.75rem] text-white shadow-lg flex flex-col items-center gap-2.5 transition-all duration-300`}
                >
                  <social.icon className="h-6 w-6" />
                  <span className="text-[10px] font-black uppercase tracking-wider">{social.label}</span>
                </motion.a>
              ))}
            </div>

            {/* Buy Me A Coffee Box */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.5 }}
              className="max-w-xl mx-auto mb-12 p-6 sm:p-8 rounded-[2.5rem] bg-gradient-to-br from-amber-50 to-orange-50/50 border border-amber-100 shadow-sm flex flex-col sm:flex-row items-center gap-6 text-left"
            >
              <div className="w-16 h-16 rounded-2xl bg-amber-500 flex items-center justify-center text-white shrink-0 shadow-lg shadow-amber-500/20 relative overflow-hidden group">
                <div className="absolute inset-0 bg-white/20 transform -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                <Coffee className="h-8 w-8 animate-bounce-slow" />
              </div>
              <div className="flex-1 text-center sm:text-left">
                <h3 className="text-lg font-black text-slate-800 mb-1 leading-tight">Wanna Buy Me A Coffee? ☕</h3>
                <p className="text-xs text-slate-500 font-bold leading-relaxed mb-4 sm:mb-0">
                  If my work brings you value or made your learning smoother, support the drive behind the code with a warm beverage!
                </p>
              </div>
              <motion.a
                href={coffeeUrl}
                target="_blank"
                rel="noopener noreferrer"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="bg-amber-500 hover:bg-amber-600 text-white font-extrabold text-[11px] uppercase tracking-widest px-6 py-4 rounded-2xl shadow-xl shadow-amber-500/20 flex items-center gap-2 shrink-0"
              >
                Buy Coffee
              </motion.a>
            </motion.div>

            {/* Contact cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-left border-t border-slate-100 pt-10">
              <div className="flex items-start gap-4 p-5 rounded-[2rem] bg-slate-50 hover:bg-white border hover:border-slate-200 transition-all duration-300">
                <Mail className="h-6 w-6 text-orange-600 shrink-0 mt-1" />
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Email</p>
                  <p className="text-sm font-extrabold text-slate-700 break-all">{settings.developer_email || "jaberbhai69@gmail.com"}</p>
                </div>
              </div>
              <div className="flex items-start gap-4 p-5 rounded-[2rem] bg-slate-50 hover:bg-white border hover:border-slate-200 transition-all duration-300">
                <Phone className="h-6 w-6 text-orange-600 shrink-0 mt-1" />
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Phone</p>
                  <p className="text-sm font-extrabold text-slate-700">{settings.developer_phone || "+880 1870-635347"}</p>
                </div>
              </div>
              <div className="flex items-start gap-4 p-5 rounded-[2rem] bg-slate-50 hover:bg-white border hover:border-slate-200 transition-all duration-300">
                <MapPin className="h-6 w-6 text-orange-600 shrink-0 mt-1" />
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Location</p>
                  <p className="text-sm font-extrabold text-slate-700">{settings.developer_location || "Bogra, Bangladesh"}</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-3 px-6 py-3 bg-orange-100/60 rounded-full text-orange-600 font-extrabold text-xs">
            <Atom className="h-5 w-5 animate-spin-slow" />
            Crafted with passion for {settings.site_name || "Jaber Math Care"}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Developer;
