import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Youtube, Play, Clock, Calendar, Search, Filter, ChevronRight, PlayCircle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { safeJson } from '../../utils/api';

const JaberTube = () => {
  const { token, user } = useAuth();
  const [videos, setVideos] = useState<any[]>([]);
  const [chapters, setChapters] = useState<any[]>([]);
  const [activeEnrollments, setActiveEnrollments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedVideo, setSelectedVideo] = useState<any | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedChapter, setSelectedChapter] = useState('all');
  const [selectedPlaylist, setSelectedPlaylist] = useState('all');

  if (!user) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-10rem)]">
        <div className="text-center">
          <h2 className="text-2xl font-black text-slate-900 mb-4">Login Required</h2>
          <p className="text-slate-500">Please log in to access Jaber Tube content.</p>
        </div>
      </div>
    );
  }

  useEffect(() => {
    fetchVideos();
    fetchChapters();
    if (token) {
      fetch(`/api/my-enrollments?t=${Date.now()}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(data => {
        if (!data.error) {
          setActiveEnrollments(Array.isArray(data) ? data.filter((e: any) => e.status === 'contacted' || e.status === 'approved') : []);
        }
      })
      .catch(console.error);
    }
  }, [token]);

  const fetchVideos = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/web-recorded-classes?t=' + Date.now(), {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (res.ok) {
        const data = await safeJson(res);
        setVideos(Array.isArray(data) ? data : []);
      }
    } catch (error) {
      console.error('Failed to fetch Jaber Tube videos:', error);
    } 
  };

  const fetchChapters = async () => {
    try {
      const res = await fetch('/api/chapters?t=' + Date.now());
      if (res.ok) {
        const data = await safeJson(res);
        setChapters(Array.isArray(data) ? data : []);
      }
    } catch (error) {
      console.error('Failed to fetch chapters:', error);
    } finally {
      setLoading(false);
    }
  };

  const getYoutubeId = (url: string) => {
    const regExp = /^.*(youtu\.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  const playlists = Array.from(new Set(videos.map(v => v.playlist).filter(Boolean)));

  const filteredVideos = videos.filter(v => {
    const matchesSearch = v.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          v.description?.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (selectedChapter !== 'all' && String(v.chapter_id) !== String(selectedChapter)) return false;
    if (selectedPlaylist !== 'all' && v.playlist !== selectedPlaylist) return false;

    // Enrollment check
    const isEnrolledInProgram = user?.program_id && String(v.program_id) === String(user.program_id);
    const isEnrolledInCourse = (user?.course_id && String(v.course_id) === String(user.course_id)) ||
                               user?.enrolled_courses?.some((c: any) => typeof c === 'string' ? String(c) === String(v.course_id) : String(c.id) === String(v.course_id));
    
    const isEnrolledInBatch = v.batch_id && v.batch_id !== 'all' && v.batch_id !== 'ALL' && (
      String(user?.batch_id) === String(v.batch_id) || 
      String(user?.batch_id_2) === String(v.batch_id) ||
      activeEnrollments?.some((e: any) => String(e.batch_id) === String(v.batch_id))
    );

    const cid = v.course_id && String(v.course_id).toUpperCase() !== 'ALL' ? v.course_id : null;
    const pid = v.program_id && String(v.program_id).toUpperCase() !== 'ALL' ? v.program_id : null;
    const bid = v.batch_id && String(v.batch_id).toUpperCase() !== 'ALL' ? v.batch_id : null;

    const isGeneralVideo = !pid && !cid && !bid;

    let matchesAccess = false;
    
    if (isGeneralVideo) {
      matchesAccess = true;
    } else {
      // Check if student matches ANY of the target IDs
      const matchesCid = cid && (isEnrolledInCourse || activeEnrollments?.some((e: any) => String(e.course_id) === String(cid)));
      const matchesPid = pid && (isEnrolledInProgram || activeEnrollments?.some((e: any) => String(e.program_id) === String(pid)));
      const matchesBid = bid && isEnrolledInBatch;

      // If video has a course_id, student MUST match it
      if (cid) {
        if (bid) {
          matchesAccess = !!(matchesCid && matchesBid);
        } else {
          matchesAccess = !!matchesCid;
        }
      } 
      // If it has a program_id, student SHOULD match it, but if specifically assigned to a batch, batch match is critical
      else if (pid) {
        if (bid) {
          matchesAccess = !!(matchesPid && matchesBid);
        } else {
          matchesAccess = !!matchesPid;
        }
      }
      // If ONLY batch_id is set
      else if (bid) {
        matchesAccess = !!matchesBid;
      }
      
      // Admins and moderators always get access
      if (user?.role === 'admin' || user?.role === 'moderator') {
        matchesAccess = true;
      }
    }

    return matchesAccess;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-10rem)]">
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 border-4 border-orange-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 font-bold animate-pulse">Loading Jaber Tube...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 pb-20">
      {/* Header Section */}
      <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-8">
        <div className="flex-1">
          <div className="flex items-center gap-4 mb-3">
            <div className="bg-red-600 p-3 rounded-2xl shadow-xl shadow-red-600/20 transform -rotate-3 hover:rotate-0 transition-transform">
              <Youtube className="h-10 w-10 text-white" />
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-black text-slate-900 tracking-tighter">
                Jaber <span className="text-red-600">Tube</span>
              </h1>
              <div className="flex items-center gap-2 mt-1">
                <span className="w-2 h-2 bg-red-600 rounded-full animate-pulse" />
                <p className="text-slate-500 font-bold uppercase text-[10px] tracking-widest leading-none">Premium Recorded Library</p>
              </div>
            </div>
          </div>
        </div>

        <div className="w-full xl:w-auto flex flex-col md:flex-row items-center gap-4">
          <div className="relative w-full md:w-80 group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 group-focus-within:text-red-600 transition-colors" />
            <input 
              type="text"
              placeholder="পছন্দের ক্লাস খুঁজুন..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-white border-2 border-slate-100 rounded-2xl pl-12 pr-4 py-4 text-slate-900 focus:outline-none focus:ring-4 focus:ring-red-500/5 focus:border-red-500 transition-all shadow-sm font-medium"
            />
          </div>

          <div className="flex items-center gap-4 w-full md:w-auto">
            <select
              value={selectedChapter}
              onChange={(e) => setSelectedChapter(e.target.value)}
              className="flex-1 md:w-48 bg-white border-2 border-slate-100 rounded-2xl px-4 py-4 text-slate-900 focus:outline-none focus:border-red-500 transition-all shadow-sm font-bold text-sm appearance-none cursor-pointer"
            >
              <option value="all">সকল চ্যাপ্টার</option>
              {chapters.filter(ch => videos.some(v => v.chapter_id === ch.id)).map(ch => (
                <option key={ch.id} value={ch.id}>{ch.title}</option>
              ))}
            </select>

            <select
              value={selectedPlaylist}
              onChange={(e) => setSelectedPlaylist(e.target.value)}
              className="flex-1 md:w-48 bg-white border-2 border-slate-100 rounded-2xl px-4 py-4 text-slate-900 focus:outline-none focus:border-red-500 transition-all shadow-sm font-bold text-sm appearance-none cursor-pointer"
            >
              <option value="all">প্লেলিস্ট ফিল্টার</option>
              {playlists.map(p => (
                <option key={p} value={p}>{p}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 gap-8">
        {filteredVideos.map((video, index) => {
          const videoId = getYoutubeId(video.url);
          const chapter = chapters.find(ch => ch.id === video.chapter_id);
          return (
            <motion.div
              key={video.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              className="group"
              onClick={() => setSelectedVideo(video)}
            >
              <div className="bg-white rounded-[3rem] p-3 shadow-2xl shadow-slate-200/50 border border-slate-100 hover:border-red-200 transition-all duration-500 hover:-translate-y-2">
                <div className="relative aspect-video rounded-[2.5rem] overflow-hidden mb-6 shadow-inner bg-slate-100">
                  {video.thumbnail || videoId ? (
                    <img 
                      src={video.thumbnail || `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`}
                      alt={video.title}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        if (!video.thumbnail) {
                          (e.target as HTMLImageElement).src = `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`;
                        }
                      }}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-slate-900">
                      <Youtube className="h-12 w-12 text-slate-700" />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center">
                    <div className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center shadow-2xl shadow-red-600/40 transform scale-75 group-hover:scale-100 transition-transform duration-500">
                      <Play className="h-8 w-8 text-white fill-white ml-1" />
                    </div>
                  </div>
                  
                  {video.playlist && (
                    <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md text-red-600 text-[10px] font-black px-3 py-1.5 rounded-xl border border-red-100 shadow-sm uppercase tracking-widest">
                      {video.playlist}
                    </div>
                  )}
                  
                  <div className="absolute bottom-4 right-4 bg-black/70 backdrop-blur-md text-white text-[9px] font-black px-3 py-1.5 rounded-xl uppercase tracking-widest border border-white/20">
                    Premium Class
                  </div>
                </div>

                <div className="px-3 pb-4">
                  {chapter && (
                    <div className="flex items-center gap-1.5 mb-2">
                      <span className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                      <span className="text-[10px] font-black text-red-600 uppercase tracking-widest">{chapter.title}</span>
                    </div>
                  )}
                  <h3 className="text-xl font-bold text-slate-900 group-hover:text-red-600 transition-colors line-clamp-2 leading-tight mb-4 min-h-[3rem]">
                    {video.title}
                  </h3>
                  
                  <div className="flex items-center justify-between pt-4 border-t border-slate-50">
                    <div className="flex items-center gap-2">
                       <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">
                          <PlayCircle className="h-4 w-4 text-slate-400 group-hover:text-red-500 transition-colors" />
                       </div>
                       <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Watch Now</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">
                      {new Date(video.created_at || Date.now()).toLocaleDateString('bn-BD')}
                    </span>
                  </div>
                </div>
              </div>
            </motion.div>
          );
        })}

        {filteredVideos.length === 0 && (
          <div className="col-span-full py-20 text-center glass rounded-[3rem] border-dashed border-2 border-slate-200">
            <div className="bg-slate-50 w-24 h-24 rounded-[2rem] flex items-center justify-center mx-auto mb-6 shadow-inner">
              <Youtube className="h-12 w-12 text-slate-200" />
            </div>
            <h3 className="text-2xl font-black text-slate-900 tracking-tight">No Classes Found</h3>
            <p className="text-slate-500 mt-2 font-medium">Try searching with different keywords or check back later.</p>
          </div>
        )}
      </div>

      {/* Video Player Modal */}
      <AnimatePresence>
        {selectedVideo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 md:p-10 bg-slate-950/95 backdrop-blur-xl"
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="w-full max-w-6xl aspect-video relative rounded-[3rem] overflow-hidden shadow-[0_0_100px_rgba(249,115,22,0.2)] border border-white/10"
            >
              <button 
                onClick={() => setSelectedVideo(null)}
                className="absolute top-6 right-6 z-10 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white p-3 rounded-2xl transition-all border border-white/10 hover:scale-110 active:scale-90"
              >
                <X className="h-6 w-6" />
              </button>
              
              <iframe 
                src={`https://www.youtube.com/embed/${getYoutubeId(selectedVideo.url)}?autoplay=1&rel=0&modestbranding=1&showinfo=0`}
                className="w-full h-full"
                allowFullScreen
                allow="autoplay"
              />

              <div className="absolute bottom-0 left-0 right-0 p-10 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent pointer-events-none">
                <h2 className="text-3xl font-black text-white mb-2 tracking-tight">{selectedVideo.title}</h2>
                <p className="text-slate-400 font-medium line-clamp-2 max-w-3xl">{selectedVideo.description}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default JaberTube;
