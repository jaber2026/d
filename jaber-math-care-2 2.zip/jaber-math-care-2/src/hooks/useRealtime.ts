import { useState, useEffect } from 'react';
import { db, auth } from '../firebase';
import { collection, onSnapshot, query, QueryConstraint, doc, onSnapshot as onDocSnapshot } from 'firebase/firestore';

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const err = error as any;
  const isPermissionError = err?.code === 'permission-denied' || (err?.message && err.message.includes('permission'));
  
  const errInfo: FirestoreErrorInfo = {
    error: err instanceof Error ? err.message : String(err),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };

  const jsonString = JSON.stringify(errInfo);
  console.error('Firestore Error: ', jsonString);
  
  if (isPermissionError) {
    console.error(`Permission denied on path: ${path} (Operation: ${operationType})`);
  }
}

const PUBLIC_CACHEABLE = ['web_links', 'support_team', 'pricing_plans', 'reviews', 'notices', 'sponsorships', 'programs'];

export function useRealtimeCollection<T = any>(collectionName: string, constraints: QueryConstraint[] = []) {
  const [data, setData] = useState<T[]>(() => {
    if (PUBLIC_CACHEABLE.includes(collectionName)) {
      try {
        const cached = localStorage.getItem(`cache_rt_v2_${collectionName}`);
        if (cached) return JSON.parse(cached);
      } catch {}
    }
    return [];
  });
  const [loading, setLoading] = useState(() => {
    if (PUBLIC_CACHEABLE.includes(collectionName)) {
      const cached = localStorage.getItem(`cache_rt_v2_${collectionName}`);
      return cached ? false : true;
    }
    return true;
  });
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let q;
    try {
      q = query(collection(db, collectionName), ...constraints);
    } catch (e) {
      console.error(`Error creating query for ${collectionName}:`, e);
      q = collection(db, collectionName);
    }

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() as any }));
      setData(docs);
      if (PUBLIC_CACHEABLE.includes(collectionName)) {
        try { localStorage.setItem(`cache_rt_v2_${collectionName}`, JSON.stringify(docs)); } catch {}
      }
      setLoading(false);
    }, (err) => {
      console.error(`Error in onSnapshot for ${collectionName}:`, err);
      setError(err as Error);
      setLoading(false);
      
      if (err?.code === 'permission-denied') {
        handleFirestoreError(err, OperationType.GET, collectionName);
        return;
      }
      
      // Fallback: try without constraints if it failed (likely index issue)
      if (constraints.length > 0) {
        console.log(`Retrying ${collectionName} without constraints...`);
        const fallbackQ = collection(db, collectionName);
        onSnapshot(fallbackQ, (s) => {
          const fallbackDocs = s.docs.map(d => ({ id: d.id, ...d.data() as any }));
          setData(fallbackDocs as any);
          if (PUBLIC_CACHEABLE.includes(collectionName)) {
            try { localStorage.setItem(`cache_rt_v2_${collectionName}`, JSON.stringify(fallbackDocs)); } catch {}
          }
        }, (fallbackErr) => {
          handleFirestoreError(fallbackErr, OperationType.GET, collectionName);
        });
      } else {
        handleFirestoreError(err, OperationType.GET, collectionName);
      }
    });

    return unsubscribe;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [collectionName]);

  return { data, loading, error };
}

export function useRealtimeDocument(collectionName: string, docId: string) {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!docId) return;
    const unsubscribe = onDocSnapshot(doc(db, collectionName, docId), (snapshot) => {
      if (snapshot.exists()) {
        setData({ id: snapshot.id, ...snapshot.data() });
      } else {
        setData(null);
      }
      setLoading(false);
    }, (err) => {
      handleFirestoreError(err, OperationType.GET, `${collectionName}/${docId}`);
      setLoading(false);
    });
    return unsubscribe;
  }, [collectionName, docId]);

  return { data, loading };
}
