import React from 'react';
import { motion } from 'motion/react';
import { Globe, ExternalLink, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useRealtimeCollection } from '../hooks/useRealtime';
import LoadingSpinner from '../components/LoadingSpinner';

const OurNetwork = () => {
  const { data: links, loading } = useRealtimeCollection('web_links');

  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-10 space-y-3">
          <h1 className="text-4xl md:text-7xl font-black text-orange-600 tracking-tighter uppercase leading-none">Our Network</h1>
          <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Connected systems empowering mathematics education</p>
        </div>

        {loading ? (
          <LoadingSpinner />
        ) : links.length === 0 ? (
          <div className="bg-white p-12 rounded-[3rem] text-center shadow-sm border border-slate-100">
             <Globe className="h-12 w-12 text-slate-200 mx-auto mb-4" />
             <p className="text-slate-400 font-bold">No network links found.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
            {links.sort((a,b)=> (a.order || 0) - (b.order || 0)).map((link, i) => (
              <motion.div 
                key={link.id} 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="bg-white rounded-[2.5rem] p-8 shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-slate-100 flex flex-col items-center text-center group h-full"
              >
                 <div className="h-24 w-24 rounded-[2rem] bg-orange-50 flex items-center justify-center mb-8 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500 shadow-inner overflow-hidden border border-orange-100/50">
                   {link.image_url ? (
                     <img src={link.image_url} alt={link.title} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                   ) : (
                     <Globe className="h-10 w-10 text-orange-600" />
                   )}
                 </div>
                 
                 <div className="space-y-6 flex-1 flex flex-col w-full">
                   <div className="space-y-1">
                     <h3 className="text-xl font-black text-slate-900 tracking-tight leading-tight group-hover:text-orange-600 transition-colors">{link.title}</h3>
                     <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest">Portal Resource</p>
                   </div>

                   <p className="text-slate-500 text-xs font-bold leading-relaxed px-2 flex-1">
                     Access specialized mathematical content and engineering resources through this official portal.
                   </p>

                   <div className="pt-6 w-full">
                     <a 
                       href={link.url} 
                       target="_blank" 
                       rel="noopener noreferrer"
                       className="w-full py-4 bg-orange-600 hover:bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg shadow-orange-600/15 active:scale-[0.98] flex items-center justify-center gap-2 group/btn"
                     >
                       Visit Resource <ExternalLink className="h-4 w-4 group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1 transition-transform" />
                     </a>
                   </div>
                 </div>
              </motion.div>
            ))}
          </div>
        )}
        {/* Back to Home Moved to Bottom */}
        <div className="text-center mt-20">
          <Link to="/" className="inline-flex items-center gap-2 px-8 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-orange-600 hover:-translate-y-1 transition-all shadow-xl">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Home Page
          </Link>
        </div>
      </div>
    </div>
  );
};

export default OurNetwork;
