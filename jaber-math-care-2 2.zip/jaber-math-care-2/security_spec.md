# Security Specification

This security specification details the data invariants, potential vulnerability vectors (Dirty Dozen Payloads), and security test cases for the educational applet's Firestore security rules.

## Data Invariants

1. **User Identity Invariant**: Users should only be allowed to read and write their own `/users/{userId}` documents unless they are designated administrators (`isAdmin()`).
2. **Staff-Only Operations**: Creating, updating, or deleting batches, programs, chapters, notices, blog posts, and setting parameters is strictly limited to staff or administrators.
3. **Enrollments Isolation**: Students can read and manage their own enrollments, whereas guests can submit new public enrollments. Administrators have full read/write management permissions on enrollment state.
4. **Logs Creation**: Logging entities like `message_logs` can be written to by server-side processes but must be locked down against arbitrary reads, updates, or deletes.

## The "Dirty Dozen" Payloads

1. **Self-Escalating Admin Role**: Requesting an update to `users/{myUid}` with `role: "admin"`.
2. **Accessing Other's PII**: Attempting a `get` document request on `/users/{otherUid}` as a standard student.
3. **Deleting Academic Batches**: Attempting to run `deleteDoc` on `/batches/{batchId}` as a student or guest.
4. **Modifying Another Student's Enrollment**: Attempting to update status to "approved" on `/enrollments/{otherEnrollmentId}` as a non-admin.
5. **Unauthorized Blog Writing**: Attempting to write a blog post in `/blogs/{blogId}` as a guest or student.
6. **Malicious Poll Update**: Setting `votes: 99999` in `/live_polls/{pollId}` by an unauthenticated user.
7. **Junk String ID Attack**: Adding a document under `/users/$junkCharSet$` with standard fields.
8. **Spoofed User Registration**: Submitting a user profile under `/users/{differentUid}` with email of an existing admin.
9. **Tampering Message Logs**: Attempting to delete logs in `/message_logs/{logId}`.
10. **Reading Private SMS/Email Log History**: Reading entries in `/message_logs/{logId}` as standard visitor.
11. **Academic Progress Manipulation**: Direct write of pass grades to `/results/{resultId}` as a student.
12. **Class Slides Deletion**: Deleting content in `/class_slides/{slideId}` as standard student.

## Complete Spec and Verification Setup

The security configuration is applied directly via `firestore.rules` containing global rules matching each specified collection.
