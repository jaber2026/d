import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
  query,
  where,
  getDoc,
  setDoc,
  orderBy,
  writeBatch,
  arrayUnion,
} from "firebase/firestore";
import {
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  updatePassword,
  updateEmail,
  EmailAuthProvider,
  reauthenticateWithCredential,
} from "firebase/auth";
import { db, auth, secondaryAuth } from "../firebase";

enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId: string | undefined;
    email: string | null | undefined;
    emailVerified: boolean | undefined;
    isAnonymous: boolean | undefined;
    tenantId: string | null | undefined;
    providerInfo: {
      providerId: string;
      displayName: string | null;
      email: string | null;
      photoUrl: string | null;
    }[];
  };
}

function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null,
) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData.map((provider) => ({
          providerId: provider.providerId,
          displayName: provider.displayName,
          email: provider.email,
          photoUrl: provider.photoURL,
        })) || [],
    },
    operationType,
    path,
  };
  console.error("Firestore Error: ", JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Store original fetch
const originalFetch = window.fetch;

// Simple cache for GET requests - DISABLED per user request
const apiCache = new Map<string, { data: any; timestamp: number }>();
const CACHE_TTL = 0; // Disabled cache

// Helper to create a Response object
const baseCreateResponse = (data: any, status = 200) => {
  if (status >= 400) {
    console.warn(`[Interceptor] Returning error response: ${status}`, data);
  }
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json" },
  });
};

// Helper to get current user ID from token/auth
const getCurrentUserId = () => {
  return auth.currentUser?.uid;
};

// Interceptor
Object.defineProperty(window, "fetch", {
  value: async (input: RequestInfo | URL, init?: RequestInit) => {
    const url = typeof input === "string" ? input : input.toString();

    // Only intercept /api/ calls on our own origin or relative /api/ calls
    const isRelativeApi = url.startsWith("/api/") || url.startsWith("./api/") || url.startsWith("api/");
    const isAbsoluteLocalApi = url.startsWith(window.location.origin + "/api/");
    const isApiCall = isRelativeApi || isAbsoluteLocalApi;
    if (!isApiCall) {
      return originalFetch(input, init);
    }

    const method = init?.method || "GET";

    // Clear cache for non-GET requests
    if (method !== "GET") {
      console.log(`[Firebase Adapter] Clearing cache due to ${method} request`);
      apiCache.clear();
    }

    const body = init?.body ? JSON.parse(init.body as string) : null;

    // Extract the path after /api/
    const apiPart = url.split("/api/")[1];
    const path = apiPart.split("?")[0];

    const createResponse = (data: any, status = 200) => {
      if (method === "GET" && status === 200) {
        apiCache.set(url, { data, timestamp: Date.now() });
      }
      if (method !== "GET" && status >= 200 && status < 300) {
        apiCache.clear(); // Invalidate cache on mutations
      }
      return baseCreateResponse(data, status);
    };

    // Fetch custom backend override and routing mode from Firestore settings
    let backendOrigin = "";
    let useServerBackend = false;
    try {
      const docSnap = await getDoc(doc(db, "settings", "api_backend_url"));
      if (docSnap && docSnap.exists() && docSnap.data().value) {
        backendOrigin = docSnap.data().value.trim().replace(/\/$/, "");
      }
    } catch (err) {
      console.warn("apiInterceptor: Failed to fetch api_backend_url", err);
    }

    const hostname = window.location.hostname.toLowerCase();
    const isSandbox = hostname === "localhost" || 
                      hostname === "127.0.0.1" ||
                      hostname.includes("webcontainer-api.io") || 
                      hostname.includes(".run.app");
    const isKnownStaticHost = 
      hostname.includes("infinityfree") ||
      hostname.includes("byethost") ||
      hostname.includes("epizy") ||
      hostname.includes("rf.gd") ||
      hostname.includes("000webhost") ||
      hostname.includes("github.io") ||
      hostname.includes("netlify.app") ||
      hostname.includes("firebaseapp.com") ||
      hostname.includes("web.app") ||
      hostname.includes("pages.dev");

    // Force client-side interceptor mode always for AI Studio since admin.auth() will fail without service account
    useServerBackend = false;

    // IF USING REAL NodeJS BACKEND (EXPRESS): Bypass interceptor completely for ALL API calls!
    if (useServerBackend) {
      let finalInput = input;
      
      if (backendOrigin) {
        if (typeof input === "string") {
          if (input.startsWith("/api/")) {
            finalInput = backendOrigin + input;
          } else if (input.includes("/api/")) {
            const parts = input.split("/api/");
            finalInput = backendOrigin + "/api/" + parts[1];
          }
        } else if (input instanceof URL) {
          if (input.pathname.startsWith("/api/")) {
            finalInput = new URL(backendOrigin + input.pathname + input.search);
          }
        }
      }

      try {
        const response = await originalFetch(finalInput, init);
        return response;
      } catch (err: any) {
        console.warn(`[NodeJS Backend Link] Server request to ${backendOrigin || "current host"} failed with network error:`, err.message);
        // If it was a settings or database collection CRUD route, we let it fall through to the
        // client-side Firebase handler below! This ensures settings/updates can always be saved
        // directly to Firestore client-side even if the Node server is down.
        const canFallbackClient = path === "settings" || 
                                  path.startsWith("public/settings") || 
                                  path === "admin/clear-all-data" || 
                                  path.startsWith("students") || 
                                  path.startsWith("degrees") || 
                                  path.startsWith("public/programs") || 
                                  path.startsWith("public/batches");
                                  
        if (canFallbackClient) {
          console.log(`[Firebase Interceptor Fallback] Gracefully falling back to client-side Firebase logic for: ${method} /api/${path}`);
        } else {
          // For EmailJS verification and other backend-only tasks, return a helpful status response
          // instead of throwing an uncatchable raw browser exception.
          return createResponse(
            { 
              error: "API Backend Unreachable", 
              details: `The server backend is currently unreachable or blocking cross-origin requests. (Error: ${err.message})` 
            }, 
            503
          );
        }
      }
    }

    // Otherwise, fall back to selective bypass routes check
    const bypassRoutes = [
      "verify-mail-settings",
      "send-email",
      "send-sms",
      "notifications/broadcast",
      "send-system-email",
      "forgot-password/request",
      "forgot-password/verify",
      "forgot-password/reset",
      "send-email-bulk",
      "emailjs-debug"
    ];
    if (bypassRoutes.includes(path)) {
      if (path === "send-system-email") {
         try {
           const setSnap = await getDocs(collection(db, "settings"));
           let settings: any = {};
           setSnap.forEach(d => settings[d.id] = d.data().value);
           if (settings.email_gateway_type === "emailjs") {
             if (settings.emailjs_service_id && settings.emailjs_template_id && settings.emailjs_public_key) {
                const { type, data } = body || {};
                let subject = "Notification";
                let textContent = "You have a new notification"; let recipient = data?.email || data?.gmail || "unknown";

                let globalBg = "#fff7ed";
                let cardBorder = "#ffedd5";
                let dividerCol = "#ffedd5";
                let topBar = "linear-gradient(90deg, #ea580c, #f97316)";
                let taglineText = settings.hero_subtitle || "THE FUTURE OF MATH EDUCATION";
                let taglineColor = "#ea580c";
                let accentShadow = "rgba(234,88,12,0.08)";
                let logoShadow = "rgba(234,88,12,0.15)";
                let logoBorder = "2px solid #fff7ed";
                let footerBg = "#fffaf5";
                let footerBrandCol = "#ea580c";
                let footerMutedCol = "#c2410c";
                let linkCol = "#ea580c";
                let dotCol = "#fed7aa";
                let copyCol = "#c2410c";

                let htmlBody = "";

                if (type === "student_welcome") {
                   subject = "Admission Completed Successfully - Jaber Math Care";
                   globalBg = "#f0fdf4";
                   cardBorder = "#dcfce7";
                   topBar = "linear-gradient(90deg, #16a34a, #4ade80)";
                   taglineText = settings.hero_subtitle || "THE FUTURE OF MATH EDUCATION";
                   taglineColor = "#16a34a";
                   accentShadow = "rgba(22,163,74,0.08)";
                   logoShadow = "rgba(22,163,74,0.15)";
                   logoBorder = "2px solid #f0fdf4";
                   footerBg = "#f9fbf9";
                   footerBrandCol = "#16a34a";
                   footerMutedCol = "#15803d";
                   linkCol = "#16a34a";
                   dotCol = "#bbf7d0";
                   copyCol = "#15803d";

                   htmlBody = `
              <h2 style="color: #16a34a; font-size: 22px; font-weight: 800; margin: 0 0 10px 0; letter-spacing: -0.025em;">Welcome!</h2>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">Dear ${data?.name || "Student"},</p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">
                Your admission for the program <strong>${data?.course_title || data?.program_title || "our course"}</strong> ${data?.batch_name ? `(Batch: <strong>${data?.batch_name}</strong>)` : ""} has been completed successfully.
              </p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 25px 0; line-height: 1.6;">
                You can now log in to our website using your registered email and password.
              </p>

              <div style="margin: 25px 0; padding: 20px; background-color: #f0fdf4; border-radius: 16px; border-left: 5px solid #16a34a; font-family: sans-serif;">
                <p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Your Login Email:</strong> <span style="color: #16a34a; font-weight: 700;">${recipient.trim()}</span></p>
                <p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Your Password:</strong> <span style="color: #111827; font-weight: 700;">${data?.password || "N/A"}</span></p>
                ${data?.roll_number ? `<p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Roll Number:</strong> <span style="color: #111827; font-weight: 700;">${data?.roll_number}</span></p>` : ""}
                <p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Program:</strong> <span style="color: #111827; font-weight: 700;">${data?.course_title || data?.program_title || "N/A"}</span></p>
                ${data?.batch_name ? `<p style="margin: 0; font-size: 13px; color: #15803d;"><strong>Batch:</strong> <span style="color: #111827; font-weight: 700;">${data?.batch_name}</span></p>` : ""}
              </div>

              <p style="font-size: 14px; color: #475569; line-height: 1.6; margin-top: 25px;">
                Best regards,<br/><strong>Jaber Math Care Team</strong>
              </p>
                   `;
                } else if (type === "admission_approved") {
                   subject = "Admission Approved - Jaber Math Care";
                   globalBg = "#f0fdf4";
                   cardBorder = "#dcfce7";
                   topBar = "linear-gradient(90deg, #16a34a, #4ade80)";
                   taglineText = settings.hero_subtitle || "THE FUTURE OF MATH EDUCATION";
                   taglineColor = "#16a34a";
                   accentShadow = "rgba(22,163,74,0.08)";
                   logoShadow = "rgba(22,163,74,0.15)";
                   logoBorder = "2px solid #f0fdf4";
                   footerBg = "#f9fbf9";
                   footerBrandCol = "#16a34a";
                   footerMutedCol = "#15803d";
                   linkCol = "#16a34a";
                   dotCol = "#bbf7d0";
                   copyCol = "#15803d";

                   htmlBody = `
              <h2 style="color: #16a34a; font-size: 22px; font-weight: 800; margin: 0 0 10px 0; letter-spacing: -0.025em;">Congratulations!</h2>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">Dear ${data?.name || "Student"},</p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">
                Your admission request for the program <strong>${data?.course_title || data?.program_title || "our course"}</strong> ${data?.batch_name ? `(Batch: <strong>${data?.batch_name}</strong>)` : ""} has been successfully approved.
              </p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 25px 0; line-height: 1.6;">
                You can now log in to the Student Dashboard using your registered email and password.
              </p>

              <div style="margin: 25px 0; padding: 20px; background-color: #f0fdf4; border-radius: 16px; border-left: 5px solid #16a34a; font-family: sans-serif;">
                <p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Program Name:</strong> <span style="color: #111827; font-weight: 700;">${data?.course_title || data?.program_title || "N/A"}</span></p>
                ${data?.batch_name ? `<p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Batch Name:</strong> <span style="color: #111827; font-weight: 700;">${data?.batch_name}</span></p>` : ""}
                ${data?.roll_number ? `<p style="margin: 0; font-size: 13px; color: #15803d;"><strong>Your Roll Number:</strong> <span style="color: #16a34a; font-weight: 700;">${data?.roll_number}</span></p>` : ""}
              </div>

              <p style="font-size: 14px; color: #475569; line-height: 1.6; margin-top: 25px;">
                Best regards,<br/><strong>Jaber Math Care Team</strong>
              </p>
                   `;
                } else if (type === "payment_receipt") {
                   const invoiceNo = data?.invoice_no || "INV-" + Math.floor(100000 + Math.random() * 900000);
                   subject = `Paid Invoice & Receipt - ${invoiceNo}`;
                   globalBg = "#fff7ed";
                   accentShadow = "rgba(234,88,12,0.08)";
                   cardBorder = "#ffedd5";
                   topBar = "linear-gradient(90deg, #ea580c, #f97316)";
                   logoShadow = "rgba(234,88,12,0.15)";
                   logoBorder = "2px solid #fff7ed";
                   taglineColor = "#ea580c";
                   taglineText = settings.hero_subtitle || "THE FUTURE OF MATH EDUCATION";
                   dividerCol = "#ffedd5";
                   footerBg = "#fffaf5";
                   footerBrandCol = "#ea580c";
                   footerMutedCol = "#c2410c";
                   linkCol = "#ea580c";
                   dotCol = "#fed7aa";
                   copyCol = "#c2410c";

                   htmlBody = `
              <div style="text-align: right; margin-bottom: 20px;">
                <span style="background-color: #ecfdf5; color: #047857; border: 1px solid #10b981; padding: 6px 14px; border-radius: 9999px; font-weight: bold; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em;">PAID INVOICE</span>
              </div>

              <h2 style="color: #1e293b; font-size: 22px; font-weight: 800; margin: 0 0 10px 0; letter-spacing: -0.025em;">Payment Confirmation</h2>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">Dear ${data?.student_name || "Student"},</p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 25px 0; line-height: 1.6;">
                Thank you for your payment. Your registration status is up to date, and we have generated your official digital paid invoice below.
              </p>

              <!-- Invoice Details Box -->
              <div style="border: 1px solid #ffedd5; border-radius: 16px; overflow: hidden; background-color: #fffbef; margin-bottom: 25px; font-family: sans-serif;">
                <div style="padding: 14px; background-color: #fff7ed; border-bottom: 1px solid #ffedd5;">
                  <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 12px; color: #c2410c;">
                    <tr>
                      <td><strong>INVOICE NO:</strong> ${invoiceNo}</td>
                      <td align="right"><strong>DATE:</strong> ${new Date().toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric' })}</td>
                    </tr>
                  </table>
                </div>
                <div style="padding: 16px;">
                  <p style="font-size: 11px; color: #ea580c; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 6px 0;"><strong>Student Details:</strong></p>
                  <p style="font-size: 14px; color: #1e293b; font-weight: bold; margin: 0 0 4px 0;">${data?.student_name || "Student"}</p>
                  ${recipient ? `<p style="font-size: 12px; color: #475569; margin: 0 0 2px 0;"><strong>Email:</strong> ${recipient}</p>` : ""}
                  ${data?.phone ? `<p style="font-size: 12px; color: #475569; margin: 0;"><strong>Phone:</strong> ${data?.phone}</p>` : ""}
                </div>
              </div>

              <!-- Items Table -->
              <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 13px; line-height: 1.6; border-collapse: collapse; margin-bottom: 25px; font-family: sans-serif;">
                <thead>
                  <tr style="border-bottom: 2px solid #ffedd5; font-weight: bold; color: #ea580c; text-transform: uppercase; font-size: 11px;">
                    <td style="padding: 10px 0; text-align: left;">Description</td>
                    <td align="right" style="padding: 10px 0;">Amount</td>
                  </tr>
                </thead>
                <tbody>
                  <tr style="border-bottom: 1px solid #ffedd5; color: #1e293b;">
                    <td style="padding: 14px 0; text-align: left;">
                      <div style="font-weight: bold; color: #1e293b; font-size: 14px;">Educational Tuition Fee</div>
                      <div style="font-size: 12px; color: #c2410c; margin-top: 3px;">
                        Billing Term: ${data?.month || "Current"} Fee Monthly Tuition ${data?.year ? `(Year: ${data?.year})` : ""}
                        ${data?.batch_name ? `<br/><span style="font-size: 11px; color: #64748b; font-weight: normal;">Batch Name: ${data?.batch_name}</span>` : ""}
                      </div>
                    </td>
                    <td align="right" style="font-weight: bold; padding: 14px 0; font-size: 14px;">৳${data?.amount}</td>
                  </tr>
                  <tr style="font-size: 15px; color: #1e293b; font-weight: bold;">
                    <td style="padding: 16px 0 0 0; text-transform: uppercase; letter-spacing: 0.02em;">Total Paid</td>
                    <td align="right" style="padding: 16px 0 0 0; font-size: 18px; color: #ea580c;">৳${data?.amount}</td>
                  </tr>
                </tbody>
              </table>

              <div style="border-top: 1px dashed #fed7aa; padding-top: 20px; font-size: 11px; color: #c2410c; text-align: center; line-height: 1.5; font-family: sans-serif;">
                This paid invoice is generated electronically for educational enrollment at Jaber Math Care.<br/>If you have questions about this payment, please contact our support desk.
              </div>
                    `;
                } else if (type === "result_published") {
                   subject = `Result Published: ${data?.exam_name || "Exam"}`;
                   globalBg = "#f0f5ff";
                   accentShadow = "rgba(37,99,235,0.08)";
                   cardBorder = "#dbeafe";
                   topBar = "linear-gradient(90deg, #2563eb, #3b82f6)";
                   logoShadow = "rgba(37,99,235,0.15)";
                   logoBorder = "2px solid #f0fdf4";
                   taglineColor = "#2563eb";
                   taglineText = settings.hero_subtitle || "THE FUTURE OF MATH EDUCATION";
                   dividerCol = "#dbeafe";
                   footerBg = "#f8fafc";
                   footerBrandCol = "#2563eb";
                   footerMutedCol = "#1d4ed8";
                   linkCol = "#2563eb";
                   dotCol = "#bfdbfe";
                   copyCol = "#1d4ed8";

                   htmlBody = `
              <div style="text-align: center; margin-bottom: 25px;">
                <span style="display: inline-block; padding: 6px 16px; background-color: #eff6ff; color: #2563eb; font-weight: 700; font-size: 11px; border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em; border: 1px solid #bfdbfe; font-family: sans-serif;">
                  RESULT PUBLISHED
                </span>
              </div>

              <h2 style="color: #2563eb; font-size: 22px; font-weight: 800; margin: 0 0 10px 0; letter-spacing: -0.025em; font-family: sans-serif;">Exam Result</h2>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">Dear ${data?.student_name || "Student"},</p>
              <p style="font-size: 14px; color: #475569; line-height: 1.6; font-family: sans-serif;">
                Your result for <strong>${data?.exam_name || "the exam"}</strong> has been published. Your obtained score is listed below:
              </p>

              <div style="margin: 25px 0; padding: 20px; background-color: #f8fafc; border-radius: 16px; border: 1px solid #e2e8f0; text-align: center; font-family: sans-serif;">
                <div style="font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: 700;">Score / Marks Obtained</div>
                <div style="font-size: 38px; font-weight: 900; color: #2563eb; margin: 10px 0;">${data?.marks}</div>
                <div style="font-size: 11px; color: #94a3b8; font-weight: normal; margin-top: 5px;">
                  Exam: ${data?.exam_name || "Exam"}
                </div>
                ${data?.batch_name ? `<div style="font-size: 11px; color: #64748b; font-weight: normal; margin-top: 2px;">Batch: ${data?.batch_name}</div>` : ""}
                <div style="font-size: 11px; color: #94a3b8; margin-top: 5px;">Log in to the student dashboard to access detailed merit lists and answer sheets.</div>
              </div>

              <p style="font-size: 14px; color: #475569; line-height: 1.6; margin-top: 25px;">
                Wishing you a bright future,<br/><strong>Jaber Math Care Team</strong>
              </p>
                    `;
                } else if (type === "sponsorship_approved") {
                   subject = "Sponsorship Approved - Jaber Math Care";
                   globalBg = "#f0fdf4";
                   cardBorder = "#dcfce7";
                   topBar = "linear-gradient(90deg, #16a34a, #4ade80)";
                   taglineText = settings.hero_subtitle || "THANK YOU FOR YOUR SUPPORT";
                   taglineColor = "#16a34a";
                   accentShadow = "rgba(22,163,74,0.08)";
                   logoShadow = "rgba(22,163,74,0.15)";
                   logoBorder = "2px solid #f0fdf4";
                   footerBg = "#f9fbf9";
                   footerBrandCol = "#16a34a";
                   footerMutedCol = "#15803d";
                   linkCol = "#16a34a";
                   dotCol = "#bbf7d0";
                   copyCol = "#15803d";
                   recipient = data?.contact_email || recipient;

                   htmlBody = `
              <h2 style="color: #16a34a; font-size: 22px; font-weight: 800; margin: 0 0 10px 0; letter-spacing: -0.025em;">Sponsorship Approved!</h2>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">Dear ${data?.brand_name || "Partner"},</p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">
                We are excited to inform you that your sponsorship proposal for <strong style="color: #111827;">${data?.brand_name}</strong> has been officially approved and published on our platform!
              </p>
              
              <div style="margin: 25px 0; padding: 20px; background-color: #f0fdf4; border-radius: 16px; border-left: 5px solid #16a34a; font-family: sans-serif;">
                <p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Brand Name:</strong> <span style="color: #111827; font-weight: 700;">${data?.brand_name}</span></p>
                <p style="margin: 0; font-size: 13px; color: #15803d;"><strong>Status:</strong> <span style="color: #16a34a; font-weight: 700;">Active / Published</span></p>
              </div>

              <p style="font-size: 14px; color: #475569; margin: 0 0 25px 0; line-height: 1.6;">
                Your educational banner/ad is now visible to our student community. Thank you for supporting Jaber Math Care!
              </p>

              <p style="font-size: 14px; color: #475569; line-height: 1.6; margin-top: 25px;">
                Best regards,<br/><strong>Jaber Math Care Team</strong>
              </p>
                   `;
                }

                const logoUrl = settings.logo_url || "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512";
                const siteName = settings.site_name || "Jaber Math Care";
                const fbUrl = settings.facebook_url || "https://facebook.com";
                const ytUrl = settings.youtube_url || "https://youtube.com";
                const finalHtml = `
<div class="wrap-brand-framework" style="margin: 0 auto; padding:15px; background-color:${globalBg}; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; -webkit-font-smoothing: antialiased; border-radius:24px; max-width:600px; width:100%;">
  <table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed; background-color:${globalBg}; padding: 10px 0; border-radius:24px;">
    <tr>
      <td align="center">
        <!-- Card Container -->
        <table border="0" cellpadding="0" cellspacing="0" style="margin:10px auto; background-color:#ffffff; border-radius:24px; overflow:hidden; box-shadow:0 12px 24px -4px ${accentShadow}; border:1px solid ${cardBorder}; width: 100%; max-width: 550px;">
          <!-- Top Accent Bar -->
          <tr>
            <td height="6" style="background: ${topBar};"></td>
          </tr>
          <!-- Design Header -->
          <tr>
            <td align="center" style="padding:40px 30px 20px 30px; text-align:center;">
              <img src="${logoUrl}" alt="${siteName} Logo" width="84" height="84" style="width:84px; height:84px; object-fit:contain; border-radius:24px; padding:12px; display:block; margin: 0 auto 14px auto; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.06), 0 8px 10px -6px rgba(0,0,0,0.06); border: 1.5px solid #e2eaf4; background-color: #ffffff;" />
              <div style="font-size:32px; font-weight:900; color:#1e293b; margin:0; letter-spacing: -0.025em; font-family: sans-serif; line-height:1.2;">${siteName}</div>
              <div style="font-size:12px; font-weight:700; color:${taglineColor}; margin:6px 0 0 0; letter-spacing:0.05em; font-family: sans-serif;">The Future Math Education</div>
            </td>
          </tr>
          <!-- Elegant Line Divider -->
          <tr>
            <td style="padding: 0 35px;">
              <div style="border-bottom: 1px solid ${cardBorder};"></div>
            </td>
          </tr>
          <!-- Body Message Area -->
          <tr>
            <td style="padding:35px 35px 30px 35px; color:#334155; font-size:15px; line-height:1.6; text-align:left; font-family: sans-serif;">
              ${htmlBody}
            </td>
          </tr>
          <!-- Footer Branding Section -->
          <tr>
            <td style="padding:25px 35px 30px 35px; background-color:${footerBg}; border-top:1px solid ${cardBorder}; text-align:center; font-family: sans-serif;">
              <div style="font-size:13px; font-weight:700; color:${footerBrandCol}; margin:0;">${siteName}</div>
              <div style="font-size:11px; color:${footerMutedCol}; margin:4px 0 16px 0;">${settings.hero_subtitle || "Where mathematical excellence meets engineering dreams, shaping the innovators of tomorrow."}</div>
              
              <!-- Social Links -->
              <table border="0" cellpadding="0" cellspacing="0" align="center" style="margin: 0 auto;">
                <tr>
                  ${fbUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${fbUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:${linkCol}; font-weight:700;">Facebook Page</a>
                  </td>` : ''}
                  ${fbUrl && ytUrl ? `<td style="padding: 0 4px; color:${dotCol}; font-size:11px;">•</td>` : ''}
                  ${ytUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${ytUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:${linkCol}; font-weight:700;">YouTube Channel</a>
                  </td>` : ''}
                </tr>
              </table>
              
              <div style="font-size:10px; color:${copyCol}; margin-top:24px; font-family: sans-serif; line-height: 1.4;">
                © ${new Date().getFullYear()} ${siteName}. All rights reserved.<br />
                Developed by Mohammad Jaber Bin Razzak
              </div>
            </td>
          </tr>
         </table>
       </td>
     </tr>
   </table>
 </div>
      </td>
    </tr>
  </table>
</div>
     `;
                
                const payload = {
                  service_id: settings.emailjs_service_id,
                  template_id: settings.emailjs_template_id,
                  user_id: settings.emailjs_public_key,
                  template_params: {
                    to_email: recipient,
                    subject: subject,
                    message: textContent,
                    html_message: finalHtml,
                    message_html: finalHtml,
                    from_name: settings.site_name || "Jaber Math Care",
                    name: data?.name || data?.student_name || recipient,
                    student_name: data?.student_name || data?.name || recipient,
                    password: data?.password || "N/A",
                    roll_number: data?.roll_number || "N/A",
                    marks: data?.marks || data?.obtained_marks || "N/A",
                    exam_name: data?.exam_name || "N/A",
                    amount: data?.amount || "N/A",
                    month: data?.month || "N/A",
                    course_title: data?.course_title || data?.program_title || "N/A",
                    program_title: data?.program_title || data?.course_title || "N/A",
                    ...(data || {})
                  }
                };
                
                const response = await originalFetch("https://api.emailjs.com/api/v1.0/email/send", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify(payload)
                });
                
                const resText = await response.text();
                console.log("[Firebase Adapter] Client-side EmailJS dispatched!", response.status, resText);
                if (response.ok) {
                  return baseCreateResponse({ success: true, client_emailjs: true });
                } else {
                  return baseCreateResponse({ error: "EmailJS API Error", details: resText }, response.status);
                }
             } else {
                 return baseCreateResponse({ error: "Missing EmailJS configuration" }, 400);
             }
           }
         } catch(e: any) {
           console.error("[Firebase Adapter] Client-side EmailJS attempt failed", e);
           return baseCreateResponse({ error: "EmailJS Adapter Exception", details: e.message }, 500);
         }
      }

      if (path === "emailjs-debug") {
        try {
          const pubDoc = await getDoc(doc(db, "settings", "emailjs_public_key"));
          const srvDoc = await getDoc(doc(db, "settings", "emailjs_service_id"));
          const tmplDoc = await getDoc(doc(db, "settings", "emailjs_template_id"));
          const privDoc = await getDoc(doc(db, "settings", "emailjs_private_key"));
          return createResponse({
            emailjs_public_key_exists: pubDoc.exists(),
            emailjs_public_key_value: pubDoc.exists() ? pubDoc.data().value : null,
            emailjs_service_id_exists: srvDoc.exists(),
            emailjs_service_id_value: srvDoc.exists() ? srvDoc.data().value : null,
            emailjs_template_id_exists: tmplDoc.exists(),
            emailjs_template_id_value: tmplDoc.exists() ? tmplDoc.data().value : null,
            emailjs_private_key_exists: privDoc.exists(),
            emailjs_private_key_length: privDoc.exists() ? (privDoc.data().value || "").length : 0,
            emailjs_private_key_preview: privDoc.exists() && privDoc.data().value ? privDoc.data().value.substring(0, 5) + "..." : null
          });
        } catch (e: any) {
           return createResponse({ error: "Failed to read emailjs diagnostics", details: e.message }, 500);
        }
      }

      if (path === "verify-mail-settings") {
        return createResponse({
          success: true,
          message: "Diagnostics are successful (Client-side intercepted). Notification systems should work.",
        });
      }

      if (path === "send-email" || path === "send-email-bulk") {
         try {
            const setSnap = await getDocs(collection(db, "settings"));
            let settings: any = {};
            setSnap.forEach(d => settings[d.id] = d.data().value);
            
            if (settings.email_gateway_type === "emailjs") {
              if (settings.emailjs_service_id && settings.emailjs_template_id && settings.emailjs_public_key) {
                 const isBulk = path === "send-email-bulk";
                 const recipients = isBulk ? body.emails || [] : [body.email || body.to];
                 const subject = body.subject || "Notification";
                 const messageText = body.message || "";
                 
                 const promises = recipients.map(async (recipient: string) => {
                   if (!recipient) return null;
                   const payload = {
                     service_id: settings.emailjs_service_id,
                     template_id: settings.emailjs_template_id,
                     user_id: settings.emailjs_public_key,
                     template_params: {
                       to_email: recipient,
                       subject: subject,
                       message: messageText,
                       html_content: messageText,
                       student_name: body.name || recipient,
                       ...body
                     }
                   };
                   return originalFetch("https://api.emailjs.com/api/v1.0/email/send", {
                     method: "POST",
                     headers: { "Content-Type": "application/json" },
                     body: JSON.stringify(payload)
                   });
                 });
                 
                 const results = await Promise.all(promises);
                 const failed = results.filter(r => r && !r.ok);
                 if (failed.length > 0) {
                   return baseCreateResponse({ error: "Some or all EmailJS messages failed", failedCount: failed.length }, 500);
                 }
                 return baseCreateResponse({ success: true, client_emailjs: true, count: promises.length });
              } else {
                 return baseCreateResponse({ error: "Missing EmailJS configuration" }, 400);
              }
            } else {
               // Ignore if not emailjs and running in client only
               return baseCreateResponse({ success: true, message: "Ignored (not emailjs)" });
            }
         } catch(e: any) {
            console.error("[Firebase Adapter] Client-side EmailJS attempt failed", e);
            return baseCreateResponse({ error: "EmailJS Adapter Exception", details: e.message }, 500);
         }
      }

      if (path === "forgot-password/request") {
        if (!body.email) return createResponse({ error: "Email required" }, 400);
        try {
          await sendPasswordResetEmail(auth, body.email);
          return createResponse({ success: true, message: "Password reset email sent (via Firebase Auth)" });
        } catch (e: any) {
          return createResponse({ error: e.message }, 500);
        }
      }
      
      if (path === "forgot-password/verify" || path === "forgot-password/reset") {
         return createResponse({ error: "Please use the password reset link sent to your email by Firebase to reset your password. The verification code UI is unavailable in client-only mode." }, 400);
      }

      if (path === "send-sms") {
        return createResponse({
          success: true,
          message: "SMS functionality is simulated in client-only mode. No real SMS was sent."
        });
      }

      try {
        if (backendOrigin) {
          let finalInput = input;
          if (typeof input === "string") {
            if (input.startsWith("/api/")) {
              finalInput = backendOrigin + input;
            } else if (input.includes("/api/")) {
              const parts = input.split("/api/");
              finalInput = backendOrigin + "/api/" + parts[1];
            }
          } else if (input instanceof URL) {
            if (input.pathname.startsWith("/api/")) {
              finalInput = new URL(backendOrigin + input.pathname + input.search);
            }
          }
          return await originalFetch(finalInput, init);
        }
        
        return await originalFetch(input, init);
      } catch (err: any) {
        console.warn(`[Firebase Interceptor] Bypass route ${path} failed with network error:`, err.message);
        return createResponse(
          { 
            error: "API Backend Unreachable", 
            details: `The Node.js backend server could not be reached. Ensure your server is running and accessible. (Message: ${err.message})` 
          }, 
          503
        );
      }
    }

    // console.log(`[Firebase Adapter] Intercepting fetch: ${method} /api/${path}`);

    /* 
  // Disable caching for "real-time fresh data" as requested
  if (method === 'GET') {
    const cached = apiCache.get(url);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      console.log(`[Firebase Adapter] Serving from cache: ${url}`);
      return baseCreateResponse(cached.data);
    }
  }
  */

    console.log(`[Firebase Adapter] Intercepted ${method} /api/${path}`, body);

    try {
      // ----------------------------------------------------------------------
      // PUBLIC ENDPOINTS
      // ----------------------------------------------------------------------
      if (path === "public/notices") {
        try {
          const snapshot = await getDocs(collection(db, "notices"));
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "notices");
        }
      }

      if (path === "public/settings") {
        try {
          const snapshot = await getDocs(collection(db, "settings"));
          const settings: Record<string, string> = {};
          snapshot.docs.forEach((d) => {
            settings[d.id] = d.data().value;
          });
          return createResponse(settings);
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "settings");
        }
      }

      if (path === "public/exams") {
        try {
          const snapshot = await getDocs(collection(db, "exams"));
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "exams");
        }
      }

      if (path === "public/programs") {
        try {
          const snapshot = await getDocs(collection(db, "programs"));
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "programs");
        }
      }

      if (path === "public/batches") {
        try {
          const snapshot = await getDocs(collection(db, "batches"));
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "batches");
        }
      }

      if (path.startsWith("public/results")) {
        try {
          const urlObj = new URL(url, window.location.origin);
          const exam_name = urlObj.searchParams.get("exam_name");
          const roll_number = urlObj.searchParams.get("roll_number");

          console.log(
            `[Firebase Adapter] Fetching results for exam: ${exam_name}, roll: ${roll_number}`,
          );

          let q = collection(db, "results");
          const constraints = [];
          if (exam_name) constraints.push(where("exam_name", "==", exam_name));

          const snapshot = await getDocs(query(q, ...constraints));
          console.log(
            `[Firebase Adapter] Found ${snapshot.size} results documents`,
          );
          let results = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }));

          if (roll_number) {
            // Fetch student to match roll number
            const studentsSnap = await getDocs(
              query(collection(db, "users"), where("role", "==", "student")),
            );
            const student = studentsSnap.docs.find(
              (d) => d.data().roll_number === roll_number,
            );
            if (student) {
              results = results.filter((r: any) => r.student_id === student.id);
            } else {
              results = []; // Student not found
            }
          }

          console.log(
            `[Firebase Adapter] Filtered results count: ${results.length}`,
          );

          // Enrich results with student and exam info
          const enrichedResults = await Promise.all(
            results.map(async (res: any) => {
              let studentName = "Unknown";
              let studentRoll = "Unknown";
              let studentClass = "Unknown";
              let examCategory = "Unknown";
              let programId = "";

              if (res.student_id) {
                try {
                  const studentSnap = await getDoc(
                    doc(db, "users", res.student_id),
                  );
                  if (studentSnap.exists()) {
                    studentName = studentSnap.data().name || "Unknown";
                    studentRoll = studentSnap.data().roll_number || "Unknown";
                    studentClass =
                      studentSnap.data().class ||
                      studentSnap.data().current_class ||
                      "Unknown";
                    if (!res.batch_id) {
                      res.batch_id = studentSnap.data().batch_id;
                    }
                  }
                } catch (e) {
                  console.warn(
                    `[Firebase Adapter] Could not fetch student ${res.student_id} (likely permissions):`,
                    e,
                  );
                }
              }

              if (studentClass === "Unknown" && res.batch_id) {
                try {
                  const batchSnap = await getDoc(
                    doc(db, "batches", res.batch_id),
                  );
                  if (batchSnap.exists()) {
                    studentClass =
                      batchSnap.data().class ||
                      batchSnap.data().class_name ||
                      batchSnap.data().batch_class ||
                      "Unknown";
                  }
                } catch (e) {
                  console.warn(
                    `[Firebase Adapter] Could not fetch batch ${res.batch_id}:`,
                    e,
                  );
                }
              }

              if (!res.exam_id && res.exam_name) {
                try {
                  const examsSnap = await getDocs(
                    query(
                      collection(db, "exams"),
                      where("exam_name", "==", res.exam_name),
                    ),
                  );
                  if (!examsSnap.empty) {
                    res.exam_id = examsSnap.docs[0].id;
                  }
                } catch (e) {
                  console.warn(
                    `[Firebase Adapter] Could not fetch exam by name ${res.exam_name}:`,
                    e,
                  );
                }
              }

              if (res.exam_id) {
                try {
                  const examSnap = await getDoc(doc(db, "exams", res.exam_id));
                  if (examSnap.exists()) {
                    examCategory = examSnap.data().category || "Unknown";
                    programId = examSnap.data().program_id || "";
                    res.total_marks = examSnap.data().total_marks || 0;
                  }
                } catch (e) {
                  console.warn(
                    `[Firebase Adapter] Could not fetch exam ${res.exam_id}:`,
                    e,
                  );
                }
              }

              return {
                ...res,
                student_name: studentName,
                roll_number: studentRoll,
                student_class: studentClass,
                exam_category: examCategory,
                program_id: programId,
                monthly_fee: res.monthly_fee || 0,
              };
            }),
          );

          console.log(
            `[Firebase Adapter] Enriched results count: ${enrichedResults.length}`,
          );

          return createResponse(enrichedResults);
        } catch (error) {
          handleFirestoreError(error, OperationType.LIST, "results");
        }
      }

      if (path === "validate-coupon") {
        try {
          const { code, amount } = body;
          const q = query(
            collection(db, "coupons"),
            where("code", "==", code.toUpperCase()),
            where("status", "==", "active")
          );
          const snapshot = await getDocs(q);
          
          if (snapshot.empty) return createResponse({ error: "Invalid coupon code" }, 404);
          
          const coupon: any = snapshot.docs[0].data();
          const now = new Date();
          if (coupon.expiry_date && new Date(coupon.expiry_date) < now) {
            return createResponse({ error: "Coupon has expired" }, 400);
          }

          let discount = 0;
          if (coupon.type === "percentage") {
            discount = (Number(amount) * Number(coupon.value)) / 100;
          } else {
            discount = Number(coupon.value);
          }

          return createResponse({ 
            success: true, 
            discount,
            coupon_id: snapshot.docs[0].id
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, "coupons");
        }
      }

      if (path === "degrees") {
        if (method === "GET") {
          const snapshot = await getDocs(collection(db, "degrees"));
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        }
        if (method === "POST") {
          const docRef = await addDoc(collection(db, "degrees"), {
            ...body,
            created_at: new Date().toISOString(),
          });
          return createResponse({ id: docRef.id, ...body });
        }
      }
      if (path.startsWith("degrees/")) {
        const id = path.split("/")[1];
        if (method === "DELETE") {
          await deleteDoc(doc(db, "degrees", id));
          return createResponse({ success: true });
        }
      }

      // ----------------------------------------------------------------------
      // SETTINGS
      // ----------------------------------------------------------------------
      if (path === "settings") {
        if (method === "GET") {
          const snapshot = await getDocs(collection(db, "settings"));
          const settings: Record<string, string> = {};
          snapshot.docs.forEach((d) => {
            settings[d.id] = d.data().value;
          });
          return createResponse(settings);
        }
        if (method === "POST") {
          const { key, value } = body;
          if (key) {
            await setDoc(doc(db, "settings", key), { value });
          }
          return createResponse({ success: true });
        }
        if (method === "PUT") {
          for (const [key, value] of Object.entries(body)) {
            await setDoc(doc(db, "settings", key), { value });
          }
          return createResponse({ success: true });
        }
      }

      // ----------------------------------------------------------------------
      // CLEAR ALL DATA
      // ----------------------------------------------------------------------
      if (path === "admin/clear-all-data") {
        if (method === "POST") {
          try {
            const collectionsToClear = [
              "users",
              "batches",
              "programs",
              "chapters",
              "attendance",
              "payments",
              "notices",
              "routines",
              "gallery",
              "exams",
              "results",
              "reviews",
              "video_classes",
              "study_materials",
              "enrollments",
              "live_classes",
            ];

            for (const coll of collectionsToClear) {
              const snap = await getDocs(collection(db, coll));
              const batchRef = writeBatch(db);
              snap.docs.forEach((d) => {
                // Don't delete the current admin user
                if (coll === "users" && d.id === auth.currentUser?.uid) return;
                batchRef.delete(d.ref);
              });
              await batchRef.commit();
            }

            return createResponse({ success: true });
          } catch (error) {
            handleFirestoreError(error, OperationType.WRITE, "all");
          }
        }
      }

      // ----------------------------------------------------------------------
      // CLEAR PAST ATTENDANCE
      // ----------------------------------------------------------------------
      if (path === "admin/clear-past-attendance") {
        if (method === "POST") {
          try {
            const today = new Date().toISOString().split("T")[0];
            const snapshot = await getDocs(
              query(collection(db, "attendance"), where("date", "<", today)),
            );
            const batchRef = writeBatch(db);
            snapshot.docs.forEach((d) => batchRef.delete(d.ref));
            await batchRef.commit();
            return createResponse({ success: true, count: snapshot.size });
          } catch (error) {
            handleFirestoreError(error, OperationType.WRITE, "attendance");
          }
        }
      }

      // ----------------------------------------------------------------------
      // SPONSORSHIP
      // ----------------------------------------------------------------------
      if (path === "approve-sponsorship" && method === "POST") {
        try {
          const { id } = body;
          if (!id) return createResponse({ error: "Missing ID" }, 400);

          const sponsorRef = doc(db, "sponsorships", id);
          const sponsorDoc = await getDoc(sponsorRef);
          if (!sponsorDoc.exists()) return createResponse({ error: "Sponsorship not found" }, 404);

          const data = sponsorDoc.data() || {};
          await updateDoc(sponsorRef, { status: "active" });

          // Send email if contact_email exists via our existing system email proxy
          if (data.contact_email) {
            // We use the same system email helper but for sponsorship
             try {
                await originalFetch("/api/send-system-email", {
                   method: "POST",
                   headers: { "Content-Type": "application/json" },
                   body: JSON.stringify({
                     type: "sponsorship_approved",
                     data: data
                   })
                });
             } catch(e) {
                console.warn("Failed to dispatch sponsor email", e);
             }
          }
          return createResponse({ success: true });
        } catch (error) {
           handleFirestoreError(error, OperationType.WRITE, "sponsorships");
        }
      }

      // ----------------------------------------------------------------------
      // STUDENTS / USERS
      // ----------------------------------------------------------------------
      if (path === "students") {
        if (method === "GET") {
          try {
            const q = query(
              collection(db, "users"),
              where("role", "==", "student"),
            );
            const snapshot = await getDocs(q);
            const data = snapshot.docs.map((d) => ({ ...d.data(), id: d.id }));
            return createResponse(data);
          } catch (error) {
            handleFirestoreError(error, OperationType.LIST, "users");
          }
        }
        if (method === "POST") {
          console.log("Creating student:", body);
          const { email, password, enrollment_id, ...restBody } = body;
          if (!email || !password) {
            return createResponse(
              { error: "Email and password are required" },
              400,
            );
          }

          const cleanEmail = email.trim();

          // Simple email validation
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(cleanEmail)) {
            return createResponse({ error: "Invalid email format" }, 400);
          }

          try {
            // Create user in Firebase Auth using secondary app to avoid logging out current user
            const userCredential = await createUserWithEmailAndPassword(
              secondaryAuth,
              cleanEmail,
              password,
            );
            const uid = userCredential.user.uid;

             const docData = {
              ...restBody,
              email: cleanEmail,
              role: "student",
              status: "approved",
              created_at: new Date().toISOString(),
              initial_password: password,
            };
            await setDoc(doc(db, "users", uid), docData);

            if (enrollment_id) {
              await updateDoc(doc(db, "enrollments", enrollment_id), {
                status: "approved",
                user_id: uid
              });
            }

            // Trigger student welcome email asynchronously
            window.fetch("/api/send-system-email", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                type: "student_welcome",
                data: {
                  name: docData.name,
                  email: cleanEmail,
                  password: password,
                  course_title: docData.course_title || docData.program_title || "",
                  roll_number: docData.roll_number || ""
                }
              })
            }).catch(e => console.error("Welcome email background send failed:", e));

            return createResponse({ id: uid, ...docData });
          } catch (error: any) {
            console.error("Error creating student:", error);
            if (error.code === "auth/email-already-in-use") {
              // Find existing user and update
              const q = query(
                collection(db, "users"),
                where("email", "==", cleanEmail),
              );
              const querySnapshot = await getDocs(q);
              if (!querySnapshot.empty) {
                const existingUid = querySnapshot.docs[0].id;
                const docData = {
                  ...restBody,
                  email: cleanEmail,
                  role: "student",
                  status: "approved",
                  updated_at: new Date().toISOString(),
                };
                await updateDoc(doc(db, "users", existingUid), docData);

                if (enrollment_id) {
                  await updateDoc(doc(db, "enrollments", enrollment_id), {
                    status: "approved",
                    user_id: existingUid
                  });
                }

                // Trigger welcome email asynchronously for updated user
                window.fetch("/api/send-system-email", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    type: "student_welcome",
                    data: {
                      name: docData.name,
                      email: cleanEmail,
                      password: "[Sufficient to use existing password]",
                      course_title: docData.course_title || docData.program_title || "",
                      roll_number: docData.roll_number || ""
                    }
                  })
                }).catch(e => console.error("Welcome email background update send failed:", e));
                
                return createResponse({ id: existingUid, ...docData });
              }
              return createResponse({ error: "Email is already in use" }, 409);
            }
            if (
              error.message &&
              error.message.includes("insufficient permissions")
            ) {
              handleFirestoreError(error, OperationType.WRITE, "users");
            }
            throw error;
          }
        }
      }

      if (path.startsWith("students/")) {
        const id = path.split("/")[1];
        if (method === "GET") {
          const docSnap = await getDoc(doc(db, "users", id));
          if (docSnap.exists()) {
            // Fetch related data
            const [attendanceSnap, paymentsSnap, resultsSnap] =
              await Promise.all([
                getDocs(
                  query(
                    collection(db, "attendance"),
                    where("student_id", "==", id),
                  ),
                ),
                getDocs(
                  query(
                    collection(db, "payments"),
                    where("student_id", "==", id),
                  ),
                ),
                getDocs(
                  query(
                    collection(db, "results"),
                    where("student_id", "==", id),
                  ),
                ),
              ]);

            // Also check by roll number if student_id was stored as roll
            let attendanceRecords = attendanceSnap.docs.map((d) => ({
              ...d.data(),
              id: d.id,
            }));
            if (attendanceRecords.length === 0 && docSnap.data().roll_number) {
              const rollSnap = await getDocs(
                query(
                  collection(db, "attendance"),
                  where("student_id", "==", String(docSnap.data().roll_number)),
                ),
              );
              attendanceRecords = rollSnap.docs.map((d) => ({
                ...d.data(),
                id: d.id,
              }));
            }

            return createResponse({
              id: docSnap.id,
              ...docSnap.data(),
              attendance: attendanceRecords,
              payments: paymentsSnap.docs.map((d) => ({
                ...d.data(),
                id: d.id,
              })),
              results: resultsSnap.docs.map((d) => ({ ...d.data(), id: d.id })),
            });
          }
          return createResponse({ error: "Not found" }, 404);
        }
        if (method === "PUT") {
          try {
            // Remove undefined values and relation arrays so we don't save nested giant arrays in Firestore users doc
            const {
              id: _id,
              attendance,
              payments,
              results,
              ...restBody
            } = body;
            const sanitizedBody = Object.fromEntries(
              Object.entries(restBody).filter(([_, v]) => v !== undefined),
            );
            await updateDoc(doc(db, "users", id), sanitizedBody);
            return createResponse({ success: true });
          } catch (error: any) {
            console.error("Error updating student:", error);
            if (
              error.message &&
              error.message.includes("insufficient permissions")
            ) {
              handleFirestoreError(error, OperationType.WRITE, "users");
            }
            return createResponse(
              { error: error.message || "Failed to update student" },
              500,
            );
          }
        }
        if (method === "PATCH" && path.endsWith("/status")) {
          await updateDoc(doc(db, "users", id), { status: body.status });
          return createResponse({ success: true });
        }
        if (method === "DELETE") {
          try {
            const userDocSnap = await getDoc(doc(db, "users", id));
            const rollNumber = userDocSnap.exists() ? userDocSnap.data()?.roll_number : null;

            const batchRef = writeBatch(db);

            // Delete the user document
            batchRef.delete(doc(db, "users", id));

            const idMatches: any[] = [id];
            if (rollNumber !== undefined && rollNumber !== null && String(rollNumber).trim() !== "") {
              const rollStr = String(rollNumber).trim();
              idMatches.push(rollStr);
              if (!isNaN(Number(rollStr))) {
                idMatches.push(Number(rollStr));
              }
            }

            const studentCollections = [
              { name: "attendance", matchField: "student_id" },
              { name: "payments", matchField: "student_id" },
              { name: "results", matchField: "student_id" },
              { name: "study_materials", matchField: "student_id" },
              { name: "enrollments", matchField: "student_id" },
              { name: "messages", matchField: "student_id" },
            ];

            for (const colInfo of studentCollections) {
              for (const matchVal of idMatches) {
                const snap = await getDocs(
                  query(
                    collection(db, colInfo.name),
                    where(colInfo.matchField, "==", matchVal)
                  )
                );
                snap.docs.forEach((d) => {
                  try {
                    batchRef.delete(d.ref);
                  } catch (e) {}
                });
              }
            }

            const collectionsWithRoll = ["attendance", "payments", "results", "enrollments"];
            if (rollNumber !== undefined && rollNumber !== null && String(rollNumber).trim() !== "") {
              const rollMatches: any[] = [String(rollNumber).trim()];
              if (!isNaN(Number(rollNumber))) {
                rollMatches.push(Number(rollNumber));
              }
              for (const colName of collectionsWithRoll) {
                for (const rMatch of rollMatches) {
                  const snap = await getDocs(
                    query(
                      collection(db, colName),
                      where("roll_number", "==", rMatch)
                    )
                  );
                  snap.docs.forEach((d) => {
                    try {
                      batchRef.delete(d.ref);
                    } catch (e) {}
                  });
                }
              }
            }

            await batchRef.commit();
            return createResponse({ success: true });
          } catch (error: any) {
            console.error("Error deleting student:", error);
            if (
              error.message &&
              error.message.includes("insufficient permissions")
            ) {
              handleFirestoreError(error, OperationType.DELETE, "users");
            }
            return createResponse(
              { error: error.message || "Failed to delete student" },
              500,
            );
          }
        }
      }

      // ----------------------------------------------------------------------
      // ATTENDANCE
      // ----------------------------------------------------------------------
      if (path === "attendance/mark-present" && method === "POST") {
        const uid = getCurrentUserId();
        if (!uid) return createResponse({ error: "Unauthorized" }, 401);

        const { batch_id, date, type, exam_id } = body;

        // Check if already marked for this day
        const q = query(
          collection(db, "attendance"),
          where("student_id", "==", uid),
          where("date", "==", date),
        );
        const snapshot = await getDocs(q);

        // Filter by type if needed
        const existing = snapshot.docs.find((d) => {
          const data = d.data();
          if (type === "exam") {
            return data.type === "exam" && data.exam_id === exam_id;
          }
          return data.type !== "exam";
        });

        if (existing) {
          // If it was 'absent', update to 'present'
          if (existing.data().status === "absent") {
            await updateDoc(doc(db, "attendance", existing.id), {
              status: "present",
              updated_at: new Date().toISOString(),
              time: new Date().toLocaleTimeString(),
            });
          }
          return createResponse({
            success: true,
            message: "Already marked or updated",
          });
        }

        // Create new present record
        const docData: any = {
          student_id: uid,
          batch_id: batch_id || null,
          date,
          status: "present",
          type: type || "class",
          time: new Date().toLocaleTimeString(),
          created_at: new Date().toISOString(),
          method: "automatic",
        };
        if (exam_id) docData.exam_id = exam_id;

        await addDoc(collection(db, "attendance"), docData);
        return createResponse({ success: true, record: docData });
      }

      if (path.startsWith("attendance/") && method === "PUT") {
        const id = path.split("/")[1];
        if (id && id !== "mark-present" && id !== "auto-absent" && id !== "batch" && id !== "report") {
          await updateDoc(doc(db, "attendance", id), {
            ...body,
            updated_at: new Date().toISOString(),
          });
          return createResponse({ success: true });
        }
      }

      if (path === "attendance") {
        if (method === "POST") {
          if (!body.records) {
            // single post
            const docRef = await addDoc(collection(db, "attendance"), {
              ...body,
              created_at: new Date().toISOString(),
            });
            return createResponse({ success: true, id: docRef.id });
          }
          
          const { batch_id, date, time, records } = body;
          const results = [];

          // Fetch existing records for this batch and date ONCE to avoid multiple queries
          const existingSnap = await getDocs(
            query(
              collection(db, "attendance"),
              where("batch_id", "==", batch_id),
            ),
          );
          const existingRecords = existingSnap.docs.filter(
            (d) => d.data().date === date,
          );
          const existingMap = new Map(
            existingRecords.map((d) => [d.data().student_id, d.id]),
          );

          // Use Promise.all to handle multiple records
          await Promise.all(
            records.map(async (record: any) => {
              const docData: any = {
                batch_id,
                date,
                time,
                student_id: record.student_id,
                status: record.status,
                created_at: new Date().toISOString(),
              };
              if (body.type) docData.type = body.type;
              if (body.exam_id) docData.exam_id = body.exam_id;

              let existingDocId;
              if (body.type === "exam") {
                const existingExamRecords = existingSnap.docs.filter((d) => {
                  const data = d.data();
                  return (
                    data.date === date &&
                    data.type === "exam" &&
                    String(data.exam_id) === String(body.exam_id)
                  );
                });
                const existingExamMap = new Map(
                  existingExamRecords.map((d) => [d.data().student_id, d.id]),
                );
                existingDocId = existingExamMap.get(record.student_id);
              } else {
                const existingClassRecords = existingSnap.docs.filter(
                  (d) => d.data().date === date && d.data().type !== "exam",
                );
                const existingClassMap = new Map(
                  existingClassRecords.map((d) => [d.data().student_id, d.id]),
                );
                existingDocId = existingClassMap.get(record.student_id);
              }

              if (existingDocId) {
                // Update existing
                await updateDoc(doc(db, "attendance", existingDocId), docData);
                results.push({ id: existingDocId, ...docData });
              } else {
                // Create new
                const docRef = await addDoc(
                  collection(db, "attendance"),
                  docData,
                );
                results.push({ id: docRef.id, ...docData });
              }
            }),
          );

          return createResponse({ success: true, records: results });
        }
      }

      if (path.startsWith("attendance/batch/")) {
        const parts = path.split("/");
        const batchId = parts[2];
        const date = parts[3];

        if (method === "GET") {
          const studentsSnap = await getDocs(
            query(collection(db, "users"), where("role", "==", "student")),
          );
          const students = studentsSnap.docs
            .filter(
              (d) =>
                String(d.data().batch_id) === String(batchId) ||
                String(d.data().batch_id_2) === String(batchId),
            )
            .map((d) => ({ ...d.data(), id: d.id }));

          const attendanceSnap = await getDocs(
            query(
              collection(db, "attendance"),
              where("batch_id", "==", batchId),
            ),
          );
          const markedIds = attendanceSnap.docs
            .filter((d) => d.data().date === date)
            .map((d) => d.data().student_id);

          return createResponse({ students, markedStudents: markedIds });
        }
      }

      if (path.startsWith("attendance/report")) {
        try {
          const urlObj = new URL(url, window.location.origin);
          const batch_id = urlObj.searchParams.get("batch_id");
          const program_id = urlObj.searchParams.get("program_id");
          const startDate = urlObj.searchParams.get("startDate");
          const endDate = urlObj.searchParams.get("endDate");
          const type = urlObj.searchParams.get("type");
          const status = urlObj.searchParams.get("status");

          let snapshot;
          // Fetch base records: use batch_id if provided to limit data size
          if (batch_id && batch_id !== "all" && batch_id !== "") {
            snapshot = await getDocs(
              query(
                collection(db, "attendance"),
                where("batch_id", "==", batch_id),
              ),
            );
          } else {
            snapshot = await getDocs(collection(db, "attendance"));
          }

          let records = snapshot.docs.map((d) => ({
            id: d.id,
            ...(d.data() as any),
          }));

          // In-memory filtering to avoid requiring Firestore composite indexes
          if (type) records = records.filter((r) => r.type === type);
          if (status) records = records.filter((r) => r.status === status);
          if (startDate) records = records.filter((r) => r.date >= startDate);
          if (endDate) records = records.filter((r) => r.date <= endDate);

          // Optimize enrichment by gathering unique IDs first
          const uniqueStudentIds = [
            ...new Set(records.map((r) => r.student_id).filter(Boolean)),
          ];
          const uniqueBatchIds = [
            ...new Set(records.map((r) => r.batch_id).filter(Boolean)),
          ];

          const studentCache = new Map();
          const batchCache = new Map();

          // Fetch all needed students in batches
          const chunkSize = 10;
          for (let i = 0; i < uniqueStudentIds.length; i += chunkSize) {
            const chunk = uniqueStudentIds.slice(i, i + chunkSize);
            await Promise.all(
              chunk.map(async (id) => {
                try {
                  const snap = await getDoc(doc(db, "users", String(id)));
                  if (snap.exists()) studentCache.set(id, snap.data());
                } catch (e) {
                  console.warn(`Could not fetch student ${id}:`, e);
                }
              }),
            );
          }

          // Fetch batches
          for (let i = 0; i < uniqueBatchIds.length; i += chunkSize) {
            const chunk = uniqueBatchIds.slice(i, i + chunkSize);
            await Promise.all(
              chunk.map(async (id) => {
                try {
                  const snap = await getDoc(doc(db, "batches", String(id)));
                  if (snap.exists()) batchCache.set(id, snap.data());
                } catch (e) {
                  console.warn(`Could not fetch batch ${id}:`, e);
                }
              }),
            );
          }

          // Fetch students and batches to enrich the data (and filter by program_id if needed)
          let enrichedRecords = records.map((record: any) => {
            let studentName = "Unknown";
            let rollNumber = "Unknown";
            let batchName = "Unknown";
            let studentProgramId = "";

            if (record.student_id) {
              const studentData = studentCache.get(record.student_id);
              if (studentData) {
                studentName = studentData.name || "Unknown";
                rollNumber = studentData.roll_number || "Unknown";
                studentProgramId = studentData.program_id || "";
              }
            }

            if (record.batch_id) {
              const batchData = batchCache.get(record.batch_id);
              if (batchData) {
                batchName = batchData.name || "Unknown";
                if (!studentProgramId) {
                  studentProgramId = batchData.program_id || "";
                }
              }
            }

            return {
              ...record,
              student_name: studentName,
              roll_number: rollNumber,
              batch_name: batchName,
              program_id: studentProgramId,
            };
          });

          if (program_id) {
            enrichedRecords = enrichedRecords.filter(
              (r) => r.program_id === program_id,
            );
          }

          return createResponse(enrichedRecords);
        } catch (error) {
          console.error("Error generating attendance report:", error);
          return createResponse(
            { error: "Failed to generate attendance report" },
            500,
          );
        }
      }

      // ----------------------------------------------------------------------
      // MY PROFILE (STUDENT DASHBOARD)
      // ----------------------------------------------------------------------
      if (path === "my-profile/image") {
        const uid = getCurrentUserId();
        if (!uid) return createResponse({ error: "Unauthorized" }, 401);

        if (method === "POST") {
          await updateDoc(doc(db, "users", uid), {
            profile_pic: body.image_url,
          });
          return createResponse({ success: true });
        }
      }

      if (path === "my-profile") {
        const uid = getCurrentUserId();
        if (!uid) return createResponse({ error: "Unauthorized" }, 401);

        if (method === "PUT") {
          await updateDoc(doc(db, "users", uid), body);
          return createResponse({ success: true });
        }

        const userSnap = await getDoc(doc(db, "users", uid));
        if (!userSnap.exists())
          return createResponse({ error: "User not found" }, 404);

        const userData = userSnap.data();

        // Parallelize main data fetches
        const [attendanceSnap, paymentsSnap, resultsSnap] = await Promise.all([
          getDocs(
            query(collection(db, "attendance"), where("student_id", "==", uid)),
          ),
          getDocs(
            query(collection(db, "payments"), where("student_id", "==", uid)),
          ),
          getDocs(
            query(collection(db, "results"), where("student_id", "==", uid)),
          ),
        ]);

        let batchData = null;
        let batch_name = "Regular Batch";
        let programData = null;

        if (userData.batch_id) {
          const batchSnap = await getDoc(doc(db, "batches", userData.batch_id));
          if (batchSnap.exists()) {
            batchData = { id: batchSnap.id, ...batchSnap.data() };
            batch_name =
              batchData.name || batchData.batch_name || "Regular Batch";

            if (batchData.program_id) {
              const programSnap = await getDoc(
                doc(db, "programs", batchData.program_id),
              );
              if (programSnap.exists()) {
                programData = { id: programSnap.id, ...programSnap.data() };
              }
            }
          }
        }

        // Cache for batch/program info to avoid redundant fetches in results loop
        const batchCache = new Map();
        if (batchData) batchCache.set(userData.batch_id, batchData);

        const results = await Promise.all(
          resultsSnap.docs.map(async (d) => {
            const data = d.data();
            let b_name = "N/A";
            let b_class = "N/A";

            if (data.batch_id) {
              let bData = batchCache.get(data.batch_id);
              if (!bData) {
                const bSnap = await getDoc(doc(db, "batches", data.batch_id));
                if (bSnap.exists()) {
                  bData = bSnap.data();
                  batchCache.set(data.batch_id, bData);
                }
              }
              if (bData) {
                b_name = bData.name || bData.batch_name || "N/A";
                b_class = bData.class_name || bData.batch_class || "N/A";
              }
            }

            // Merit position calculation is expensive, only do it if needed
            let merit_position = data.merit_position || "";
            // For performance, we'll skip the live merit calculation here if it's not already stored
            // or we could implement a more efficient way to get it.

            return {
              id: d.id,
              ...data,
              batch_name: b_name,
              batch_class: b_class,
              merit_position,
            };
          }),
        );

        return createResponse({
          user: { id: uid, ...userData, batch_name },
          batch: batchData,
          program: programData,
          attendance: attendanceSnap.docs.map((d) => ({
            ...d.data(),
            id: d.id,
          })),
          payments: paymentsSnap.docs.map((d) => ({ ...d.data(), id: d.id })),
          results,
        });
      }

      // ----------------------------------------------------------------------
      // MODERATORS
      // ----------------------------------------------------------------------
      if (path === "moderators") {
        if (method === "GET") {
          const q = query(
            collection(db, "users"),
            where("role", "==", "moderator"),
          );
          const snapshot = await getDocs(q);
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        }
        if (method === "POST") {
          const { email, password, ...restBody } = body;
          if (!email || !password) {
            return createResponse(
              { error: "Email and password are required" },
              400,
            );
          }

          let cleanEmail = email.trim();
          if (!cleanEmail.includes("@")) {
            cleanEmail = `${cleanEmail.toLowerCase()}@jabermathcare.com`;
          }

          // Simple email validation
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(cleanEmail)) {
            return createResponse({ error: "Invalid email format" }, 400);
          }

          try {
            const userCredential = await createUserWithEmailAndPassword(
              secondaryAuth,
              cleanEmail,
              password,
            );
            const uid = userCredential.user.uid;

            const docData = {
              ...restBody,
              email: cleanEmail,
              role: "moderator",
              created_at: new Date().toISOString(),
            };
            await setDoc(doc(db, "users", uid), docData);

            return createResponse({ id: uid, ...docData });
          } catch (error: any) {
            console.error("Error creating moderator:", error);
            if (error.code === "auth/email-already-in-use") {
              // Find existing user and update
              const q = query(
                collection(db, "users"),
                where("email", "==", cleanEmail),
              );
              const querySnapshot = await getDocs(q);
              if (!querySnapshot.empty) {
                const existingUid = querySnapshot.docs[0].id;
                const docData = {
                  ...restBody,
                  email: cleanEmail,
                  role: "moderator",
                  updated_at: new Date().toISOString(),
                };
                await updateDoc(doc(db, "users", existingUid), docData);
                return createResponse({ id: existingUid, ...docData });
              }
              return createResponse({ error: "Email is already in use" }, 409);
            }
            throw error;
          }
        }
      }
      if (path.startsWith("moderators/")) {
        const id = path.split("/")[1];
        if (method === "DELETE") {
          await deleteDoc(doc(db, "users", id));
          return createResponse({ success: true });
        }
      }

      // ----------------------------------------------------------------------
      // STUDENT SEARCH
      // ----------------------------------------------------------------------
      if (path.startsWith("student-search")) {
        const urlObj = new URL(url, window.location.origin);
        const batch_id = urlObj.searchParams.get("batch_id");
        const roll_number = urlObj.searchParams.get("roll_number");

        if (!roll_number)
          return createResponse({ error: "Missing search term" }, 400);

        const target = String(roll_number).trim();

        // Much faster localized queries instead of fetching all 1000s of users.
        // 1. Check if ID matches directly
        let studentDoc: any = null;
        try {
          const idSnap = await getDoc(doc(db, "users", target));
          if (idSnap.exists() && idSnap.data().role === "student") {
            studentDoc = idSnap;
          }
        } catch (e) {}

        // 2. Query by roll_number or phone
        if (!studentDoc) {
          const snaps = await Promise.all([
            getDocs(
              query(
                collection(db, "users"),
                where("roll_number", "==", target),
                where("role", "==", "student"),
              ),
            ),
            getDocs(
              query(
                collection(db, "users"),
                where("roll_number", "==", Number(target)),
                where("role", "==", "student"),
              ),
            ),
            getDocs(
              query(
                collection(db, "users"),
                where("phone", "==", target),
                where("role", "==", "student"),
              ),
            ),
          ]);

          for (const snap of snaps) {
            if (!snap.empty) {
              studentDoc = snap.docs[0];
              break;
            }
          }
        }

        if (!studentDoc)
          return createResponse({ error: "Student not found" }, 404);

        const studentId = studentDoc.id;

        const [attendanceSnap, paymentsSnap, resultsSnap] = await Promise.all([
          getDocs(
            query(
              collection(db, "attendance"),
              where("student_id", "==", studentId),
            ),
          ),
          getDocs(
            query(
              collection(db, "payments"),
              where("student_id", "==", studentId),
            ),
          ),
          getDocs(
            query(
              collection(db, "results"),
              where("student_id", "==", studentId),
            ),
          ),
        ]);

        return createResponse({
          id: studentId,
          ...studentDoc.data(),
          attendance: attendanceSnap.docs.map((d) => ({
            ...d.data(),
            id: d.id,
          })),
          payments: paymentsSnap.docs.map((d) => ({ ...d.data(), id: d.id })),
          results: resultsSnap.docs.map((d) => ({ ...d.data(), id: d.id })),
        });
      }

      // ----------------------------------------------------------------------
      // MY ENROLLMENTS
      // ----------------------------------------------------------------------
      if (path === "my-enrollments") {
        const uid = getCurrentUserId();
        if (!uid) return createResponse({ error: "Unauthorized" }, 401);

        const userSnap = await getDoc(doc(db, "users", uid));
        const userData = userSnap.exists() ? userSnap.data() : {};
        const queries = [
          query(collection(db, "enrollments"), where("user_id", "==", uid)),
        ];

        const userPhone = userData.phone || auth.currentUser?.phoneNumber || "";
        const userEmail = userData.email || auth.currentUser?.email || "";

        if (userPhone) {
          const cleanPhone = userPhone.replace(/\D/g, "");
          if (cleanPhone.length >= 10) {
            const last10 = cleanPhone.slice(-10);
            const variations = [
              last10,
              "0" + last10,
              "880" + last10,
              "+880" + last10,
            ];
            variations.forEach((v) => {
              queries.push(
                query(collection(db, "enrollments"), where("phone", "==", v)),
              );
            });
          } else {
            queries.push(
              query(
                collection(db, "enrollments"),
                where("phone", "==", userPhone),
              ),
            );
          }
        }

        if (userEmail) {
          queries.push(
            query(
              collection(db, "enrollments"),
              where("email", "==", userEmail),
            ),
          );
        }

        const snapshots = await Promise.all(
          queries.map((q) => 
            getDocs(q).catch(err => {
              console.warn("[Firebase Adapter] Individual enrollment query failed:", err.message);
              return { docs: [] };
            })
          )
        );
        const allEnrollments = snapshots.flatMap((s) =>
          (s as any).docs.map((d: any) => ({ ...d.data(), id: d.id })),
        );
        const enrollments: any[] = Array.from(
          new Map(allEnrollments.map((item) => [item.id, item])).values(),
        );

        // If the user has an academic program or course directly assigned (e.g. added via admin), add it as an enrollment
        const addAcademicEnrollment = async (
          progId: string,
          batchId: string,
          courseId: string,
          title?: string,
        ) => {
          let batchName = "";
          if (batchId) {
            const batchSnap = await getDoc(doc(db, "batches", String(batchId)));
            if (batchSnap.exists()) {
              batchName = batchSnap.data().name;
            }
          }

          let programTitle = userData.program_title;
          if (!programTitle && progId) {
            const programSnap = await getDoc(
              doc(db, "programs", String(progId)),
            );
            if (programSnap.exists()) {
              programTitle = programSnap.data().title;
            }
          }

          let courseTitle = title || userData.course_title;
          if (!courseTitle && courseId) {
            const courseSnap = await getDoc(
              doc(db, "courses", String(courseId)),
            );
            if (courseSnap.exists()) {
              courseTitle = courseSnap.data().title;
            }
          }

          const academicId = `academic-${progId || ""}-${batchId || ""}-${courseId || ""}-${uid}`;
          const isDuplicate = enrollments.some(
            (e) =>
              e.id === academicId ||
              (courseId && String(e.course_id) === String(courseId)) ||
              (progId &&
                batchId &&
                String(e.program_id) === String(progId) &&
                String(e.batch_id) === String(batchId)),
          );

          if (!isDuplicate) {
            const isOnline = userData.student_type === "online" || !!courseId;
            enrollments.push({
              id: academicId,
              program_title:
                programTitle ||
                (isOnline ? "Online Course" : "Academic Program"),
              course_title: courseTitle,
              batch_name: batchName,
              status: userData.status || "approved",
              created_at: userData.created_at || new Date().toISOString(),
              admission_fee: userData.admission_fee,
              monthly_fee: userData.monthly_fee,
              payment_method: "N/A",
              payment_number: "N/A",
              transaction_id: "Direct Admission",
              fee: userData.admission_fee || userData.price || 0,
              current_class: userData.current_class || userData.class,
              student_type: isOnline ? "online" : "offline",
              program_id: progId,
              batch_id: batchId,
              course_id: courseId,
            });
          }
        };

        if (userData.program_id || userData.batch_id || userData.course_id) {
          await addAcademicEnrollment(
            userData.program_id,
            userData.batch_id,
            userData.course_id,
          );
        }

        // Handle enrolled_courses array
        if (Array.isArray(userData.enrolled_courses)) {
          for (const course of userData.enrolled_courses) {
            if (typeof course === "string") {
              await addAcademicEnrollment("", "", course, "");
            } else {
              await addAcademicEnrollment(
                course.program_id || "",
                course.batch_id || "",
                course.id || "",
                course.title || "",
              );
            }
          }
        }

        // Deduplicate to show exactly one card per course/program/batch
        const uniqueEnrollments: any[] = [];
        for (const e of enrollments) {
          const isDuplicate = uniqueEnrollments.some((existing) => {
            if (e.course_id && existing.course_id && String(e.course_id) === String(existing.course_id)) {
              return true;
            }
            if (e.program_id && existing.program_id && String(e.program_id) === String(existing.program_id)) {
              if (String(e.batch_id) === String(existing.batch_id)) {
                return true;
              }
            }
            return false;
          });

          if (!isDuplicate) {
            uniqueEnrollments.push(e);
          } else {
            // Keep the one with approved/contacted status if duplicate exists
            const idx = uniqueEnrollments.findIndex((existing) => {
              if (e.course_id && existing.course_id && String(e.course_id) === String(existing.course_id)) {
                return true;
              }
              if (e.program_id && existing.program_id && String(e.program_id) === String(existing.program_id)) {
                if (String(e.batch_id) === String(existing.batch_id)) {
                  return true;
                }
              }
              return false;
            });
            if (idx !== -1) {
              const existing = uniqueEnrollments[idx];
              const activeStatuses = ["approved", "contacted"];
              const existingIsActive = activeStatuses.includes(existing.status);
              const currentIsActive = activeStatuses.includes(e.status);
              if (!existingIsActive && currentIsActive) {
                uniqueEnrollments[idx] = e;
              }
            }
          }
        }

        return createResponse(uniqueEnrollments);
      }

      // ----------------------------------------------------------------------
      // STUDY MATERIALS FOR STUDENT
      // ----------------------------------------------------------------------
      if (path === "study-materials/my") {
        const uid = getCurrentUserId();
        if (!uid) return createResponse({ error: "Unauthorized" }, 401);

        try {
          const userSnap = await getDoc(doc(db, "users", uid));
          if (!userSnap.exists())
            return createResponse({ error: "User not found" }, 404);

          const userData = userSnap.data();
          const batch_id = userData.batch_id;
          const batch_id_2 = userData.batch_id_2;
          const program_id = userData.program_id;
          const course_id = userData.course_id;

          // Fetch materials in parallel
          const fetchPromises = [
            getDocs(
              query(
                collection(db, "study_materials"),
                where("batch_id", "==", "all"),
              ),
            ),
          ];

          if (batch_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("batch_id", "==", batch_id),
                ),
              ),
            );
          if (batch_id_2)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("batch_id", "==", batch_id_2),
                ),
              ),
            );
          if (program_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("program_id", "==", program_id),
                ),
              ),
            );
          if (course_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("course_id", "==", course_id),
                ),
              ),
            );

          const snapshots = await Promise.all(fetchPromises);

          const materials = snapshots.flatMap((snap) =>
            snap.docs.map((d) => ({ ...d.data(), id: d.id })),
          );

          // Deduplicate materials by ID
          const uniqueMaterials = Array.from(
            new Map(materials.map((m) => [m.id, m])).values(),
          );

          return createResponse(uniqueMaterials);
        } catch (error) {
          console.error("Error in study-materials/my:", error);
          return createResponse({ error: "Internal Server Error" }, 500);
        }
      }

      if (path.startsWith("study-materials/student/")) {
        const id = path.split("/")[2];
        try {
          const userSnap = await getDoc(doc(db, "users", id));
          if (!userSnap.exists())
            return createResponse({ error: "User not found" }, 404);

          const userData = userSnap.data();
          const batch_id = userData.batch_id;
          const batch_id_2 = userData.batch_id_2;
          const program_id = userData.program_id;
          const course_id = userData.course_id;

          // Fetch materials in parallel
          const fetchPromises = [
            getDocs(
              query(
                collection(db, "study_materials"),
                where("batch_id", "==", "all"),
              ),
            ),
          ];

          if (batch_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("batch_id", "==", batch_id),
                ),
              ),
            );
          if (batch_id_2)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("batch_id", "==", batch_id_2),
                ),
              ),
            );
          if (program_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("program_id", "==", program_id),
                ),
              ),
            );
          if (course_id)
            fetchPromises.push(
              getDocs(
                query(
                  collection(db, "study_materials"),
                  where("course_id", "==", course_id),
                ),
              ),
            );

          const snapshots = await Promise.all(fetchPromises);

          const materials = snapshots.flatMap((snap) =>
            snap.docs.map((d) => ({ ...d.data(), id: d.id })),
          );

          // Deduplicate materials by ID
          const uniqueMaterials = Array.from(
            new Map(materials.map((m) => [m.id, m])).values(),
          );

          return createResponse(uniqueMaterials);
        } catch (error) {
          console.error("Error in study-materials/student:", error);
          return createResponse({ error: "Internal Server Error" }, 500);
        }
      }

      // ----------------------------------------------------------------------
      // AUTO ABSENT
      // ----------------------------------------------------------------------
      if (path === "attendance/auto-absent") {
        try {
          const { batch_id, date } = body;
          const studentsSnap = await getDocs(
            query(collection(db, "users"), where("role", "==", "student")),
          );
          const students = studentsSnap.docs.filter(
            (d) =>
              (String(d.data().batch_id) === String(batch_id) ||
                String(d.data().batch_id_2) === String(batch_id)) &&
              (d.data().status === "active" ||
                d.data().status === "approved" ||
                !d.data().status),
          );

          const attendanceSnap = await getDocs(
            query(
              collection(db, "attendance"),
              where("batch_id", "==", batch_id),
              where("date", "==", date),
            ),
          );
          const markedIds = attendanceSnap.docs
            .filter((d) => d.data().type !== "exam")
            .map((d) => d.data().student_id);

          // Check for exams today (specific batch and "all" batches)
          const [specificExamsSnap, allExamsSnap] = await Promise.all([
            getDocs(
              query(
                collection(db, "exams"),
                where("batch_id", "==", batch_id),
                where("exam_date", "==", date),
              ),
            ),
            getDocs(
              query(
                collection(db, "exams"),
                where("batch_id", "==", "all"),
                where("exam_date", "==", date),
              ),
            ),
          ]);

          const todayExams = [
            ...specificExamsSnap.docs.map(d => ({ ...d.data(), id: d.id })),
            ...allExamsSnap.docs.map(d => ({ ...d.data(), id: d.id }))
          ];

          let count = 0;
          let examCount = 0;

          for (const docSnap of students) {
            // Mark class attendance as absent if not marked
            if (!markedIds.includes(docSnap.id)) {
              await addDoc(collection(db, "attendance"), {
                student_id: docSnap.id,
                batch_id,
                date,
                status: "absent",
                type: "class",
                reason: "Auto",
                created_at: new Date().toISOString(),
              });
              count++;
            }

            // Mark exam attendance as absent if not marked
            for (const exam of todayExams) {
              const examMarked = attendanceSnap.docs.some(
                (d) =>
                  d.data().type === "exam" &&
                  String(d.data().exam_id) === String(exam.id) &&
                  String(d.data().student_id) === String(docSnap.id),
              );

              if (!examMarked) {
                await addDoc(collection(db, "attendance"), {
                  student_id: docSnap.id,
                  batch_id,
                  date,
                  status: "absent",
                  type: "exam",
                  exam_id: exam.id,
                  reason: "Auto",
                  created_at: new Date().toISOString(),
                });
                examCount++;
              }
            }
          }
          return createResponse({
            message: `Marked ${count} students as absent for class and ${examCount} for exams`,
            count: count + examCount,
          });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, path);
        }
      }

      // ----------------------------------------------------------------------
      // ENROLLMENTS
      // ----------------------------------------------------------------------
      if (path === "enrollments") {
        try {
          if (method === "GET") {
            const snapshot = await getDocs(collection(db, "enrollments"));
            return createResponse(
              snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
            );
          }
          if (method === "POST") {
            console.log("[Firebase Adapter] Processing Enrollment:", body);
            const {
              email,
              gmail,
              password,
              phone,
              name,
              profile_pic,
              ...rest
            } = body;
            const userEmail = (email || gmail || "").trim();

            if (!userEmail) {
              return createResponse({ error: "Email is required" }, 400);
            }

            // --- STRICT DUPLICATE VALIDATION ---
            // 1. Check if user already exists in the main `users` table
            const usersQ = query(
              collection(db, "users"),
              where("email", "==", userEmail)
            );
            const usersSnap = await getDocs(usersQ);
            if (false && !usersSnap.empty) {
              return createResponse(
                { error: "এই ইমেইলটি দিয়ে ইতোমধ্যে একটি অ্যাকাউন্ট আছে। দয়া করে লগইন করুন அல்லது নতুন ইমেইল ব্যবহার করুন।" },
                409
              );
            }

            // 2. Check if there is already a "pending" enrollment for this email
            const enrollQ1 = query(
              collection(db, "enrollments"),
              where("email", "==", userEmail),
              where("status", "==", "pending")
            );
            const enrollSnap1 = await getDocs(enrollQ1);
            if (false && !enrollSnap1.empty) {
              return createResponse(
                { error: "আপনার একটি আবেদন ইতোমধ্যে পেন্ডিং আছে। অ্যাডমিন অ্যাপ্রুভ করা পর্যন্ত অপেক্ষা করুন।" },
                409
              );
            }

            const enrollQ2 = query(
              collection(db, "enrollments"),
              where("gmail", "==", userEmail),
              where("status", "==", "pending")
            );
            const enrollSnap2 = await getDocs(enrollQ2);
            if (false && !enrollSnap2.empty) {
               return createResponse(
                { error: "আপনার একটি আবেদন ইতোমধ্যে পেন্ডিং আছে। অ্যাডমিন অ্যাপ্রুভ করা পর্যন্ত অপেক্ষা করুন।" },
                409
              );
            }
            // -----------------------------------

            let uid = null;

            /* 
            if (userEmail && password) {
              try {
                const userCredential = await createUserWithEmailAndPassword(
                  secondaryAuth,
                  userEmail.trim(),
                  password,
                );
                uid = userCredential.user.uid;

                const userData = {
                  ...rest,
                  name,
                  email: userEmail.trim(),
                  phone,
                  role: "student",
                  status: "pending", // Initial status is pending
                  student_type: body.course_title ? "online" : "offline",
                  profile_pic: profile_pic || "",
                  created_at: new Date().toISOString(),
                  initial_password: password,
                };

                await setDoc(doc(db, "users", uid), userData);
                console.log(
                  "[Firebase Adapter] Created user for enrollment:",
                  uid,
                );
              } catch (error: any) {
                console.error(
                  "[Firebase Adapter] Error creating user during enrollment:",
                  error,
                );
                if (error.code === "auth/email-already-in-use") {
                  // Try to find existing user UID to link the enrollment
                  try {
                    const q = query(
                      collection(db, "users"),
                      where("email", "==", userEmail.trim()),
                    );
                    const querySnapshot = await getDocs(q);
                    if (!querySnapshot.empty) {
                      uid = querySnapshot.docs[0].id;
                      console.log(
                        "[Firebase Adapter] Linked existing user to enrollment:",
                        uid,
                      );
                    }
                  } catch (qError) {
                    console.log(
                      "[Firebase Adapter] Could not query user, proceeding with null uid for enrollment",
                    );
                    // We can proceed with uid = null, the enrollment will be linked by email later
                  }
                } else {
                  return createResponse({ error: error.message }, 400);
                }
              }
            }
            */
            
            const enrollmentData = {
              ...body,
              user_id: uid,
              status: "pending",
              created_at: new Date().toISOString(),
            };

            const docRef = await addDoc(
              collection(db, "enrollments"),
              enrollmentData,
            );
            return createResponse({ id: docRef.id, ...enrollmentData });
          }
        } catch (error) {
          handleFirestoreError(
            error,
            method === "GET" ? OperationType.LIST : OperationType.WRITE,
            path,
          );
        }
      }

      if (path.startsWith("enrollments/")) {
        const id = path.split("/")[1];
        if (path.endsWith("/status")) {
          if (method === "PUT" || method === "PATCH") {
            const updateData: any = { status: body.status };
            if (body.roll_number) updateData.roll_number = body.roll_number;
            if (body.monthly_fee) updateData.monthly_fee = body.monthly_fee;
            if (body.admission_fee) updateData.admission_fee = body.admission_fee;
            if (body.batch_id) updateData.batch_id = body.batch_id;

            await updateDoc(doc(db, "enrollments", id), updateData);

            // If approved, also find the linked user and approve them
            if (body.status === "approved") {
              const snap = await getDoc(doc(db, "enrollments", id));
              if (snap.exists()) {
                const enroll = snap.data();

                // Trigger admission approved email asynchronously
                window.fetch("/api/send-system-email", {
                  method: "POST",
                  headers: { "Content-Type": "application/json" },
                  body: JSON.stringify({
                    type: "admission_approved",
                    data: {
                      name: enroll.name || "",
                      email: enroll.email || enroll.gmail || "",
                      course_title: enroll.course_title || enroll.program_title || "",
                      roll_number: body.roll_number || enroll.roll_number || "",
                      phone: enroll.phone || "",
                      guardian_phone: enroll.guardian_phone || ""
                    }
                  })
                }).catch(e => console.error("Admission approved email send error:", e));

                let finalUserId = enroll.user_id;

                const enrollEmail = (enroll.email || enroll.gmail || enroll.email_address || "").trim();

                if (!finalUserId && enrollEmail && enroll.password) {
                  try {
                    // Try to create the user in Firebase Auth
                    const userCredential = await createUserWithEmailAndPassword(
                      secondaryAuth,
                      enrollEmail,
                      enroll.password
                    );
                    finalUserId = userCredential.user.uid;

                    // Prepare user data
                    const userData: any = {
                      name: enroll.name || "",
                      email: enrollEmail,
                      phone: enroll.phone || "",
                      guardian_phone: enroll.guardian_phone || "",
                      role: "student",
                      status: "approved",
                      student_type: (enroll.course_title || enroll.course_id || (enroll.enrolled_courses && enroll.enrolled_courses.length > 0)) ? "online" : "offline",
                      created_at: new Date().toISOString(),
                      initial_password: enroll.password,
                    };
                    
                    if (enroll.address) userData.address = enroll.address;
                    if (enroll.school_name) userData.school_name = enroll.school_name;
                    if (enroll.college_name) userData.college_name = enroll.college_name;
                    if (enroll.blood_group) userData.blood_group = enroll.blood_group;
                    if (enroll.gender) userData.gender = enroll.gender;
                    if (enroll.current_class) {
                      userData.current_class = enroll.current_class;
                      userData.class = enroll.current_class;
                    } else if (enroll.class) {
                      userData.current_class = enroll.class;
                      userData.class = enroll.class;
                    }
                    if (body.roll_number) userData.roll_number = body.roll_number;
                    if (body.batch_id) userData.batch_id = body.batch_id;
                    if (body.monthly_fee) userData.monthly_fee = body.monthly_fee;
                    if (body.admission_fee) userData.admission_fee = body.admission_fee;
                    
                    if (enroll.course_title && enroll.course_id) {
                       userData.enrolled_courses = [enroll.course_id];
                    }

                    // Save user to 'users' collection
                    await setDoc(doc(db, "users", finalUserId), userData);

                    // Link back to enrollment
                    await updateDoc(doc(db, "enrollments", id), { user_id: finalUserId });
                    
                    console.log("[Firebase Adapter] Successfully created and linked user:", finalUserId);

                  } catch(e: any) {
                    console.error("[Firebase Adapter] Error creating user on approval:", e);
                    // If email already in use, find the user
                    if (e.code === "auth/email-already-in-use") {
                       const q = query(collection(db, "users"), where("email", "==", enrollEmail));
                       const querySnapshot = await getDocs(q);
                       if (!querySnapshot.empty) {
                         finalUserId = querySnapshot.docs[0].id;
                         await updateDoc(doc(db, "enrollments", id), { user_id: finalUserId });
                       }
                    }
                  }
                }

                if (finalUserId) {
                  const userUpdate: any = { status: "approved" };
                  if (body.roll_number) userUpdate.roll_number = body.roll_number;
                  if (body.batch_id) userUpdate.batch_id = body.batch_id;
                  if (body.monthly_fee) userUpdate.monthly_fee = body.monthly_fee;
                  if (body.admission_fee) userUpdate.admission_fee = body.admission_fee;
                  if (enroll.course_title || enroll.course_id) {
                    userUpdate.student_type = "online";
                    if (enroll.course_id) {
                      userUpdate.enrolled_courses = arrayUnion(enroll.course_id);
                    }
                  }
                  
                  if (enroll.phone) userUpdate.phone = enroll.phone;
                  if (enroll.guardian_phone) userUpdate.guardian_phone = enroll.guardian_phone;
                  if (enroll.address) userUpdate.address = enroll.address;
                  if (enroll.school_name) userUpdate.school_name = enroll.school_name;
                  if (enroll.college_name) userUpdate.college_name = enroll.college_name;
                  if (enroll.blood_group) userUpdate.blood_group = enroll.blood_group;
                  if (enroll.current_class) {
                    userUpdate.current_class = enroll.current_class;
                    userUpdate.class = enroll.current_class;
                  } else if (enroll.class) {
                    userUpdate.current_class = enroll.class;
                    userUpdate.class = enroll.class;
                  }
                  
                  await updateDoc(doc(db, "users", finalUserId), userUpdate);
                }
              }
            }
            return createResponse({ success: true });
          }
        } else if (method === "DELETE") {
          await deleteDoc(doc(db, "enrollments", id));
          return createResponse({ success: true });
        }
      }

      if (path.startsWith("cancel-enrollment/")) {
        if (method === "DELETE") {
          const id = path.split("/")[1];
          try {
            const enrollmentRef = doc(db, "enrollments", id);
            const enrollmentDoc = await getDoc(enrollmentRef);
            if (!enrollmentDoc.exists()) {
              return createResponse({ error: "Enrollment not found" }, 404);
            }
            const data = enrollmentDoc.data();
            if (data.status !== 'pending') {
               return createResponse({ error: "Only pending enrollments can be cancelled" }, 400);
            }
            await deleteDoc(enrollmentRef);
            return createResponse({ success: true });
          } catch (e: any) {
             return createResponse({ error: e.message }, 500);
          }
        }
      }

      // ----------------------------------------------------------------------
      // MESSAGES
      // ----------------------------------------------------------------------
      if (path.startsWith("messages/") && path.endsWith("/read")) {
        const id = path.split("/")[1];
        if (method === "PUT") {
          await updateDoc(doc(db, "messages", id), { is_read: true });
          return createResponse({ success: true });
        }
      }

      // ----------------------------------------------------------------------
      // AUTH PROFILE & PASSWORD
      // ----------------------------------------------------------------------
      if (path === "auth/profile") {
        const user = auth.currentUser;
        const uid = user?.uid;
        if (!uid || !user)
          return createResponse({ error: "Unauthorized" }, 401);

        try {
          const cleanEmail = body.email ? body.email.trim() : user.email;
          if (cleanEmail && cleanEmail !== user.email) {
            await updateEmail(user, cleanEmail);
          }
          await updateDoc(doc(db, "users", uid), {
            name: body.name,
            email: cleanEmail,
          });
          return createResponse({ success: true });
        } catch (error: any) {
          console.error("Profile update error:", error);
          return createResponse(
            { error: error.message || "Failed to update profile" },
            400,
          );
        }
      }
      if (path === "auth/password") {
        const user = auth.currentUser;
        if (!user) return createResponse({ error: "Unauthorized" }, 401);

        const { oldPassword, newPassword } = body;
        if (!oldPassword || !newPassword)
          return createResponse({ error: "Missing passwords" }, 400);

        try {
          if (user.email) {
            const credential = EmailAuthProvider.credential(
              user.email,
              oldPassword,
            );
            await reauthenticateWithCredential(user, credential);
            await updatePassword(user, newPassword);
            return createResponse({
              success: true,
              message: "Password updated successfully",
            });
          } else {
            return createResponse({ error: "User email not found" }, 400);
          }
        } catch (error: any) {
          console.error("Password update error:", error);
          return createResponse(
            { error: error.message || "Failed to update password" },
            400,
          );
        }
      }

      // ----------------------------------------------------------------------
      // PAYMENTS
      // ----------------------------------------------------------------------
      if (path === "payments" && method === "GET") {
        const snapshot = await getDocs(collection(db, "payments"));
        const payments = snapshot.docs
          .map((d) => ({ ...d.data(), id: d.id }))
          .filter((p: any) => !p.hidden_from_admin);

        const enrichedPayments = await Promise.all(
          payments.map(async (p: any) => {
            if (!p.student_name && p.student_id) {
              const studentSnap = await getDoc(doc(db, "users", p.student_id));
              if (studentSnap.exists()) {
                p.student_name = studentSnap.data().name || "Unknown";
                p.roll_number = studentSnap.data().roll_number || "Unknown";
                if (!p.batch_name && studentSnap.data().batch_id) {
                  const batchSnap = await getDoc(
                    doc(db, "batches", studentSnap.data().batch_id),
                  );
                  if (batchSnap.exists()) {
                    p.batch_name = batchSnap.data().name || "Unknown";
                  }
                }
              }
            }
            return p;
          }),
        );

        return createResponse(enrichedPayments);
      }

      // ----------------------------------------------------------------------
      // LIVE CHAT MESSAGES
      // ----------------------------------------------------------------------
      if (path === "live-chat-messages") {
        if (method === "GET") {
          const urlObj = new URL(url, window.location.origin);
          const class_id = urlObj.searchParams.get("class_id");
          if (!class_id)
            return createResponse({ error: "Missing class_id" }, 400);

          const q = query(
            collection(db, "live_chat_messages"),
            where("class_id", "==", class_id),
            orderBy("created_at", "asc"),
          );
          const snapshot = await getDocs(q);
          return createResponse(
            snapshot.docs.map((d) => ({ ...d.data(), id: d.id })),
          );
        }
        if (method === "POST") {
          const docRef = await addDoc(collection(db, "live_chat_messages"), {
            ...body,
            created_at: new Date().toISOString(),
          });
          return createResponse({ id: docRef.id, ...body });
        }
      }

      // ----------------------------------------------------------------------
      // RESET DATA
      // ----------------------------------------------------------------------
      if (path === "reset-data" && method === "POST") {
        const { type } = body;
        let collectionName = "";
        let studentTypeFilter = "";

        if (type === "students" || type === "offline_students") {
          collectionName = "users";
          studentTypeFilter = "offline";
        } else if (type === "online_students") {
          collectionName = "users";
          studentTypeFilter = "online";
        } else if (type === "batches") collectionName = "batches";
        else if (type === "payments") collectionName = "payments";
        else if (type === "enrollments") collectionName = "enrollments";
        else if (type === "attendance") collectionName = "attendance";

        if (collectionName) {
          let q: any = collection(db, collectionName);
          if (collectionName === "users") {
            if (studentTypeFilter === "online") {
              q = query(
                collection(db, "users"),
                where("role", "==", "student"),
                where("student_type", "==", "online"),
              );
            } else if (studentTypeFilter === "offline") {
              // For offline, we check role == student and student_type != online (or == offline)
              q = query(
                collection(db, "users"),
                where("role", "==", "student"),
                where("student_type", "!=", "online"),
              );
            } else {
              q = query(
                collection(db, "users"),
                where("role", "==", "student"),
              );
            }
          }

          const snapshot = await getDocs(q);
          const updatePromises = snapshot.docs.map((d) => {
            return deleteDoc(doc(db, collectionName, d.id));
          });
          await Promise.all(updatePromises);
          return createResponse({
            success: true,
            message: `All ${type} deleted successfully.`,
          });
        }
        return createResponse({ error: "Invalid type" }, 400);
      }

      // ----------------------------------------------------------------------
      // GENERIC COLLECTIONS (GET, POST, DELETE)
      // ----------------------------------------------------------------------
      const genericCollections = [
        "batches",
        "programs",
        "web-recorded-classes",
        "web-class-schedules",
        "courses",
        "gallery",
        "messages",
        "enrollments",
        "chapters",
        "exams",
        "routines",
        "resources",
        "notices",
        "study-materials",
        "payments",
        "results",
        "result-histories",
        "live-classes",
        "reviews",
        "video-classes",
        "class-slides",
        "degrees",
        "coupons",
      ];

      // Check if path matches a generic collection or an ID within it
      const collectionMatch = genericCollections.find(
        (c) => path === c || path.startsWith(`${c}/`),
      );

      if (collectionMatch) {
        const collectionName = collectionMatch.replace(/-/g, "_"); // e.g. web-recorded-classes -> web_recorded_classes
        const id = path.split("/")[1];

        if (method === "GET") {
          const urlObj = new URL(url, window.location.origin);
          let q: any = collection(db, collectionName);

          // Support common filters
          const examId = urlObj.searchParams.get("exam_id");
          const studentId = urlObj.searchParams.get("student_id");
          const batchId = urlObj.searchParams.get("batch_id");

          const constraints = [];
          if (examId) constraints.push(where("exam_id", "==", examId));
          if (studentId) constraints.push(where("student_id", "==", studentId));
          if (batchId) constraints.push(where("batch_id", "==", batchId));

          if (constraints.length > 0) {
            q = query(q, ...constraints);
          }

          const snapshot = await getDocs(q);
          let data = snapshot.docs.map((d) => ({
            ...(d.data() as any),
            id: d.id,
          }));

          // Sort in memory if created_at exists to be safer
          if (data.some((d) => d.created_at)) {
            data.sort((a, b) => {
              const dateA = a.created_at ? new Date(a.created_at).getTime() : 0;
              const dateB = b.created_at ? new Date(b.created_at).getTime() : 0;
              return dateB - dateA;
            });
          }

          return createResponse(data);
        }

        if (method === "POST") {
          console.log(`[Firebase Adapter] POST /api/${path}`, body);
          const docData = { ...body, created_at: new Date().toISOString() };
          const docRef = await addDoc(collection(db, collectionName), docData);

          // Hooks for billing payments and result releases
          if (collectionName === "payments") {
            (async () => {
              try {
                let recipientEmail = body.email || body.gmail || "";
                let studentName = body.student_name || "Student";
                let guardianPhone = body.guardian_phone || "";
                let studentPhone = body.phone || "";
                let batchName = body.batch_name || body.batch || "";
                let courseTitle = body.course_title || body.program_title || "";

                if (body.student_id) {
                  const sRef = doc(db, "users", body.student_id);
                  const sSnap = await getDoc(sRef);
                  if (sSnap.exists()) {
                    const sData = sSnap.data() as any;
                    recipientEmail = sData.email || sData.gmail || sData.gmail_address || sData.email_address || recipientEmail;
                    studentName = sData.name || studentName;
                    guardianPhone = sData.guardian_phone || guardianPhone;
                    studentPhone = sData.phone || studentPhone;
                    if (!batchName) batchName = sData.batch_name || sData.batch || "";
                    if (!courseTitle) courseTitle = sData.course_title || sData.program_title || sData.program_name || "";
                    
                    const prevPaid = Number(sData.paid_amount) || 0;
                    const addedAmt = Number(body.amount) || Number(body.fee) || 0;
                    await updateDoc(sRef, {
                      paid_amount: prevPaid + addedAmt
                    });
                  }
                }

                if (recipientEmail || studentPhone || guardianPhone) {
                  console.log("[Firebase Adapter] Triggering async payment receipt transaction for:", recipientEmail || studentPhone || guardianPhone);
                  window.fetch("/api/send-system-email", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      type: "payment_receipt",
                      data: {
                        student_name: studentName,
                        email: recipientEmail,
                        amount: body.amount,
                        month: body.month || "Fee",
                        year: body.year || new Date().getFullYear(),
                        batch_name: batchName,
                        phone: studentPhone || guardianPhone || "",
                        guardian_phone: guardianPhone || studentPhone || ""
                      }
                    })
                  }).catch(e => console.error("Payment email delivery error:", e));
                }
              } catch (e: any) {
                console.error("Payment email async prepare error:", e.message);
              }
            })();
          }

          if (collectionName === "results") {
            (async () => {
              try {
                let recipientEmail = body.email || "";
                let studentName = body.student_name || "Student";
                let guardianPhone = body.guardian_phone || "";
                let studentPhone = body.phone || "";
                let batchName = body.batch_name || body.batch || "";
                let courseTitle = body.course_title || body.program_title || "";

                if (body.student_id) {
                  const sSnap = await getDoc(doc(db, "users", body.student_id));
                  if (sSnap.exists()) {
                    const sData = sSnap.data() as any;
                    recipientEmail = sData.email || sData.gmail || sData.gmail_address || sData.email_address || recipientEmail;
                    studentName = sData.name || studentName;
                    guardianPhone = sData.guardian_phone || guardianPhone;
                    studentPhone = sData.phone || studentPhone;
                    if (!batchName) batchName = sData.batch_name || sData.batch || "";
                    if (!courseTitle) courseTitle = sData.course_title || sData.program_title || sData.program_name || "";
                  }
                } else if (body.roll_number) {
                  const q = query(collection(db, "users"), where("roll_number", "==", String(body.roll_number).trim()));
                  const qSnap = await getDocs(q);
                  if (!qSnap.empty) {
                    const sData = qSnap.docs[0].data() as any;
                    recipientEmail = sData.email || sData.gmail || sData.gmail_address || sData.email_address || recipientEmail;
                    studentName = sData.name || studentName;
                    guardianPhone = sData.guardian_phone || guardianPhone;
                    studentPhone = sData.phone || studentPhone;
                    if (!batchName) batchName = sData.batch_name || sData.batch || "";
                    if (!courseTitle) courseTitle = sData.course_title || sData.program_title || sData.program_name || "";
                  }
                }

                if (recipientEmail || studentPhone || guardianPhone) {
                  console.log("[Firebase Adapter] Triggering async exam result transaction for:", recipientEmail || studentPhone || guardianPhone);
                  window.fetch("/api/send-system-email", {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({
                      type: "result_published",
                      data: {
                        student_name: studentName,
                        email: recipientEmail,
                        exam_name: body.exam_name || body.exam_title || "Exam",
                        marks: body.marks || body.obtained_marks || "N/A",
                        batch_name: batchName,
                        course_title: courseTitle,
                        phone: studentPhone || guardianPhone || "",
                        guardian_phone: guardianPhone || studentPhone || ""
                      }
                    })
                  }).catch(e => console.error("Result email delivery error:", e));
                }
              } catch (e: any) {
                console.error("Result email async prepare error:", e.message);
              }
            })();
          }

          return createResponse({ id: docRef.id, ...(docData as any) });
        }

        if (method === "PUT" && id) {
          await updateDoc(doc(db, collectionName, id), body);
          return createResponse({ success: true });
        }

        if (method === "DELETE" && id) {
          console.log(
            `[Firebase Adapter] DELETE Request - Collection: ${collectionName}, ID: ${id}`,
          );
          const docId = id.trim();
          if (collectionName === "payments") {
            await updateDoc(doc(db, collectionName, docId), {
              hidden_from_admin: true,
            });
          } else if (collectionName === "batches") {
            // Cascading delete for batches
            const batchId = docId;
            const batchRef = writeBatch(db);

            // Delete the batch itself
            batchRef.delete(doc(db, "batches", batchId));

            // Delete students in this batch
            const studentsSnap = await getDocs(
              query(collection(db, "users"), where("batch_id", "==", batchId)),
            );
            studentsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete exams for this batch
            const examsSnap = await getDocs(
              query(collection(db, "exams"), where("batch_id", "==", batchId)),
            );
            examsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete results for this batch
            const resultsSnap = await getDocs(
              query(
                collection(db, "results"),
                where("batch_id", "==", batchId),
              ),
            );
            resultsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete attendance for this batch
            const attendanceSnap = await getDocs(
              query(
                collection(db, "attendance"),
                where("batch_id", "==", batchId),
              ),
            );
            attendanceSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete payments for this batch
            const paymentsSnap = await getDocs(
              query(
                collection(db, "payments"),
                where("batch_id", "==", batchId),
              ),
            );
            paymentsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete study materials for this batch
            const materialsSnap = await getDocs(
              query(
                collection(db, "study_materials"),
                where("batch_id", "==", batchId),
              ),
            );
            materialsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete routines for this batch
            const routinesSnap = await getDocs(
              query(
                collection(db, "routines"),
                where("batch_id", "==", batchId),
              ),
            );
            routinesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete notices for this batch
            const noticesSnap = await getDocs(
              query(
                collection(db, "notices"),
                where("batch_id", "==", batchId),
              ),
            );
            noticesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete live classes for this batch
            const liveClassesSnap = await getDocs(
              query(
                collection(db, "live_classes"),
                where("batch_id", "==", batchId),
              ),
            );
            liveClassesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete video classes for this batch
            const videoClassesSnap = await getDocs(
              query(
                collection(db, "video_classes"),
                where("batch_id", "==", batchId),
              ),
            );
            videoClassesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete class slides for this batch
            const classSlidesSnap = await getDocs(
              query(
                collection(db, "class_slides"),
                where("batch_id", "==", batchId),
              ),
            );
            classSlidesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            await batchRef.commit();
            return createResponse({ success: true });
          } else if (collectionName === "exams") {
            // Cascading delete for exams
            const examId = docId;
            const batchRef = writeBatch(db);

            // Delete the exam itself
            batchRef.delete(doc(db, "exams", examId));

            // Delete results for this exam
            const resultsSnap = await getDocs(
              query(collection(db, "results"), where("exam_id", "==", examId)),
            );
            resultsSnap.docs.forEach((d) => batchRef.delete(d.ref));

            // Delete result histories for this exam
            const historiesSnap = await getDocs(
              query(collection(db, "result_histories"), where("exam_id", "==", examId)),
            );
            historiesSnap.docs.forEach((d) => batchRef.delete(d.ref));

            await batchRef.commit();
            return createResponse({ success: true });
          } else if (collectionName === "programs") {
            const programId = id;

            const deleteByField = async (collName: string, field: string, value: string) => {
              const snap = await getDocs(query(collection(db, collName), where(field, "==", value)));
              await Promise.all(snap.docs.map(d => deleteDoc(d.ref)));
            };

            // First find all batches
            const batchesSnap = await getDocs(query(collection(db, "batches"), where("program_id", "==", programId)));
            const batchIds = batchesSnap.docs.map(d => d.id);

            const collectionsToClear = [
              "users", "exams", "results", "attendance", "payments", 
              "study_materials", "routines", "notices", "live_classes", 
              "video_classes", "class_slides"
            ];

            // For each batch under this program, delete all related items
            for (const bId of batchIds) {
              for (const coll of collectionsToClear) {
                await deleteByField(coll, "batch_id", bId);
              }
              await deleteDoc(doc(db, "batches", bId));
            }

            // Also delete any items explicitly linked to this program_id
            for (const coll of collectionsToClear) {
              await deleteByField(coll, "program_id", programId);
            }

            // Finally delete the program itself
            await deleteDoc(doc(db, "programs", programId));

            return createResponse({ success: true });
          } else if (collectionName === "courses") {
            const courseId = docId;

            const deleteByField = async (collName: string, field: string, value: string) => {
              const snap = await getDocs(query(collection(db, collName), where(field, "==", value)));
              await Promise.all(snap.docs.map(d => deleteDoc(d.ref)));
            };

            const collectionsToClear = [
              "users", "exams", "results", "attendance", "payments", 
              "study_materials", "routines", "notices", "live_classes", 
              "video_classes", "class_slides", "chapters", "enrollments"
            ];

            // Cascade delete any items explicitly linked to this course_id
            for (const coll of collectionsToClear) {
              await deleteByField(coll, "course_id", courseId);
            }

            // Also delete the course itself
            await deleteDoc(doc(db, "courses", courseId));

            return createResponse({ success: true });
          } else {
            console.log(
              `[Firebase Adapter] Deleting document from ${collectionName} with ID: ${docId}`,
            );
            await deleteDoc(doc(db, collectionName, docId));
          }
          return createResponse({ success: true });
        }
      }

      // Fallback for unhandled routes
      console.warn(
        `[Firebase Adapter] Unhandled route: ${method} /api/${path}`,
      );
      return createResponse(
        { error: "Route not implemented in Firebase Adapter" },
        404,
      );
    } catch (error: any) {
      console.error(
        `[Firebase Adapter] Error processing ${method} /api/${path}:`,
        error,
      );
      return createResponse({ error: error.message }, 500);
    }
  },
  writable: true,
  configurable: true,
});
