import React, { useState, useEffect, useRef } from 'react';

export const DebouncedInput = ({ value, onChange, debounce = 0, onEnter, onKeyDown, ...props }: any) => {
  const [internalVal, setInternalVal] = useState(value ?? "");
  const onChangeRef = useRef(onChange);

  useEffect(() => {
    onChangeRef.current = onChange;
  }, [onChange]);

  useEffect(() => {
    setInternalVal(value ?? "");
  }, [value]);

  useEffect(() => {
    if (debounce === 0) return;

    const valString = String(value ?? "");
    if (String(internalVal) === valString) {
      return;
    }

    const handler = setTimeout(() => {
      onChangeRef.current(internalVal);
    }, debounce);

    return () => clearTimeout(handler);
  }, [internalVal, debounce, value]);

  const displayVal = debounce === 0 ? (value ?? "") : internalVal;

  return (
    <input
      value={displayVal}
      onChange={(e) => {
        const newVal = e.target.value;
        if (debounce === 0) {
          onChangeRef.current(newVal);
        } else {
          setInternalVal(newVal);
        }
      }}
      onKeyDown={(e) => {
        if (e.key === "Enter") {
          const runVal = debounce === 0 ? (value ?? "") : internalVal;
          onChangeRef.current(runVal);
          if (onEnter) onEnter(runVal);
        }
        if (onKeyDown) onKeyDown(e);
      }}
      {...props}
    />
  );
};
