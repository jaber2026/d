import React from 'react';
import { Link } from 'react-router-dom';
import { Home, AlertCircle } from 'lucide-react';
import { motion } from 'motion/react';

const NotFound = () => {
  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] relative overflow-hidden">
      <div className="absolute top-0 right-0 p-32 bg-orange-500/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 p-32 bg-rose-500/10 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2" />
      
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass max-w-lg w-full rounded-[3rem] p-10 md:p-14 text-center shadow-2xl border border-white/60 relative z-10 bg-white/70 backdrop-blur-2xl"
      >
        <div className="w-24 h-24 mx-auto bg-rose-100 text-rose-600 rounded-3xl flex items-center justify-center mb-8 shadow-inner border w-full border-rose-200">
          <AlertCircle className="h-10 w-10" />
        </div>
        
        <h1 className="text-8xl md:text-9xl font-black text-transparent bg-clip-text bg-gradient-to-br from-orange-600 to-rose-600 mb-4 tracking-tighter drop-shadow-sm">
          404
        </h1>
        <h2 className="text-2xl md:text-3xl font-black text-slate-900 mb-4 tracking-tight">
          Page Not Found
        </h2>
        <p className="text-slate-500 font-bold mb-10 text-sm md:text-base leading-relaxed">
          The page you are looking for doesn't exist or has been moved. Check the URL or return home.
        </p>
        
        <Link 
          to="/" 
          className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-600 to-rose-600 hover:from-orange-500 hover:to-rose-500 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest transition-all shadow-[0_10px_25px_rgba(249,115,22,0.3)] hover:shadow-[0_15px_35px_rgba(249,115,22,0.4)] hover:-translate-y-1"
        >
          <Home className="h-5 w-5" />
          Back to Home
        </Link>
      </motion.div>
    </div>
  );
};

export default NotFound;
