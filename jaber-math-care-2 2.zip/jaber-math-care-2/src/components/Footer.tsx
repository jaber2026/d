import React from 'react';
import { Link } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin, Award, GraduationCap, Star, Users, Atom, ChevronRight, Linkedin, Send, Globe, MessageSquare } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';
import { motion } from 'motion/react';

// Brand SVGs for "Original Logo" look
const XIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
);

const TelegramIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M11.944 0C5.346 0 0 5.346 0 11.944c0 6.598 5.346 11.944 11.944 11.944 6.598 0 11.944-5.346 11.944-11.944C23.888 5.346 18.542 0 11.944 0zm5.206 8.19c-.197 1.97-.899 6.035-1.261 7.998-.145.728-.409.972-.651.994-.53.044-1.026-.225-1.536-.559-.798-.522-1.248-.847-2.022-1.357-.896-.589-.315-.913.195-1.444.133-.138 2.457-2.457 2.502-2.648.006-.024.01-.112-.056-.141a.208.208 0 00-.147-.031c-.067.01-1.129.71-3.189 2.103-.301.206-.575.307-.822.301-.272-.006-.793-.154-1.18-.281-.476-.155-.854-.238-.821-.503.018-.139.203-.284.557-.435 2.179-.949 3.633-1.575 4.362-1.877 2.073-.854 2.503-.997 2.784-1.002.062 0 .201.015.29.088.075.062.096.148.105.212z"/></svg>
);

const WhatsAppIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
);

const RedditIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm3.176 17.525c-.714.714-2.025 1.05-3.176 1.05s-2.463-.336-3.176-1.05c-.173-.173-.173-.454 0-.627.172-.172.453-.172.626 0 .546.546 1.587.828 2.55.828.963 0 2.004-.282 2.55-.828.172-.172.453-.172.626 0 .173.173.172.454 0 .627zm4.244-6.425c.08.31.026.634-.144.89-.172.256-.456.413-.767.433-.186.206-.407.4-.664.577.01.12.016.242.016.368 0 2.31-2.613 4.183-5.83 4.183-3.218 0-5.83-1.873-5.83-4.183 0-.115.006-.228.014-.34-.288-.198-.53-.418-.73-.655-.312-.02-.596-.177-.768-.433-.17-.256-.224-.58-.144-.89.077-.294.275-.54.542-.66.195-.084.41-.09.613-.03.262-.36.59-.684.97-.96l-.503-2.36c-.035-.164.03-.337.164-.438.136-.102.316-.118.467-.043l3.22 1.61c.42-.192.88-.306 1.36-.336l.245-1.127c.032-.15.14-.274.288-.316.148-.043.308.006.406.126l.72.875c.576.015 1.11.135 1.594.343l2.842-1.42c.18-.092.398-.066.55.064.153.13.208.312.148.484l-.624 1.776c.404.293.743.642 1.012 1.033.203-.06.418-.053.613.03.267.12.465.366.542.66zm-7.42 2.15c0 .607.493 1.1 1.1 1.1s1.1-.493 1.1-1.1-.493-1.1-1.1-1.1-1.1.493-1.1 1.1zm-4.4 0c0 .607.493 1.1 1.1 1.1s1.1-.493 1.1-1.1-.493-1.1-1.1-1.1-1.1.493-1.1 1.1z"/></svg>
);

const HikmahIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 2L1 7l11 5 11-5-11-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
);

const ThreadsIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8zm0-14.4c-3.535 0-6.4 2.818-6.4 6.287 0 3.468 2.865 6.287 6.4 6.287 3.535 0 6.4-2.819 6.4-6.287 0-3.469-2.865-6.287-6.4-6.287zm0 10.954c-2.481 0-4.5-2.097-4.5-4.667s2.019-4.667 4.5-4.667 4.5 2.097 4.5 4.667-2.019 4.667-4.5 4.667z"/></svg>
);

const Footer = () => {
  const { settings } = useSettings();

  return (
    <footer className="bg-orange-600 text-white mt-auto relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-white via-orange-400 to-white"></div>
      <div className="absolute -top-24 -left-24 w-64 h-64 bg-orange-700/30 rounded-full blur-3xl"></div>
      <div className="absolute -bottom-24 -right-24 w-64 h-64 bg-orange-700/30 rounded-full blur-3xl"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 md:gap-8 mb-6 md:mb-8 text-center md:text-left">
          {/* Brand Section */}
          <div className="md:col-span-3 space-y-4 md:space-y-6 flex flex-col items-center md:items-start">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="flex flex-col items-center md:items-start"
            >
              <img 
                src={settings.logo_url || "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512"} 
                alt={`${settings.site_name || "Jaber Math Care"} Logo`} 
                className="w-20 h-20 rounded-3xl mb-4 p-2 bg-white border border-slate-200/50 object-contain shadow-lg"
                referrerPolicy="no-referrer"
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512";
                }}
              />
              <h3 className="text-3xl font-black tracking-tighter text-white mb-2">
                {settings.site_name || "JABER MATH CARE"}
              </h3>
              <div className="h-1 w-12 bg-white rounded-full"></div>
            </motion.div>
            
            <p className="text-orange-50 text-sm leading-relaxed max-w-sm">
              {settings.footer_description || 'Empowering students with deep conceptual understanding of mathematics. Join us to master the world of numbers with expert guidance and modern learning techniques.'}
            </p>
            
            <div className="flex flex-wrap gap-2.5 justify-center md:justify-start pt-2 max-w-sm">
              {[
                { name: 'Facebook Page', icon: Facebook, url: settings.facebook_url },
                { name: 'Facebook Group', icon: Users, url: settings.facebook_group_url },
                { name: 'YouTube Channel', icon: Youtube, url: settings.youtube_url },
                { name: 'Instagram', icon: Instagram, url: settings.instagram_url },
                { name: 'LinkedIn', icon: Linkedin, url: settings.linkedin_url },
                { name: 'X / Twitter', icon: XIcon, url: settings.x_url || settings.twitter_url },
                { name: 'Telegram', icon: TelegramIcon, url: settings.telegram_url },
                { name: 'WhatsApp', icon: WhatsAppIcon, url: settings.whatsapp_url },
                { name: 'Hikmah Platform', icon: HikmahIcon, url: settings.hikmah_url },
                { name: 'Reddit', icon: RedditIcon, url: settings.reddit_url },
                { name: 'Threads', icon: ThreadsIcon, url: settings.threads_url },
                { name: 'Website', icon: Globe, url: settings.website_url || settings.website_link },
              ]
                .filter((social) => social.url)
                .map((social, i) => (
                  <motion.a
                    key={i}
                    href={social.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    whileHover={{ y: -8, scale: 1.15, rotate: 5 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-3 rounded-xl bg-orange-500 text-white hover:bg-white hover:text-orange-600 transition-all duration-300 shadow-xl border border-white/20 flex items-center justify-center"
                    title={social.name}
                  >
                    <social.icon className="h-5 w-5" />
                  </motion.a>
                ))}
            </div>
          </div>
          
          {/* Quick Links Section */}
          <div className="md:col-span-3 flex flex-col items-center md:items-start">
            <h4 className="font-bold text-lg mb-4 md:mb-6 text-white">Quick Links</h4>
            <ul className="space-y-2 md:space-y-3 text-orange-50 text-sm">
              {[
                { name: 'Home', path: '/' },
                { name: 'About Us', path: '/about' },
                { name: 'Our Network', path: '/our-network' },
                { name: 'Support Team', path: '/support' },
                { name: 'FAQ', path: '/faq' },
                { name: 'Feedback & Reviews', path: '/reviews' },
                { name: 'Sponsorship Program', path: '/sponsorship' },
                { name: 'Our Sponsors & Partners', path: '/sponsors' },
                { name: 'Contact Us', path: '/contact' }
              ].map((item, i) => (
                <motion.li 
                  key={i}
                  whileHover={{ x: 5 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                >
                  <Link 
                    to={item.path} 
                    className="hover:text-white transition-all flex items-center justify-center md:justify-start group gap-2"
                  >
                    <ChevronRight className="h-0 w-0 group-hover:h-4 group-hover:w-4 transition-all duration-300 text-white opacity-0 group-hover:opacity-100" />
                    {item.name}
                  </Link>
                </motion.li>
              ))}
            </ul>
          </div>

          {/* Student Corner Section */}
          <div className="md:col-span-3 flex flex-col items-center md:items-start">
            <h4 className="font-bold text-lg mb-4 md:mb-6 text-white">Student Corner</h4>
            <ul className="space-y-2 md:space-y-3 text-orange-50 text-sm mb-4 md:mb-6">
              {[
                { name: 'Online Courses', path: '/online-courses' },
                { name: 'Physical Courses', path: '/courses' },
                { name: 'Academic Programs', path: '/programs' },
                { name: 'Routine Schedule', path: '/schedule' },
                { name: 'Notice Board', path: '/notices' },
                { name: 'Latest Blogs', path: '/blogs' },
                { name: 'Student Results', path: '/results' },
                { name: 'Recorded Classes', path: '/recorded-classes' },
                { name: 'Free Resources', path: '/resources' },
                { name: 'Public Video Library', path: '/video-library' }
              ].map((item, i) => (
                <motion.li 
                  key={i}
                  whileHover={{ x: 5 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                >
                  <Link 
                    to={item.path} 
                    className="hover:text-white transition-all flex items-center justify-center md:justify-start group gap-2"
                  >
                    <ChevronRight className="h-0 w-0 group-hover:h-4 group-hover:w-4 transition-all duration-300 text-white opacity-0 group-hover:opacity-100" />
                    {item.name}
                  </Link>
                </motion.li>
              ))}
            </ul>
            {/* Decorative Icon for empty space */}
            <motion.div 
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
              className="opacity-20 hidden md:block"
            >
              <Atom className="h-16 w-16 text-white" />
            </motion.div>
          </div>
          
          {/* Contact Section */}
          <div className="md:col-span-3 flex flex-col items-center md:items-start">
            <h4 className="font-bold text-lg mb-4 md:mb-6 text-white">Contact</h4>
            <ul className="space-y-3 md:space-y-4 text-orange-50 text-sm mb-4 md:mb-6">
              <li className="flex items-start justify-center md:justify-start space-x-3">
                <MapPin className="h-5 w-5 text-white flex-shrink-0 mt-0.5" />
                <div className="flex flex-col">
                  <span className="font-bold">Campus 1:</span>
                  <span>{settings.office_address || 'Farmgate, Dhaka, Bangladesh'}</span>
                </div>
              </li>
              <li className="flex items-start justify-center md:justify-start space-x-3">
                <MapPin className="h-5 w-5 text-white flex-shrink-0 mt-0.5" />
                <div className="flex flex-col">
                  <span className="font-bold">Campus 2:</span>
                  <span>{settings.office_address_2 || 'Mouchak, Dhaka, Bangladesh'}</span>
                </div>
              </li>
              <li className="flex items-center justify-center md:justify-start space-x-3">
                <Phone className="h-5 w-5 text-white flex-shrink-0" />
                <span>{settings.contact_phone || '+880 1234 567890'}</span>
              </li>
              <li className="flex items-center justify-center md:justify-start space-x-3">
                <Mail className="h-5 w-5 text-white flex-shrink-0" />
                <span>{settings.contact_email || 'contact@jabermathcare.com'}</span>
              </li>
            </ul>
            
            {/* Legal Links as Cards */}
            <div className="grid grid-cols-1 gap-2 w-full max-w-[200px]">
              <Link 
                to="/terms" 
                className="bg-orange-600 hover:bg-orange-700 text-white p-2 rounded-xl border border-white/20 transition-all text-xs font-black uppercase tracking-widest text-center shadow-xl flex items-center justify-center gap-1 group"
              >
                <ChevronRight className="h-0 w-0 group-hover:h-3 group-hover:w-3 transition-all" />
                Terms & Conditions
              </Link>
              <Link 
                to="/privacy" 
                className="bg-orange-600 hover:bg-orange-700 text-white p-2 rounded-xl border border-white/20 transition-all text-xs font-black uppercase tracking-widest text-center shadow-xl flex items-center justify-center gap-1 group"
              >
                <ChevronRight className="h-0 w-0 group-hover:h-3 group-hover:w-3 transition-all" />
                Privacy Policy
              </Link>
              <Link 
                to="/refund-policy" 
                className="bg-orange-600 hover:bg-orange-700 text-white p-2 rounded-xl border border-white/20 transition-all text-xs font-black uppercase tracking-widest text-center shadow-xl flex items-center justify-center gap-1 group mb-4"
              >
                <ChevronRight className="h-0 w-0 group-hover:h-3 group-hover:w-3 transition-all" />
                Refund Policy
              </Link>

              {/* Developer Info moved here */}
              <Link 
                to="/developer"
                className="flex flex-col items-center bg-white/10 p-4 rounded-2xl border border-white/20 w-full hover:bg-white/20 transition-all group shadow-xl backdrop-blur-sm mt-2"
              >
                <p className="text-[10px] uppercase tracking-[0.2em] text-orange-100 mb-1 font-black">Developed By</p>
                <div className="flex items-center gap-2">
                  <div className="flex flex-col text-center">
                    <span className="font-black text-xs text-white tracking-tight">
                      Mohammad Jaber Bin Razzak
                    </span>
                  </div>
                </div>
              </Link>
            </div>
          </div>
        </div>

        {/* Payment Image - Centered at the bottom of content area */}
        <div className="w-full flex justify-center pb-8 px-4 sm:px-6 lg:px-8">
          <img 
            src="https://securepay.sslcommerz.com/public/image/SSLCommerz-Pay-With-logo-All-Size-01.png" 
            alt="Payment Methods" 
            className="w-full max-w-4xl rounded-xl shadow-lg bg-white p-4"
            referrerPolicy="no-referrer"
          />
        </div>
      </div>
      
      {/* Bottom Bar - Full Width Border */}
      <div className="border-t border-white/20 bg-orange-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col items-center text-center gap-3 text-white">
          <p className="font-black text-white text-base sm:text-lg tracking-tight drop-shadow-sm">
            {settings.copyright_text || `© 2026 ${settings.site_name || "Jaber Math Care"}. All rights reserved.`}
          </p>
          <div className="h-px w-12 bg-white/30"></div>
          <p className="text-[10px] sm:text-xs text-orange-100 font-bold uppercase tracking-[0.2em] opacity-90">
            Developed by Mohammad Jaber Bin Razzak
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
