import LoadingSpinner from '../components/LoadingSpinner';
import React, { useEffect, useState } from 'react';
import { useSettings } from '../context/SettingsContext';
import { BookOpen, Award, CheckCircle, TrendingUp, User, GraduationCap } from 'lucide-react';
import { motion } from 'motion/react';
import { db } from '../firebase';
import { collection, onSnapshot } from 'firebase/firestore';

const About = () => {
  const { settings, loading } = useSettings();
  const [degrees, setDegrees] = useState<any[]>([]);
  const [degreesLoading, setDegreesLoading] = useState(true);

  useEffect(() => {
    // Real-time listener for degrees
    const unsubscribe = onSnapshot(collection(db, 'degrees'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setDegrees(data);
      setDegreesLoading(false);
    }, (error) => {
      console.error('Degrees real-time error:', error);
      setDegreesLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const features = [
    {
      icon: <Award className="w-8 h-8 text-orange-600" />,
      title: "Expert Mentorship",
      description: "Guided by expert instructors, providing top-tier math education."
    },
    {
      icon: <CheckCircle className="w-8 h-8 text-orange-600" />,
      title: "Rigorous Testing",
      description: "Regular weekly and monthly exams designed to simulate real admission and academic challenges."
    },
    {
      icon: <BookOpen className="w-8 h-8 text-orange-600" />,
      title: "Premium Resources",
      description: "Exclusive lecture sheets and video resources covering the entire HSC and Admission syllabus."
    },
    {
      icon: <TrendingUp className="w-8 h-8 text-orange-600" />,
      title: "Performance Tracking",
      description: "Detailed merit lists and progress reports to ensure every student reaches their full potential."
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header Section */}
      <div className="pt-14 pb-4 sm:pt-18 sm:pb-6 px-4 sm:px-6 lg:px-8 text-center bg-white border-b border-slate-100 relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-4xl bg-orange-500/5 blur-[100px] rounded-full pointer-events-none"></div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-10"
        >
          <h1 className="section-title">
            About Us
          </h1>
          <p className="section-subtitle">
            Empowering students with deep conceptual understanding.
          </p>
        </motion.div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Content Section */}
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="glass p-8 md:p-10 lg:p-16 rounded-[40px] shadow-2xl border border-white/60 mb-20 relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-96 h-96 bg-orange-500/10 rounded-full blur-[100px] -mr-48 -mt-48"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-orange-500/10 rounded-full blur-[100px] -ml-48 -mb-48"></div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 relative z-10">
            <div className="flex items-center justify-center order-1 md:order-1 overflow-hidden rounded-[3rem]">
              <div className="relative w-full h-full min-h-[400px]">
                <div className="absolute inset-0 bg-gradient-to-tr from-orange-500 to-orange-300 opacity-20 blur-xl"></div>
                {settings.about_image ? (
                  <img 
                    src={settings.about_image} 
                    alt="About Us" 
                    className="w-full h-full object-cover relative z-10"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-full h-full bg-slate-100 flex items-center justify-center text-slate-300 relative z-10">
                    <User className="w-32 h-32" />
                  </div>
                )}
              </div>
            </div>
            <div className="flex flex-col justify-center items-center text-center order-2 md:order-2">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-100 text-orange-600 font-black tracking-[0.2em] uppercase text-[10px] mb-6 w-max">
                <Award className="h-4 w-4" /> Mentor and Instructor
              </div>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-black mb-8 leading-tight tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-orange-600 to-rose-600">
                {settings.mentor_name || "Wasi Uddin"}
              </h2>
              <div className="space-y-6 text-slate-600 text-lg leading-relaxed mb-10">
                {settings.about_text ? (
                  <div className="whitespace-pre-wrap">{settings.about_text}</div>
                ) : (
                  <>
                    <p>
                      At {settings.site_name || "Jaber Math Care"}, we believe mathematics is not just a subject, but a language of nature. Our mission is to simplify complex mathematical concepts for HSC and Admission seekers.
                    </p>
                    <p>
                      With years of experience and a deep understanding of the engineering admission landscape, we focus on building a strong foundation that helps students tackle any challenge with confidence.
                    </p>
                  </>
                )}
              </div>
              <div className="pt-8 border-t border-slate-200/60 space-y-4">
                {degrees.length > 0 ? (
                  degrees.map((deg, idx) => (
                    <div key={deg.id || idx} className="inline-flex items-center gap-4 p-6 rounded-3xl bg-white shadow-xl border border-orange-100 group/degree hover:border-orange-500 transition-all duration-500 w-full">
                      <div className="w-12 h-12 rounded-2xl bg-orange-100 flex items-center justify-center text-orange-600 group-hover/degree:scale-110 transition-transform shrink-0">
                        <GraduationCap className="h-6 w-6" />
                      </div>
                      <div>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{deg.description || 'Academic Qualification'}</p>
                        <p className="font-black text-slate-900 text-xl tracking-tight">{deg.title}</p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="inline-flex items-center gap-4 p-6 rounded-3xl bg-white shadow-xl border border-orange-100 group/degree hover:border-orange-500 transition-all duration-500 w-full">
                    <div className="w-12 h-12 rounded-2xl bg-orange-100 flex items-center justify-center text-orange-600 group-hover/degree:scale-110 transition-transform shrink-0">
                      <GraduationCap className="h-6 w-6" />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Academic Qualification</p>
                      <p className="font-black text-slate-900 text-xl tracking-tight">{settings.mentor_degree || "B.Sc in Engineering"}</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </motion.div>

        {/* Why Choose Us Section */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16 relative"
        >
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-orange-600 mb-4 tracking-tight">Why Choose Us?</h2>
          <div className="w-24 h-1.5 bg-orange-500 mx-auto rounded-full"></div>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <motion.div 
              key={index} 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="glass p-8 rounded-[2rem] text-center hover:-translate-y-2 transition-transform duration-500 border border-white/60 shadow-xl group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-orange-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="w-20 h-20 mx-auto bg-white rounded-2xl shadow-lg flex items-center justify-center mb-6 transform group-hover:rotate-6 transition-transform duration-500 relative z-10">
                {feature.icon}
              </div>
              <h3 className="text-xl font-black text-slate-900 mb-4 tracking-tight relative z-10">{feature.title}</h3>
              <p className="text-slate-500 leading-relaxed relative z-10">{feature.description}</p>
            </motion.div>
          ))}
        </div>

      </div>
    </div>
  );
};

export default About;
