import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { db } from '../../firebase';
import { collection, onSnapshot, doc, deleteDoc } from 'firebase/firestore';
import { Monitor, Smartphone, Trash2, Info, CheckCircle, Wifi, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { showAlert } from '../../utils/alert';

const ManageDevices = () => {
  const { user } = useAuth();
  const [devices, setDevices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const currentDeviceId = localStorage.getItem('mc_device_id') || '';

  useEffect(() => {
    if (!user) return;

    const devicesRef = collection(db, 'users', user.id, 'devices');
    const unsubscribe = onSnapshot(devicesRef, (snapshot) => {
      const fetched = snapshot.docs.map(snap => ({
        id: snap.id,
        ...snap.data()
      }));
      setDevices(fetched);
      setLoading(false);
    }, (error) => {
      console.error('Error listening to devices:', error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleRemoveDevice = async (deviceId: string, name: string) => {
    if (!user) return;
    
    // Check if user is removing their active device
    const isCurrent = deviceId === currentDeviceId;
    const confirmMessage = isCurrent 
      ? `সতর্কতা: আপনি আপনার কারেন্ট ডিভাইসটি রিমুভ করার চেষ্টা করছেন। আপনি কি সত্যিই এটি রিমুভ করতে চান? রিমুভ করলে পুনরায় রেজিস্ট্রেশন করতে হতে পারে।`
      : `আপনি কি "${name}" নামক ডিভাইসটি রিমুভ করতে চান?`;

    if (!window.confirm(confirmMessage)) return;

    try {
      await deleteDoc(doc(db, 'users', user.id, 'devices', deviceId));
      showAlert(`ডিভাইসটি সফলভাবে রিমুভ করা হয়েছে!`, "success");
      
      // If they removed their current device, reload to trigger re-registration
      if (isCurrent) {
        window.location.reload();
      }
    } catch (err: any) {
      console.error('Error deleting device:', err);
      showAlert(`ডিভাইস রিমুভ করতে ব্যর্থ হয়েছে: ${err.message}`, "error");
    }
  };

  const getDeviceIcon = (name: string) => {
    const lower = (name || '').toLowerCase();
    if (lower.includes('android') || lower.includes('iphone') || lower.includes('ios') || lower.includes('phone')) {
      return <Smartphone className="h-6 w-6 text-orange-600" />;
    }
    return <Monitor className="h-6 w-6 text-orange-600" />;
  };

  const formatLoggedInTime = (timeStr: any) => {
    if (!timeStr) return 'N/A';
    try {
      const date = new Date(timeStr);
      return date.toLocaleDateString('bn-BD', {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      }) + ' ' + date.toLocaleTimeString('bn-BD', {
        hour: '2-digit',
        minute: '2-digit',
        hour12: true
      });
    } catch {
      return String(timeStr);
    }
  };

  return (
    <div className="px-4 py-6 md:px-8 md:py-8 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 overflow-y-auto h-[calc(100vh-80px)] scrollbar-hide">
      
      {/* Dynamic Header with Gradient Background */}
      <div className="relative overflow-hidden bg-slate-900 rounded-[2.5rem] p-8 md:p-12 shadow-2xl">
        <div className="absolute top-0 right-0 w-64 h-64 bg-orange-600/20 blur-[100px] -mr-32 -mt-32 rounded-full"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/10 blur-[100px] -ml-32 -mb-32 rounded-full"></div>
        
        <div className="relative flex flex-col md:flex-row items-center gap-6 md:gap-8">
          <div className="p-5 bg-orange-600 text-white rounded-[2rem] shadow-xl shadow-orange-600/20 ring-8 ring-orange-600/10">
            <Monitor className="h-10 w-10" />
          </div>
          <div className="text-center md:text-left">
            <h1 id="devices-title" className="text-3xl md:text-5xl font-black text-white tracking-tight leading-tight">
              Manage Your <span className="text-orange-500">Connected Devices</span>
            </h1>
            <p className="text-slate-400 font-bold text-base md:text-xl mt-3 max-w-2xl">
              Security check: You can access Jaber Math Care from up to 2 devices simultaneously. Manage your active sessions below.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column: Device Cards */}
        <div className="lg:col-span-2 space-y-6">
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2 ml-2">
            <Wifi className="h-5 w-5 text-orange-600" />
            Active Sessions ({devices.length}/2)
          </h2>
          
          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 gap-4 bg-white rounded-[2.5rem] shadow-sm">
              <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
              <p className="text-slate-500 font-bold">ডিভাইস তালিকা লোড হচ্ছে...</p>
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              {devices.length === 0 ? (
                <motion.div 
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white p-12 rounded-[2.5rem] border-2 border-dashed border-slate-200 text-center space-y-4"
                >
                  <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto text-slate-300">
                    <Monitor className="h-10 w-10" />
                  </div>
                  <p className="text-slate-500 font-bold text-lg">No active devices found.</p>
                </motion.div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {devices.map((device) => {
                    const isCurrent = device.id === currentDeviceId;
                    return (
                      <motion.div
                        key={device.id}
                        layout
                        initial={{ opacity: 0, scale: 0.9 }}
                        animate={{ opacity: 1, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        className={`group relative bg-white p-6 rounded-[2.5rem] border-2 transition-all ${isCurrent ? 'border-orange-500 shadow-xl ring-4 ring-orange-50' : 'border-slate-100 hover:border-orange-200 hover:shadow-lg'}`}
                      >
                        {isCurrent && (
                          <div className="absolute -top-3 left-8 px-4 py-1 bg-orange-600 text-white text-[10px] font-black uppercase tracking-widest rounded-full shadow-lg z-10">
                            Current Device
                          </div>
                        )}
                        
                        <div className="flex flex-col h-full">
                          <div className="flex items-start justify-between mb-6">
                            <div className={`p-4 rounded-2xl shadow-sm ${isCurrent ? 'bg-orange-600 text-white' : 'bg-slate-50 text-slate-400 group-hover:bg-orange-50 group-hover:text-orange-600 transition-colors'}`}>
                              {getDeviceIcon(device.name)}
                            </div>
                            <button
                              onClick={() => handleRemoveDevice(device.id, device.name || 'Unknown Device')}
                              className="p-3 text-slate-300 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"
                              title="Remove Device"
                            >
                              <Trash2 className="h-5 w-5" />
                            </button>
                          </div>
                          
                          <div className="space-y-4 mt-auto">
                            <div>
                              <h3 className="font-black text-slate-800 line-clamp-1 text-lg">{device.name || 'Unknown Device'}</h3>
                              <div className="flex items-center gap-2 text-slate-500 font-bold text-xs mt-1">
                                <div className={`w-2 h-2 rounded-full ${isCurrent ? 'bg-green-500 animate-pulse' : 'bg-slate-300'}`} />
                                {device.platform || 'System'} • {device.browser || 'Browser'}
                              </div>
                            </div>
                            
                            <div className="flex flex-col gap-2 p-4 bg-slate-50 rounded-2xl border border-slate-100 group-hover:bg-orange-50/50 group-hover:border-orange-100 transition-colors">
                              <div className="flex items-center gap-2">
                                <Clock className="h-4 w-4 text-slate-400 group-hover:text-orange-500" />
                                <div className="text-[10px] font-black text-slate-500 uppercase tracking-tight">
                                  Last Seen: <span className="text-slate-900 ml-1">{formatLoggedInTime(device.last_login || device.loggedIn)}</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-2">
                                <Wifi className="h-4 w-4 text-slate-400 group-hover:text-orange-500" />
                                <div className="text-[10px] font-black text-slate-500 uppercase tracking-tight">
                                  IP Address: <span className="text-slate-900 ml-1 font-mono">{device.ipAddress || '---.---.---.---'}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              )}
            </AnimatePresence>
          )}
        </div>

        {/* Right Column: Info & Security */}
        <div className="space-y-6">
          <h2 className="text-xl font-black text-slate-800 flex items-center gap-2 ml-2">
            <Info className="h-5 w-5 text-orange-600" />
            Policies
          </h2>
          
          <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-6">
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-green-50 text-green-600 rounded-lg mt-1">
                  <CheckCircle className="h-4 w-4" />
                </div>
                <p className="text-slate-600 font-medium text-sm leading-relaxed">
                  You can use one account on two different devices (e.g., Phone and Laptop).
                </p>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-2 bg-green-50 text-green-600 rounded-lg mt-1">
                  <CheckCircle className="h-4 w-4" />
                </div>
                <p className="text-slate-600 font-medium text-sm leading-relaxed">
                  Logging in on a 3rd device will require removing an existing session.
                </p>
              </div>
              <div className="flex items-start gap-4">
                <div className="p-2 bg-orange-50 text-orange-600 rounded-lg mt-1">
                  <Smartphone className="h-4 w-4" />
                </div>
                <p className="text-slate-600 font-medium text-sm leading-relaxed text-orange-700/80 italic font-bold">
                  সতর্কতা: প্রাইভেসী রক্ষার স্বার্থে আপনার লগইন তথ্য অন্যদের সাথে শেয়ার করা হতে বিরত থাকুন।
                </p>
              </div>
            </div>
            
            <div className="pt-6 border-t border-slate-100">
              <button 
                onClick={() => window.location.reload()}
                className="w-full bg-orange-600 text-white py-4 rounded-2xl font-black text-sm hover:bg-orange-700 shadow-lg shadow-orange-600/20 transition-all active:scale-95"
              >
                Refresh Sessions
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ManageDevices;
