import { showAlert } from '../utils/alert';
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mail, Phone, MapPin, Send, CheckCircle, Loader, Facebook, Youtube, Instagram, Users, ArrowRight, Linkedin, MessageCircle, Share2, Globe } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

// Brand SVGs for "Original Logo" look
const XIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>
);

const TelegramIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M11.944 0C5.346 0 0 5.346 0 11.944c0 6.598 5.346 11.944 11.944 11.944 6.598 0 11.944-5.346 11.944-11.944C23.888 5.346 18.542 0 11.944 0zm5.206 8.19c-.197 1.97-.899 6.035-1.261 7.998-.145.728-.409.972-.651.994-.53.044-1.026-.225-1.536-.559-.798-.522-1.248-.847-2.022-1.357-.896-.589-.315-.913.195-1.444.133-.138 2.457-2.457 2.502-2.648.006-.024.01-.112-.056-.141a.208.208 0 00-.147-.031c-.067.01-1.129.71-3.189 2.103-.301.206-.575.307-.822.301-.272-.006-.793-.154-1.18-.281-.476-.155-.854-.238-.821-.503.018-.139.203-.284.557-.435 2.179-.949 3.633-1.575 4.362-1.877 2.073-.854 2.503-.997 2.784-1.002.062 0 .201.015.29.088.075.062.096.148.105.212z"/></svg>
);

const WhatsAppIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413Z"/></svg>
);

const RedditIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 0c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm3.176 17.525c-.714.714-2.025 1.05-3.176 1.05s-2.463-.336-3.176-1.05c-.173-.173-.173-.454 0-.627.172-.172.453-.172.626 0 .546.546 1.587.828 2.55.828.963 0 2.004-.282 2.55-.828.172-.172.453-.172.626 0 .173.173.172.454 0 .627zm4.244-6.425c.08.31.026.634-.144.89-.172.256-.456.413-.767.433-.186.206-.407.4-.664.577.01.12.016.242.016.368 0 2.31-2.613 4.183-5.83 4.183-3.218 0-5.83-1.873-5.83-4.183 0-.115.006-.228.014-.34-.288-.198-.53-.418-.73-.655-.312-.02-.596-.177-.768-.433-.17-.256-.224-.58-.144-.89.077-.294.275-.54.542-.66.195-.084.41-.09.613-.03.262-.36.59-.684.97-.96l-.503-2.36c-.035-.164.03-.337.164-.438.136-.102.316-.118.467-.043l3.22 1.61c.42-.192.88-.306 1.36-.336l.245-1.127c.032-.15.14-.274.288-.316.148-.043.308.006.406.126l.72.875c.576.015 1.11.135 1.594.343l2.842-1.42c.18-.092.398-.066.55.064.153.13.208.312.148.484l-.624 1.776c.404.293.743.642 1.012 1.033.203-.06.418-.053.613.03.267.12.465.366.542.66zm-7.42 2.15c0 .607.493 1.1 1.1 1.1s1.1-.493 1.1-1.1-.493-1.1-1.1-1.1-1.1.493-1.1 1.1zm-4.4 0c0 .607.493 1.1 1.1 1.1s1.1-.493 1.1-1.1-.493-1.1-1.1-1.1-1.1.493-1.1 1.1z"/></svg>
);

const HikmahIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 2L1 7l11 5 11-5-11-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>
);

const ThreadsIcon = ({ className }: { className?: string }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}><path d="M12 2C6.477 2 2 6.477 2 12s4.477 10 10 10 10-4.477 10-10S17.523 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8zm0-14.4c-3.535 0-6.4 2.818-6.4 6.287 0 3.468 2.865 6.287 6.4 6.287 3.535 0 6.4-2.819 6.4-6.287 0-3.469-2.865-6.287-6.4-6.287zm0 10.954c-2.481 0-4.5-2.097-4.5-4.667s2.019-4.667 4.5-4.667 4.5 2.097 4.5 4.667-2.019 4.667-4.5 4.667z"/></svg>
);

const Contact = () => {
  const { settings } = useSettings();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    current_class: '',
    school_name: '',
    college_name: '',
    subject: 'Contact Form Submission',
    message: '',
    is_read: false
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  React.useEffect(() => {
    // Dynamic loading of Creattie embed script
    const scriptId = 'creattie-embed-script';
    let scriptExists = document.getElementById(scriptId);
    if (!scriptExists) {
      const script = document.createElement('script');
      script.id = scriptId;
      script.src = "https://creattie.com/js/embed.js?id=d4eb0285e02de3c8cd73";
      script.defer = true;
      document.body.appendChild(script);
    }
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    try {
      // 1. Save to database
      const res = await fetch(`/api/messages?t=${Date.now()}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, created_at: new Date().toISOString() })
      });
      
      if (!res.ok) {
        throw new Error('Failed to send message');
      }

      setIsSuccess(true);
      setFormData({ name: '', email: '', phone: '', current_class: '', school_name: '', college_name: '', subject: 'Contact Form Submission', message: '', is_read: false });
      setTimeout(() => setIsSuccess(false), 5000);
    } catch (error) {
      console.error("Error sending message:", error);
      showAlert('An error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen pt-4 md:pt-12 pb-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12 pt-4">
          <motion.h1 
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl sm:text-5xl font-black text-orange-600 tracking-tight"
          >
            Contact Us
          </motion.h1>
          <div className="w-16 h-1.5 bg-orange-600 mx-auto rounded-full mt-3"></div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="grid grid-cols-1 lg:grid-cols-[1.3fr_1fr] md:gap-10 lg:gap-12"
        >
          {/* Contact Info */}
          <div className="bg-gradient-to-br from-orange-600 to-orange-800 text-white rounded-[2rem] p-6 lg:p-12 shadow-xl flex flex-col h-full min-h-[600px] pb-12 lg:pb-16">
            <div className="text-center lg:text-left mb-10">
              <h2 className="text-3xl lg:text-4xl font-bold text-white mb-2">
                Get In Touch
              </h2>
            </div>

            <div className="space-y-6 flex-1">
              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="bg-white/10 p-6 rounded-2xl flex flex-col lg:flex-row items-center lg:items-start text-center lg:text-left lg:space-x-5 space-y-4 lg:space-y-0"
              >
                <div className="text-white mt-1">
                  <MapPin className="h-7 w-7" />
                </div>
                <div className="w-full">
                  <h3 className="text-white font-bold text-lg mb-1.5">Main Branch</h3>
                  <p className="text-indigo-100 font-medium whitespace-pre-line text-sm leading-relaxed">{settings.office_address || 'Kamarpara, Bogura'}</p>
                </div>
              </motion.div>

              {(settings.office_address_2 || settings.office_address_2?.length > 0) && (
                <motion.div 
                  whileHover={{ scale: 1.02 }}
                  className="bg-white/10 p-6 rounded-2xl flex flex-col lg:flex-row items-center lg:items-start text-center lg:text-left lg:space-x-5 space-y-4 lg:space-y-0"
                >
                  <div className="text-white mt-1">
                    <MapPin className="h-7 w-7" />
                  </div>
                  <div className="w-full">
                    <h3 className="text-white font-bold text-lg mb-1.5">Second Branch</h3>
                    <p className="text-indigo-100 font-medium whitespace-pre-line text-sm leading-relaxed">{settings.office_address_2}</p>
                  </div>
                </motion.div>
              )}

              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="bg-white/10 p-6 rounded-2xl flex flex-col lg:flex-row items-center lg:items-start text-center lg:text-left lg:space-x-5 space-y-4 lg:space-y-0"
              >
                <div className="text-white mt-1">
                  <Phone className="h-7 w-7" />
                </div>
                <div className="w-full">
                  <h3 className="text-white font-bold text-lg mb-1.5">Phone</h3>
                  <p className="text-indigo-100 font-medium text-sm leading-relaxed whitespace-pre-line">
                    {settings.contact_phone || '+880 1310 265252'}
                  </p>
                </div>
              </motion.div>

              <motion.div 
                whileHover={{ scale: 1.02 }}
                className="bg-white/10 p-6 rounded-2xl flex flex-col lg:flex-row items-center lg:items-start text-center lg:text-left lg:space-x-5 space-y-4 lg:space-y-0"
              >
                <div className="text-white mt-1">
                  <Mail className="h-7 w-7" />
                </div>
                <div className="w-full">
                  <h3 className="text-white font-bold text-lg mb-1.5">Email</h3>
                  <a href={`mailto:${settings.contact_email || 'contact@jabermathcare.com'}`} className="text-orange-100 font-medium hover:text-white break-all transition-colors inline-block text-sm">
                    {settings.contact_email || 'contact@jabermathcare.com'}
                  </a>
                </div>
              </motion.div>
            </div>

            {/* Social Links */}
            <div className="mt-12 pt-8 border-t border-orange-400/30">
              <div className="flex flex-wrap justify-center lg:justify-start gap-2.5 max-w-sm">
                {[
                  { name: 'Facebook Page', icon: Facebook, url: settings.facebook_url },
                  { name: 'Facebook Group', icon: Users, url: settings.facebook_group_url },
                  { name: 'YouTube Channel', icon: Youtube, url: settings.youtube_url },
                  { name: 'Instagram', icon: Instagram, url: settings.instagram_url },
                  { name: 'LinkedIn', icon: Linkedin, url: settings.linkedin_url },
                  { name: 'X / Twitter', icon: XIcon, url: settings.x_url || settings.twitter_url },
                  { name: 'Telegram', icon: TelegramIcon, url: settings.telegram_url },
                  { name: 'WhatsApp', icon: WhatsAppIcon, url: settings.whatsapp_url },
                  { name: 'Hikmah Platform', icon: HikmahIcon, url: settings.hikmah_url },
                  { name: 'Reddit', icon: RedditIcon, url: settings.reddit_url },
                  { name: 'Threads', icon: ThreadsIcon, url: settings.threads_url },
                  { name: 'Website', icon: Globe, url: settings.website_url || settings.website_link },
                ]
                  .filter((social) => social.url)
                  .map((social, i) => (
                    <motion.a
                      key={i}
                      href={social.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      whileHover={{ y: -8, scale: 1.15, rotate: 5 }}
                      whileTap={{ scale: 0.9 }}
                      className="p-3 rounded-xl bg-orange-500 text-white hover:bg-white hover:text-orange-600 transition-all duration-300 shadow-xl border border-white/20 flex items-center justify-center"
                      title={social.name}
                    >
                      <social.icon className="h-5 w-5" />
                    </motion.a>
                  ))}
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="glass-card p-10 relative overflow-hidden">
            <AnimatePresence>
              {isSuccess && (
                <motion.div
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  className="absolute inset-0 bg-white/95 backdrop-blur-md z-20 flex flex-col items-center justify-center p-8 text-center rounded-2xl"
                >
                  <motion.div 
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", damping: 12 }}
                    className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mb-6"
                  >
                    <CheckCircle className="h-12 w-12" />
                  </motion.div>
                  <h3 className="text-3xl font-black text-slate-900 mb-2">Message Sent!</h3>
                  <p className="text-slate-600 font-medium">We will get back to you soon.</p>
                </motion.div>
              )}
            </AnimatePresence>
            
            <h2 className="text-2xl font-black text-orange-600 mb-8 tracking-tight">Send us a Message</h2>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">Full Name</label>
                  <input
                    type="text"
                    className="glass-input"
                    placeholder="John Doe"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">Phone Number</label>
                  <input
                    type="tel"
                    className="glass-input"
                    placeholder="01XXXXXXXXX"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    required
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">Current Class</label>
                  <input
                    type="text"
                    className="glass-input"
                    placeholder="Class 10"
                    value={formData.current_class}
                    onChange={(e) => setFormData({ ...formData, current_class: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">School Name</label>
                  <input
                    type="text"
                    className="glass-input"
                    placeholder="School Name"
                    value={formData.school_name}
                    onChange={(e) => setFormData({ ...formData, school_name: e.target.value })}
                    required
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">College Name</label>
                <input
                  type="text"
                  className="glass-input"
                  placeholder="College Name"
                  value={formData.college_name}
                  onChange={(e) => setFormData({ ...formData, college_name: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">Email Address</label>
                <input
                  type="email"
                  className="glass-input"
                  placeholder="your@email.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest ml-1">Message</label>
                <textarea
                  className="glass-input h-40 resize-none"
                  placeholder="How can we help you?"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  required
                ></textarea>
              </div>
              <motion.button 
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit" 
                disabled={isSubmitting} 
                className="glass-btn w-full"
              >
                {isSubmitting ? (
                  <Loader className="h-5 w-5 animate-spin" />
                ) : (
                  <><Send className="h-5 w-5" /> Send Message</>
                )}
              </motion.button>
            </form>
          </div>
        </motion.div>

        {/* Map Section */}
        {(settings.map_embed_code || settings.map_embed_code_2) && (
          <div className="mt-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-center mb-16"
            >
              <h2 className="text-3xl font-bold text-orange-600 mb-3">Our Location</h2>
              <div className="w-32 h-1.5 bg-orange-600 mx-auto rounded-full"></div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.2 }}
              className="grid grid-cols-1 md:grid-cols-2 gap-8"
            >
            {settings.map_embed_code && (
              <div className="bg-white p-4 rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
                <h3 className="text-lg font-bold text-slate-800 mb-3 flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-orange-600" /> Campus 1 Location
                </h3>
                <div className="aspect-video w-full rounded-xl overflow-hidden shadow-inner bg-slate-100 h-[350px] [&>iframe]:w-full [&>iframe]:h-full" dangerouslySetInnerHTML={{ __html: settings.map_embed_code }} />
              </div>
            )}

            {settings.map_embed_code_2 && (
              <div className="bg-white p-4 rounded-2xl shadow-lg border border-slate-200 overflow-hidden">
                <h3 className="text-lg font-bold text-slate-800 mb-3 flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-orange-600" /> Campus 2 Location
                </h3>
                <div className="aspect-video w-full rounded-xl overflow-hidden shadow-inner bg-slate-100 h-[350px] [&>iframe]:w-full [&>iframe]:h-full" dangerouslySetInnerHTML={{ __html: settings.map_embed_code_2 }} />
              </div>
            )}
          </motion.div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Contact;
