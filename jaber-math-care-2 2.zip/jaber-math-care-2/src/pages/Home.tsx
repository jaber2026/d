import { useRealtimeCollection } from '../hooks/useRealtime';
import { where, collection, query, limit, orderBy, getDocs } from 'firebase/firestore';
import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { ArrowRight, BookOpen, Users, Award, PlayCircle, Rocket, Info, Phone, LogIn, User, GraduationCap, Atom, Magnet, FlaskConical, Zap, Calendar, X, Star, BarChart2, Youtube, Bell, Sparkles, SquareRadical, Download, Heart, Globe, ExternalLink, ShieldCheck, Trophy, Crown, Quote } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { Link } from 'react-router-dom';
import { useSettings } from '../context/SettingsContext';
import { db } from '../firebase';
import { useAuth } from '../context/AuthContext';
import { ChevronRight } from 'lucide-react';
import LoadingSpinner from '../components/LoadingSpinner';
import FloatingNoticePopup from '../components/FloatingNoticePopup';
import FeaturedSlider from '../components/FeaturedSlider';
import ECommerceBannerSlider from '../components/ECommerceBannerSlider';

const BlogSection = () => {
  const { data: blogs } = useRealtimeCollection('blogs', [orderBy('created_at', 'desc'), limit(3)]);

  if (blogs.length === 0) return null;

  return (
    <section className="py-10 md:py-14 bg-slate-50 border-t border-slate-200/50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-6 mb-16">
          <span className="inline-block px-4 py-2 rounded-full bg-orange-100 text-orange-600 text-xs font-black uppercase tracking-widest">
            Latest Updates
          </span>
          <h2 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tighter">
            Our Blog & <span className="text-orange-600">News</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogs.map((blog: any, idx: number) => (
            <motion.div
              key={blog.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white rounded-[2rem] overflow-hidden border border-slate-100 shadow-xl shadow-slate-200/50 flex flex-col group hover:-translate-y-2 transition-all duration-300"
            >
              <Link to="/blogs" className="block flex-1 flex flex-col">
                <div className="h-52 relative overflow-hidden bg-slate-100 flex-shrink-0">
                  {blog.image_url ? (
                    <img 
                      src={blog.image_url} 
                      alt={blog.title} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <div className="w-full h-full bg-orange-500/5 flex items-center justify-center">
                      <BookOpen className="h-12 w-12 text-orange-500 opacity-20" />
                    </div>
                  )}
                  <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-md px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest text-orange-600 flex items-center gap-1.5 shadow-sm">
                    <Calendar className="h-3 w-3" /> 
                    {blog.created_at ? new Date(blog.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'Recent'}
                  </div>
                </div>

                <div className="p-8 flex flex-col flex-1">
                  <h3 className="text-xl font-black text-slate-900 tracking-tight leading-snug line-clamp-2 group-hover:text-orange-600 transition-colors mb-3">
                    {blog.title}
                  </h3>
                  <p className="text-slate-500 text-sm mt-auto leading-relaxed line-clamp-3">
                    {blog.content}
                  </p>
                  <div className="pt-6 mt-6 border-t border-slate-50 flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-xs font-bold text-slate-400 uppercase tracking-widest">
                      <User className="h-3.5 w-3.5 text-orange-500/70" /> {blog.author || 'Instructor'}
                    </span>
                    <span className="text-orange-600 font-black text-xs uppercase tracking-widest flex items-center gap-2">
                       Read <ArrowRight className="h-4 w-4" />
                    </span>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        <div className="flex justify-center mt-12">
          <Link 
            to="/blogs" 
            className="px-8 py-4 bg-orange-50 hover:bg-orange-600 text-orange-600 hover:text-white rounded-xl font-black text-xs uppercase tracking-widest transition-all shadow-sm active:scale-95 flex items-center gap-3"
          >
            View All Articles <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
};

const WebLinksSection = () => {
  const { data: links } = useRealtimeCollection('web_links');
  if (links.length === 0) return null;
  return (
    <section className="py-8 bg-white/50 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-slate-100 rounded-full blur-[100px] opacity-40"></div>
      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="glass p-6 md:p-8 rounded-[3rem] border border-white bg-white/40 shadow-2xl backdrop-blur-3xl overflow-hidden relative group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full blur-2xl group-hover:scale-150 transition-transform duration-1000"></div>
          <div className="flex flex-col md:flex-row items-center justify-between mb-8 gap-4">
            <div className="space-y-0.5 text-center md:text-left">
              <h3 className="text-lg md:text-xl font-black text-slate-800 flex items-center justify-center md:justify-start gap-4 tracking-tighter">
                <Globe className="h-5 w-5 text-orange-600" /> OUR NETWORK
              </h3>
              <p className="text-[9px] uppercase tracking-[0.2em] font-black text-slate-400">Official Web Portals & Partner Resources</p>
            </div>
            <div className="h-px flex-1 bg-slate-200/50 mx-4 hidden md:block"></div>
            <div className="px-3 py-1.5 rounded-full bg-orange-50 border border-orange-100 text-[10px] font-black text-orange-600 uppercase tracking-widest whitespace-nowrap">
              Connect With Us
            </div>
          </div>
          <div className="grid grid-cols-2 min-[400px]:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
            {links.sort((a,b)=> (a.order || 0) - (b.order || 0)).map(link => (
              <motion.a 
                key={link.id} 
                href={link.url} 
                target="_blank" 
                rel="noopener noreferrer"
                whileHover={{ y: -5, scale: 1.02 }}
                className="bg-white/60 p-3.5 sm:p-5 rounded-[1.8rem] hover:bg-white transition-all flex flex-col items-center gap-3 group border border-white shadow-lg hover:shadow-orange-900/5"
              >
                 <div className="h-10 w-10 sm:h-12 sm:w-12 rounded-2xl bg-slate-50 flex items-center justify-center group-hover:scale-110 transition-transform overflow-hidden shadow-inner border border-slate-100 shrink-0">
                   {link.image_url ? (
                     <img src={link.image_url} alt={link.title} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                   ) : (
                     <Globe className="h-5 w-5 sm:h-6 sm:w-6 text-orange-600" />
                   )}
                 </div>
                 <div className="text-center space-y-0.5">
                   <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-tight text-slate-800 group-hover:text-orange-600 transition-colors block leading-tight truncate max-w-[80px]">{link.title}</span>
                   <ExternalLink className="h-2.5 w-2.5 text-slate-300 mx-auto group-hover:text-orange-400 transition-colors" />
                 </div>
              </motion.a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

const SupportTeamSection = () => {
  const { data: members } = useRealtimeCollection('support_team');
  if (members.length === 0) return null;
  return (
    <section id="support-team" className="py-12 md:py-16 bg-slate-50 relative overflow-hidden">
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-orange-100/50 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="text-center mb-12 space-y-3">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-block px-3 py-1.5 rounded-full bg-blue-100 text-blue-600 text-[10px] font-black uppercase tracking-widest"
          >
            Always Here To Help
          </motion.div>
          <h3 className="text-2xl md:text-4xl font-black text-slate-900 flex items-center justify-center gap-4 tracking-tighter">
             Dedicated Support Team
          </h3>
          <p className="text-slate-500 font-medium text-xs max-w-xl mx-auto">Ensuring your mathematical journey is smooth and successful with 24/7 expert assistance.</p>
        </div>
        
        <div className="grid grid-cols-1 min-[480px]:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
          {members.sort((a,b)=> (a.order || 0) - (b.order || 0)).map((member, i) => (
            <motion.div 
              key={member.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              whileHover={{ y: -8 }}
              className="glass rounded-[2.5rem] overflow-hidden flex flex-col items-center text-center group border border-white shadow-2xl bg-white/40 backdrop-blur-3xl h-[460px] max-w-[260px] mx-auto relative transition-all duration-500"
            >
               <div className="absolute top-4 right-4 z-20">
                 <div className="p-2 bg-white/80 backdrop-blur-md rounded-2xl shadow-lg border border-white">
                   <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
                 </div>
               </div>

               <div className="h-64 w-full overflow-hidden relative shrink-0">
                  <img 
                    src={member.image_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(member.name)}&background=ea580c&color=fff&size=512`} 
                    alt={member.name}
                    className="h-full w-full object-cover group-hover:scale-110 transition-all duration-1000" 
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
               </div>
               
               <div className="p-5 flex flex-col items-center flex-1 justify-between">
                  <div className="space-y-1 w-full">
                    <h4 className="text-md font-black text-slate-900 tracking-tight leading-tight truncate">{member.name}</h4>
                    <div className="inline-flex px-2.5 py-0.5 bg-orange-100 text-orange-600 rounded-full text-[9px] font-black uppercase tracking-widest border border-orange-200/50">
                      {member.role}
                    </div>
                  </div>
                  
                  <p className="text-[10px] text-slate-500 font-bold leading-relaxed px-1 line-clamp-5 mt-3 italic">
                    "{member.description}"
                  </p>
                  
                  <div className="mt-auto pt-4 border-t border-slate-100 w-full">
                    <div className="flex justify-center gap-0.5">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className="h-2.5 w-2.5 text-orange-400 fill-orange-400" />
                      ))}
                    </div>
                  </div>
               </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const QuickPricingSection = () => {
  const { data: plans } = useRealtimeCollection('pricing_plans', [
    where('is_active', '==', true),
    orderBy('order', 'asc'),
    limit(3)
  ]);

  if (plans.length === 0) return null;

  return (
    <section className="py-12 md:py-16 bg-white relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-24 bg-gradient-to-b from-slate-50 to-transparent"></div>
      <div className="max-w-7xl mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between mb-12 gap-6">
          <div className="text-center md:text-left space-y-1.5">
            <h3 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tighter uppercase">Support & Partner</h3>
            <p className="text-slate-500 font-medium text-xs max-w-xl">Choose a sponsorship model to support our mission and get featured in our ecosystem.</p>
          </div>
          <Link 
            to="/sponsorship" 
            className="px-6 py-3.5 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-800 transition-all shadow-xl active:scale-95 flex items-center gap-2"
          >
            View All Plans <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {plans.map((plan, i) => (
            <motion.div
              key={plan.id}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className={`p-6 rounded-[2.5rem] border-2 transition-all duration-500 flex flex-col items-center text-center relative group ${
                i === 1 ? 'border-orange-500 bg-orange-50/5 shadow-2xl scale-105 z-10' : 'border-slate-100 bg-white shadow-xl hover:border-orange-200'
              }`}
            >
              <div className={`p-3 rounded-2xl mb-5 shadow-lg transform group-hover:rotate-12 transition-transform ${
                i === 0 ? 'bg-blue-600 text-white' : i === 1 ? 'bg-orange-600 text-white' : 'bg-slate-900 text-white'
              }`}>
                {i === 0 ? <Zap className="h-5 w-5" /> : i === 1 ? <Trophy className="h-5 w-5" /> : <Rocket className="h-5 w-5" />}
              </div>

              <h4 className="text-lg font-black text-slate-900 mb-1">{plan.title}</h4>
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-3xl font-black text-slate-900">{plan.price}</span>
                <span className="text-slate-400 text-[9px] font-black uppercase tracking-widest">/ {plan.duration}</span>
              </div>

              <Link
                to={`/sponsorship?amount=${String(plan.price).replace(/[^0-9]/g, '')}&plan=${encodeURIComponent(plan.title)}`}
                className={`w-full py-3.5 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all shadow-lg active:scale-95 flex items-center justify-center gap-2 ${
                  i === 1 ? 'bg-orange-600 text-white hover:bg-orange-700 shadow-orange-600/30' : 'bg-slate-900 text-white hover:bg-slate-800'
                }`}
              >
                Become Sponsor
                <ArrowRight className="h-3 w-3" />
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const StudentReviewsGrid = () => {
  const { data: reviews } = useRealtimeCollection('reviews', [
    where('status', '==', 'approved')
  ]);

  if (reviews.length === 0) return null;

  const displayReviews = reviews.slice(0, 3);

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 py-6">
      {displayReviews.map((review, idx) => (
        <motion.div
          key={review.id + '-' + idx}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: idx * 0.1 }}
          className="relative p-8 rounded-[2.5rem] border border-slate-100 shadow-xl bg-white hover:shadow-2xl transition-all group overflow-hidden text-left"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-orange-50 rounded-full -mr-16 -mt-16 transition-transform group-hover:scale-150 duration-700 ease-out"></div>
          <div className="relative z-10">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-2xl overflow-hidden border-2 border-white shadow-lg group-hover:scale-110 transition-transform duration-500">
                <img 
                  src={review.student_image || `https://picsum.photos/seed/student${review.id}/200/200`} 
                  alt={review.student_name} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <div className="min-w-0">
                <h4 className="text-lg font-black text-slate-900 tracking-tight truncate">{review.student_name}</h4>
                <div className="flex gap-1 mt-1">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={`h-4 w-4 ${i < (review.rating || 5) ? 'text-orange-500 fill-orange-500' : 'text-slate-200'}`} 
                    />
                  ))}
                </div>
              </div>
            </div>
            <Quote className="h-10 w-10 text-orange-100 mb-4 transform -scale-x-100" />
            <p className="text-slate-600 font-medium leading-relaxed italic line-clamp-4">
              "{review.comment}"
            </p>
          </div>
        </motion.div>
      ))}
    </div>
  );
};

const ScrollingNotices = () => {
  const { data: notices } = useRealtimeCollection('notices');

  if (notices.length === 0) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden bg-white/40 backdrop-blur-md border border-white/60 py-4 rounded-[2rem] shadow-sm group hover:bg-white/60 transition-all"
    >
      <div className="flex items-center gap-4 px-6 absolute left-0 top-0 h-full z-20 bg-white/80 backdrop-blur-md border-r border-slate-100">
        <div className="relative">
          <Bell className="h-5 w-5 text-orange-600" />
          <motion.span 
            animate={{ scale: [1, 1.5, 1], opacity: [1, 0, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="absolute -top-1 -right-1 w-2 h-2 bg-orange-500 rounded-full"
          />
        </div>
        <span className="text-[10px] font-black uppercase tracking-widest text-slate-900 whitespace-nowrap">Latest News</span>
      </div>
      
      {/* Gradient Fades */}
      <div className="absolute inset-y-0 left-48 w-20 bg-gradient-to-r from-white/80 to-transparent z-10 pointer-events-none" />
      <div className="absolute inset-y-0 right-0 w-20 bg-gradient-to-l from-white/80 to-transparent z-10 pointer-events-none" />

      <div className="flex overflow-hidden">
        <motion.div 
          animate={{ x: [0, -1000] }}
          transition={{ 
            duration: 30, 
            repeat: Infinity, 
            ease: "linear" 
          }}
          className="flex gap-16 whitespace-nowrap pl-56"
        >
          {notices.map((notice, i) => (
            <div key={i} className="flex items-center gap-4 group/item">
              <div className="w-2 h-2 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.5)]" />
              <span className="text-sm font-black text-slate-700 uppercase tracking-wide group-hover/item:text-orange-600 transition-colors">
                {notice.title}
              </span>
            </div>
          ))}
          {/* Duplicate for seamless loop */}
          {notices.map((notice, i) => (
            <div key={`dup-${i}`} className="flex items-center gap-4 group/item">
              <div className="w-2 h-2 rounded-full bg-orange-500 shadow-[0_0_8px_rgba(249,115,22,0.5)]" />
              <span className="text-sm font-black text-slate-700 uppercase tracking-wide group-hover/item:text-orange-600 transition-colors">
                {notice.title}
              </span>
            </div>
          ))}
        </motion.div>
      </div>
    </motion.div>
  );
};

const MouseScrollIcon = () => (
  <motion.div
    initial={{ opacity: 0, y: -10 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 1, delay: 1 }}
    className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 hidden lg:flex"
  >
    <div className="w-6 h-10 rounded-full border-2 border-orange-500/30 flex justify-center p-1">
      <motion.div
        animate={{ y: [0, 12, 0] }}
        transition={{ duration: 1.5, repeat: Infinity, ease: "easeInOut" }}
        className="w-1.5 h-1.5 rounded-full bg-orange-500"
      />
    </div>
    <span className="text-[10px] font-black uppercase tracking-[0.2em] text-orange-500/50">Scroll</span>
  </motion.div>
);

const CompactHTMLAdRenderer = ({ htmlCode }: { htmlCode: string }) => {
  const iframeRef = React.useRef<HTMLIFrameElement>(null);

  useEffect(() => {
    if (iframeRef.current && htmlCode) {
      const doc = iframeRef.current.contentDocument || iframeRef.current.contentWindow?.document;
      if (doc) {
        doc.open();
        doc.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <meta charset="utf-8">
              <style>
                body {
                  margin: 0;
                  padding: 0;
                  display: flex;
                  justify-content: center;
                  align-items: center;
                  background-color: transparent;
                  overflow: hidden;
                }
              </style>
            </head>
            <body>
              ${htmlCode}
            </body>
          </html>
        `);
        doc.close();
      }
    }
  }, [htmlCode]);

  return (
    <div className="w-full flex justify-center bg-white/5 p-2 rounded-xl border border-white/10 min-h-[100px] relative overflow-hidden">
      <iframe
        ref={iframeRef}
        title="Sponsor Banner ad"
        className="w-full min-h-[90px] border-0"
        style={{ width: "100%", height: "100%", border: "none" }}
        sandbox="allow-scripts allow-popups allow-popups-to-escape-sandbox allow-same-origin"
      />
    </div>
  );
};

const DynamicAdComponent = () => {
  return (
    <div className="my-6 p-4 md:p-8 bg-gradient-to-br from-orange-600 via-orange-500 to-amber-500 rounded-[2rem] text-white shadow-xl relative overflow-hidden border border-orange-400/30">
      <div className="absolute top-0 right-0 w-80 h-80 bg-white/10 rounded-full translate-x-1/4 -translate-y-1/4 blur-2xl pointer-events-none animate-pulse" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-amber-400/20 rounded-full -translate-x-1/4 translate-y-1/4 blur-2xl pointer-events-none" />
      
      <div className="relative z-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="bg-white/20 p-4 rounded-3xl backdrop-blur-md border border-white/20">
            <Heart className="h-8 w-8 text-white animate-pulse fill-white" />
          </div>
          <div>
            <span className="text-xs text-orange-100 font-extrabold uppercase tracking-widest block mb-1">আমাদের গর্বিত পার্টনার</span>
            <h3 className="text-2xl md:text-3xl font-black tracking-tight text-white leading-tight">
              Official Sponsors
            </h3>
          </div>
        </div>
        <Link 
          to="/sponsors" 
          className="px-6 py-3.5 bg-white text-orange-600 hover:bg-orange-50 rounded-2xl font-black text-sm uppercase tracking-widest shadow-lg shadow-orange-900/20 transition-all cursor-pointer hover:-translate-y-1 active:scale-95 text-center flex items-center gap-2"
        >
          View All Sponsors & Partners <ArrowRight className="w-4 h-4" />
        </Link>
      </div>
    </div>
  );
};

const HtmlAdSponsorships = () => {
  const { data: rawSponsors } = useRealtimeCollection('sponsorships', [
    where("status", "==", "active"),
    orderBy("order_index", "asc")
  ]);

  const [htmlAds, setHtmlAds] = useState<any[]>([]);

  useEffect(() => {
    if (!rawSponsors) return;
    const ads = rawSponsors.filter((s: any) => 
      s.banner_type === 'html' && 
      s.html_code && 
      !((s.brand_name || '').toLowerCase().includes('adsterra')) &&
      !((s.html_code || '').toLowerCase().includes('adsterra'))
    );
    setHtmlAds(ads);
  }, [rawSponsors]);

  if (htmlAds.length === 0) return null;

  const doubledAds = [...htmlAds, ...htmlAds];

  return (
    <div className="py-10 bg-white shadow-sm border border-slate-100 overflow-hidden relative w-full mb-12 rounded-none">
      <div className="w-full mb-8 text-center px-4">
        <h3 className="text-2xl md:text-3xl font-black text-slate-800 tracking-tight">
          Sponsored <span className="text-orange-500">Advertisements</span>
        </h3>
        <p className="text-slate-500 font-medium mt-2 text-sm">Supporting the future of mathematics excellence</p>
      </div>
      <div className="flex overflow-hidden relative w-full py-2">
        <motion.div
          animate={{ x: ["0%", "-50%"] }}
          transition={{
            duration: 40,
            repeat: Infinity,
            ease: "linear",
          }}
          className="flex gap-8 items-center shrink-0 pr-8"
        >
          {doubledAds.map((ad, i) => (
            <div key={ad.id + '-' + i} className="flex-shrink-0 w-[300px] md:w-[400px] bg-white/50 backdrop-blur-sm p-3 rounded-[2rem] border border-slate-100/50 shadow-sm flex items-center justify-center overflow-hidden hover:bg-white/80 transition-colors">
              <CompactHTMLAdRenderer htmlCode={ad.html_code} />
            </div>
          ))}
        </motion.div>
      </div>
    </div>
  );
};

const Home = () => {
  const { settings } = useSettings();
  const { data: programs } = useRealtimeCollection('programs');

  return (
    <div className="overflow-hidden bg-gradient-to-br from-orange-50/20 via-white to-amber-50/15 relative">
      {/* Background covering/overlay decorations matching notice.html system design globally */}
      <div className="absolute inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-[8%] right-[-5%] w-[35rem] h-[35rem] bg-orange-600/[0.03] animate-morph-blob-1" />
        <div className="absolute top-[35%] left-[-10%] w-[30rem] h-[30rem] bg-rose-600/[0.025] animate-morph-blob-2" />
        <div className="absolute top-[65%] right-[-8%] w-[32rem] h-[32rem] bg-amber-600/[0.03] animate-morph-blob-1" />
        <div className="absolute bottom-[5%] left-[5%] w-[28rem] h-[28rem] bg-orange-500/[0.025] animate-morph-blob-2" />
        {/* Subtle radial gradients from notice-section::before */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(249,115,22,0.03),transparent_25%),radial-gradient(circle_at_80%_80%,rgba(217,119,6,0.03),transparent_25%)]" />
      </div>

      {/* Hero Section */}
      <section className="relative min-h-[70vh] lg:min-h-[85vh] flex items-center pt-8 md:pt-12 lg:pt-16 pb-10 lg:pb-16 overflow-hidden">
        {/* Background Decorative Elements - Removed animate-pulse for performance */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none hidden md:block">
          <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-orange-500/10 rounded-full blur-[100px]" />
          <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-rose-500/10 rounded-full blur-[100px]" />
          <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-blue-500/5 rounded-full blur-[80px]" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-10 lg:gap-24 items-center">
            <div className="space-y-6 text-center lg:text-left">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
                className="space-y-4"
              >
                <div className="flex flex-wrap items-center justify-center lg:justify-start gap-3">
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-orange-100 text-orange-600 text-[10px] md:text-xs font-bold uppercase tracking-widest border border-orange-200/50 shadow-sm">
                    <Sparkles className="h-4 w-4" />
                    <span>{settings.hero_badge_text || "THE FUTURE OF MATH EDUCATION"}</span>
                  </div>
                </div>
                
                <h1 className="font-black leading-tight tracking-tight text-slate-900 text-center lg:text-left">
                  <div className="relative inline-flex flex-col items-center lg:items-start group">
                    <div className="relative">
                      <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-600 via-rose-600 to-orange-600 mb-1 whitespace-nowrap text-[2.2rem] min-[360px]:text-[2.6rem] min-[400px]:text-[3.1rem] min-[440px]:text-[3.5rem] sm:text-6xl md:text-[4.5rem] lg:text-7xl xl:text-[5rem] font-black leading-[1.15] pb-4 inline-block overflow-visible tracking-tighter shadow-sm animate-fade-in">
                        {settings.site_name || "Jaber Math Care"}
                      </span>
                      {/* Animated Underline */}
                      <motion.div 
                        className="absolute bottom-3 left-0 h-1.5 bg-gradient-to-r from-orange-500 to-rose-500 rounded-full"
                        initial={{ width: 0 }}
                        animate={{ width: "100%" }}
                        transition={{ duration: 1.2, delay: 0.5, ease: "circOut" }}
                      />
                    </div>
                  </div>
                </h1>
                
                <div className="flex flex-col lg:flex-row items-center lg:items-center gap-4 lg:gap-8">
                  <div className="order-2 lg:order-1 flex-1">
                    <p className="text-xs sm:text-base md:text-lg text-orange-600 max-w-xl mx-auto lg:mx-0 leading-relaxed font-bold text-center lg:text-left drop-shadow-sm">
                      {settings.hero_subtitle || "Where mathematical excellence meets engineering dreams, shaping the innovators of tomorrow."}
                    </p>
                  </div>
                  
                  <motion.div 
                    animate={{ 
                      y: [0, -10, 0],
                      rotate: [0, 5, -5, 0],
                      scale: [1, 1.05, 1]
                    }}
                    transition={{ 
                      duration: 3, 
                      repeat: Infinity, 
                      ease: "easeInOut" 
                    }}
                    className="order-1 lg:order-2 text-orange-600 drop-shadow-[0_15px_30px_rgba(249,115,22,0.4)] shrink-0 z-20 pointer-events-none relative"
                  >
                    <SquareRadical className="h-14 w-14 sm:h-18 sm:w-18 lg:h-28 lg:w-28 border-none" strokeWidth={2.5} />
                    <motion.div
                      animate={{ opacity: [0.1, 1, 0.1], scale: [0.8, 1.2, 0.8] }}
                      transition={{ duration: 1.8, repeat: Infinity }}
                      className="absolute -top-2 -right-5 sm:-right-7 lg:-right-10 text-orange-400"
                    >
                      <Star className="h-5 w-5 sm:h-6 sm:w-6 lg:h-8 lg:w-8 fill-current" />
                    </motion.div>
                  </motion.div>
                </div>
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="space-y-4 max-w-md mx-auto lg:mx-0"
              >
                <div className="flex gap-4">
                  <Link to="/programs" className="flex-1 bg-orange-600 text-white px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl shadow-orange-600/20 flex items-center justify-center gap-2 group active:scale-95">
                    Programs
                    <GraduationCap className="h-4 w-4" />
                  </Link>
                  <Link to="/contact" className="flex-1 bg-white text-slate-900 px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-50 transition-all shadow-lg border border-slate-200 flex items-center justify-center gap-2 active:scale-95">
                    Contact Us
                    <Phone className="h-4 w-4" />
                  </Link>
                </div>
                
                <div className="hidden lg:block">
                  <Link to={settings.jaber_tube_link || "/video-library"} className="w-full bg-orange-600 text-white px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl shadow-orange-600/20 flex items-center justify-center gap-2 group active:scale-95">
                    {settings.jaber_tube_text || "Jaber Math Care Tube"}
                    <Youtube className="h-5 w-5 group-hover:scale-110 transition-transform" />
                  </Link>
                </div>
              </motion.div>
              
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.5 }}
                className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 pt-6 md:pt-8"
              >
                {[
                  { icon: Calendar, label: "Schedule", path: "/schedule" },
                  { icon: BarChart2, label: "Results", path: "/results" },
                  { icon: PlayCircle, label: "Recorded Classes", path: "/recorded-classes" },
                  { icon: Zap, label: "Sponsor Pricing", path: "/sponsorship" }
                ].map((item, i) => (
                  <Link 
                    key={i}
                    to={item.path}
                    className="flex flex-col items-center gap-2 max-md:gap-1.5 p-4 md:p-6 rounded-[2rem] bg-white/50 hover:bg-white border border-white/50 hover:border-orange-200 transition-all group shadow-sm hover:shadow-md"
                  >
                    <div className="w-10 h-10 md:w-14 md:h-14 rounded-2xl bg-orange-50 flex items-center justify-center text-orange-600 group-hover:scale-110 transition-transform">
                      <item.icon className="h-5 w-5 md:h-7 md:w-7" />
                    </div>
                    <span className="text-[10px] md:text-[12px] font-black uppercase tracking-widest text-slate-500 group-hover:text-orange-600 text-center leading-tight">{item.label}</span>
                  </Link>
                ))}
              </motion.div>

              {/* Scrolling news ticker placed perfectly below the 4 boxes */}
              <div className="pt-4">
                <ScrollingNotices />
              </div>
            </div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1, type: "spring" }}
              className="relative mt-1.5 sm:mt-6 lg:mt-0 lg:scale-[1.05] xl:scale-[1.1] lg:translate-x-16 xl:translate-x-24 mx-auto lg:mx-0 flex justify-center items-center z-0 w-fit h-fit"
            >
              {/* Rotating Rings - Light & Optimized for performance */}
              <motion.div 
                className="absolute inset-[-12px] sm:inset-[-25px] lg:inset-[-40px] xl:inset-[-50px] rounded-full border-[4px] sm:border-[6px] border-dashed border-orange-500/60 shadow-[0_0_30px_rgba(249,115,22,0.2)] z-0 transform-gpu"
                animate={{ rotate: 360 }}
                transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
              />
              <motion.div 
                className="absolute inset-[-22px] sm:inset-[-45px] lg:inset-[-70px] xl:inset-[-90px] rounded-full border-[3px] sm:border-[4px] border-dotted border-rose-500/40 shadow-[0_0_20px_rgba(244,63,94,0.1)] z-0 transform-gpu"
                animate={{ rotate: -360 }}
                transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
              />
              <div 
                className="absolute inset-[-40px] lg:inset-[-65px] xl:inset-[-85px] rounded-full bg-gradient-to-tr from-orange-400/10 to-rose-400/10 blur-[60px] z-[-1] animate-pulse pointer-events-none hidden md:block"
              />
              
              <div className="relative z-10 glass p-2 lg:p-3 rounded-[3.8rem] md:rounded-[4.8rem] border border-white/80 shadow-2xl bg-white/40 backdrop-blur-md overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-tr from-orange-500/15 to-rose-500/15 opacity-0 group-hover:opacity-100 transition-opacity duration-700" />
                <img 
                  src={settings.hero_image || "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512"} 
                  alt="Hero" 
                  className="w-[280px] sm:w-[320px] md:w-[400px] lg:w-[460px] xl:w-[500px] aspect-square rounded-[3.5rem] md:rounded-[4.5rem] shadow-2xl transform group-hover:scale-[1.01] transition-all duration-700 object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
            </motion.div>
          </div>
        </div>
        <MouseScrollIcon />
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <DynamicAdComponent />
      </div>

      <FeaturedSlider />

      <WebLinksSection />
      
      <div className="w-full mt-4 mb-4">
        <ECommerceBannerSlider />
      </div>

      {/* Stats Section */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="py-10 relative overflow-hidden"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
            {[
              { label: settings.stat_1_label || "Success Rate", value: settings.stat_1_value || "95%", icon: Award, color: "orange", gradient: "from-orange-50 to-white" },
              { label: settings.stat_2_label || "Expert Mentors", value: settings.stat_2_value || "4+", icon: GraduationCap, color: "blue", gradient: "from-blue-50 to-white" },
              { label: settings.stat_3_label || "Study Materials", value: settings.stat_3_value || "500+", icon: BookOpen, color: "emerald", gradient: "from-emerald-50 to-white" },
              { label: settings.stat_4_label || "Math Labs", value: settings.stat_4_value || "Online", icon: FlaskConical, color: "rose", gradient: "from-rose-50 to-white" }
            ].map((stat, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -6, scale: 1.03 }}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className={`relative overflow-hidden p-6 lg:py-10 lg:px-8 xl:py-12 xl:px-10 rounded-[2rem] lg:rounded-[3rem] bg-white border border-slate-100 shadow-xl shadow-slate-200/40 group text-center transform transition-all duration-500`}
              >
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.gradient} opacity-40 group-hover:opacity-100 transition-opacity duration-500`} />
                <div className="relative z-10 animate-fade-in-up">
                  <div className={`w-14 h-14 lg:w-20 lg:h-20 mx-auto rounded-2xl lg:rounded-[1.8rem] bg-white shadow-lg flex items-center justify-center mb-4 lg:mb-6 group-hover:scale-110 group-hover:rotate-12 transition-all duration-500 text-${stat.color}-600 border border-slate-50`}>
                    <stat.icon className="h-7 w-7 lg:h-10 lg:w-10" />
                  </div>
                  <div className="text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-black text-slate-900 mb-1 tracking-tighter">{stat.value}</div>
                  <div className="text-[9px] lg:text-xs font-black text-slate-400 uppercase tracking-[0.2em]">{stat.label}</div>
                </div>
                
                {/* Decorative Element */}
                <div className={`absolute -right-6 -bottom-6 w-32 h-32 bg-${stat.color}-500/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-1000`} />
              </motion.div>
            ))}
          </div>

          {/* Mobile Jaber Tube Button */}
          <div className="mt-8 flex justify-center lg:hidden px-4">
            <Link to={settings.jaber_tube_link || "/video-library"} className="w-full sm:w-auto bg-orange-600 text-white px-6 py-3.5 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl shadow-orange-600/20 flex items-center justify-center gap-2 group active:scale-95">
              {settings.jaber_tube_text || "Jaber Math Care Tube"}
              <Youtube className="h-5 w-5 group-hover:scale-110 transition-transform" />
            </Link>
          </div>
        </div>
      </motion.section>

      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="py-10 md:py-14 relative bg-white"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-20 space-y-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="inline-block px-4 py-2 rounded-full bg-slate-100 text-slate-600 text-xs font-black uppercase tracking-widest"
            >
              Our Excellence
            </motion.div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-orange-600 tracking-tighter leading-none whitespace-nowrap">
              Why Choose Us
            </h2>
            <p className="text-slate-500 font-medium text-lg">
              We provide a comprehensive learning ecosystem designed for success.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              { icon: Users, title: "Expert Teachers", desc: "Learn from highly qualified educators with years of teaching experience.", color: "orange" },
              { icon: BookOpen, title: "Proven Curriculum", desc: "Structured learning path with comprehensive study materials and practice sets.", color: "blue" },
              { icon: Award, title: "Regular Exams", desc: "Weekly and monthly assessments to ensure continuous improvement.", color: "emerald" },
              { icon: BarChart2, title: "Progress Tracking", desc: "Regular assessments and detailed progress reports to monitor improvement.", color: "rose" },
              { icon: User, title: "Personal Care", desc: "Individual attention to every student's needs for better understanding.", color: "purple" },
              { icon: Zap, title: "Interactive Classes", desc: "Engaging learning environment with real-world examples and experiments.", color: "amber" },
              { icon: Info, title: "Doubt Clearing", desc: "Dedicated sessions to solve every query instantly and effectively.", color: "indigo" },
              { icon: PlayCircle, title: "Digital Resources", desc: "Access to recorded lectures and PDF notes 24/7 from anywhere.", color: "cyan" },
              { icon: Magnet, title: "Conceptual Clarity", desc: "Deep dive into math concepts to build a strong foundation.", color: "orange" }
            ].map((feature, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="group relative p-10 rounded-[3rem] bg-slate-50 hover:bg-white border border-transparent hover:border-orange-100 transition-all duration-500 hover:shadow-2xl hover:shadow-orange-900/5"
              >
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-8 shadow-lg group-hover:scale-110 transition-transform duration-500 bg-${feature.color}-100 text-${feature.color}-600`}>
                  <feature.icon className="h-8 w-8" />
                </div>
                <h4 className="text-2xl font-black text-slate-900 mb-4 tracking-tight group-hover:text-orange-600 transition-colors">{feature.title}</h4>
                <p className="text-slate-600 font-medium leading-relaxed">{feature.desc}</p>
                
                <div className="absolute top-8 right-8 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className={`w-2 h-2 rounded-full bg-${feature.color}-500 animate-ping`} />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </motion.section>



      {/* Reviews Section */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="py-6 md:py-8 bg-slate-50/50 overflow-hidden"
      >
        <HtmlAdSponsorships />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="inline-block px-4 py-2 rounded-full bg-orange-100 text-orange-600 text-xs font-black uppercase tracking-widest"
            >
              Testimonials
            </motion.div>
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-black text-orange-600 tracking-tighter leading-none">
              What Our Students Say
            </h2>
            <p className="text-slate-500 font-medium text-lg">
              Real stories from students who have transformed their math journey with us.
            </p>
          </div>

          <div className="w-full mb-12">
            <StudentReviewsGrid />
          </div>

          <div className="flex justify-center mt-16">
            <Link 
              to="/reviews" 
              className="glass px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest text-slate-900 border border-white/60 shadow-xl hover:bg-white/60 transition-all flex items-center gap-3 group"
            >
              View All Reviews
              <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>
        </div>
      </motion.section>

      <BlogSection />

      {/* CTA Section */}
      <motion.section 
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="py-10 md:py-14"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="glass p-12 md:p-12 lg:p-20 rounded-[4rem] border border-white/60 shadow-[0_32px_64px_-12px_rgba(249,115,22,0.2)] bg-gradient-to-br from-orange-600 to-rose-600 text-center text-white relative overflow-hidden"
          >
            <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')]" />
            <div className="relative z-10 max-w-3xl mx-auto space-y-10">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-black tracking-tighter leading-tight">
                Ready to Excel in Mathematics? <br />
                Join Us <span className="text-orange-200">Today!</span>
              </h2>
              <p className="text-xl text-orange-100 font-medium">
                Join thousands of successful students and master mathematics with expert guidance. Start your journey towards academic excellence now.
              </p>
              <div className="flex flex-wrap justify-center gap-6">
                <Link 
                  to="/contact" 
                  className="bg-white text-orange-600 px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-orange-50 transition-all shadow-2xl hover:scale-105 active:scale-95 flex items-center gap-3"
                >
                  Contact Us Now
                  <ArrowRight className="h-5 w-5" />
                </Link>
                <Link 
                  to="/programs" 
                  className="bg-black/20 backdrop-blur-md text-white border border-white/30 px-10 py-5 rounded-2xl font-black text-sm uppercase tracking-widest hover:bg-black/30 transition-all flex items-center gap-3"
                >
                  View Programs
                </Link>
              </div>
            </div>
          </motion.div>
        </div>
      </motion.section>
      <FloatingNoticePopup />
    </div>
  );
};

export default Home;
