import React from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, FileText, Ban, RefreshCw, Clock } from 'lucide-react';
import { useSettings } from '../context/SettingsContext';

const RefundPolicy = () => {
  const { settings } = useSettings();
  const siteName = settings?.site_name || "Jaber Math Care";

  return (
    <div className="min-h-screen pt-4 md:pt-8 pb-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-16"
        >
          <div className="inline-flex p-4 rounded-full bg-orange-100 text-orange-600 mb-6">
            <ShieldAlert size={40} />
          </div>
          <h1 className="section-title">Refund Policy</h1>
          <p className="section-subtitle">
            Please read our refund policy carefully before making any purchases/enrollments.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-slate-200 space-y-8 text-slate-700 leading-relaxed"
        >
          {settings.refund_policy_content ? (
            <div className="space-y-6">
              {settings.refund_policy_content.split(/\n+/).filter(Boolean).map((p: string, idx: number) => {
                // Formatting heading starts with '#'
                if (p.trim().startsWith('#')) {
                  const headingText = p.trim().replace(/^#+\s*/, '');
                  return (
                    <h2 key={idx} className="text-2xl font-black text-slate-900 pt-4 border-b border-orange-100 pb-2 flex items-center gap-2">
                       <FileText className="text-orange-600 h-6 w-6 shrink-0" /> {headingText}
                    </h2>
                  );
                }

                // Formatting sections starting with digits
                const sectionMatch = p.trim().match(/^(\d+(?:\.\d+)*\.*)\s*(.*)/);
                if (sectionMatch) {
                  // Determine appropriate icon for sections of refund policy helper
                  const isSpecialSec = sectionMatch[2].toLowerCase().includes("refund");
                  return (
                    <section key={idx} className={`space-y-3 pt-2 ${isSpecialSec ? "shadow-sm p-6 rounded-2xl border border-orange-100 bg-orange-50/30" : ""}`}>
                      <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                        {isSpecialSec ? (
                          <Ban className="text-orange-600 h-5 w-5 shrink-0" />
                        ) : (
                          <FileText className="text-orange-600 h-5 w-5 shrink-0" />
                        )}
                        {sectionMatch[1]} {sectionMatch[2]}
                      </h2>
                    </section>
                  );
                }

                // Subheadings or short lines
                if (p.trim().length < 60 && !p.trim().endsWith('.')) {
                  return (
                    <h3 key={idx} className="text-lg font-bold text-slate-900 pt-2 flex items-center gap-2">
                      <Clock className="text-orange-600 h-4 w-4 shrink-0" strokeWidth={2.5} /> {p.trim()}
                    </h3>
                  );
                }

                // Normal Paragraphs
                return (
                  <p key={idx} className="text-slate-600 leading-relaxed text-sm sm:text-base">
                    {p.trim()}
                  </p>
                );
              })}
            </div>
          ) : (
            <>
              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                  <FileText className="text-orange-600" /> 1. Welcome
                </h2>
                <p>
                  Welcome to {siteName}. Thank you for showing interest in our courses. We want you to have a great positive experience through purchasing our various courses and materials.
                </p>
              </section>

              <section className="space-y-4 shadow-sm p-6 rounded-2xl border border-orange-100 bg-orange-50/30">
                <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                  <Ban className="text-orange-600" /> 2. Refund Policy
                </h2>
                <p className="font-semibold text-slate-800">
                  After purchasing our courses, no refunds are given for any reason, whether online or offline. If there are any problems with the course, we will try to resolve them, but money will not be refunded.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                  <RefreshCw className="text-orange-600" /> 3. Course Exchange Policy
                </h2>
                <p>
                  We also do not exchange courses. Once a course is purchased, it cannot be changed or exchanged with another course. We do not encourage any service exchange of our courses.
                </p>
              </section>

              <section className="space-y-4">
                <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                  <Clock className="text-orange-600" /> 4. Refund Processing Timeline
                </h2>
                <p>
                  Although we generally do not provide refunds, if a refund is approved under special circumstances by management, it may take 7 to 10 business days to process.
                </p>
                <p>
                  Thank you for understanding our policy.
                </p>
              </section>
            </>
          )}

          <div className="pt-8 border-t border-slate-100 text-sm text-slate-500 text-center uppercase tracking-wider font-bold">
            Last Updated: June 9, 2026
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default RefundPolicy;
