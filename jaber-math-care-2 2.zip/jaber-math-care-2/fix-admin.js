import fs from 'fs';
let content = fs.readFileSync('src/pages/AdminDashboard.tsx', 'utf8');
content = content.replace(/\(user as any\)\?\.isActualModerator/g, 'user?.role === "moderator"');
fs.writeFileSync('src/pages/AdminDashboard.tsx', content);
