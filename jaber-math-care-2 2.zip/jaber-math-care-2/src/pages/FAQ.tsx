import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus, Languages } from 'lucide-react';
import PageTransition from '../components/PageTransition';

type Language = 'en' | 'bn';

const faqsData = {
  en: [
    {
      question: "What is Jaber Math Care?",
      answer: "Jaber Math Care is a premium Mathematics Academy designed to help students achieve top-tier academic success through conceptual clarity and advanced problem-solving techniques."
    },
    {
      question: "Do you offer online classes?",
      answer: "Yes! We offer fully featured online courses with live Zoom classes, recorded video libraries, and digital study materials accessible via our student dashboard."
    },
    {
      question: "How do I enroll in a course?",
      answer: "You can browse our available offline and online courses from the 'Courses' section and enroll directly online, or visit our physical campus for offline admissions."
    },
    {
      question: "Is there any refund policy?",
      answer: "Yes, you can read about our specific class and enrollment refund conditions on our Refund Policy page located at the bottom menu."
    },
    {
      question: "Can I access recorded classes if I miss a live session?",
      answer: "Absolutely. All live classes are recorded and uploaded to the 'Recorded Classes' section of your student dashboard within 24 hours of the session."
    },
    {
      question: "How can I check my exam results?",
      answer: "Once exams are evaluated, you can view your detailed exam results directly from the 'Results' section in the Student Dashboard."
    },
    {
      question: "Who can I contact for support?",
      answer: "You can find our support contact information, including phone numbers and email addresses, on the 'Contact Us' page or the 'Support Team' page."
    }
  ],
  bn: [
    {
      question: "জাবের ম্যাথ কেয়ার কী?",
      answer: "জাবের ম্যাথ কেয়ার একটি প্রিমিয়াম গণিত একাডেমি, যা শিক্ষার্থীদের ধারণাগুলোকে স্পষ্ট করে এবং উন্নত সমস্যা সমাধানের কৌশলের মাধ্যমে উচ্চমানের একাডেমিক সাফল্য অর্জনে সহায়তা করার জন্য প্রতিষ্ঠিত হয়েছে।"
    },
    {
      question: "আপনারা কি অনলাইন ক্লাস করান?",
      answer: "হ্যাঁ! আমরা সম্পূর্ণ সুবিধাযুক্ত অনলাইন কোর্স অফার করি, যার মধ্যে রয়েছে লাইভ জুম ক্লাস, রেকর্ড করা ভিডিও লাইব্রেরি এবং স্টুডেন্ট ড্যাশবোর্ড থেকে অ্যাক্সেসযোগ্য ডিজিটাল স্টাডি ম্যাটেরিয়াল।"
    },
    {
      question: "আমি কীভাবে কোর্সে ভর্তি হবো?",
      answer: "আপনি 'কোর্স' বিভাগ থেকে আমাদের বর্তমান অফলাইন এবং অনলাইন কোর্সগুলো দেখতে পারেন ও সরাসরি অনলাইনে ভর্তি হতে পারেন, অথবা অফলাইনে ভর্তির জন্য আমাদের ফিজিক্যাল ক্যাম্পাসে ভিজিট করতে পারেন।"
    },
    {
      question: "বিকল্প টাকা ফেরতের কোনো নীতিমালা আছে কি?",
      answer: "হ্যাঁ, আপনি নিচের মেনুতে থাকা আমাদের রিফান্ড পলিসি পেজ থেকে ক্লাস ও ভর্তির টাকা ফেরত সংক্রান্ত নির্দিষ্ট শর্তাবলী সম্পর্কে পড়তে পারবেন।"
    },
    {
      question: "লাইভ ক্লাস মিস করলে কি রেকর্ডেড ক্লাস দেখা যাবে?",
      answer: "অবশ্যই। প্রতিটি লাইভ ক্লাস রেকর্ড করা হয় এবং সেশন শেষ হওয়ার ২৪ ঘণ্টার মধ্যে আপনার স্টুডেন্ট ড্যাশবোর্ডের 'রেকর্ডেড ক্লাস' বিভাগে আপলোড করা হয়।"
    },
    {
      question: "আমি আমার পরীক্ষার ফলাফল কীভাবে দেখব?",
      answer: "পরীক্ষার খাতা মূল্যায়ন করা হয়ে গেলে, আপনি সরাসরি আপনার স্টুডেন্ট ড্যাশবোর্ডের 'ফলাফল' বা 'Results' বিভাগ থেকে আপনার বিস্তারিত ফলাফল দেখতে পারবেন।"
    },
    {
      question: "যোগাযোগ বা সাপোর্ট এর জন্য কার সাথে কথা বলবো?",
      answer: "আপনি 'যোগাযোগ করুন' (Contact Us) অথবা 'সাপোর্ট টিম' (Support Team) পেজ থেকে আমাদের সাপোর্ট টিমের ফোন নম্বর এবং ইমেইল ঠিকানা সহ যোগাযোগের তথ্য পেতে পারেন।"
    }
  ]
};

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const [lang, setLang] = useState<Language>('en');

  const faqs = faqsData[lang];

  return (
    <PageTransition>
      <div className="min-h-screen pt-12 pb-16 px-4">
        <div className="max-w-3xl mx-auto space-y-12">
          
          <div className="flex justify-end">
            <button
              onClick={() => setLang(lang === 'en' ? 'bn' : 'en')}
              className="px-4 py-2 bg-gradient-to-r from-orange-600 to-orange-500 text-white rounded-full font-medium flex items-center gap-2 hover:opacity-90 transition-opacity shadow-sm"
            >
              <Languages className="w-4 h-4" />
              {lang === 'en' ? 'বাংলা রূপান্তর' : 'Translate to English'}
            </button>
          </div>

          <div className="text-center space-y-4">
            <h1 className="text-4xl md:text-5xl font-black tracking-tight text-slate-900 dark:text-white">
              {lang === 'en' ? 'Frequently Asked' : 'সচরাচর জিজ্ঞাসিত'} <span className="text-orange-600">{lang === 'en' ? 'Questions' : 'প্রশ্নসমূহ'}</span>
            </h1>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              {lang === 'en' 
                ? 'Find answers to common questions about our courses, admissions, and platform features.'
                : 'আমাদের কোর্স, ভর্তি ও প্ল্যাটফর্মের সুবিধাগুলো সম্পর্কে সাধারণ প্রশ্নের উত্তর খুঁজুন।'}
            </p>
          </div>

          <div className="space-y-4">
            {faqs.map((faq, index) => {
              const isOpen = openIndex === index;
              return (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  key={index}
                  className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden"
                >
                  <button
                    onClick={() => setOpenIndex(isOpen ? null : index)}
                    className="w-full flex items-center justify-between p-6 text-left focus:outline-none focus:ring-2 focus:ring-orange-600 focus:ring-inset"
                  >
                    <span className="text-lg font-bold text-slate-900 dark:text-white pr-8">
                      {faq.question}
                    </span>
                    <div className={`p-2 rounded-full border transition-colors ${isOpen ? 'bg-orange-600 border-orange-600 text-white' : 'border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400'}`}>
                      {isOpen ? <Minus className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                    </div>
                  </button>
                  
                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                      >
                        <div className="px-6 pb-6 text-slate-600 dark:text-slate-400 leading-relaxed">
                          {faq.answer}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
          
        </div>
      </div>
    </PageTransition>
  );
}
