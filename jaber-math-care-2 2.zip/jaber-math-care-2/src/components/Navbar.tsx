import React, { useState, useEffect, memo } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { Menu, X, LogOut, User, LogIn, ChevronRight, Mail, Phone, Play, Bell } from 'lucide-react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';

const Navbar = memo(() => {
  const { user, logout } = useAuth();
  const { settings } = useSettings();
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (!user?.id) return;
    const q = query(
      collection(db, 'notifications'),
      where('user_id', '==', user.id),
      where('is_read', '==', false)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setUnreadCount(snapshot.docs.length);
    });
    return () => unsubscribe();
  }, [user?.id]);

  useEffect(() => {
    if (isOpen) {
      const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
      document.body.style.paddingRight = `${scrollbarWidth}px`;
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
      document.body.style.paddingRight = '0px';
    }
    return () => {
      document.body.style.overflow = 'unset';
      document.body.style.paddingRight = '0px';
    };
  }, [isOpen]);

  const links: { name: string; path: string; isSpecial?: boolean; isRed?: boolean; hideDesktop?: boolean }[] = [
    { name: 'Home', path: '/' },
    { name: 'About', path: '/about' },
    { name: 'Programs', path: '/programs' },
    { name: 'Course', path: '/online-courses' },
    { name: 'Class', path: '/recorded-classes' },
    { name: 'Schedule', path: '/schedule' },
    { name: 'Notices', path: '/notices' },
    { name: 'Results', path: '/results' },
    { name: 'Contact', path: '/contact' },
  ];

  return (
    <>
      <nav 
        className="fixed top-4 left-1/2 -translate-x-1/2 z-50 shadow-[0_8px_32px_rgba(249,115,22,0.2)] w-[calc(100%-0.75rem)] sm:w-[calc(100%-1.5rem)] lg:w-[calc(100%-2rem)] max-w-[1400px] rounded-2xl bg-orange-600/95 backdrop-blur-md border border-white/20 py-2"
      >
        <div className="px-3 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-14 sm:h-16">
            {/* Logo */}
            <div className="flex-shrink-0 mr-auto lg:mr-4">
              <Link 
                to="/" 
                className="flex items-center space-x-2 group"
              >
                <div className="h-10 w-10 sm:h-11 sm:w-11 bg-white p-1 rounded-2xl flex items-center justify-center shadow-lg border border-orange-200/30 overflow-hidden group-hover:scale-110 transition-transform duration-300">
                  <img 
                    src={settings.logo_url || "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512"} 
                    alt="Logo" 
                    className="w-full h-full object-contain" 
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512";
                    }}
                  />
                </div>
                <div className="flex flex-col">
                  <span className="text-xl sm:text-2xl font-black text-white leading-none tracking-tighter drop-shadow-md whitespace-nowrap">
                    {settings.site_name || "Jaber Math Care"}
                  </span>
                </div>
              </Link>
            </div>

            {/* Desktop Menu */}
            <div className="hidden lg:flex flex-1 justify-end px-1 lg:px-2 lg:ml-2">
              <div className="flex items-center space-x-1.5 bg-white/10 backdrop-blur-md p-1.5 rounded-[15px] border border-white/10 shadow-inner whitespace-nowrap">
                {links.filter(l => !l.hideDesktop).map((link) => (
                  <div key={link.name}>
                    <Link
                      to={link.path}
                      onClick={(e) => {
                        if (location.pathname === link.path) {
                          e.preventDefault();
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }
                      }}
                      className={`px-1.5 xl:px-3 py-2 rounded-xl text-[10.5px] xl:text-[12px] font-black uppercase tracking-wide whitespace-nowrap flex items-center gap-1 transition-all duration-300 ${
                        link.isRed
                          ? 'bg-red-500 text-white hover:bg-red-600 shadow-lg shadow-red-500/20'
                          : link.isSpecial 
                            ? 'bg-white/20 text-white hover:bg-white/30 border border-white/20' 
                            : location.pathname === link.path
                              ? 'bg-white text-orange-600 shadow-lg scale-105'
                              : 'text-white/95 hover:bg-white/20 hover:text-white'
                      }`}
                    >
                      {link.isSpecial && <Play className="h-3 w-3 fill-current" />}
                      {link.name}
                    </Link>
                  </div>
                ))}
              </div>
            </div>

            {/* Dashboard/Logout/Login */}
            <div className="hidden lg:flex items-center gap-2 ml-2">
              {user ? (
                <>
                  <Link
                    to={user.role === 'admin' || user.role === 'moderator' ? '/admin' : '/dashboard'}
                    className="bg-white/20 text-white px-5 py-2 rounded-xl text-[11px] lg:text-[12px] font-black uppercase tracking-wider transition-all backdrop-blur-md border border-white/20 hover:bg-white/30 hover:scale-105 active:scale-95 shadow-lg whitespace-nowrap"
                  >
                    Dashboard
                  </Link>
                  <button
                    onClick={logout}
                    className="bg-orange-700/50 hover:bg-orange-850/50 text-white border border-white/20 p-2.5 rounded-xl transition-all shadow-lg backdrop-blur-sm group flex-shrink-0"
                    title="Logout"
                  >
                    <LogOut className="h-4.5 w-4.5 group-hover:scale-110 transition-transform" />
                  </button>
                </>
              ) : (
                <Link
                  to="/login"
                  className="bg-white text-orange-600 px-5 lg:px-6 py-2 rounded-xl text-[11px] lg:text-[12px] font-black uppercase tracking-widest hover:bg-orange-50 shadow-[0_0_20px_rgba(255,255,255,0.4)] hover:shadow-[0_0_30px_rgba(255,255,255,0.6)] hover:scale-105 active:scale-95 transition-all flex items-center gap-1.5 md:gap-2 border-2 border-white whitespace-nowrap"
                >
                  <LogIn className="h-4.5 w-4.5" /> Login
                </Link>
              )}
            </div>

            {/* Mobile Auth Icons */}
            <div className="flex lg:hidden items-center ml-4">
              {/* Mobile menu button - Far Right */}
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="relative p-2.5 rounded-xl cursor-pointer hover:bg-white/10 transition-all z-[100]"
              >
                <div className="flex flex-col justify-center items-center">
                  <span className={`block w-[25px] h-[2px] bg-white my-[2.5px] rounded-[2px] transition-all duration-300 origin-center ${isOpen ? 'rotate-45 translate-x-[5px] translate-y-[5px]' : ''}`} />
                  <span className={`block w-[25px] h-[2px] bg-white my-[2.5px] rounded-[2px] transition-all duration-300 ${isOpen ? 'opacity-0 -translate-x-[20px]' : ''}`} />
                  <span className={`block w-[25px] h-[2px] bg-white my-[2.5px] rounded-[2px] transition-all duration-300 origin-center ${isOpen ? '-rotate-[45deg] translate-x-[7px] -translate-y-[6px]' : ''}`} />
                </div>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Menu */}
      {isOpen && (() => {
        const hasUser = !!user;
        const containerPadding = 'p-3 sm:p-4';
        const containerSpaceY = 'space-y-1 sm:space-y-1.5';
        const linkPadding = 'px-3.5 py-2 sm:py-2.5 rounded-[12px]';
        // Precise consistent sizes for both states to avoid scrolling and overflow
        const linkFontSize = 'text-[13px] sm:text-[14px]';
        const linkMargin = 'mx-1 my-0.5 sm:my-1';
        const bottomPadding = 'p-3 sm:p-4';
        const bottomGap = 'gap-1.5 sm:gap-2';
        const buttonPadding = 'px-3.5 py-2 sm:py-2.5 rounded-xl';
        const buttonFontSize = 'text-[13px] sm:text-[14px]';
        
        return (
          <div className="fixed inset-0 z-40 xl:hidden flex justify-center items-start pt-[104px] sm:pt-[112px] pb-4 px-4">
            <div
              onClick={() => setIsOpen(false)}
              className="absolute inset-0 bg-black/40 backdrop-blur-sm"
            />
            <div
              className="relative w-[85vw] max-w-[300px] sm:max-w-[360px] md:max-w-[420px] bg-orange-600/98 backdrop-blur-xl rounded-[1.5rem] md:rounded-[2rem] shadow-2xl flex flex-col border border-white/20 overflow-hidden z-50 animate-in fade-in zoom-in duration-300 h-auto max-h-[82vh] sm:max-h-[85vh]"
            >
              <div className={`flex-grow overflow-y-auto ${containerPadding} ${containerSpaceY} text-center scrollbar-hide`}>
                {links.map((link) => (
                  <div key={link.name}>
                    <Link
                      to={link.path}
                      onClick={(e) => {
                        setIsOpen(false);
                        if (location.pathname === link.path) {
                          e.preventDefault();
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }
                      }}
                      className={`flex items-center justify-center ${linkPadding} ${linkFontSize} font-black uppercase tracking-widest transition-all ${
                        location.pathname === link.path
                          ? `bg-white text-orange-600 shadow-xl ${linkMargin}`
                          : link.isSpecial 
                            ? `bg-white/20 text-white border border-white/20 ${linkMargin}`
                            : `text-white/90 hover:bg-white/20 hover:text-white ${linkMargin}`
                      }`}
                    >
                      {link.isSpecial && <Play className="h-3 w-3 mr-1.5 fill-current" />}
                      {link.name}
                    </Link>
                  </div>
                ))}
              </div>
              
              <div className={`${bottomPadding} border-t border-white/10 bg-black/20 flex flex-col ${bottomGap} shrink-0`}>
                {user ? (
                  <>
                    <Link
                      to={user.role === 'admin' || user.role === 'moderator' ? '/admin' : '/dashboard'}
                      onClick={() => setIsOpen(false)}
                      className={`w-full flex items-center justify-center gap-2 bg-white text-orange-600 ${buttonPadding} ${buttonFontSize} font-black uppercase tracking-widest shadow-xl hover:scale-105 transition-all`}
                    >
                      <User className="h-3.5 w-3.5 sm:h-4 sm:w-4" /> Dashboard
                    </Link>
                    <button
                      onClick={() => {
                        logout();
                        setIsOpen(false);
                      }}
                      className={`w-full flex items-center justify-center gap-2 bg-orange-600 text-white border-2 border-white/20 ${buttonPadding} ${buttonFontSize} font-black uppercase tracking-widest hover:bg-orange-700 transition-all shadow-xl`}
                    >
                      <LogOut className="h-3.5 w-3.5 sm:h-4 sm:w-4" /> Logout
                    </button>
                  </>
                ) : (
                  <Link
                    to="/login"
                    onClick={() => setIsOpen(false)}
                    className={`w-full flex items-center justify-center gap-2 bg-white text-orange-600 ${buttonPadding} ${buttonFontSize} font-black uppercase tracking-widest shadow-xl hover:scale-105 transition-all`}
                  >
                    <LogIn className="h-3.5 w-3.5 sm:h-4 sm:w-4" /> Login
                  </Link>
                )}
              </div>
            </div>
          </div>
        );
      })()}
    </>
  );
});

export default Navbar;
