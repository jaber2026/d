import React, { useState, useMemo, useEffect } from 'react';
import { useRealtimeCollection } from '../../hooks/useRealtime';
import { useAuth } from '../../context/AuthContext';
import { 
  Play, Search, Folder, Calendar, Video, Clock, X, Eye, 
  ChevronDown, ChevronUp, PlayCircle, BookOpen, ExternalLink, HelpCircle,
  FileText, Lock, Award, ChevronRight
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const StudentRecorded = () => {
  const { user, token } = useAuth();
  const [enrollments, setEnrollments] = useState<any[]>([]);

  useEffect(() => {
    if (token) {
      fetch(`/api/my-enrollments?t=${Date.now()}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(data => {
        if (!data.error) setEnrollments(Array.isArray(data) ? data : []);
      })
      .catch(console.error);
    }
  }, [token]);

  const isOnlineStudent = useMemo(() => {
    if (!user) return false;
    if (user.role === 'admin' || user.role === 'moderator') return true;
    if (user.student_type === 'online' || !!user.course_id || (Array.isArray(user.enrolled_courses) && user.enrolled_courses.length > 0)) return true;
    if (enrollments.some(e => e.status === 'approved' || e.status === 'contacted')) return true;
    return false;
  }, [user, enrollments]);

  // Fetch both so we can serve whichever one is needed
  const { data: studyMaterials, loading: studyLoading } = useRealtimeCollection('study_materials');
  const { data: videoClasses, loading: videoLoading } = useRealtimeCollection('video_classes');
  const { data: courses } = useRealtimeCollection('courses');

  const [searchQuery, setSearchQuery] = useState('');
  const [activeVideo, setActiveVideo] = useState<any | null>(null);
  const [expandedPlaylists, setExpandedPlaylists] = useState<Record<string, boolean>>({});
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);

  const studentCourses = useMemo(() => {
    if (!courses || !user) return [];
    if (user.role === 'admin' || user.role === 'moderator') return courses;
    
    let enrolledIDs = new Set<string>();
    if (user.course_id) enrolledIDs.add(String(user.course_id));
    if (Array.isArray(user.enrolled_courses)) {
      user.enrolled_courses.forEach(c => {
        const cid = typeof c === 'object' && c !== null ? (c.course_id || c.id) : c;
        if (cid) enrolledIDs.add(String(cid));
      });
    }

    enrollments.forEach(e => {
       if ((e.status === 'approved' || e.status === 'contacted') && e.course_id) {
           enrolledIDs.add(String(e.course_id));
       }
    });
    
    return courses.filter((c: any) => enrolledIDs.has(String(c.id)));
  }, [courses, user, enrollments]);

  const activeCourse = useMemo(() => {
    if (!courses || courses.length === 0) return null;
    if (selectedCourseId) {
      const match = courses.find((c: any) => String(c.id) === String(selectedCourseId));
      if (match) return match;
    }
    return null;
  }, [courses, selectedCourseId]);

  const activeCourseName = useMemo(() => {
    return activeCourse ? activeCourse.title : 'Final Gear 2.0 : HSC - 26 (100% Free)';
  }, [activeCourse]);

  // Helper to extract YouTube ID
  const getYoutubeId = (url: string) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  // Format date helper
  const formatDate = (val: any) => {
    if (!val) return 'N/A';
    let date: Date;
    if (typeof val === 'object' && val.seconds !== undefined) {
      date = new Date(val.seconds * 1000);
    } else if (typeof val === 'string') {
      date = new Date(val);
    } else if (val instanceof Date) {
      date = val;
    } else if (typeof val === 'number') {
      date = new Date(val);
    } else {
      return 'N/A';
    }
    return isNaN(date.getTime()) ? 'N/A' : date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  // ==========================================
  // ONLINE VIEW: Groups videos + notes together
  // ==========================================
  const onlineGroupedPlaylists = useMemo(() => {
    if (!isOnlineStudent || !studyMaterials) return [];

    const filtered = studyMaterials.filter((item: any) => {
      // 1. Search query
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q ? true : (
        item.title?.toLowerCase().includes(q) ||
        item.playlist?.toLowerCase().includes(q)
      );

      if (!matchesSearch) return false;

      // 2. Admin/Moderator full access
      if (user?.role === 'admin' || user?.role === 'moderator') {
        return true;
      }

      // 3. Selectivity checking
      const userProgramId = user?.program_id ? String(user.program_id) : '';
      const userBatchId = user?.batch_id ? String(user.batch_id) : '';
      const userBatchId2 = user?.batch_id_2 ? String(user.batch_id_2) : '';
      const userCourseId = user?.course_id ? String(user.course_id) : '';
      const userCourses = user?.enrolled_courses || [];

      const pid = item.program_id ? String(item.program_id) : '';
      const bid = item.batch_id ? String(item.batch_id) : '';
      const cid = item.course_id ? String(item.course_id) : '';

      // General
      if (!pid && !bid && !cid) {
        return true;
      }

      if (pid && pid !== 'all' && pid.toUpperCase() !== 'ALL') {
        if (userProgramId !== pid) return false;
      }

      if (bid && bid !== 'all' && bid.toUpperCase() !== 'ALL') {
        if (userBatchId !== bid && userBatchId2 !== bid) return false;
      }

      if (cid && cid !== 'all' && cid.toUpperCase() !== 'ALL') {
        if (selectedCourseId && cid !== selectedCourseId) return false;
        const hasAccess = userCourseId === cid || userCourses.some((c: any) => 
          typeof c === 'string' ? String(c) === cid : String(c.id) === cid
        );
        if (!hasAccess) return false;
      }
      
      // If a course is selected and the video isn't specifically mapped to this course (and isn't explicitly 'all'), decide if it should show.
      // Usually, if we view a specific course, we ONLY want that course's materials.
      if (selectedCourseId && cid !== selectedCourseId) {
         if (!cid || cid === 'all' || cid.toUpperCase() === 'ALL') {
            // It's a general material. If user wants strictly course materials, we should hide it.
            return false;
         }
      }

      return true;
    });

    const groups: { [key: string]: any[] } = {};
    filtered.forEach((item: any) => {
      const playlistName = (item.playlist || "General Classes").trim();
      if (!groups[playlistName]) {
        groups[playlistName] = [];
      }
      groups[playlistName].push(item);
    });

    return Object.entries(groups).map(([name, items]) => {
      // Sort items inside this playlist/chapter: prioritize serial/order or creation order
      const sortedItems = [...items].sort((a, b) => {
        if (a.serial_no !== undefined && b.serial_no !== undefined) {
          return Number(a.serial_no) - Number(b.serial_no);
        }
        if (a.order !== undefined && b.order !== undefined) {
          return Number(a.order) - Number(b.order);
        }
        const tA = a.created_at ? new Date(a.created_at).getTime() : (a.timestamp ? new Date(a.timestamp).getTime() : 0);
        const tB = b.created_at ? new Date(b.created_at).getTime() : (b.timestamp ? new Date(b.timestamp).getTime() : 0);
        if (tA !== tB) return tA - tB; // asc (first added first)
        return (a.title || "").localeCompare(b.title || "", undefined, { numeric: true, sensitivity: 'base' });
      });

      return {
        name,
        items: sortedItems
      };
    }).sort((a, b) => {
      return a.name.localeCompare(b.name, undefined, { numeric: true, sensitivity: 'base' });
    });
  }, [studyMaterials, searchQuery, user, isOnlineStudent, selectedCourseId]);

  // ==========================================
  // OFFLINE VIEW: Videos from Jaber Tube (video_classes)
  // ==========================================
  const offlineVideosList = useMemo(() => {
    if (isOnlineStudent || !videoClasses) return [];

    return videoClasses.filter((item: any) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch = !q ? true : (
        item.title?.toLowerCase().includes(q) ||
        item.description?.toLowerCase().includes(q)
      );

      if (!matchesSearch) return false;

      if (user?.role === 'admin' || user?.role === 'moderator') {
        return true;
      }

      const userProgramId = user?.program_id ? String(user.program_id) : '';
      const userBatchId = user?.batch_id ? String(user.batch_id) : '';
      const userBatchId2 = user?.batch_id_2 ? String(user.batch_id_2) : '';
      const userCourseId = user?.course_id ? String(user.course_id) : '';

      const pid = item.program_id ? String(item.program_id) : '';
      const bid = item.batch_id ? String(item.batch_id) : '';
      const cid = item.course_id ? String(item.course_id) : '';

      const isGeneral = !pid && !bid && !cid;
      if (isGeneral) return true;

      if (cid && cid.toUpperCase() !== 'ALL') {
        if (userCourseId === cid) {
          return !bid || userBatchId === bid || userBatchId2 === bid;
        }
        return false;
      }

      if (pid && pid.toUpperCase() !== 'ALL') {
        if (userProgramId === pid) {
          return !bid || userBatchId === bid || userBatchId2 === bid;
        }
        return false;
      }

      if (bid && bid.toUpperCase() !== 'ALL') {
        return userBatchId === bid || userBatchId2 === bid;
      }

      return true;
    }).sort((a, b) => {
      // Newest first
      const tA = a.created_at ? (a.created_at.seconds ? a.created_at.seconds * 1000 : new Date(a.created_at).getTime()) : 0;
      const tB = b.created_at ? (b.created_at.seconds ? b.created_at.seconds * 1000 : new Date(b.created_at).getTime()) : 0;
      return tB - tA;
    });
  }, [videoClasses, searchQuery, user, isOnlineStudent]);

  // Handle default automatic selected video on initial load
  useEffect(() => {
    if (isOnlineStudent) {
      if (onlineGroupedPlaylists.length > 0 && !activeVideo) {
        const firstPlaylist = onlineGroupedPlaylists[0];
        const firstVideo = firstPlaylist.items.find((i: any) => i.type === 'video');
        if (firstVideo) {
          setActiveVideo(firstVideo);
          setExpandedPlaylists(prev => ({
            ...prev,
            [firstPlaylist.name]: true
          }));
        }
      }
    } else {
      if (offlineVideosList.length > 0 && !activeVideo) {
        setActiveVideo(offlineVideosList[0]);
      }
    }
  }, [onlineGroupedPlaylists, offlineVideosList, isOnlineStudent, activeVideo]);

  const togglePlaylist = (name: string) => {
    setExpandedPlaylists(prev => ({
      ...prev,
      [name]: prev[name] === false ? true : false
    }));
  };

  const currentLoading = isOnlineStudent ? studyLoading : videoLoading;

  return (
    <div className="w-full space-y-6 animate-in fade-in duration-500">
      
      {/* ----------------- HEADER AREA ----------------- */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-4 border-b border-slate-100">
        {isOnlineStudent ? (
          <div>
            <h1 className="text-3xl font-black text-orange-600 tracking-tight flex items-center gap-3">
              Recorded Class
            </h1>
            <p className="text-slate-500 font-bold mt-2 text-sm md:text-base">
              আপনার অনলাইন কোর্সের সকল রেকর্ডকৃত ক্লাস ও ক্লাস নোট চ্যাপ্টার অনুযায়ী নিচে সাজানো রয়েছে।
            </p>
          </div>
        ) : (
          <div className="w-full text-center md:text-left">
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-block"
            >
              <h1 className="text-4xl md:text-5xl font-black tracking-tighter flex flex-row items-center gap-2 md:gap-3 justify-center md:justify-start">
                <span className="text-slate-900">Jaber</span>
                <span className="bg-orange-600 text-white px-5 py-1.5 rounded-[2rem] shadow-xl shadow-orange-600/20 transform -rotate-1 text-2xl md:text-3xl">Tube</span>
              </h1>
              <p className="text-slate-500 font-black mt-2 text-xs uppercase tracking-[0.2em]">Watch your ad-free class recordings anytime</p>
            </motion.div>
          </div>
        )}

        {/* Generic Search Input */}
        <div className="relative w-full md:w-80 shrink-0">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
          <input
            type="text"
            placeholder={isOnlineStudent ? "ক্লাস বা চ্যাপ্টার খুঁজুন..." : "Search recorded classes..."}
            className="w-full pl-12 pr-4 py-3 bg-white border border-slate-200 rounded-2xl shadow-sm focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all font-bold text-slate-700"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* ----------------- RENDER STATES ----------------- */}
      {isOnlineStudent && !selectedCourseId ? (
        <div className="w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {studentCourses.map(course => (
              <div 
                key={course.id} 
                onClick={() => setSelectedCourseId(String(course.id))}
                className="group cursor-pointer bg-white rounded-3xl border border-slate-200 shadow-sm hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 overflow-hidden flex flex-col sm:flex-row relative"
              >
                <div className="w-full sm:w-2/5 aspect-[4/3] sm:aspect-auto sm:h-auto shrink-0 relative overflow-hidden bg-slate-100">
                  <img 
                    src={course.image || course.thumbnail || "https://ui-avatars.com/api/?name=" + encodeURIComponent(course.title) + "&background=ea580c&color=fff"} 
                    alt={course.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" 
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/60 to-transparent sm:hidden" />
                </div>
                <div className="p-6 md:p-8 flex flex-col flex-1 justify-center bg-white relative">
                  <span className="text-[10px] font-black uppercase tracking-widest text-orange-600 mb-2.5">
                    Enrolled Course
                  </span>
                  <h3 className="text-xl md:text-2xl font-black text-slate-900 leading-tight mb-3 group-hover:text-orange-600 transition-colors">
                    {course.title}
                  </h3>
                  <div className="text-sm font-bold text-slate-500 mb-6 line-clamp-2 md:line-clamp-3 leading-relaxed">
                    {course.description || "Access all your recorded classes, study materials, and guidelines for this course."}
                  </div>
                  <div className="mt-auto flex items-center justify-between">
                     {course.created_at ? (
                       <span className="text-xs text-slate-400 font-bold flex items-center gap-1">
                         <Calendar className="h-4 w-4" /> Added {formatDate(course.created_at)}
                       </span>
                     ) : (
                       <span />
                     )}
                     <button className="flex items-center gap-2 bg-slate-900/5 group-hover:bg-orange-600 group-hover:text-white text-slate-800 px-5 py-2.5 rounded-xl font-black text-[11px] uppercase tracking-wider transition-all shadow-sm border border-slate-200 group-hover:border-orange-500">
                       Go To Course <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                     </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {studentCourses.length === 0 && (
            <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-200">
              <Folder className="h-16 w-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-xl font-black text-slate-700 mb-2">No Enrolled Courses</h3>
              <p className="text-slate-500 font-bold text-sm">You are not currently enrolled in any online courses.</p>
            </div>
          )}
        </div>
      ) : currentLoading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
          <p className="text-slate-500 font-bold">লোড হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন...</p>
        </div>
      ) : (isOnlineStudent && selectedCourseId !== null && onlineGroupedPlaylists.length === 0) || (!isOnlineStudent && offlineVideosList.length === 0) ? (
        <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-200 relative">
          {isOnlineStudent && selectedCourseId && (
            <button 
              onClick={() => setSelectedCourseId(null)} 
              className="absolute top-6 left-6 flex items-center gap-2 bg-slate-100 hover:bg-slate-200 text-slate-600 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest transition-colors"
            >
              <X className="h-4 w-4" /> Back
            </button>
          )}
          <Folder className="h-16 w-16 text-slate-300 mx-auto mb-4 animate-bounce" />
          <h3 className="text-xl font-black text-slate-700 mb-2">কোনো রেকর্ডকৃত ক্লাস বা মেটেরিয়াল পাওয়া যায়নি।</h3>
          <p className="text-slate-500 font-bold text-sm">অনুগ্রহ করে পরে আবার চেষ্টা করুন বা অন্য সার্চ কি-ওয়ার্ড দিন।</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-slate-900 rounded-[2.5rem] overflow-hidden shadow-2xl border border-slate-800 flex flex-col relative">
              <div className="w-full h-[320px] sm:h-[420px] md:h-[500px] lg:h-[540px] relative bg-slate-950">
                {activeVideo ? (
                  <iframe
                    src={`https://www.youtube.com/embed/${getYoutubeId(activeVideo.url)}?autoplay=0&rel=0&modestbranding=1`}
                    title={activeVideo.title}
                    className="absolute inset-0 w-full h-full border-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  ></iframe>
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center text-slate-400 p-8 text-center bg-slate-950">
                    <Video className="h-16 w-16 text-slate-700 mb-4 animate-pulse" />
                    <p className="font-extrabold text-lg text-slate-300">কোনো ভিডিও নির্বাচিত নেই</p>
                    <p className="text-xs text-slate-500 mt-1 max-w-sm">ডানপাশের তালিকা থেকে যেকোনো ক্লাস প্লে করতে ক্লিক করুন।</p>
                  </div>
                )}
              </div>

              {activeVideo && (
                <div className="p-6 md:p-8 bg-white border-t border-slate-100 text-left">
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    <span className="px-2.5 py-1 bg-gradient-to-r from-orange-500 to-rose-500 text-white rounded-xl text-[10px] font-black uppercase tracking-wider shadow-sm">
                      ACTIVE LESSON
                    </span>
                    {activeVideo.playlist && (
                      <span className="bg-orange-50 text-orange-700 border border-orange-100 px-3 py-1 rounded-full text-xs font-bold">
                        📁 {activeVideo.playlist}
                      </span>
                    )}
                  </div>
                  <h2 className="text-xl md:text-2xl font-black text-slate-900 leading-tight">
                    {activeVideo.title}
                  </h2>
                  <div className="flex flex-wrap items-center gap-4 text-slate-500 text-xs font-bold pt-4 mt-4 border-t border-slate-100">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-4 w-4 text-slate-400" /> আপলোড ডেট: {formatDate(activeVideo.created_at || activeVideo.createdAt)}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>

           {/* RIGHT VIEW: Differentiated based on student_type */}
          <div className="lg:col-span-4 h-full flex flex-col gap-4">
            {isOnlineStudent && (
              <button 
                onClick={() => setSelectedCourseId(null)} 
                className="w-full flex items-center justify-center gap-2 bg-white hover:bg-slate-50 text-slate-700 p-3.5 rounded-2xl text-xs font-black uppercase tracking-widest transition-colors shadow-sm border border-slate-200"
              >
                <ChevronDown className="h-4 w-4 rotate-90" /> Back to My Courses
              </button>
            )}
            
            {isOnlineStudent ? (
              /* ========================================================
                 ONLINE STUDENT ACCORDION (Videos and Notes in play list)
                 ======================================================== */
               <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xl overflow-hidden flex flex-col max-h-[700px]">
                 {/* Header containing course content title */}
                 <div className="bg-gradient-to-r from-orange-500 via-orange-600 to-amber-500 text-white p-5 flex items-center gap-4">
                   <div className="p-2.5 bg-white/20 text-white rounded-xl shadow-md border border-white/20 shrink-0">
                     <BookOpen className="h-5 w-5" />
                   </div>
                   <div className="text-left min-w-0">
                     <h3 className="font-extrabold text-lg tracking-wide leading-none text-white">কোর্স কন্টেন্ট</h3>
                     <p className="text-[11px] text-orange-50 font-medium mt-1.5 truncate leading-tight">{activeCourseName}</p>
                   </div>
                 </div>

                 {/* Playlist list */}
                 <div className="flex-1 overflow-y-auto p-4 space-y-3.5 max-h-[580px] scrollbar-hide">
                   {onlineGroupedPlaylists.map((playlist, idx) => {
                     const isExpanded = expandedPlaylists[playlist.name] !== false;
                     return (
                       <div key={playlist.name} className="border border-slate-200 rounded-2xl overflow-hidden shadow-sm transition-all duration-300 bg-slate-50/20">
                         <button
                           onClick={() => togglePlaylist(playlist.name)}
                           className={`w-full flex items-center justify-between p-4 font-bold text-left transition-colors ${
                             isExpanded ? 'bg-orange-50 border-b border-orange-100 text-orange-850' : 'bg-white text-slate-800 hover:bg-orange-50/30'
                           }`}
                         >
                           <div className="flex items-center gap-3">
                             <span className="w-8 h-8 rounded-full bg-orange-600 text-white flex items-center justify-center font-extrabold text-xs shadow-md shrink-0">
                               {String(idx + 1).padStart(2, '0')}
                             </span>
                             <div className="flex flex-col text-left">
                               <span className="text-sm font-black text-slate-800 line-clamp-1 leading-snug">{playlist.name}</span>
                               <span className="text-[10px] text-slate-400 font-bold mt-0.5">{playlist.items.length} ফাইল / ভিডিও</span>
                             </div>
                           </div>
                           {isExpanded ? <ChevronUp className="h-5 w-5 text-slate-400" /> : <ChevronDown className="h-5 w-5 text-slate-400" />}
                         </button>

                         <AnimatePresence initial={false}>
                           {isExpanded && (
                             <motion.div
                               initial={{ height: 0 }}
                               animate={{ height: "auto" }}
                               exit={{ height: 0 }}
                               className="overflow-hidden bg-white/90 p-3 space-y-2"
                             >
                               {playlist.items.map((item: any, itemIdx: number) => {
                                 const isVideo = item.type === "video";
                                 const isCurrent = isVideo && (activeVideo?.id === item.id || activeVideo?.url === item.url);

                                 return (
                                   <button
                                     key={item.id || itemIdx}
                                     onClick={() => {
                                       if (isVideo) {
                                         setActiveVideo(item);
                                       } else {
                                         window.open(item.url, '_blank');
                                       }
                                     }}
                                     className={`w-full flex items-center justify-between p-3 rounded-xl border text-left transition-all relative ${
                                       isCurrent 
                                         ? 'border-orange-500 bg-orange-50/40 text-orange-600 shadow-sm' 
                                         : 'border-slate-100 bg-white hover:border-slate-300 text-slate-700 shadow-sm hover:shadow-md'
                                     }`}
                                   >
                                     <div className="flex items-center gap-3 min-w-0">
                                       <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 shadow-sm ${
                                         isVideo 
                                           ? 'bg-red-500 text-white shadow-red-500/10'
                                           : 'bg-violet-600 text-white shadow-violet-600/10'
                                       }`}>
                                         {isVideo ? (
                                           <Play className="h-3.5 w-3.5 fill-current ml-0.5" />
                                         ) : (
                                           <FileText className="h-4.5 w-4.5" />
                                         )}
                                       </div>
                                       <div className="space-y-0.5 min-w-0">
                                         <p className="text-xs font-extrabold text-slate-800 line-clamp-1 leading-snug">
                                           {item.title}
                                         </p>
                                         {!isVideo && (
                                           <span className="text-[9px] font-extrabold text-violet-500 uppercase tracking-widest flex items-center gap-1">
                                             ক্লাস নোট
                                           </span>
                                         )}
                                       </div>
                                     </div>
                                     <div className="shrink-0 pl-2">
                                       <ChevronDown className="h-4 w-4 text-slate-300 rotate-270" />
                                     </div>
                                   </button>
                                 );
                               })}
                             </motion.div>
                           )}
                         </AnimatePresence>
                       </div>
                     );
                   })}
                 </div>

                 <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs font-bold text-slate-500">
                   <div className="flex items-center gap-1.5 text-slate-700 font-extrabold">
                     <BookOpen className="h-4 w-4 text-slate-400" />
                     <span>মোট অধ্যায়: {onlineGroupedPlaylists.length}</span>
                   </div>
                   <div className="flex items-center gap-1.5 bg-orange-50 border border-orange-100 text-orange-600 font-extrabold rounded-full px-3.5 py-1.5 text-[11px] uppercase tracking-wide">
                     <Award className="h-3 w-3 text-orange-500 fill-current" />
                     কোর্স কন্টেন্ট
                   </div>
                 </div>
               </div>
            ) : (
              /* ========================================================
                 OFFLINE STUDENT UP NEXT PLAYLIST (Sourced from Jaber Tube)
                 ======================================================== */
              <div className="bg-white rounded-3xl border border-slate-200 shadow-md overflow-hidden sticky top-6">
                <div className="p-5 border-b border-slate-100 bg-slate-50/50">
                  <h3 className="font-black text-slate-800 flex items-center justify-between">
                    <span>Up Next</span>
                    <span className="text-xs font-bold bg-orange-100 text-orange-600 px-2.5 py-0.5 rounded-full">
                      {offlineVideosList.length} Classes
                    </span>
                  </h3>
                </div>

                <div className="max-h-[580px] overflow-y-auto p-3 space-y-3 scrollbar-hide">
                  <AnimatePresence mode="popLayout">
                    {offlineVideosList.map((video) => {
                      const videoId = video.youtube_id || getYoutubeId(video.url);
                      const isSelected = activeVideo?.id === video.id;
                      return (
                        <motion.button
                          layout
                          key={video.id}
                          onClick={() => {
                            setActiveVideo(video);
                          }}
                          className={`w-full text-left flex gap-3 p-2 rounded-2xl transition-all group ${
                            isSelected 
                              ? 'bg-orange-50 ring-1 ring-orange-200' 
                              : 'hover:bg-slate-50'
                          }`}
                        >
                          <div className="relative w-28 aspect-video rounded-xl overflow-hidden shrink-0 bg-slate-100">
                            <img 
                              src={video.thumbnail || `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`} 
                              alt={video.title} 
                              className="w-full h-full object-cover"
                              referrerPolicy="no-referrer"
                            />
                            {isSelected && (
                              <div className="absolute inset-0 bg-orange-600/20 flex items-center justify-center">
                                <div className="bg-orange-600 text-white p-1 rounded-full shadow-lg">
                                  <PlayCircle className="h-4 w-4" />
                                </div>
                              </div>
                            )}
                          </div>
                          <div className="flex-1 min-w-0 py-1 text-left">
                            <h4 className={`font-bold text-xs line-clamp-2 leading-tight mb-1 ${
                              isSelected ? 'text-orange-700 font-extrabold' : 'text-slate-800'
                            }`}>
                              {video.title}
                            </h4>
                            <p className="text-[9px] font-bold text-slate-400 uppercase tracking-wider">
                              {formatDate(video.created_at)}
                            </p>
                          </div>
                        </motion.button>
                      );
                    })}
                  </AnimatePresence>
                </div>
              </div>
            )}
          </div>

        </div>
      )}

    </div>
  );
};

export default StudentRecorded;
