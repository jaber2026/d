import React, { useState, useMemo } from 'react';
import { useRealtimeCollection } from '../hooks/useRealtime';
import { Play, Search, Folder, Calendar, Video, Clock, X, Eye, Laptop } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useSettings } from '../context/SettingsContext';

const RecordedClasses = () => {
  const { settings } = useSettings();
  const { data: videoClasses, loading } = useRealtimeCollection('web_recorded_classes');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeVideo, setActiveVideo] = useState<any | null>(null);

  // Helper to extract YouTube ID
  const getYoutubeId = (url: string) => {
    if (!url) return null;
    // Standard and embed YouTube urls
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
    const match = url.match(regExp);
    if (match && match[2].length === 11) {
      return match[2];
    }
    // Also handle direct youtube key if passed instead of URL
    if (url.length === 11) return url;
    return null;
  };

  // Helper to get HQ YouTube thumbnail
  const getYoutubeThumbnail = (url: string) => {
    const videoId = getYoutubeId(url);
    if (videoId) {
      return `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`;
    }
    return 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&auto=format&fit=crop&q=60';
  };

  // Format date helper
  const formatDate = (val: any) => {
    if (!val) return 'N/A';
    let date: Date;
    if (typeof val === 'object' && val.seconds !== undefined) {
      date = new Date(val.seconds * 1000);
    } else if (typeof val === 'string') {
      date = new Date(val);
    } else if (val instanceof Date) {
      date = val;
    } else if (typeof val === 'number') {
      date = new Date(val);
    } else {
      return 'N/A';
    }
    return isNaN(date.getTime()) ? 'N/A' : date.toLocaleDateString('bn-BD', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  // Filter and group classes by playlist (title)
  const groupedPlaylists = useMemo(() => {
    const filtered = (videoClasses || []).filter((item: any) => {
      const q = searchQuery.toLowerCase().trim();
      if (!q) return true;
      return (
        item.title?.toLowerCase().includes(q) ||
        item.playlist?.toLowerCase().includes(q) ||
        item.description?.toLowerCase().includes(q)
      );
    });

    const groups: { [key: string]: any[] } = {};
    filtered.forEach((item: any) => {
      const playlistName = (item.playlist || "সংরক্ষিত ক্লাসসমূহ (Recorded Classes)").trim();
      if (!groups[playlistName]) {
        groups[playlistName] = [];
      }
      groups[playlistName].push(item);
    });

    // Convert to sorted array
    return Object.entries(groups).map(([name, videos]) => {
      // Sort videos in descending order of creation or title
      const sortedVideos = [...videos].sort((a, b) => {
        const timeA = a.created_at?.seconds || new Date(a.created_at).getTime() || 0;
        const timeB = b.created_at?.seconds || new Date(b.created_at).getTime() || 0;
        return timeB - timeA;
      });

      return {
        name,
        videos: sortedVideos
      };
    });
  }, [videoClasses, searchQuery]);

  return (
    <div className="min-h-screen pt-16 pb-20 px-4 sm:px-6 lg:px-8 bg-slate-50">
      <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500">
        
        {/* Page Top Header */}
        <div className="flex flex-col items-center justify-center text-center gap-6 pb-8 border-b border-slate-200">
          <div className="space-y-4">
            <h1 className="text-3xl md:text-5xl font-black text-orange-600 tracking-tight">
              Recorded Class
            </h1>
          </div>

          {/* Search Bar */}
          <div className="relative w-full max-w-md shrink-0">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400 focus-within:text-orange-500 transition-colors" />
            <input
              type="text"
              placeholder="ক্লাস বা অধ্যায় খুঁজুন..."
              className="w-full pl-12 pr-4 py-3.5 bg-white border border-slate-200 rounded-2xl shadow-sm focus:ring-2 focus:ring-orange-500/25 focus:border-orange-500 outline-none transition-all font-bold text-slate-700 text-center"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-24 gap-4">
            <div className="w-12 h-12 border-4 border-orange-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-slate-500 font-bold">ক্লাসগুলো লোড হচ্ছে, কিছু সময় দিন...</p>
          </div>
        ) : groupedPlaylists.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-200 shadow-sm">
            <Folder className="h-16 w-16 text-slate-300 mx-auto mb-4 animate-bounce" />
            <h3 className="text-xl font-black text-slate-700 mb-2">কোনো ক্লাস খুঁজে পাওয়া যায়নি</h3>
            <p className="text-slate-500 font-medium">আপনার খোঁজা বিষয়টি আমাদের প্লেলিস্টে এই মুহূর্তে নেই।</p>
          </div>
        ) : (
          <div className="space-y-16">
            {groupedPlaylists.map((playlist, playlistIdx) => (
              <motion.div
                key={playlist.name}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: playlistIdx * 0.08 }}
                className="space-y-6"
              >
                {/* Playlist Header Tag */}
                <div className="flex items-center gap-3 bg-white p-5 rounded-3xl border border-slate-100 shadow-sm">
                  <div className="p-2.5 bg-gradient-to-br from-orange-500 to-orange-600 text-white rounded-2xl shadow-md">
                    <Folder className="h-5 w-5 fill-current" />
                  </div>
                  <div className="flex flex-col md:flex-row md:items-center justify-between w-full gap-2">
                    <h2 className="text-xl md:text-2xl font-black text-slate-800 tracking-tight">
                      {playlist.name}
                    </h2>
                    <span className="bg-orange-50 text-orange-600 px-4 py-1.5 rounded-full text-xs font-black border border-orange-100 w-fit">
                      মোট ক্লাস: {playlist.videos.length} টি
                    </span>
                  </div>
                </div>

                {/* Grid of videos in this playlist */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                  {playlist.videos.map((vid: any, vidIdx: number) => {
                    return (
                      <motion.div
                        key={vid.id || vidIdx}
                        whileHover={{ y: -6 }}
                        className="bg-white rounded-3xl border border-slate-200/50 overflow-hidden shadow-xs hover:shadow-xl hover:border-orange-200 transition-all duration-300 flex flex-col group"
                      >
                        {/* Video Aspect Screen */}
                        <div 
                          className="aspect-video relative bg-slate-950 overflow-hidden cursor-pointer" 
                          onClick={() => setActiveVideo(vid)}
                        >
                          <img
                            src={getYoutubeThumbnail(vid.url || vid.youtube_id)}
                            alt={vid.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?w=600&auto=format&fit=crop&q=60';
                            }}
                          />
                          {/* Dark bottom gradient overlay */}
                          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80" />
                          
                          {/* Centered glass play button trigger */}
                          <div className="absolute inset-0 flex items-center justify-center">
                            <div className="w-14 h-14 bg-orange-600 text-white rounded-full flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-all duration-300">
                              <Play className="h-6 w-6 fill-current ml-1" />
                            </div>
                          </div>

                          {/* Free tag corner */}
                          <div className="absolute top-4 left-4 bg-emerald-500 text-white text-[10px] font-black uppercase tracking-wider px-2.5 py-1 rounded-md shadow-sm">
                            FREE CLASS
                          </div>
                        </div>

                        {/* Text Fields details */}
                        <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                          <div className="space-y-2">
                            <h3 className="font-extrabold text-slate-800 text-lg line-clamp-2 leading-snug group-hover:text-orange-600 transition-colors">
                              {vid.title}
                            </h3>
                            {vid.description && (
                              <p className="text-slate-500 font-semibold text-xs line-clamp-2 leading-relaxed">
                                {vid.description}
                              </p>
                            )}
                          </div>

                          <div className="flex items-center justify-between text-[11px] text-slate-400 font-bold border-t border-slate-100 pt-4 self-end w-full">
                            <span className="flex items-center gap-1.5 bg-slate-50 text-slate-500 px-3 py-1.5 rounded-full border border-slate-150">
                              <Calendar className="h-3.5 w-3.5" />
                              {formatDate(vid.created_at || vid.createdAt)}
                            </span>
                            <button
                              onClick={() => setActiveVideo(vid)}
                              className="text-orange-600 hover:text-orange-700 font-black tracking-wider uppercase text-[11px] flex items-center gap-1"
                            >
                              Watch Now <Eye className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>

      {/* Embedded Cinema Playback Player Modal */}
      <AnimatePresence>
        {activeVideo && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/85 backdrop-blur-md z-50 flex items-center justify-center p-4 md:p-8"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="bg-white rounded-[2rem] overflow-hidden shadow-2xl max-w-4xl w-full border border-slate-800 flex flex-col"
            >
              {/* Modal controls header */}
              <div className="flex items-center justify-between p-4 md:p-6 bg-slate-900 text-white border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 bg-orange-600 rounded text-xs font-black uppercase tracking-wider">FREE RECORDED CLASS</span>
                  {activeVideo.playlist && (
                    <span className="text-slate-400 text-xs font-semibold hidden md:inline">| {activeVideo.playlist}</span>
                  )}
                </div>
                <button
                  onClick={() => setActiveVideo(null)}
                  className="p-1.5 hover:bg-slate-850 text-slate-400 hover:text-white rounded-full transition-colors"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              {/* YouTube Responsive Frame */}
              <div className="aspect-video relative bg-black">
                <iframe
                  src={`https://www.youtube.com/embed/${getYoutubeId(vidUrl(activeVideo))}?autoplay=1&rel=0&modestbranding=1`}
                  title={activeVideo.title}
                  className="absolute inset-0 w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                ></iframe>
              </div>

              {/* Video descriptive lines */}
              <div className="p-6 md:p-8 space-y-4 bg-white text-left">
                <h2 className="text-xl md:text-2xl font-black text-slate-900 leading-tight">
                  {activeVideo.title}
                </h2>
                {activeVideo.description && (
                  <p className="text-slate-600 text-sm font-semibold leading-relaxed whitespace-pre-wrap max-h-32 overflow-y-auto pr-2">
                    {activeVideo.description}
                  </p>
                )}
                <div className="flex items-center gap-3 text-slate-500 text-xs font-bold pt-3 border-t border-slate-100">
                  <span className="flex items-center gap-1"><Calendar className="h-3.5 w-3.5" /> {formatDate(activeVideo.created_at || activeVideo.createdAt)}</span>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );

  // Safely extract video url or play ID
  function vidUrl(v: any) {
    return v.url || v.youtube_id || '';
  }
};

export default RecordedClasses;
