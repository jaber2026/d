import { db } from '../firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Bell, FileText, AlertCircle, Loader, Calendar, CheckCircle2, X, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const Notices = () => {
  const { user } = useAuth();
  const [notices, setNotices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedNotice, setSelectedNotice] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'all' | 'academic' | 'online'>('all');

  const filteredNotices = notices.filter(notice => {
    let isAllowed = false;
    if (user?.role === 'student') {
      // General audience filter
      const audienceMatch = !notice.target_audience || notice.target_audience === 'all' || notice.target_audience === user.student_type;
      
      // Check program
      const matchesProgram = !notice.program_id || notice.program_id === 'all' || String(notice.program_id) === String(user.program_id);
      
      // Check batch (allow all if unspecified, or check both batch_id and batch_id_2)
      const matchesBatch = !notice.batch_id || notice.batch_id === 'all' || notice.batch_id === '' || 
        String(notice.batch_id) === String(user.batch_id) || String(notice.batch_id) === String(user.batch_id_2);
        
      isAllowed = audienceMatch && matchesProgram && matchesBatch;
    } else if (user?.role === 'admin' || user?.role === 'moderator') {
      // Admins and moderators see everything
      isAllowed = true;
    } else {
      // Guests see only completely public notices (no specific batch, program or course restriction)
      isAllowed = !notice.batch_id && !notice.program_id && !notice.course_id;
    }

    if (!isAllowed) return false;

    if (activeTab === 'all') return true;
    const audience = notice.target_audience?.toLowerCase();
    if (activeTab === 'academic') return audience === 'academic' || audience === 'offline';
    return audience === 'online';
  });

  useEffect(() => {
    if (selectedNotice) {
      const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
      document.body.style.paddingRight = `${scrollbarWidth}px`;
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
      document.body.style.paddingRight = '0px';
    }
    return () => {
      document.body.style.overflow = 'unset';
      document.body.style.paddingRight = '0px';
    };
  }, [selectedNotice]);

  useEffect(() => {
    // Real-time listener for notices
    const q = query(collection(db, 'notices'), orderBy('created_at', 'desc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      // Robust sorting for different date formats
      const sortedData = [...data].sort((a: any, b: any) => {
        const timeA = new Date(a.created_at || a.createdAt || a.date || 0).getTime();
        const timeB = new Date(b.created_at || b.createdAt || b.date || 0).getTime();
        return timeB - timeA;
      });
      setNotices(sortedData);
      setLoading(false);
    }, (error) => {
      console.error('Notices real-time error:', error);
      // Fallback
      onSnapshot(collection(db, 'notices'), (s) => {
        setNotices(s.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        setLoading(false);
      });
    });

    return unsubscribe;
  }, []);

  const formatDate = (dateValue: any, options?: Intl.DateTimeFormatOptions) => {
    const defaultOptions: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric', year: 'numeric' };
    const opts = options || defaultOptions;
    if (!dateValue) return new Date().toLocaleDateString('en-US', opts);
    try {
      if (dateValue.seconds) {
        return new Date(dateValue.seconds * 1000).toLocaleDateString('en-US', opts);
      }
      const d = new Date(dateValue);
      if (isNaN(d.getTime())) return new Date().toLocaleDateString('en-US', opts);
      return d.toLocaleDateString('en-US', opts);
    } catch (e) {
      return new Date().toLocaleDateString('en-US', opts);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50/40 via-white to-amber-50/30 pt-4 md:pt-8 pb-20 relative overflow-hidden">
      {/* Background covering/overlay decorations matching notice.html design */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute top-[5%] right-[5%] w-[28rem] h-[28rem] bg-orange-600/[0.03] animate-morph-blob-1" />
        <div className="absolute bottom-[5%] left-[5%] w-[22rem] h-[22rem] bg-amber-600/[0.04] animate-morph-blob-2" />
        {/* Subtle radial gradients from notice-section::before */}
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(249,115,22,0.06),transparent_30%),radial-gradient(circle_at_80%_80%,rgba(217,119,6,0.06),transparent_30%)]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="section-title">Notice Board</h1>
          <p className="section-subtitle">
            Important announcements and updates for students.
          </p>
        </motion.div>

        <div className="flex justify-center gap-4 mb-12 flex-wrap">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('all')}
            className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${
              activeTab === 'all' ? 'bg-orange-600 text-white shadow-md' : 'bg-white text-slate-600 hover:bg-orange-50'
            }`}
          >
            All Notices
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('academic')}
            className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${
              activeTab === 'academic' ? 'bg-orange-600 text-white shadow-md' : 'bg-white text-slate-600 hover:bg-orange-50'
            }`}
          >
            Academic Students
          </motion.button>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setActiveTab('online')}
            className={`px-6 py-2 rounded-full font-bold text-sm transition-all ${
              activeTab === 'online' ? 'bg-orange-600 text-white shadow-md' : 'bg-white text-slate-600 hover:bg-orange-50'
            }`}
          >
            Online Students
          </motion.button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {loading ? (
            [1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="bg-white rounded-3xl p-6 border border-slate-100 shadow-lg h-64 animate-pulse">
                <div className="h-4 bg-slate-200 rounded w-1/3 mb-4"></div>
                <div className="h-6 bg-slate-200 rounded w-full mb-2"></div>
                <div className="h-4 bg-slate-200 rounded w-full mb-2"></div>
                <div className="h-4 bg-slate-200 rounded w-2/3"></div>
              </div>
            ))
          ) : filteredNotices.length === 0 ? (
            <motion.p 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="col-span-full text-center text-slate-500 py-20"
            >
              No notices found.
            </motion.p>
          ) : (
            filteredNotices.map((notice, index) => (
              <motion.div 
                key={notice.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="relative bg-gradient-to-br from-orange-500/[0.04] to-amber-500/[0.08] backdrop-blur-md rounded-2xl p-6 border border-orange-500/15 shadow-[0_6px_20px_rgba(234,88,12,0.06),0_2px_6px_rgba(234,88,12,0.04)] transition-all duration-300 ease-out hover:-translate-y-1.5 hover:scale-[1.015] hover:shadow-[0_20px_45px_rgba(234,88,12,0.16),0_6px_18px_rgba(234,88,12,0.1)] hover:border-orange-500/25 flex flex-col h-full cursor-pointer group overflow-hidden"
                onClick={() => setSelectedNotice(notice)}
              >
                {/* Decorative circular elements from notice.html design */}
                <div className="absolute top-4 right-4 w-20 h-20 bg-orange-500/[0.03] group-hover:bg-orange-500/[0.06] rounded-full pointer-events-none transition-all duration-500" />
                <div className="absolute -left-6 -bottom-6 w-24 h-24 bg-amber-500/[0.04] group-hover:bg-amber-500/[0.08] rounded-full pointer-events-none transition-all duration-500 blur-sm" />

                <div className="flex items-center justify-between mb-3 z-10">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                    <Calendar className="h-3.5 w-3.5 text-orange-500" />
                    {formatDate(notice.date || notice.created_at || notice.createdAt)}
                  </span>
                  <div className="flex gap-2">
                    <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-orange-100/75 text-orange-700 border border-orange-200/50">
                      Notice
                    </span>
                    {notice.target_audience && notice.target_audience !== 'all' && (
                      <span className="px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider bg-blue-100/70 text-blue-700 border border-blue-200/40">
                        {notice.target_audience.toLowerCase() === 'offline' ? 'Academic' : notice.target_audience}
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="flex-1 flex flex-col z-10 mt-1">
                  <div className="flex items-center gap-2 mb-2">
                    {notice.is_verified && (
                      <span className="flex items-center gap-1 text-emerald-700 font-extrabold text-[10px] bg-emerald-100/80 px-2.5 py-0.5 rounded-full border border-emerald-200/30">
                        <CheckCircle2 className="h-3 w-3 fill-emerald-600 text-white" />
                        Verified
                      </span>
                    )}
                  </div>

                  <h3 className="text-lg font-bold text-slate-800 mb-2 line-clamp-2 group-hover:text-orange-600 transition-colors duration-200">
                    {notice.title}
                  </h3>

                  <p className="text-sm text-slate-600 mb-5 flex-grow line-clamp-3 leading-relaxed">
                    {notice.content}
                  </p>

                  <div className="mt-auto pt-4 border-t border-orange-500/10 flex items-center justify-between">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">By {notice.admin_name || notice.author || 'Admin'}</span>
                    <div className="flex items-center gap-1 text-orange-600 font-bold text-xs group-hover:translate-x-1.5 transition-transform duration-200">
                      Read More <ArrowRight className="h-3 w-3" />
                    </div>
                  </div>
                </div>
              </motion.div>
            ))
          )}
        </div>
      </div>

      {/* Notice Modal */}
      <AnimatePresence>
        {selectedNotice && (
          <div 
            className="fixed inset-0 z-[10000] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => setSelectedNotice(null)}
          >
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 40 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 40 }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="bg-white/90 backdrop-blur-xl w-full max-w-2xl rounded-[2.5rem] shadow-2xl overflow-hidden max-h-[85vh] flex flex-col border border-white/50"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-orange-50/50">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-100 text-orange-600 rounded-xl">
                    <Bell className="h-5 w-5" />
                  </div>
                  <h2 className="text-xl font-bold text-slate-800">Notice Details</h2>
                </div>
                <button onClick={() => setSelectedNotice(null)} className="p-2 hover:bg-slate-100 rounded-full transition-colors">
                  <X className="h-6 w-6 text-slate-400" />
                </button>
              </div>
              
              <div className="p-8 overflow-y-auto space-y-6">
                <div className="flex items-center gap-4 text-sm font-bold text-slate-400 uppercase tracking-widest">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {formatDate(selectedNotice.date || selectedNotice.created_at || selectedNotice.createdAt, { month: 'long', day: 'numeric', year: 'numeric' })}
                  </div>
                  {selectedNotice.is_verified && (
                    <div className="flex items-center gap-1 text-blue-600">
                      <CheckCircle2 className="h-4 w-4 fill-blue-600 text-white" />
                      Verified
                    </div>
                  )}
                </div>

                <h3 className="text-3xl font-black text-slate-900 leading-tight">
                  {selectedNotice.title}
                </h3>

                <div className="prose prose-slate max-w-none">
                  <p className="text-slate-600 text-lg leading-relaxed whitespace-pre-wrap">
                    {selectedNotice.content}
                  </p>
                </div>

                {selectedNotice.attachment_url && (
                  <div className="pt-6 border-t border-slate-100">
                    <motion.a 
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      href={selectedNotice.attachment_url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 bg-slate-100 text-slate-700 px-6 py-3 rounded-xl font-bold hover:bg-slate-200 transition-colors"
                    >
                      <FileText className="h-5 w-5" /> View Attachment
                    </motion.a>
                  </div>
                )}
              </div>

              <div className="p-6 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-600 rounded-full flex items-center justify-center text-white font-bold">
                    {(selectedNotice.admin_name || selectedNotice.author || 'A')[0]}
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">{selectedNotice.admin_name || selectedNotice.author || 'Administrator'}</div>
                    <div className="text-xs text-slate-500">Official Announcement</div>
                  </div>
                </div>
                <motion.button 
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => setSelectedNotice(null)}
                  className="bg-white border border-slate-200 text-slate-600 px-6 py-2 rounded-xl font-bold hover:bg-slate-50 transition-colors"
                >
                  Close
                </motion.button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Notices;
