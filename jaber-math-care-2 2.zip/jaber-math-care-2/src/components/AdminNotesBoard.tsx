import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ClipboardList, Plus, Trash2, CheckCircle, Circle, AlertCircle } from 'lucide-react';

interface NoteItem {
  id: string;
  text: string;
  completed: boolean;
  priority: 'low' | 'medium' | 'high';
  createdAt: string;
}

const DEFAULT_NOTES: NoteItem[] = [
  { id: '1', text: 'Verify and approve pending student offline Blood group submissions', completed: false, priority: 'high', createdAt: new Date().toISOString() },
  { id: '2', text: 'Sms template update for HSC 2026 Batch class starts alert', completed: false, priority: 'medium', createdAt: new Date().toISOString() },
  { id: '3', text: 'Audit monthly invoice collections from Bkash and Nagad portals', completed: true, priority: 'low', createdAt: new Date().toISOString() },
];

export const AdminNotesBoard: React.FC = () => {
  const [notes, setNotes] = useState<NoteItem[]>([]);
  const [newText, setNewText] = useState('');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');

  // Load from localstorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem('jaber_math_admin_scratchpad');
      if (saved) {
        setNotes(JSON.parse(saved));
      } else {
        setNotes(DEFAULT_NOTES);
        localStorage.setItem('jaber_math_admin_scratchpad', JSON.stringify(DEFAULT_NOTES));
      }
    } catch (e) {
      setNotes(DEFAULT_NOTES);
    }
  }, []);

  // Save changes
  const saveNotes = (updated: NoteItem[]) => {
    setNotes(updated);
    try {
      localStorage.setItem('jaber_math_admin_scratchpad', JSON.stringify(updated));
    } catch (e) {
      console.error(e);
    }
  };

  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newText.trim()) return;

    const newNote: NoteItem = {
      id: Date.now().toString(),
      text: newText.trim(),
      completed: false,
      priority,
      createdAt: new Date().toISOString(),
    };

    const updated = [newNote, ...notes];
    saveNotes(updated);
    setNewText('');
  };

  const toggleComplete = (id: string) => {
    const updated = notes.map(n => n.id === id ? { ...n, completed: !n.completed } : n);
    saveNotes(updated);
  };

  const deleteNote = (id: string) => {
    const updated = notes.filter(n => n.id !== id);
    saveNotes(updated);
  };

  const clearCompleted = () => {
    const updated = notes.filter(n => !n.completed);
    saveNotes(updated);
  };

  return (
    <div className="glass p-6 md:p-8 rounded-3xl shadow-2xl border border-white/40 relative overflow-hidden bg-white/40 backdrop-blur-xl">
      <div className="absolute top-0 right-0 w-48 h-48 bg-orange-500/5 rounded-full blur-3xl -mr-24 -mt-24 pointer-events-none" />
      
      <div className="flex justify-between items-center mb-6 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-orange-100 rounded-xl text-orange-600 shadow-sm">
            <ClipboardList className="h-5 w-5" />
          </div>
          <div>
            <h3 className="text-lg md:text-xl font-black text-slate-900 tracking-tight">
              Admin Priorities & Scratchpad
            </h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">
              Persistent checklist and priorities for portal administration
            </p>
          </div>
        </div>
        {notes.some(n => n.completed) && (
          <button 
            onClick={clearCompleted}
            className="text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-orange-600 hover:underline transition-colors flex items-center gap-1"
          >
            Clear Done
          </button>
        )}
      </div>

      <form onSubmit={handleAddNote} className="gap-3 mb-6 flex flex-col sm:flex-row relative z-10">
        <input 
          type="text"
          value={newText}
          onChange={(e) => setNewText(e.target.value)}
          placeholder="Write a priority note or task..."
          className="flex-1 bg-white border border-slate-200 rounded-xl px-4 py-2.5 text-sm text-slate-800 outline-none focus:border-orange-500 transition-colors shadow-sm"
        />
        <div className="flex items-center gap-2">
          <select 
            value={priority}
            onChange={(e) => setPriority(e.target.value as any)}
            className="w-full md:w-auto bg-white border border-slate-200 text-slate-700 text-xs font-black uppercase tracking-wider rounded-xl px-4 py-3 outline-none focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 shadow-sm appearance-none cursor-pointer"
            style={{
              backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M5 8l5 5 5-5'/%3e%3c/svg%3e")`,
              backgroundPosition: 'right 0.75rem center',
              backgroundRepeat: 'no-repeat',
              backgroundSize: '1.25em 1.25em',
              paddingRight: '2.5rem'
            }}
          >
            <option value="low">Low Priority</option>
            <option value="medium">Med Priority</option>
            <option value="high">High Priority</option>
          </select>
          <button 
            type="submit"
            className="bg-orange-600 hover:bg-orange-700 text-white p-2.5 rounded-xl transition-all shadow-md active:scale-95 flex items-center justify-center shrink-0"
            title="Add Task"
          >
            <Plus className="h-5 w-5" />
          </button>
        </div>
      </form>

      <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1 select-none relative z-10 scrollbar-thin">
        <AnimatePresence initial={false}>
          {notes.length === 0 ? (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-center py-10 text-slate-400 border border-dashed border-slate-200/85 rounded-2xl bg-slate-50/50"
            >
              <AlertCircle className="h-8 w-8 mx-auto mb-2 text-slate-300" />
              <p className="text-xs font-medium">All tasks cleared! Have a spectacular day.</p>
            </motion.div>
          ) : (
            notes.map((note) => (
              <motion.div
                key={note.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -10 }}
                layout
                className={`flex gap-3 items-start justify-between p-3.5 rounded-xl transition-all border group ${
                  note.completed 
                    ? 'bg-slate-50/70 border-slate-100 opacity-60' 
                    : 'bg-white border-slate-100 hover:border-slate-200/80 hover:shadow-sm'
                }`}
              >
                <button 
                  type="button"
                  onClick={() => toggleComplete(note.id)}
                  className="mt-0.5 text-slate-400 hover:text-orange-600 transition-colors shrink-0"
                >
                  {note.completed ? (
                    <CheckCircle className="h-4.5 w-4.5 text-emerald-500 fill-emerald-50" />
                  ) : (
                    <Circle className="h-4.5 w-4.5" />
                  )}
                </button>
                <div className="flex-1 min-w-0">
                  <span className={`text-xs font-medium leading-relaxed block break-words ${note.completed ? 'line-through text-slate-400' : 'text-slate-750 font-semibold'}`}>
                    {note.text}
                  </span>
                  {!note.completed && (
                    <span className={`inline-block text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-md mt-1.5 ${
                      note.priority === 'high' 
                        ? 'bg-rose-50 text-rose-600 border border-rose-100/50' 
                        : note.priority === 'medium'
                          ? 'bg-orange-50 text-orange-600 border border-orange-100/50'
                          : 'bg-slate-100 text-slate-600'
                    }`}>
                      {note.priority} Priority
                    </span>
                  )}
                </div>
                <button 
                  onClick={() => deleteNote(note.id)}
                  className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-red-500 transition-all p-1"
                  title="Delete Item"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </motion.div>
            ))
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
