import { db } from '../firebase';
import { collection, onSnapshot } from 'firebase/firestore';
import React, { createContext, useContext, useState, useEffect } from 'react';

interface Settings {
  site_name?: string;
  hero_image?: string;
  about_image?: string;
  contact_phone?: string;
  contact_email?: string;
  office_address?: string;
  facebook_url?: string;
  youtube_url?: string;
  instagram_url?: string;
  logo_url?: string;
  developer_name?: string;
  developer_photo_url?: string;
  developer_bio?: string;
  developer_email?: string;
  developer_phone?: string;
  developer_location?: string;
  developer_coffee_url?: string;
  [key: string]: any;
}

interface SettingsContextType {
  settings: Settings;
  loading: boolean;
  refreshSettings: () => Promise<void>;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

const updateFavicon = (url: string) => {
  if (!url) return;
  let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
  if (!link) {
    link = document.createElement('link');
    link.rel = 'icon';
    document.head.appendChild(link);
  }
  link.href = url;

  let preload = document.querySelector("link[rel='preload'][as='image']") as HTMLLinkElement;
  if (!preload) {
    preload = document.createElement('link');
    preload.rel = 'preload';
    preload.as = 'image';
    document.head.appendChild(preload);
  }
  preload.href = url;
};

const updateMetaTags = (settingsData: Settings) => {
  const siteName = settingsData.site_name || 'Jaber Math Care';
  const subtitle = settingsData.hero_subtitle || 'Jaber Math Care is a premium Mathematics Academy helping students achieve academic success and conceptual understanding.';
  const logo = settingsData.brand_logo || settingsData.logo_url || 'https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff';
  const keywords = settingsData.seo_keywords || 'Jaber Math Care, JMC, Bogra Coaching, Jaber Sir, Math Admission preparation, Higher Math Academy, Mohammad Jaber Bin Razzak, Engineering admission';

  const setMeta = (nameOrProperty: string, value: string, isProperty = false) => {
    const attr = isProperty ? 'property' : 'name';
    let element = document.querySelector(`meta[${attr}='${nameOrProperty}']`) as HTMLMetaElement;
    if (!element) {
      element = document.createElement('meta');
      element.setAttribute(attr, nameOrProperty);
      document.head.appendChild(element);
    }
    element.content = value;
  };

  setMeta('description', subtitle);
  setMeta('keywords', keywords);
  setMeta('author', settingsData.developer_name || 'Mohammad Jaber Bin Razzak');
  setMeta('og:title', siteName, true);
  setMeta('og:description', subtitle, true);
  setMeta('og:image', logo, true);
  setMeta('twitter:title', siteName);
  setMeta('twitter:description', subtitle);
  setMeta('twitter:image', logo);

  // Inject custom SEO tags if present
  if (settingsData.custom_seo_tags) {
    const customHeadContainer = document.getElementById('custom-seo-tags') || document.createElement('div');
    customHeadContainer.id = 'custom-seo-tags';
    customHeadContainer.innerHTML = settingsData.custom_seo_tags;
    
    // Find all scripts inside and re-create them so they execute
    const scripts = customHeadContainer.getElementsByTagName('script');
    for (let i = 0; i < scripts.length; i++) {
        const newScript = document.createElement('script');
        newScript.text = scripts[i].text;
        if(scripts[i].src) newScript.src = scripts[i].src;
        if(scripts[i].id) newScript.id = scripts[i].id;
        scripts[i].parentNode?.replaceChild(newScript, scripts[i]);
    }

    if (!document.getElementById('custom-seo-tags')) {
      document.head.appendChild(customHeadContainer);
    }
  }
};

export const SettingsProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<Settings>(() => {
    const saved = localStorage.getItem('site_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const siteName = parsed.site_name || 'Jaber Math Care';
        document.title = siteName;
        if (parsed.brand_logo) {
          updateFavicon(parsed.brand_logo);
        }
        // Preload logo and brand images for instant high-speed aesthetic loading
        if (parsed.logo_url) {
          const img1 = new Image();
          img1.src = parsed.logo_url;
        }
        if (parsed.brand_logo) {
          const img2 = new Image();
          img2.src = parsed.brand_logo;
        }
        if (parsed.hero_image) {
          const img3 = new Image();
          img3.src = parsed.hero_image;
        }
        if (parsed.about_image) {
          const img4 = new Image();
          img4.src = parsed.about_image;
        }
        updateMetaTags(parsed);
        return parsed;
      } catch (e) {
        return {};
      }
    }
    return {};
  });
  const [loading, setLoading] = useState(() => {
    const saved = localStorage.getItem('site_settings');
    if (saved) {
      try {
        JSON.parse(saved);
        return false; // Skip loading screen if cache exists for instant render!
      } catch (e) {
        return true;
      }
    }
    return true;
  });

  useEffect(() => {
    // Real-time listener for settings collection
    const unsubscribe = onSnapshot(collection(db, 'settings'), (snapshot) => {
      const data: any = {};
      snapshot.docs.forEach(doc => {
        const docData = doc.data();
        if (docData.key) {
          data[docData.key] = docData.value;
        } else {
          data[doc.id] = docData.value !== undefined ? docData.value : docData;
        }
      });
      
      setSettings(data);
      localStorage.setItem('site_settings', JSON.stringify(data));
      
      if (data.site_name) {
        document.title = data.site_name;
      }
      if (data.brand_logo) {
        updateFavicon(data.brand_logo);
      }
      updateMetaTags(data);
      
      setLoading(false);
    }, (error) => {
      console.error('Settings real-time error:', error);
      setLoading(false);
      // Trigger a custom event so the UI can respond
      window.dispatchEvent(new CustomEvent('firebase-offline', { detail: `Settings loading failed: ${error.message}. If using a custom project, make sure Firestore Rules are deployed.` }));
    });

    return () => unsubscribe();
  }, []);

  const refreshSettings = async () => {
    // No-op since it's real-time now, but kept for compatibility
  };

  return (
    <SettingsContext.Provider value={{ settings, loading, refreshSettings }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
