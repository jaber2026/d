import React, { useEffect, useState, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Video, Users, MessageSquare, LogOut, Send, X, ExternalLink, MonitorPlay, PlayCircle, ArrowRight, CheckCircle2 } from 'lucide-react';
import { safeJson } from '../utils/api';

import { useAuth } from '../context/AuthContext';
// ...
export default function AdminLiveClassStudio() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const displayName = user?.role === 'admin' ? 'Instructor' : (user?.name || 'User');
  const encodedDisplayName = encodeURIComponent(displayName);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [activeClass, setActiveClass] = useState<any>(null);
  const [allClasses, setAllClasses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [courses, setCourses] = useState<any[]>([]);
  const [programs, setPrograms] = useState<any[]>([]);
  const [batches, setBatches] = useState<any[]>([]);
  const [showSidebar, setShowSidebar] = useState(true);
  
  // Generate a unique Jitsi room name for this session
  const [jitsiRoom] = useState('JaberMathCare_Live_' + Math.random().toString(36).substring(2, 12));
  
  const [newClassData, setNewClassData] = useState({
    title: 'Live Class - ' + new Date().toLocaleDateString(),
    course_id: '',
    program_id: '',
    batch_id: 'ALL',
    coaching_name: '',
  });
  const chatEndRef = useRef<HTMLDivElement>(null);

  const fetchClassesAndCourses = async () => {
    try {
      const [liveRes, coursesRes, programsRes, batchesRes] = await Promise.all([
        fetch('/api/live-classes'),
        fetch('/api/courses'),
        fetch('/api/programs'),
        fetch('/api/batches')
      ]);
      
      if (liveRes.ok && coursesRes.ok && programsRes.ok && batchesRes.ok) {
        const liveData = await safeJson(liveRes);
        const coursesData = await safeJson(coursesRes);
        const programsData = await safeJson(programsRes);
        const batchesData = await safeJson(batchesRes);
        
        setCourses(coursesData);
        setPrograms(programsData);
        setBatches(batchesData);

        const enriched = liveData.map((lc: any) => ({
          ...lc,
          course_name: coursesData.find((c: any) => c.id === lc.course_id)?.title || 'General Class'
        }));
        
        setAllClasses(enriched);

        const urlParams = new URLSearchParams(window.location.search);
        const classId = urlParams.get('classId');
        if (classId) {
          const found = enriched.find((c: any) => c.id === classId);
          if (found) setActiveClass(found);
        }
      }
    } catch (error) {
      console.error('Failed to fetch classes', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const isAuth = sessionStorage.getItem('liveClassAdminAuth');
    if (!isAuth) {
      navigate('/admin/live-class-login');
      return;
    }
    fetchClassesAndCourses();
  }, [navigate]);

  useEffect(() => {
    if (!activeClass) return;

    const fetchMessages = async () => {
      try {
        const res = await fetch(`/api/live-chat-messages?class_id=${activeClass.id}`);
        if (res.ok) {
          const data = await safeJson(res);
          setMessages(data);
        }
      } catch (error) {
        console.error('Failed to fetch messages', error);
      }
    };

    fetchMessages();
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') {
        fetchMessages();
      }
    }, 5000);
    return () => clearInterval(interval);
  }, [activeClass]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !activeClass) return;

    try {
      const res = await fetch('/api/live-chat-messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          class_id: activeClass.id,
          user_id: 'admin',
          user_name: 'Instructor',
          content: newMessage,
          role: 'admin'
        }),
      });

      if (res.ok) {
        setNewMessage('');
        const data = await safeJson(res);
        setMessages(prev => [...prev, data]);
      }
    } catch (error) {
      console.error('Failed to send message', error);
    }
  };

  const handleEndClass = async () => {
    if (activeClass) {
      try {
        await fetch(`/api/live-classes/${activeClass.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ status: 'completed' })
        });
      } catch (error) {
        console.error('Failed to end class', error);
      }
    }
    setActiveClass(null);
    await fetchClassesAndCourses();
  };

  const handleExitStudio = () => {
    sessionStorage.removeItem('liveClassAdminAuth');
    navigate('/admin');
  };

  const handleCreateInstantClass = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClassData.title) {
      alert('Please fill in the Title.');
      return;
    }
    if (!newClassData.course_id && !newClassData.program_id) {
      alert('Please select either a Program/Batch OR a Course.');
      return;
    }

    try {
      const res = await fetch('/api/live-classes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ...newClassData,
          zoom_id: jitsiRoom, // Store Jitsi room name here
          zoom_password: 'None', // No password needed for Jitsi by default
          date: new Date().toISOString().split('T')[0],
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          status: 'active',
          zoom_link: `https://meet.jit.si/${jitsiRoom}`,
          is_jitsi: true
        }),
      });

      if (res.ok) {
        const createdClass = await safeJson(res);
        await fetchClassesAndCourses();
        setActiveClass({
          ...createdClass,
          course_name: courses.find((c: any) => c.id === createdClass.course_id)?.title || 'General Class'
        });
        setNewClassData({
          title: 'Live Class - ' + new Date().toLocaleDateString(),
          course_id: '',
          program_id: '',
          batch_id: 'ALL',
          coaching_name: '',
        });
      }
    } catch (error) {
      console.error('Failed to create instant class', error);
      alert('Failed to start instant class. Please try again.');
    }
  };

  // Use the active class's room if it exists, otherwise use the newly generated one
  const currentRoom = activeClass ? activeClass.zoom_id : jitsiRoom;

  const jitsiPane = useMemo(() => (
    <div className="flex-1 bg-slate-950 flex flex-col relative overflow-hidden border-r border-white/5 min-h-[60vh] md:min-h-0">
      <div className="bg-slate-900 p-2 flex items-center justify-between border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="flex gap-1.5 px-2">
            <div className="w-3 h-3 rounded-full bg-red-500/80"></div>
            <div className="w-3 h-3 rounded-full bg-amber-500/80"></div>
            <div className="w-3 h-3 rounded-full bg-emerald-500/80"></div>
          </div>
          <div className="bg-slate-950 rounded-md px-3 py-1.5 text-xs text-slate-400 flex items-center gap-2 border border-white/5 font-mono">
            <MonitorPlay className="h-3 w-3 text-emerald-400" />
            Live Studio Camera
          </div>
        </div>
        <a 
          href={`https://meet.jit.si/${currentRoom}`} 
          target="_blank" 
          rel="noopener noreferrer"
          className="md:hidden bg-white/10 hover:bg-white/20 text-white px-3 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all"
        >
          <ExternalLink className="h-3 w-3" /> Open App
        </a>
      </div>
      <iframe 
        src={`https://meet.jit.si/${currentRoom}#config.prejoinPageEnabled=false&userInfo.displayName=%22${encodedDisplayName}%22`}
        className="w-full flex-1 border-0 bg-slate-900"
        allow="camera; microphone; fullscreen; display-capture; autoplay"
        title="Live Class Studio"
      ></iframe>
    </div>
  ), [currentRoom]);

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="h-12 w-12 border-4 border-orange-600 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col text-white overflow-hidden relative">
      {/* Floating End Class Button when broadcasting */}
      {activeClass && (
        <div className="fixed top-4 right-4 z-[100] flex gap-2">
          <button 
            onClick={handleEndClass}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-full font-black text-xs uppercase tracking-widest shadow-2xl shadow-red-900/50 flex items-center gap-2 transition-all active:scale-95"
          >
            <LogOut className="h-4 w-4" /> End Session
          </button>
          <button 
            onClick={handleExitStudio}
            className="bg-slate-800/80 backdrop-blur-md hover:bg-slate-700 text-white p-2 rounded-full shadow-2xl transition-all active:scale-95"
            title="Exit Studio"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
      )}

      {!activeClass && (
        <header className="h-16 bg-slate-900 border-b border-white/10 flex items-center justify-between px-6 z-30">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center">
              <Video className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-sm md:text-lg font-bold">Live Studio Setup</h1>
              <p className="hidden md:block text-xs text-slate-400">Start your camera, then broadcast to students</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={handleExitStudio}
              className="p-2 hover:bg-white/5 rounded-xl transition-colors text-slate-400 hover:text-white"
              title="Exit Studio"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </header>
      )}

      <div className={`flex-1 flex flex-col md:flex-row overflow-hidden ${!activeClass ? 'h-[calc(100vh-64px)]' : 'h-screen'}`}>
        {/* Jitsi Interface - ALWAYS VISIBLE & EMBEDDABLE */}
        {jitsiPane}

        {/* Right Side - Broadcast Form OR Chat */}
        {!activeClass && (
          <div className={`${showSidebar ? 'flex' : 'hidden'} md:flex w-full md:w-80 lg:w-96 bg-slate-900 border-l border-white/10 flex-col shadow-2xl z-20`}>
            <div className="p-6 flex flex-col h-full overflow-y-auto">
              <h2 className="text-xl font-bold mb-6 flex items-center gap-2">
                <PlayCircle className="h-6 w-6 text-orange-500" />
                Broadcast to Students
              </h2>
              
              <form onSubmit={handleCreateInstantClass} className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-2">Select Coaching Name</label>
                    <select 
                      value={newClassData.coaching_name}
                      onChange={(e) => setNewClassData({...newClassData, coaching_name: e.target.value})}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                    >
                      <option value="">Select Coaching...</option>
                      <option value="Jaber Math Care">Jaber Math Care</option>
                      <option value="Jaber Math Care">Jaber Math Care</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-2">Select Program (Optional)</label>
                    <select 
                      value={newClassData.program_id}
                      onChange={(e) => setNewClassData({...newClassData, program_id: e.target.value, batch_id: 'ALL'})}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                    >
                      <option value="">Select a program...</option>
                      {programs.map((prog: any) => (
                        <option key={prog.id} value={prog.id}>
                          {prog.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-2">Select Batch</label>
                    <select 
                      value={newClassData.batch_id}
                      onChange={(e) => setNewClassData({...newClassData, batch_id: e.target.value})}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                    >
                      <option value="ALL">ALL BATCHES</option>
                      {batches.filter(b => !newClassData.program_id || String(b.program_id) === String(newClassData.program_id)).map((batch: any) => (
                        <option key={batch.id} value={batch.id}>
                          {batch.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-2">Select Course</label>
                    <select 
                      value={newClassData.course_id}
                      onChange={(e) => setNewClassData({...newClassData, course_id: e.target.value})}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                    >
                      <option value="">Select a course...</option>
                      {courses.map((course: any) => (
                        <option key={course.id} value={course.id}>
                          {course.title}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-2">Class Title</label>
                    <input 
                      type="text"
                      required
                      placeholder="e.g., Math Batch 2026 - Lecture 04"
                      value={newClassData.title}
                      onChange={(e) => setNewClassData({...newClassData, title: e.target.value})}
                      className="w-full bg-slate-950 border border-white/10 rounded-xl px-4 py-3 focus:ring-2 focus:ring-orange-500 outline-none transition-all"
                    />
                  </div>

                  <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl">
                    <p className="text-sm text-emerald-400 flex items-start gap-2">
                      <CheckCircle2 className="h-5 w-5 shrink-0 mt-0.5" />
                      <span>Your live video feed is ready on the left. Just select the course and click broadcast to invite students!</span>
                    </p>
                  </div>
                </div>

                <button 
                  type="submit"
                  className="w-full bg-orange-600 hover:bg-orange-500 text-white font-bold py-4 rounded-2xl transition-all shadow-lg shadow-orange-600/20 flex items-center justify-center gap-2 group"
                >
                  <Send className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
                  Broadcast to Students
                </button>
              </form>

              <div className="mt-8 pt-8 border-t border-white/5">
                <h3 className="text-sm font-bold text-slate-400 mb-4">Recent Classes</h3>
                <div className="space-y-3">
                  {allClasses.slice(0, 3).map((lc: any) => (
                    <button
                      key={lc.id}
                      onClick={() => setActiveClass(lc)}
                      className="w-full p-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-left transition-all group"
                    >
                      <div className="flex justify-between items-center mb-1">
                        <div className="flex items-center gap-2">
                          <div className="text-xs font-bold text-orange-500">{lc.course_name}</div>
                          {lc.coaching_name && (
                            <>
                              <span className="w-1 h-1 rounded-full bg-slate-600" />
                              <div className="text-[10px] font-bold text-slate-400">{lc.coaching_name}</div>
                            </>
                          )}
                        </div>
                        <div className={`text-[10px] px-1.5 py-0.5 rounded uppercase ${lc.status === 'active' ? 'bg-emerald-500/20 text-emerald-500' : 'bg-slate-500/20 text-slate-500'}`}>
                          {lc.status}
                        </div>
                      </div>
                      <div className="text-sm font-medium line-clamp-1">{lc.title}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
