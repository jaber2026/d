import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { FileText, Award, Calendar } from 'lucide-react';
import SmallLoadingSpinner from '../../components/SmallLoadingSpinner';
import { db } from '../../firebase';
import { collection, onSnapshot, query, where } from 'firebase/firestore';

const Results = () => {
  const { token, user } = useAuth();
  const [results, setResults] = useState<any[]>([]);
  const [exams, setExams] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!token || !user) return;

    const unsubscribes: (() => void)[] = [];

    // Listen to results
    const qResults = query(collection(db, 'results'), where('student_id', 'in', [user.id, user.roll_number || '']));
    const unsubResults = onSnapshot(qResults, (snapshot) => {
      setResults(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
    });
    unsubscribes.push(unsubResults);

    // Listen to exams
    const unsubExams = onSnapshot(collection(db, 'exams'), (snapshot) => {
      setExams(snapshot.docs.map(d => ({ ...d.data(), id: d.id })));
      setLoading(false);
    });
    unsubscribes.push(unsubExams);

    return () => unsubscribes.forEach(unsub => unsub());
  }, [token, user]);

  const userBatches = [
    String(user.batch_id || ''),
    String(user.batch_id_2 || ''),
    ...(user.enrolled_courses || []).map(c => String(c.batch_id))
  ].filter(b => b && b !== 'undefined');

  const myExams = exams.filter(exam => {
    if (!exam.published) return false;
    if (exam.batch_id === 'all' || exam.program_id === 'all') return true;
    if (userBatches.includes(String(exam.batch_id))) return true;
    return false;
  }).sort((a, b) => new Date(b.exam_date || b.created_at || 0).getTime() - new Date(a.exam_date || a.created_at || 0).getTime());

  if (loading) return <SmallLoadingSpinner />;

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <h2 className="text-3xl font-black text-slate-900 tracking-tight flex items-center gap-3">
            <div className="p-2 bg-orange-100 rounded-xl">
              <Award className="h-6 w-6 text-orange-600" />
            </div>
            Exam Results
          </h2>
          <p className="text-slate-500 mt-1 text-sm font-medium">View your performance across different exams.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6">
        {myExams.map((exam) => {
          const result = results.find(r => r.exam_id === exam.id || r.exam_name === exam.exam_name) || null;
          const isPending = !result;
          
          const totalMarks = result ? (result.total_marks || result.e_total || exam.highest_marks || exam.total_marks || 100) : (exam.highest_marks || exam.total_marks || 100);
          const totalNum = Number(totalMarks) || 100;
          const marksNum = result ? Number(result.marks) : 0;
          // Passing criteria is 40% of total
          const hasPassed = !isPending && (marksNum >= totalNum * 0.4);

          return (
            <div key={exam.id} className={`glass p-8 rounded-[2.5rem] border ${isPending ? 'border-slate-200 shadow-sm bg-slate-50/50 hover:bg-slate-50' : 'border-white/60 shadow-xl bg-orange-50/10 hover:bg-orange-50/20'} flex flex-col lg:flex-row justify-between items-center gap-8 transition-all relative overflow-hidden`}>
              <div className={`absolute top-0 right-0 w-32 h-32 ${isPending ? 'bg-slate-300/10' : 'bg-orange-500/5'} rounded-full -mr-16 -mt-16 blur-2xl`}></div>
              
              <div className="flex items-center gap-6 w-full lg:w-auto">
                <div className={`p-5 rounded-2xl ${isPending ? 'bg-slate-100 text-slate-400' : 'bg-gradient-to-br from-orange-500 to-red-500 text-white shadow-lg shadow-orange-200'}`}>
                  <FileText className="h-8 w-8" />
                </div>
                <div>
                  <h3 className={`font-black text-2xl tracking-tight ${isPending ? 'text-slate-500' : 'text-slate-900'}`}>{exam.exam_name}</h3>
                  <div className="flex flex-col gap-1 mt-3">
                    <span className="text-slate-500 text-[10px] font-black uppercase tracking-widest">
                      Category: <span className="text-orange-600 ml-1">{exam.category || '-'}</span>
                    </span>
                    <span className="text-slate-500 text-[10px] font-black uppercase tracking-widest">
                      Exam Type: <span className="text-red-500 ml-1">{exam.exam_type || 'Monthly'}</span>
                    </span>
                  </div>
                  <div className="flex flex-wrap items-center gap-3 mt-3">
                    <span className="text-slate-400 text-[10px] font-black uppercase tracking-widest flex items-center gap-1.5 bg-white px-3 py-1 rounded-lg border border-slate-100 shadow-sm">
                      <Calendar className="h-3 w-3 text-orange-400" />
                      {new Date(result?.created_at || exam.exam_date || exam.created_at).toLocaleDateString()}
                    </span>
                    {exam.answer_pdf && (
                      <a 
                        href={exam.answer_pdf} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-green-600 text-[10px] font-black uppercase tracking-widest bg-green-50 px-3 py-1 rounded-lg border border-green-100 hover:bg-green-100 transition-colors shadow-sm"
                      >
                        Answer PDF
                      </a>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center lg:justify-end gap-10 w-full lg:w-auto bg-white/70 backdrop-blur-md p-6 rounded-[2rem] border border-slate-100 inline-flex shadow-sm">
                <div className="text-center">
                  <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1.5">Obtained Marks</p>
                  {isPending ? (
                    <div className="flex flex-col items-center">
                      <div className="text-xl font-black text-slate-400 tracking-tighter leading-none mt-1">
                        PENDING
                      </div>
                      <div className="mt-2 text-[9px] font-bold text-slate-500 bg-slate-100 border border-slate-200 px-2 py-0.5 rounded-md uppercase tracking-widest">
                        Awaiting Result
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center">
                      <div className="text-4xl font-black text-cyan-600 tracking-tighter">
                        {result.marks} 
                        <span className="text-xl text-slate-300 ml-1">/ {totalNum}</span>
                      </div>
                      {hasPassed ? (
                        <div className="mt-1.5 text-[10px] font-bold text-emerald-700 bg-emerald-100 border border-emerald-200 px-2 py-0.5 rounded-md">
                          পাস
                        </div>
                      ) : (
                        <div className="mt-1.5 text-[10px] font-bold text-red-700 bg-red-100 border border-red-200 px-2 py-0.5 rounded-md">
                          পাস হয়নি
                        </div>
                      )}
                    </div>
                  )}
                </div>
                {!isPending && <div className="h-12 w-[1px] bg-orange-100 hidden sm:block"></div>}
                {!isPending && (
                  <div className="text-center">
                    <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1.5">Highest</p>
                    <div className="text-3xl font-black text-slate-800 tracking-tighter">{result.highest_marks || exam.highest_marks || '-'}</div>
                  </div>
                )}
                {!isPending && <div className="h-12 w-[1px] bg-orange-100 hidden sm:block"></div>}
                {!isPending && (
                  <div className="text-center">
                    <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mb-1.5">Merit Position</p>
                    <div className="text-4xl font-black text-orange-600 tracking-tighter">{result.merit_position ? `#${result.merit_position}` : '-'}</div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
        {myExams.length === 0 && (
          <div className="glass p-16 rounded-[2.5rem] border border-white/60 shadow-xl bg-white/40 text-center">
            <div className="max-w-xs mx-auto">
              <div className="p-6 bg-slate-50 rounded-full inline-block mb-4">
                <Award className="h-12 w-12 text-slate-200" />
              </div>
              <h3 className="text-xl font-black text-slate-900 mb-2">No Results Yet</h3>
              <p className="text-slate-500 font-medium">Your exam results will appear here once they are published.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Results;
