import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useRealtimeCollection } from '../hooks/useRealtime';
import { orderBy, where } from 'firebase/firestore';

const ECommerceBannerSlider = () => {
  const { data: rawSponsors } = useRealtimeCollection('sponsorships');

  const [images, setImages] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (rawSponsors) {
      const activeImages = rawSponsors
        .filter((s: any) => s.status === 'active' && s.banner_type === 'image' && s.image_url)
        .sort((a: any, b: any) => (a.order_index || 0) - (b.order_index || 0));
      setImages(activeImages);
    }
  }, [rawSponsors]);

  // Auto-play
  useEffect(() => {
    if (images.length === 0) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [images.length]);

  if (images.length === 0) return null;

  const handleNext = () => setCurrentIndex(prev => (prev + 1) % images.length);
  const handlePrev = () => setCurrentIndex(prev => (prev === 0 ? images.length - 1 : prev - 1));

  return (
    <div className="relative w-full h-[300px] md:h-[450px] lg:h-[600px] bg-slate-100 overflow-hidden group">
      <AnimatePresence initial={false}>
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.8 }}
          className="absolute inset-0 cursor-pointer"
          onClick={() => {
             if (images[currentIndex]?.link) {
               window.open(images[currentIndex].link, '_blank');
             }
          }}
        >
          <img 
            src={images[currentIndex].image_url} 
            alt={images[currentIndex].title || 'Banner'} 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/10 transition-colors" />
        </motion.div>
      </AnimatePresence>

      {/* Controls */}
      <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 flex justify-between px-4 md:px-8 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
        <button 
          onClick={(e) => { e.stopPropagation(); handlePrev(); }}
          className="w-12 h-12 rounded-full bg-white/70 hover:bg-white backdrop-blur-md flex items-center justify-center text-slate-800 shadow-xl transition-all active:scale-95"
        >
          <ChevronLeft className="w-7 h-7" />
        </button>
        <button 
          onClick={(e) => { e.stopPropagation(); handleNext(); }}
          className="w-12 h-12 rounded-full bg-white/70 hover:bg-white backdrop-blur-md flex items-center justify-center text-slate-800 shadow-xl transition-all active:scale-95"
        >
          <ChevronRight className="w-7 h-7" />
        </button>
      </div>

      {/* Indicators */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-2">
        {images.map((_, idx) => (
          <button
            key={idx}
            onClick={(e) => { e.stopPropagation(); setCurrentIndex(idx); }}
            className={`transition-all rounded-full ${currentIndex === idx ? 'w-10 h-2.5 bg-orange-600' : 'w-2.5 h-2.5 bg-white/60 hover:bg-white'}`}
          />
        ))}
      </div>
    </div>
  );
};

export default ECommerceBannerSlider;
