import React from 'react';
import { motion } from 'motion/react';
import { ShieldCheck, Star, ArrowLeft, Facebook, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useRealtimeCollection } from '../hooks/useRealtime';
import LoadingSpinner from '../components/LoadingSpinner';

const SupportTeam = () => {
  const { data: members, loading } = useRealtimeCollection('support_team');

  return (
    <div className="min-h-screen bg-slate-50 pt-16 pb-20">
      <div className="max-w-7xl mx-auto px-4">
        <div className="text-center mb-10 space-y-3">
          <h1 className="text-4xl md:text-7xl font-black text-orange-600 tracking-tighter uppercase leading-none">Support Team</h1>
          <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Expert assistance for your mathematical journey</p>
        </div>

        {loading ? (
          <div className="flex justify-center py-20">
            <LoadingSpinner />
          </div>
        ) : members.length === 0 ? (
          <div className="bg-white p-12 rounded-[3rem] text-center shadow-sm border border-slate-100">
             <ShieldCheck className="h-12 w-12 text-slate-200 mx-auto mb-4" />
             <p className="text-slate-400 font-bold">No support members found.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 max-w-6xl mx-auto">
            {members.sort((a,b)=> (a.order || 0) - (b.order || 0)).map((member, i) => (
              <motion.div 
                key={member.id}
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white rounded-[2.5rem] p-6 shadow-[0_20px_50px_rgba(0,0,0,0.05)] border border-slate-100 flex flex-col items-center text-center group"
              >
                 <div className="w-full aspect-square rounded-[2rem] overflow-hidden mb-8 shadow-inner bg-slate-50">
                    <img 
                      src={member.image_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(member.name)}&background=ea580c&color=fff&size=512`} 
                      alt={member.name}
                      className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-700" 
                      referrerPolicy="no-referrer"
                    />
                 </div>
                 
                 <div className="space-y-4 flex-1 flex flex-col items-center w-full">
                    <h4 className="text-2xl font-black text-orange-600 tracking-tight">{member.name}</h4>
                    
                    <div className="inline-flex px-6 py-2 bg-orange-50 text-orange-600 rounded-full text-[10px] font-black uppercase tracking-widest">
                       {member.role || 'Member'}
                    </div>

                    <p className="text-slate-500 text-sm font-medium leading-relaxed px-4">
                      {member.description}
                    </p>

                    <div className="mt-auto w-full pt-6">
                      <a 
                        href={member.facebook_url || "#"} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="w-full py-4 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest transition-all shadow-lg shadow-orange-600/20 active:scale-[0.98] flex items-center justify-center gap-2"
                      >
                        Visit Facebook Profile
                      </a>
                    </div>
                 </div>
              </motion.div>
            ))}
          </div>
        )}
        {/* Back to Home Moved to Bottom */}
        <div className="text-center mt-20">
          <Link to="/" className="inline-flex items-center gap-2 px-8 py-3 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-orange-600 hover:-translate-y-1 transition-all shadow-xl">
            <ArrowLeft className="h-3.5 w-3.5" /> Back to Home Page
          </Link>
        </div>
      </div>
    </div>
  );
};

export default SupportTeam;
