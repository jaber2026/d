import React, { useState, useEffect, Suspense } from 'react';
import { useOutlet, Link, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { 
  LayoutDashboard, User, BookOpen, FileText, Calendar, 
  BarChart2, CheckSquare, CreditCard, PlayCircle, Bell, 
  LogOut, Menu, X, ChevronRight, Home, Video, Youtube,
  Smartphone, ShieldAlert
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import LiveClassButton from './LiveClassButton';
import DashboardLoading from './DashboardLoading';
import { db } from '../firebase';
import { collection, doc, getDocs, setDoc } from 'firebase/firestore';

// Multi-device ban countdown component
const BanBanner: React.FC<{ bannedUntil: string; reason?: string; count: number; logout: () => void; user: any }> = ({ bannedUntil, reason, count, logout, user }) => {
  const [timeLeft, setTimeLeft] = useState('');
  const [submittingAppeal, setSubmittingAppeal] = useState(false);
  const [appealSent, setAppealSent] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const diff = new Date(bannedUntil).getTime() - Date.now();
      if (diff <= 0) {
        setTimeLeft('Ban expired! Please refresh.');
        return;
      }
      const hrs = Math.floor(diff / (1000 * 60 * 60));
      if (hrs > 1000) {
        setTimeLeft('Account Terminated');
        return;
      }
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const secs = Math.floor((diff % (1000 * 60)) / 1000);
      setTimeLeft(`${hrs} Hours, ${mins} Minutes, ${secs} Seconds`);
    };

    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, [bannedUntil]);

  // Lock window scroll with zero overhead while modal is displayed
  useEffect(() => {
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = '';
    };
  }, []);

  const handleSendAppeal = async () => {
    setSubmittingAppeal(true);
    try {
      const appealId = user?.id || 'unknown';
      await setDoc(doc(db, 'ban_appeals', appealId), {
        student_id: user?.id || 'unknown',
        student_name: user?.name || 'Unknown Student',
        phone: user?.phone || user?.gmail || 'Unknown Phone',
        roll_number: user?.roll_number || 'N/A',
        device_ban_count: count,
        ban_reason: reason || 'Multi-device violation',
        banned_until: bannedUntil,
        requested_at: new Date().toISOString(),
        status: 'pending'
      }, { merge: true });
      setAppealSent(true);
      alert('Unlock appeal submitted successfully!');
    } catch (err: any) {
      console.error(err);
      alert('Failed to submit unlock appeal. Please contact the administrator directly.');
    } finally {
      setSubmittingAppeal(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-950 text-white z-50 flex items-center justify-center p-6 md:p-12 overflow-y-auto">
      <div className="max-w-2xl w-full bg-slate-900 border border-red-500/30 p-8 md:p-12 rounded-[2.5rem] shadow-2xl text-center space-y-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-red-500/5 rounded-full blur-[80px] -mr-32 -mt-32"></div>
        <div className="w-20 h-20 bg-red-500/10 rounded-full flex items-center justify-center mx-auto border border-red-500/25 text-red-500 animate-pulse">
          <ShieldAlert className="h-10 w-10" />
        </div>
        <div className="space-y-2">
          <h1 className="text-2xl md:text-3xl font-black text-red-500 tracking-tight">Your Account has been Temporarily Locked!</h1>
          <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Account Suspended: Multi-Device Violation</p>
        </div>
        <p className="text-slate-300 font-medium text-sm md:text-base leading-relaxed max-w-xl mx-auto">
          Sorry, you have exceeded the maximum device limit or attempted to use this account simultaneously across multiple different devices. Under our class integrity guidelines, interactive screen sharing or concurrent browser pairing is strictly forbidden.
        </p>
 
        <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-3 text-left max-w-md mx-auto">
          {reason && (
            <p className="text-xs text-red-400 font-bold flex items-start gap-2">
              <span className="text-slate-400 text-[11px] font-black uppercase shrink-0">Reason:</span> <span className="font-medium text-slate-200">{reason}</span>
            </p>
          )}
          <p className="text-xs text-slate-400 font-bold flex items-center gap-2">
            <span className="text-slate-400 text-[11px] font-black uppercase">Total Violations:</span> <span className="text-red-400 font-black">{count} {count === 1 ? 'time' : 'times'}</span>
          </p>
          <div className="p-4 bg-red-500/10 rounded-xl text-center border border-red-500/20">
            <p className="text-[10px] text-red-400 font-black uppercase tracking-widest leading-none mb-1.5">Unban Timer Remaining</p>
            <p className="text-lg font-black text-red-500">{timeLeft}</p>
          </div>
        </div>
 
        <div className="text-xs text-slate-500 font-semibold max-w-md mx-auto leading-relaxed">
          {count === 1 ? (
            <div className="text-[12px] bg-red-500/5 p-4 rounded-xl border border-red-500/20 text-slate-300">
              <strong className="block mb-1 text-red-400 uppercase tracking-wider text-[11px]">First Warning:</strong>
              A temporary 6-hour lock has been initiated for first-time multi-device pairing. 
              <strong className="text-red-500 font-black block mt-2">Critical Notice: Attempting another unauthorized device login will lead to permanent account termination!</strong>
            </div>
          ) : (
            <div className="bg-red-600 text-white p-4 rounded-xl shadow-lg border border-red-700 animate-pulse">
               <p className="text-xl font-black uppercase tracking-widest mb-1">Account Terminated!</p>
               <p className="text-sm font-semibold opacity-90 leading-tight">
                 Since repetitive device violations were committed despite the initial warning, this account is permanently deactivated and queued for deletion.
               </p>
            </div>
          )}
        </div>
 
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          {appealSent ? (
            <div className="bg-emerald-500/10 border border-emerald-500/20 px-6 py-3 rounded-2xl text-emerald-400 text-xs font-bold leading-tight">
              ✓ Unlock appeal successfully registered and sent to the administrator panel!
            </div>
          ) : (
            <button
              onClick={handleSendAppeal}
              disabled={submittingAppeal}
              className="px-6 py-3.5 bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white font-black text-xs uppercase tracking-widest rounded-xl shadow-lg active:scale-95 flex items-center gap-2"
            >
              🚀 Submit Unlock Appeal (Request Unban)
            </button>
          )}
 
          <button
            onClick={logout}
            className="px-6 py-3.5 bg-slate-800 hover:bg-slate-700 text-white font-black text-xs uppercase tracking-widest rounded-xl shadow-lg transition-transform active:scale-95 flex items-center gap-2"
          >
            <LogOut className="h-4 w-4" /> Logout
          </button>
        </div>
      </div>
    </div>
  );
};

const DashboardLayout = () => {
  const { user, logout } = useAuth();
  const { settings } = useSettings();
  const location = useLocation();
  const navigate = useNavigate();
  const outlet = useOutlet();
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);

  // Parse helper for getting OS and Browser
  const getDeviceName = () => {
    const ua = navigator.userAgent;
    let browser = "Unknown Browser";
    let os = "Unknown OS";
    if (ua.includes("Firefox")) browser = "Firefox";
    else if (ua.includes("SamsungBrowser")) browser = "Samsung Browser";
    else if (ua.includes("Opera") || ua.includes("OPR")) browser = "Opera";
    else if (ua.includes("Trident")) browser = "Internet Explorer";
    else if (ua.includes("Edge") || ua.includes("Edg")) browser = "Edge";
    else if (ua.includes("Chrome")) browser = "Chrome";
    else if (ua.includes("Safari")) browser = "Safari";

    if (ua.includes("Windows NT 10.0")) os = "on Windows 10/11";
    else if (ua.includes("Windows NT 6.2")) os = "on Windows 8";
    else if (ua.includes("Windows NT 6.1")) os = "on Windows 7";
    else if (ua.includes("Macintosh")) os = "on Mac OS";
    else if (ua.includes("Android")) os = "on Android";
    else if (ua.includes("iPhone") || ua.includes("iPad")) os = "on iOS";
    else if (ua.includes("Linux")) os = "on Linux";

    return `${browser} ${os}`;
  };

  // Run device check system for logged-in students
  useEffect(() => {
    const checkDeviceAndRegister = async () => {
      if (!user || user.role !== 'student') return;

      // Skip checking if already banned
      if (user.banned_until && new Date(user.banned_until) > new Date()) return;

      let deviceId = localStorage.getItem('mc_device_id');
      if (!deviceId) {
        deviceId = 'dev_' + Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
        localStorage.setItem('mc_device_id', deviceId);
      }

      try {
        let clientIp = 'Unknown IP';
        try {
          const ipRes = await fetch('https://api.ipify.org?format=json');
          if (ipRes.ok) {
            const ipData = await ipRes.json();
            clientIp = ipData.ip;
          }
        } catch (_) {}

        const devicesRef = collection(db, 'users', user.id, 'devices');
        const snap = await getDocs(devicesRef);
        const registered = snap.docs.map(d => d.data());

        const matched = registered.find(d => d.id === deviceId);

        if (matched) {
          // Update details & timestamp of existing verified device
          await setDoc(doc(db, 'users', user.id, 'devices', deviceId), {
            lastActive: new Date().toISOString(),
            ipAddress: clientIp
          }, { merge: true });
        } else {
          // If we have under 2 devices, register the newer one
          if (registered.length < 2) {
            await setDoc(doc(db, 'users', user.id, 'devices', deviceId), {
              id: deviceId,
              name: getDeviceName(),
              ipAddress: clientIp,
              loggedIn: new Date().toISOString(),
              lastActive: new Date().toISOString()
            });
          } else {
            // Online user attempting to login/visit with a 3rd device! Auto-ban!
            const count = user.device_ban_count || 0;
            const nextCount = count + 1;
            
            // 1st offense = 6 hours, 2nd+ offense = PERMANENT (100 years)
            const banHours = nextCount >= 2 ? (100 * 365 * 24) : 6;
            const bannedUntil = new Date(Date.now() + banHours * 60 * 60 * 1000).toISOString();

            // Set profile banned state in Firestore
            await setDoc(doc(db, 'users', user.id), {
              banned_until: bannedUntil,
              device_ban_count: nextCount,
              ban_reason: `Attempted login on a 3rd device: ${getDeviceName()}`
            }, { merge: true });

            if (nextCount >= 2) {
              // Delete the user from the database directly if allowed (Firestore rules might prevent this for self, so we just permanently ban)
              // We'll also just fire and forget a delete request if we ever add an open endpoint, but the permanent ban works perfectly.
            }

            window.location.reload();
          }
        }
      } catch (err) {
        console.error('Failed to run device checks:', err);
      }
    };

    checkDeviceAndRegister();
  }, [user]);

  useEffect(() => {
    // Prevent body from scrolling when dashboard is active
    document.body.style.overflow = 'hidden';
    document.documentElement.style.overflow = 'hidden';
    
    return () => {
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
    };
  }, []);

  // Menu items list
  const menuItems = [
    { name: 'Dashboard', path: '/dashboard', icon: LayoutDashboard },
    { name: 'My Enrollments', path: '/dashboard/enrollments', icon: FileText },
    { name: 'Live Zoom Classes', path: '/dashboard/live-classes', icon: Video },
    ...(user?.role === 'admin' || user?.role === 'moderator' ? [
      { name: 'Live Studio', path: '/admin/live-class-studio', icon: Youtube },
    ] : []),
    { name: 'Routines', path: '/dashboard/routines', icon: Calendar },
    { name: 'Profile', path: '/dashboard/profile', icon: User },
    ...(user?.role === 'student' ? [
      { name: 'Manage Devices', path: '/dashboard/devices', icon: Smartphone }
    ] : []),
    { name: 'Student Recorded', path: '/dashboard/classes', icon: PlayCircle },
    ...(user?.student_type !== 'online' ? [
      { name: 'ID Card', path: '/dashboard/id-card', icon: CreditCard },
      { name: 'Chapters', path: '/dashboard/chapters', icon: FileText },
      { name: 'Attendance', path: '/dashboard/attendance', icon: Calendar },
      { name: 'Results', path: '/dashboard/results', icon: BarChart2 },
      { name: 'Exams', path: '/dashboard/exams', icon: CheckSquare },
      { name: 'Fees', path: '/dashboard/fees', icon: CreditCard },
    ] : []),
    { name: 'Class Slides', path: '/dashboard/class-slides', icon: FileText },
    { name: 'Study Materials', path: '/dashboard/materials', icon: FileText },
    { name: 'All Resources', path: '/dashboard/all-resources', icon: FileText },
    { name: 'Notices', path: '/dashboard/notices', icon: Bell },
  ];

  // Intercept fully if the student is online and currently banned
  const isBanned = user?.role === 'student' && user?.student_type === 'online' && user?.banned_until && new Date(user.banned_until) > new Date();

  if (isBanned) {
    return (
      <BanBanner
        bannedUntil={user.banned_until}
        reason={user.ban_reason}
        count={user.device_ban_count || 1}
        logout={logout}
        user={user}
      />
    );
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* Sidebar */}
      <motion.div 
        animate={{ width: isSidebarOpen ? 280 : 80 }}
        className="bg-white border-r border-slate-200 flex flex-col shadow-xl z-20 relative hidden lg:flex"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-orange-50/30">
          <Link to="/" className={`flex items-center gap-3 ${!isSidebarOpen && 'justify-center'}`}>
            <div className="h-11 w-11 bg-white p-1 rounded-2xl overflow-hidden flex items-center justify-center shadow-lg border border-slate-200/50">
              <img 
                src={settings.logo_url || "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512"} referrerPolicy="no-referrer" 
                alt="Logo" 
                className="w-full h-full object-contain" 
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512";
                }}
              />
            </div>
            {isSidebarOpen && (
              <div className="flex flex-col">
                <span className="font-black text-lg text-orange-600 tracking-tighter leading-tight">
                  {settings.site_name || "Jaber Math Care"}
                </span>
                <span className="text-[10px] font-bold text-orange-600 uppercase tracking-widest">Student Panel</span>
              </div>
            )}
          </Link>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-hide py-4 px-3 space-y-0.5">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-300 group ${
                  isActive 
                    ? 'bg-orange-600 text-white shadow-lg shadow-orange-900/20 translate-x-1' 
                    : 'text-slate-500 hover:bg-orange-50 hover:text-orange-600 hover:translate-x-1'
                } ${!isSidebarOpen && 'justify-center'}`}
              >
                <item.icon className={`h-5 w-5 ${isActive ? 'animate-pulse' : 'text-slate-400 group-hover:text-orange-600'}`} />
                {isSidebarOpen && <span className="font-bold text-sm tracking-tight">{item.name}</span>}
                {isSidebarOpen && isActive && <ChevronRight className="ml-auto h-4 w-4 opacity-50" />}
              </Link>
            );
          })}
        </div>

        <div className="p-4 border-t border-slate-100">
          {isSidebarOpen && <LiveClassButton className="mb-4 px-2" />}
          <button 
            onClick={logout}
            className={`flex items-center gap-3 w-full px-4 py-3 rounded-xl text-slate-500 hover:bg-red-50 hover:text-red-600 transition-colors ${!isSidebarOpen && 'justify-center'}`}
          >
            <LogOut className="h-5 w-5" />
            {isSidebarOpen && <span>Logout</span>}
          </button>
        </div>
      </motion.div>

      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isMobileSidebarOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsMobileSidebarOpen(false)}
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          />
        )}
      </AnimatePresence>

      {/* Mobile Sidebar */}
      <motion.div
        initial={{ x: -280 }}
        animate={{ x: isMobileSidebarOpen ? 0 : -280 }}
        transition={{ type: 'tween', duration: 0.2 }}
        className="fixed inset-y-0 left-0 w-72 bg-white shadow-2xl z-50 lg:hidden flex flex-col h-full"
      >
        <div className="p-6 border-b border-slate-100 flex items-center justify-between flex-shrink-0">
          <Link to="/" className="flex items-center gap-3">
            <div className="h-10 w-10 bg-white p-1 rounded-2xl overflow-hidden flex items-center justify-center shadow-lg border border-slate-200/50">
              <img 
                src={settings.logo_url || "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512"} referrerPolicy="no-referrer" 
                alt="Logo" 
                className="w-full h-full object-contain" 
                onError={(e) => {
                  (e.target as HTMLImageElement).src = "https://ui-avatars.com/api/?name=JMC&background=ea580c&color=fff&size=512";
                }}
              />
            </div>
            <div className="flex flex-col">
              <span className="font-black text-lg text-orange-600 tracking-tighter leading-tight">{settings.site_name || "Jaber Math Care"}</span>
              <span className="text-[10px] font-bold text-orange-600 uppercase tracking-widest">Student Panel</span>
            </div>
          </Link>
          <button 
            onClick={() => setIsMobileSidebarOpen(false)} 
            className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500"
          >
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="flex-1 overflow-y-auto scrollbar-hide py-4 px-3 space-y-0.5 touch-pan-y">
          {menuItems.map((item) => {
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setIsMobileSidebarOpen(false)}
                className={`flex items-center gap-3 px-4 py-2.5 rounded-xl transition-all duration-300 group ${
                  isActive 
                    ? 'bg-orange-600 text-white shadow-lg shadow-orange-900/20 translate-x-1' 
                    : 'text-slate-500 hover:bg-orange-50 hover:text-orange-600 hover:translate-x-1'
                }`}
              >
                <item.icon className={`h-5 w-5 ${isActive ? 'animate-pulse' : 'text-slate-400 group-hover:text-orange-600'}`} />
                <span className="font-bold text-sm tracking-tight">{item.name}</span>
                {isActive && <ChevronRight className="ml-auto h-4 w-4 opacity-50" />}
              </Link>
            );
          })}
        </div>
        <div className="p-4 border-t border-slate-100 flex-shrink-0">
          <button 
            onClick={logout}
            className="flex items-center gap-3 w-full px-4 py-3 rounded-xl text-slate-500 hover:bg-red-50 hover:text-red-600 transition-colors"
          >
            <LogOut className="h-4 w-4" />
            <span>Logout</span>
          </button>
        </div>
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        {/* Header */}
        <header className="bg-white border-b border-slate-200 h-16 flex items-center justify-between px-4 sm:px-6 shadow-sm z-10">
          <div className="flex items-center gap-3 sm:gap-4">
            <button 
              onClick={() => setIsMobileSidebarOpen(true)}
              className="lg:hidden p-2 text-slate-500 hover:bg-slate-100 rounded-lg"
            >
              <Menu className="h-6 w-6" />
            </button>
            <h1 className="text-xl font-bold text-orange-600 md:text-slate-800">
              {user?.role === 'admin' ? 'Admin Dashboard' : 'Student Panel'}
            </h1>
          </div>
          
          <div className="flex items-center gap-4">
            <Link to="/" className="hidden sm:flex items-center gap-2 text-sm font-medium text-slate-500 hover:text-orange-600 transition-colors bg-slate-50 px-4 py-2 rounded-full border border-slate-200 hover:border-orange-200">
              <Home className="h-4 w-4" /> Go to Website
            </Link>
            <div className="h-8 w-px bg-slate-200 mx-2 hidden sm:block"></div>
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block min-w-[100px]">
                <div className="text-sm font-bold text-slate-800 truncate">
                  {user?.role === 'admin' ? 'Admin' : (user?.name === 'W Sir' ? 'Please set your name' : (user?.name || 'Loading...'))}
                </div>
                <div className="text-[10px] text-slate-500 truncate max-w-[150px]">{user?.email || ''}</div>
                <div className="text-[9px] uppercase tracking-widest font-black text-orange-600">{user?.role || '...'}</div>
              </div>
              <div className="h-10 w-10 bg-orange-100 rounded-full flex items-center justify-center text-orange-600 font-bold border-2 border-orange-200 flex-shrink-0">
                {user?.name?.charAt(0) || '?'}
              </div>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden scrollbar-hide p-4 sm:p-5 lg:px-6 lg:py-6 bg-slate-50">
          <Suspense fallback={null}>
            <AnimatePresence mode="wait">
              <motion.div
                key={location.pathname}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.2 }}
              >
                {outlet}
              </motion.div>
            </AnimatePresence>
          </Suspense>
        </main>
        
        {/* Simple Footer for Dashboard */}
        <footer className="bg-white border-t border-slate-200 py-4 px-6 text-center text-xs text-slate-400">
          <p>&copy; {new Date().getFullYear()} {settings.site_name || "Jaber Math Care"}. All rights reserved.</p>
          <p className="mt-1 opacity-75">
            Developed By <Link to="/developer" className="hover:text-slate-600 underline decoration-slate-300 underline-offset-2 transition-all">Mohammad Jaber Bin Razzak</Link>
          </p>
        </footer>

      </div>
    </div>
  );
};

export default DashboardLayout;
