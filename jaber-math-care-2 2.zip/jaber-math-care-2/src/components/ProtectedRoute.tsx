import React from 'react';
import { useLocation, Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

interface ProtectedRouteProps {
  children: React.ReactNode;
  role?: string | string[];
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, role }) => {
  const { user, isAuthenticated, loading } = useAuth();
  const location = useLocation();

  // If we are loading but already have a user from localStorage, 
  // we can skip the loading screen to prevent layout jumps.
  if (loading && !user) {
    return null;
  }

  if (!isAuthenticated && !loading) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (user) {
    // If Admin/Moderator tries to access student /dashboard, redirect them to /admin
    if ((user.role === 'admin' || user.role === 'moderator') && (location.pathname === '/dashboard' || location.pathname.startsWith('/dashboard/'))) {
      return <Navigate to="/admin" replace />;
    }
    // If Student tries to access /admin or /scanner, redirect them to student /dashboard
    if (user.role === 'student' && (location.pathname === '/admin' || location.pathname === '/scanner')) {
      return <Navigate to="/" replace />;
    }
  }

  if (role) {
    const roles = Array.isArray(role) ? role : [role];
    if (!roles.includes(user?.role as any)) {
      return <Navigate to="/" replace />;
    }
  }

  return <>{children}</>;
};

export default ProtectedRoute;
