import express from "express";
import cors from "cors";
import { createServer as createViteServer } from "vite";
import path from "path";
import admin from "firebase-admin";
import { getFirestore } from "firebase-admin/firestore";
import fs from "fs";
import { sendSmtpEmail, sendAutosms } from "./messaging";

// Initialize Firebase Admin
let firebaseConfig: any = {};
try {
  const configPath = path.join(process.cwd(), "firebase-applet-config.json");
  if (fs.existsSync(configPath)) {
    firebaseConfig = JSON.parse(fs.readFileSync(configPath, "utf-8"));
  }
} catch (e: any) {
  console.warn("Could not read firebase-applet-config.json:", e.message);
}

if (!admin.apps.length) {
  let credential = admin.credential.applicationDefault();
  
  const localServiceAccountPath = path.join(process.cwd(), "firebase-service-account.json");
  if (fs.existsSync(localServiceAccountPath)) {
    try {
      const sa = JSON.parse(fs.readFileSync(localServiceAccountPath, "utf-8"));
      credential = admin.credential.cert(sa);
      console.log("Firebase Admin initialized using local firebase-service-account.json.");
    } catch (e: any) {
      console.warn("Failed to parse local firebase-service-account.json:", e.message);
    }
  } else if (process.env.FIREBASE_PRIVATE_KEY && process.env.FIREBASE_CLIENT_EMAIL && process.env.FIREBASE_PROJECT_ID) {
    credential = admin.credential.cert({
      projectId: process.env.FIREBASE_PROJECT_ID,
      clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
      privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
    });
    console.log("Firebase Admin initialized using individual env vars.");
  } else if (process.env.FIREBASE_SERVICE_ACCOUNT) {
    try {
      let sa = process.env.FIREBASE_SERVICE_ACCOUNT;
      if (typeof sa === "string") {
        sa = JSON.parse(sa);
      }
      // Handle case where user copy-pasted with quotes making it double encoded
      if (typeof sa === "string") {
        sa = JSON.parse(sa);
      }
      if (typeof sa !== "object" || sa === null) {
        throw new Error("Service account must be an object.");
      }
      credential = admin.credential.cert(sa);
      console.log("Firebase Admin initialized using FIREBASE_SERVICE_ACCOUNT secret.");
    } catch (e: any) {
      console.warn("Failed to parse FIREBASE_SERVICE_ACCOUNT:", e.message);
    }
  }

  const projectId = firebaseConfig.projectId || process.env.FIREBASE_PROJECT_ID;

  admin.initializeApp({
    credential,
    projectId: projectId,
  });
  console.log(
    `Firebase Admin initialized for project: ${projectId || "unknown"}`,
  );
}

let db: admin.firestore.Firestore;
try {
  const dbId =
    firebaseConfig.firestoreDatabaseId &&
    firebaseConfig.firestoreDatabaseId !== "(default)"
      ? firebaseConfig.firestoreDatabaseId
      : process.env.FIRESTORE_DATABASE_ID && process.env.FIRESTORE_DATABASE_ID !== "(default)"
      ? process.env.FIRESTORE_DATABASE_ID
      : undefined;

  if (dbId) {
    console.log("Using named database:", dbId);
    db = getFirestore(admin.app(), dbId);
  } else {
    console.log("Using default database");
    db = getFirestore(admin.app());
  }

  // Test connection
  db.collection("test")
    .doc("connection")
    .set(
      {
        last_verified: new Date().toISOString(),
      },
      { merge: true },
    )
    .then(async () => {
      console.log("Firestore connection verified.");
      try {
        const emailDoc = await db
          .collection("settings")
          .doc("smtp_email")
          .get();
        const passDoc = await db
          .collection("settings")
          .doc("smtp_password")
          .get();

        console.log(
          "[SMTP Boot Check] Loaded on startup - smtp_email:",
          emailDoc.exists ? emailDoc.data()?.value : "NOT SET",
        );
        console.log(
          "[SMTP Boot Check] Loaded on startup - smtp_password length:",
          passDoc.exists
            ? String(passDoc.data()?.value || "").length
            : "NOT SET",
        );

        const targetEmail = "jaberbhai69@gmail.com";
        const targetPassValue = "qkecrqatjnkmfurs";

        if (!emailDoc.exists) {
          await db
            .collection("settings")
            .doc("smtp_email")
            .set({ value: targetEmail }, { merge: true });
          console.log(
            "[SMTP Init] Auto-configured smtp_email to jaberbhai69@gmail.com",
          );
        }
        if (!passDoc.exists) {
          await db
            .collection("settings")
            .doc("smtp_password")
            .set({ value: targetPassValue }, { merge: true });
          console.log(
            "[SMTP Init] Auto-configured smtp_password key to qkecrqatjnkmfurs",
          );
        }
      } catch (e: any) {
        console.error(
          "[SMTP Init] Failed to auto-configure SMTP settings:",
          e.message,
        );
      }
    })
    .catch((err) => console.warn("Firestore test failed:", err.message));
} catch (error) {
  console.error("Critical error initializing Firestore SDK:", error);
  db = admin.firestore();
}

// Cascading delete helper functions
async function deleteStudentData(studentId: string) {
  try {
    const payments = await db
      .collection("payments")
      .where("student_id", "==", studentId)
      .get();
    for (const doc of payments.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error("Failed to delete payments for student:", studentId, e);
  }

  try {
    const attendance = await db
      .collection("attendance")
      .where("student_id", "==", studentId)
      .get();
    for (const doc of attendance.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error("Failed to delete attendance for student:", studentId, e);
  }

  try {
    const results = await db
      .collection("results")
      .where("student_id", "==", studentId)
      .get();
    for (const doc of results.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error("Failed to delete results for student:", studentId, e);
  }

  try {
    const enrollments = await db
      .collection("enrollments")
      .where("user_id", "==", studentId)
      .get();
    for (const doc of enrollments.docs) {
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error("Failed to delete enrollments for student:", studentId, e);
  }
}

async function deleteBatchData(batchId: string) {
  try {
    const students = await db
      .collection("users")
      .where("batch_id", "==", batchId)
      .get();
    for (const doc of students.docs) {
      try {
        await admin
          .auth()
          .deleteUser(doc.id)
          .catch(() => {});
        await deleteStudentData(doc.id);
        await doc.ref.delete();
      } catch (e) {
        console.error(
          "Failed to recursively delete student under batch:",
          doc.id,
          e,
        );
      }
    }

    const students2 = await db
      .collection("users")
      .where("batch_id_2", "==", batchId)
      .get();
    for (const doc of students2.docs) {
      try {
        await admin
          .auth()
          .deleteUser(doc.id)
          .catch(() => {});
        await deleteStudentData(doc.id);
        await doc.ref.delete();
      } catch (e) {
        console.error(
          "Failed to recursively delete student_2 under batch:",
          doc.id,
          e,
        );
      }
    }
  } catch (e) {
    console.error(
      "Failed to process student deletion under batch:",
      batchId,
      e,
    );
  }

  try {
    const exams = await db
      .collection("exams")
      .where("batch_id", "==", batchId)
      .get();
    for (const doc of exams.docs) {
      try {
        const results = await db
          .collection("results")
          .where("exam_id", "==", doc.id)
          .get();
        for (const rDoc of results.docs) {
          await rDoc.ref.delete().catch(() => {});
        }
        await doc.ref.delete().catch(() => {});
      } catch (examErr) {
        console.error(
          "Failed to cascade delete exam results:",
          doc.id,
          examErr,
        );
      }
    }
  } catch (e) {
    console.error("Failed to process exams under batch:", batchId, e);
  }

  const batchIdColls = [
    "attendance",
    "payments",
    "live_classes",
    "notices",
    "video_classes",
    "class_slides",
    "routines",
  ];
  for (const col of batchIdColls) {
    try {
      const items = await db
        .collection(col)
        .where("batch_id", "==", batchId)
        .get();
      for (const doc of items.docs) {
        await doc.ref.delete().catch(() => {});
      }
    } catch (e) {
      console.error(
        `Failed to delete col ${col} items under batch ${batchId}:`,
        e,
      );
    }
  }
}

async function deleteProgramData(programId: string) {
  try {
    const batches = await db
      .collection("batches")
      .where("program_id", "==", programId)
      .get();
    for (const doc of batches.docs) {
      await deleteBatchData(doc.id);
      await doc.ref.delete().catch(() => {});
    }
  } catch (e) {
    console.error(
      "Failed to process batches cascading deletion under program:",
      programId,
      e,
    );
  }

  try {
    const students = await db
      .collection("users")
      .where("program_id", "==", programId)
      .get();
    for (const doc of students.docs) {
      try {
        await admin
          .auth()
          .deleteUser(doc.id)
          .catch(() => {});
        await deleteStudentData(doc.id);
        await doc.ref.delete();
      } catch (e) {
        console.error(
          "Failed to recursively delete student under program:",
          doc.id,
          e,
        );
      }
    }
  } catch (e) {
    console.error("Failed to process students under program:", programId, e);
  }
}

export const app = express();
app.use(cors({ origin: true, credentials: true })); // Allow all cross-origin requests for decoupled frontend

async function startServer() {
  process.on("uncaughtException", (err) => {
    console.error("Critical Uncaught Exception:", err);
  });
  process.on("unhandledRejection", (reason, promise) => {
    console.error("Unhandled Rejection at:", promise, "reason:", reason);
  });

  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // Basic Security Headers to prevent hacking/inspection
  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-XSS-Protection", "1; mode=block");
    res.setHeader(
      "Strict-Transport-Security",
      "max-age=31536000; includeSubDomains",
    );
    next();
  });

  // Disable caching globally for all routes
  app.use((req, res, next) => {
    res.set(
      "Cache-Control",
      "no-store, no-cache, must-revalidate, proxy-revalidate",
    );
    res.set("Pragma", "no-cache");
    res.set("Expires", "0");
    res.set("Surrogate-Control", "no-store");
    next();
  });

  // Enable CORS so hosted static instances can talk to the server for bypassed endpoints
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Access-Control-Allow-Credentials", "true");
    } else {
      res.setHeader("Access-Control-Allow-Origin", "*");
    }
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization, X-Requested-With, Accept");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Middleware to verify Firebase ID Token
  const authenticate = async (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      console.log(
        `[AUTH] Missing or invalid Authorization header from ${req.method} ${req.url}`,
      );
      return res
        .status(401)
        .json({
          error: "Unauthorized",
          details: "Missing Authorization header",
        });
    }
    const idToken = authHeader.split("Bearer ")[1];
    try {
      // Use the default admin app for verification
      const decodedToken = await admin.auth().verifyIdToken(idToken);
      const email = (decodedToken.email || "").toLowerCase();
      console.log(`[AUTH] Authenticated: ${email}`);
      req.user = decodedToken;

      let superAdminEmails: string[] = [];
      try {
        const superAdminsDoc = await db.collection("settings").doc("super_admin_emails").get();
        if (superAdminsDoc.exists) {
          const val = superAdminsDoc.data()?.value;
          if (val && typeof val === "string") {
            superAdminEmails = val.split(",").map((e: string) => e.trim().toLowerCase());
          }
        }
      } catch (e) {
        console.error("Error reading super admin emails from settings:", e);
      }

      const adminEmails = [
        "jabermathcare@gmail.com",
        "tipsandtechunlimited@gmail.com",
        "jaberbhai69@gmail.com",
        "jaber@gmail.com",
        ...superAdminEmails
      ].map((e) => e.toLowerCase());

      if (adminEmails.includes(email)) {
        req.user.role = "admin";
      } else {
        const userDoc = await db.collection("users").doc(decodedToken.uid).get();
        if (userDoc.exists) {
          const role = userDoc.data()?.role;
          if (role === "admin" || role === "moderator") {
            req.user.role = role;
          } else {
            req.user.role = "student";
          }
        } else {
          req.user.role = "student";
        }
      }
      next();
    } catch (error: any) {
      console.error(`[AUTH] Error verifying token:`, error.message);
      res.status(401).json({ error: "Unauthorized", details: error.message });
    }
  };

  // API Routes

  // Diagnostic
  app.get("/api/admin/debug-auth", authenticate, (req: any, res) => {
    res.json({
      user: req.user,
      firebaseProjectId: admin.app().options.projectId,
      configProjectId: firebaseConfig.projectId,
    });
  });

  // Migration Route
  app.get("/migrate-results", async (req: any, res) => {
    try {
      const snapshot = await db.collection("results").get();
      let migrated = 0;
      for (const resultDoc of snapshot.docs) {
        const data = resultDoc.data();
        if (!data.roll_number || !data.student_name) {
          if (data.student_id) {
            const studentDoc = await db
              .collection("users")
              .doc(data.student_id)
              .get();
            if (studentDoc.exists) {
              await resultDoc.ref.update({
                roll_number: studentDoc.data()?.roll_number || "",
                student_name: studentDoc.data()?.name || "",
              });
              migrated++;
            }
          }
        }
      }
      res.json({ success: true, migrated });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/my-enrollments", authenticate, async (req: any, res) => {
    try {
      const email = (req.user.email || "").toLowerCase();
      const phone = req.user.phone_number || "";

      // 1. Get enrollments by user_id
      const snapshotById = await db
        .collection("enrollments")
        .where("user_id", "==", req.user.uid)
        .get();

      let enrollments: any[] = snapshotById.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));

      // 2. Get enrollments by email
      if (email) {
        const snapshotByEmail = await db
          .collection("enrollments")
          .where("email", "==", email)
          .get();
        snapshotByEmail.docs.forEach((doc) => {
          if (!enrollments.find((e) => e.id === doc.id)) {
            enrollments.push({ id: doc.id, ...doc.data() });
          }
        });
        
        // Also check gmail field if exists
        const snapshotByGmail = await db
          .collection("enrollments")
          .where("gmail", "==", email)
          .get();
        snapshotByGmail.docs.forEach((doc) => {
          if (!enrollments.find((e) => e.id === doc.id)) {
            enrollments.push({ id: doc.id, ...doc.data() });
          }
        });
      }

      // 3. Get enrollments by phone
      if (phone) {
        const snapshotByPhone = await db
          .collection("enrollments")
          .where("phone", "==", phone)
          .get();
        snapshotByPhone.docs.forEach((doc) => {
          if (!enrollments.find((e) => e.id === doc.id)) {
            enrollments.push({ id: doc.id, ...doc.data() });
          }
        });
      }

      // Deduplicate to show exactly one card per course/program/batch
      const uniqueEnrollments: any[] = [];
      for (const e of enrollments) {
        const isDuplicate = uniqueEnrollments.some((existing) => {
          if (e.course_id && existing.course_id && String(e.course_id) === String(existing.course_id)) {
            return true;
          }
          if (e.program_id && existing.program_id && String(e.program_id) === String(existing.program_id)) {
            if (String(e.batch_id) === String(existing.batch_id)) {
              return true;
            }
          }
          return false;
        });

        if (!isDuplicate) {
          uniqueEnrollments.push(e);
        } else {
          // Keep the one with approved/contacted status if duplicate exists
          const idx = uniqueEnrollments.findIndex((existing) => {
            if (e.course_id && existing.course_id && String(e.course_id) === String(existing.course_id)) {
              return true;
            }
            if (e.program_id && existing.program_id && String(e.program_id) === String(existing.program_id)) {
              if (String(e.batch_id) === String(existing.batch_id)) {
                return true;
              }
            }
            return false;
          });
          if (idx !== -1) {
            const existing = uniqueEnrollments[idx];
            const activeStatuses = ["approved", "contacted"];
            const existingIsActive = activeStatuses.includes(existing.status);
            const currentIsActive = activeStatuses.includes(e.status);
            if (!existingIsActive && currentIsActive) {
              uniqueEnrollments[idx] = e;
            }
          }
        }
      }

      res.json(uniqueEnrollments);
    } catch (error) {
      console.error("Error fetching my-enrollments:", error);
      res.status(500).json({ error: "Failed to fetch enrollments" });
    }
  });

  // Auth Profile
  app.get("/api/auth/profile", authenticate, async (req: any, res) => {
    try {
      const userDoc = await db.collection("users").doc(req.user.uid).get();
      if (!userDoc.exists)
        return res.status(404).json({ error: "User not found" });
      const data = userDoc.data();
      res.json({ id: userDoc.id, ...data });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  // Messages
  app.get("/api/messages", authenticate, async (req, res) => {
    try {
      const snapshot = await db
        .collection("messages")
        .orderBy("created_at", "desc")
        .get();
      const messages = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  // Settings
  app.get("/api/settings", async (req, res) => {
    try {
      const snapshot = await db.collection("settings").get();
      const settings: any = {};
      snapshot.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });
      res.json(settings);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: String(error) });
    }
  });

  app.get("/api/public/settings", async (req, res) => {
    try {
      const snapshot = await db.collection("settings").get();
      const settings: any = {};
      snapshot.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });
      res.json(settings);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: String(error) });
    }
  });

  app.get("/api/emailjs-debug", async (req, res) => {
    try {
      const pubDoc = await db.collection("settings").doc("emailjs_public_key").get();
      const srvDoc = await db.collection("settings").doc("emailjs_service_id").get();
      const tmplDoc = await db.collection("settings").doc("emailjs_template_id").get();
      const privDoc = await db.collection("settings").doc("emailjs_private_key").get();

      res.json({
        emailjs_public_key_exists: pubDoc.exists,
        emailjs_public_key_value: pubDoc.exists ? pubDoc.data()?.value : null,
        emailjs_service_id_exists: srvDoc.exists,
        emailjs_service_id_value: srvDoc.exists ? srvDoc.data()?.value : null,
        emailjs_template_id_exists: tmplDoc.exists,
        emailjs_template_id_value: tmplDoc.exists ? tmplDoc.data()?.value : null,
        emailjs_private_key_exists: privDoc.exists,
        emailjs_private_key_length: privDoc.exists
          ? String(privDoc.data()?.value || "").length
          : 0,
        emailjs_private_key_preview: privDoc.exists
          ? String(privDoc.data()?.value || "").substring(0, 3) + "..."
          : null,
      });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/email-logs-debug", async (req, res) => {
    try {
      const logsSnap = await db.collection("message_logs")
        .orderBy("timestamp", "desc")
        .limit(20)
        .get();
      const logs: any[] = [];
      logsSnap.forEach(doc => {
        logs.push({ id: doc.id, ...doc.data() });
      });
      res.json({ logs });
    } catch (e: any) {
      res.status(500).json({ error: e.message });
    }
  });

  app.get("/api/proxy-image", async (req, res) => {
    try {
      const url = req.query.url as string;
      if (!url) {
        return res.status(400).send("Missing url parameter");
      }
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Failed to fetch image: ${response.statusText}`);
      }
      const contentType = response.headers.get("content-type") || "image/png";
      const buffer = await response.arrayBuffer();
      res.setHeader("Content-Type", contentType);
      res.setHeader("Cache-Control", "public, max-age=86400");
      res.send(Buffer.from(buffer));
    } catch (e: any) {
      console.error("Proxy image error:", e);
      res.status(500).send(e.message);
    }
  });

  app.post("/api/settings", authenticate, async (req, res) => {
    try {
      const { key, value } = req.body;
      if (!key) return res.status(400).json({ error: "Key is required" });

      let cleanValue = value;
      if (key === "smtp_password" && typeof value === "string") {
        cleanValue = value.replace(/\s+/g, "");
      } else if (key === "smtp_email" && typeof value === "string") {
        cleanValue = value.trim().toLowerCase();
      }

      await db
        .collection("settings")
        .doc(key)
        .set({ value: cleanValue }, { merge: true });
      res.json({ success: true, value: cleanValue });
    } catch (error) {
      console.error("Error saving settings:", error);
      res.status(500).json({ error: "Failed to save settings" });
    }
  });

  // Special handling for enrollments (public for guests)
  app.post("/api/enrollments", async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ["image_url", "profile_pic", "student_image"]) {
          if (
            typeof parsed[key] === "string" &&
            parsed[key].includes("drive.google.com")
          ) {
            const match = parsed[key].match(
              /drive\.google\.com\/file\/d\/([^\/]+)/,
            );
            if (match && match[1]) {
              parsed[key] =
                `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };

      req.body = sanitizeUrls(req.body);
      const {
        email: rawEmail,
        gmail: rawGmail,
        password,
        phone,
        name,
        profile_pic,
        ...rest
      } = req.body;
      const email = rawEmail ? String(rawEmail).trim().toLowerCase() : "";
      const gmail = rawGmail ? String(rawGmail).trim().toLowerCase() : "";
      const userEmail = email || gmail;

      if (userEmail) {
        // Relaxing strict check: allow re-enrollment if the previous one is not 'pending' 
        // or simply allow it but warn. User requested "form fillup hoccena" likely due to this check.
        // We will remove the check to allow freedom of enrollment.
      }

      let uid = null;

      if (userEmail && password) {
        // We no longer create the auth user or the `users` document immediately during enrollment submission.
        // It will be created ONLY when the admin approves the enrollment.
      }

      const enrollmentData = {
        ...req.body,
        email: email || undefined,
        gmail: gmail || undefined,
        user_id: uid,
        status: "pending",
        created_at: new Date().toISOString(),
      };

      const docRef = await db.collection("enrollments").add(enrollmentData);
      res.json({ id: docRef.id, ...enrollmentData });
    } catch (error) {
      console.error("Enrollment error:", error);
      res.status(500).json({ error: "Failed to process enrollment" });
    }
  });

  // Special handling for messages (public for guests)
  app.post("/api/messages", async (req, res) => {
    try {
      const data = { ...req.body, created_at: new Date().toISOString() };
      await db.collection("messages").add(data);
      
      // Dispatch email to admin asynchronously
      db.collection("settings").doc("smtp_email").get().then(async (doc) => {
        const adminEmail = doc.exists ? doc.data()?.value : null;
        if (adminEmail) {
          await sendSmtpEmail({
            to: adminEmail,
            subject: `New Contact Form Submission: ${data.subject || "No Subject"}`,
            html: `Name: ${data.name}<br>Email: ${data.email}<br>Phone: ${data.phone}<br>Class: ${data.current_class}<br>School: ${data.school_name}<br>College: ${data.college_name}<br><br>Message:<br>${data.message}`,
            db: db,
            extraParams: data
          }).catch(err => console.error("Contact form email error:", err));
        }
      }).catch(err => console.error("Error fetching settings for contact email:", err));

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to send message" });
    }
  });
  app.get("/api/students", authenticate, async (req, res) => {
    try {
      let query: any = db.collection("users").where("role", "==", "student");
      Object.keys(req.query).forEach((key) => {
        if (key !== "t") query = query.where(key, "==", req.query[key]);
      });
      const snapshot = await query.get();
      res.json(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch students" });
    }
  });

  app.get("/api/students/:id", authenticate, async (req, res) => {
    try {
      const doc = await db.collection("users").doc(req.params.id).get();
      if (!doc.exists) return res.status(404).json({ error: "Not found" });
      let data: any = { id: doc.id, ...doc.data() };

      const [attendance, payments, results, enrollments] = await Promise.all([
        db.collection("attendance").where("student_id", "==", doc.id).get(),
        db.collection("payments").where("student_id", "==", doc.id).get(),
        db.collection("results").where("student_id", "==", doc.id).get(),
        db.collection("enrollments").where("user_id", "==", doc.id).get(),
      ]);

      data = {
        ...data,
        attendance: attendance.docs.map((d) => ({ id: d.id, ...d.data() })),
        payments: payments.docs.map((d) => ({ id: d.id, ...d.data() })),
        results: results.docs.map((d) => ({ id: d.id, ...d.data() })),
        enrolled_courses: enrollments.docs.map((d) => ({
          id: d.id,
          ...d.data(),
        })),
      };
      res.json(data);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch student details" });
    }
  });

  app.post("/api/students", authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ["image_url", "profile_pic", "student_image"]) {
          if (
            typeof parsed[key] === "string" &&
            parsed[key].includes("drive.google.com")
          ) {
            const match = parsed[key].match(
              /drive\.google\.com\/file\/d\/([^\/]+)/,
            );
            if (match && match[1]) {
              parsed[key] =
                `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };
      req.body = sanitizeUrls(req.body);
      const {
        email: rawEmail,
        password,
        name,
        enrollment_id,
        ...rest
      } = req.body;
      if (!rawEmail || !password)
        return res.status(400).json({ error: "Email and password required" });
      const email = String(rawEmail).trim().toLowerCase();

      // Enforce 1 course per student (one email address = at most 1 user profile)
      const usersSnap = await db
        .collection("users")
        .where("email", "==", email)
        .get();
      if (!usersSnap.empty) {
        return res.status(400).json({ error: "A student with this email address is already registered. Each student can only register for one course with a unique email address." });
      }

      let uid = "";
      try {
        const userRecord = await admin.auth().createUser({
          email: email,
          password,
          displayName: name,
        });
        uid = userRecord.uid;
      } catch (err: any) {
        const isAlreadyInUse =
          err.code === "auth/email-already-exists" ||
          err.code === "auth/email-already-in-use" ||
          String(err.message || "").includes("email-already-in-use") ||
          String(err.message || "").includes("email-already-exists") ||
          String(err.message || "").includes("already in use") ||
          String(err.message || "").includes("already exists");
        if (isAlreadyInUse) {
          const userRecord = await admin.auth().getUserByEmail(email);
          uid = userRecord.uid;
          await admin.auth().updateUser(uid, { password, displayName: name });
        } else {
          throw err;
        }
      }

      const userData = {
        ...rest,
        name,
        email: email,
        gmail: email,
        role: "student",
        status: "approved",
        initial_password: password,
        created_at:
          rest.created_at ||
          rest.admission_date ||
          rest.date_of_admission ||
          new Date().toISOString(),
      };
      await db.collection("users").doc(uid).set(userData, { merge: true });

      // Automatically record initial payment as admission fee if paid_amount is provided
      const paidAmountNum = Number(rest.paid_amount || 0);
      if (paidAmountNum > 0) {
        let batchName = "";
        let programId = rest.program_id || "";
        if (rest.batch_id) {
          try {
            const batchDoc = await db
              .collection("batches")
              .doc(rest.batch_id)
              .get();
            if (batchDoc.exists) {
              batchName = batchDoc.data()?.name || "";
              if (!programId) {
                programId = batchDoc.data()?.program_id || "";
              }
            }
          } catch (batchErr) {
            console.warn(
              "Failed to fetch batch details for payment record:",
              batchErr,
            );
          }
        }

        const now = new Date();
        const paymentDoc = {
          amount: paidAmountNum,
          type: "admission",
          date: now.toISOString().split("T")[0],
          month:
            rest.admission_month ||
            now.toLocaleString("en-US", { month: "long" }),
          year: rest.admission_year || now.getFullYear().toString(),
          status: "approved",
          student_id: uid,
          student_name: name,
          roll_number: rest.roll_number || "",
          batch_id: rest.batch_id || "",
          batch_name: batchName,
          program_id: programId,
          email: email.trim(),
          phone: rest.phone || "",
          payment_method: "Cash",
          method: "Cash",
          created_at: now.toISOString(),
        };
        try {
          await db.collection("payments").add(paymentDoc);
        } catch (paymentErr) {
          console.error("Failed to auto-record admission payment:", paymentErr);
        }
      }

      if (enrollment_id) {
        try {
          await db.collection("enrollments").doc(enrollment_id).update({
            status: "approved",
            user_id: uid,
          });
        } catch (e) {
          console.warn("Failed to update enrollment:", e);
        }
      }

      // Dispatch welcome email via SMTP
      if (email && email.trim()) {
        try {
          sendSmtpEmail({
            to: email.trim(),
            subject: "Admission Completed Successfully - Jaber Math Care",
            db: db,
            html: `
              <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
                <h2 style="color: #16a34a;">Welcome to Jaber Math Care!</h2>
                <p>Dear ${name || "Student"},</p>
                <p>Your admission for the program <strong>${rest.course_title || rest.program_title || "our course"}</strong> has been completed successfully.</p>
                <p>You can now log in to our portal using your registered email and password.</p>
                <div style="margin: 20px 0; padding: 15px; background: #f0fdf4; border-radius: 8px; border-left: 5px solid #16a34a;">
                  <p style="margin: 0;"><strong>Your Login Email:</strong> ${email.trim()}</p>
                  <p style="margin: 5px 0 0 0;"><strong>Your Password:</strong> ${password}</p>
                  ${rest.roll_number ? `<p style="margin: 5px 0 0 0;"><strong>Roll Number:</strong> ${rest.roll_number}</p>` : ""}
                  <p style="margin: 5px 0 0 0;"><strong>Program:</strong> ${rest.course_title || rest.program_title || "N/A"}</p>
                </div>
                <p>Best regards,<br/>Jaber Math Care Team</p>
              </div>
            `,
            extraParams: { name, student_name: name, password, email, roll_number: rest.roll_number, course_title: rest.course_title || rest.program_title, ...rest }
          }).catch(console.error);
        } catch (emailErr) {
          console.error("Failed to set up welcome email:", emailErr);
        }
      }

      // Dispatch welcome SMS with batch name
      const phoneToNotify = (rest.guardian_phone || rest.phone || "").trim();
      if (phoneToNotify) {
        try {
          let batchNameStr = "";
          if (rest.batch_id) {
            const batchDoc = await db.collection("batches").doc(rest.batch_id).get();
            if (batchDoc.exists) {
              batchNameStr = batchDoc.data()?.name || "";
            }
          }
          const rollStr = rest.roll_number || "N/A";
          const programStr = rest.course_title || rest.program_title || "Jaber Math Care Program";
          const usernameStr = rest.roll_number || email.split("@")[0] || email;
          const loginUrl = "https://jabermathcare.com";

          const smsMsg = `Welcome to Jaber Math Care!\n\n` +
                         `Name: ${name || "Student"}\n` +
                         `Roll: ${rollStr}\n` +
                         `Class: ${programStr}\n` +
                         `${batchNameStr ? `Batch: ${batchNameStr}\n` : ""}\n` +
                         `Account Details:\n` +
                         `Username: ${usernameStr}\n` +
                         `Password: ${password}\n\n` +
                         `Your account is approved! You can login to student portal.\n` +
                         `Login: ${loginUrl}`;

          sendAutosms(phoneToNotify, smsMsg, db).catch(console.error);
          console.log(`[OFFLINE SMS DISPATCH] Sent welcome message to ${phoneToNotify} for batch "${batchNameStr}"`);
        } catch (smsErr: any) {
          console.error("[OFFLINE SMS ERROR]:", smsErr.message || smsErr);
        }
      }

      res.json({ id: uid, ...userData });
    } catch (error: any) {
      console.error("Error creating student:", error);
      res
        .status(500)
        .json({ error: error.message || "Failed to create student" });
    }
  });

  app.put("/api/students/:id", authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ["image_url", "profile_pic", "student_image"]) {
          if (
            typeof parsed[key] === "string" &&
            parsed[key].includes("drive.google.com")
          ) {
            const match = parsed[key].match(
              /drive\.google\.com\/file\/d\/([^\/]+)/,
            );
            if (match && match[1]) {
              parsed[key] =
                `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };

      const payload = sanitizeUrls(req.body);
      const { password, confirmPassword, ...updateData } = payload;

      if (updateData.email) {
        updateData.email = String(updateData.email).trim().toLowerCase();
        updateData.gmail = updateData.email;
      } else if (updateData.gmail) {
        updateData.gmail = String(updateData.gmail).trim().toLowerCase();
        updateData.email = updateData.gmail;
      }

      // If a new password is provided during update, update it in Auth
      if (password && password.length >= 6) {
        try {
          await admin.auth().updateUser(req.params.id, { password });
          updateData.initial_password = password; // Optional: keep record of latest password if they want
        } catch (authErr) {
          console.warn(
            "Could not update auth password for student update:",
            authErr,
          );
        }
      }

      // If email is changed, update it in Auth
      if (updateData.email || updateData.gmail) {
        const newEmail = (updateData.email || updateData.gmail).trim().toLowerCase();
        try {
          await admin.auth().updateUser(req.params.id, { email: newEmail });
        } catch (authErr) {
          console.warn("Could not update auth email:", authErr);
        }
      }

      await db.collection("users").doc(req.params.id).update(updateData);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to update student" });
    }
  });

  app.delete("/api/students/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    try {
      // Also delete from Auth if possible (optional but good)
      try {
        await admin.auth().deleteUser(req.params.id);
      } catch (e) {
        console.log(
          "User not in Auth or delete failed, proceeding with Firestore delete",
        );
      }
      await deleteStudentData(req.params.id);
      await db.collection("users").doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete student" });
    }
  });

  app.delete(
    "/api/cancel-enrollment/:id",
    authenticate,
    async (req: any, res) => {
      try {
        const enrollmentRef = db.collection("enrollments").doc(req.params.id);
        const enrollmentDoc = await enrollmentRef.get();
        if (!enrollmentDoc.exists)
          return res.status(404).json({ error: "Enrollment not found" });

        const enrollmentData = enrollmentDoc.data() as any;

        const userRef = await db.collection("users").doc(req.user.uid).get();
        const userData = userRef.exists ? userRef.data() : null;

        const isOwner =
          (req.user.role === "admin" || req.user.role === "moderator") ||
          enrollmentData.user_id === req.user.uid ||
          (userData &&
            userData.email &&
            enrollmentData.email === userData.email) ||
          (userData &&
            userData.email &&
            enrollmentData.gmail === userData.email) ||
          (userData &&
            userData.phone &&
            enrollmentData.phone === userData.phone) ||
          (userData &&
            userData.phone &&
            enrollmentData.phone &&
            userData.phone.replace(/\\D/g, "").slice(-10) ===
              enrollmentData.phone.replace(/\\D/g, "").slice(-10));

        if (!isOwner) {
          return res.status(403).json({ error: "Forbidden" });
        }
        if (enrollmentData.status !== "pending" && req.user.role !== "admin" && req.user.role !== "moderator") {
          return res
            .status(400)
            .json({ error: "Only pending enrollments can be cancelled" });
        }

        await enrollmentRef.delete();
        res.json({ success: true });
      } catch (error) {
        console.error("Error cancelling enrollment:", error);
        res.status(500).json({ error: "Failed to cancel application" });
      }
    },
  );

  app.delete("/api/moderators/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    try {
      await db.collection("users").doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete moderator" });
    }
  });

  // Moderator CRUD
  app.get("/api/moderators", authenticate, async (req, res) => {
    try {
      const snapshot = await db
        .collection("users")
        .where("role", "==", "moderator")
        .get();
      res.json(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch moderators" });
    }
  });

  app.post("/api/moderators", authenticate, async (req, res) => {
    try {
      const sanitizeUrls = (obj: any) => {
        const parsed = { ...obj };
        for (const key of ["image_url", "profile_pic", "student_image"]) {
          if (
            typeof parsed[key] === "string" &&
            parsed[key].includes("drive.google.com")
          ) {
            const match = parsed[key].match(
              /drive\.google\.com\/file\/d\/([^\/]+)/,
            );
            if (match && match[1]) {
              parsed[key] =
                `https://drive.google.com/uc?export=view&id=${match[1]}`;
            }
          }
        }
        return parsed;
      };
      req.body = sanitizeUrls(req.body);
      const { email, password, name, ...rest } = req.body;
      const userRecord = await admin.auth().createUser({
        email: email.trim(),
        password,
        displayName: name,
      });
      const userData = {
        ...rest,
        name,
        email: email.trim(),
        role: "moderator",
        created_at: new Date().toISOString(),
      };
      await db.collection("users").doc(userRecord.uid).set(userData);
      res.json({ id: userRecord.uid, ...userData });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Enrollment Status & Approval
  app.put("/api/enrollments/:id/status", authenticate, async (req, res) => {
    try {
      const { status, roll_number, monthly_fee, admission_fee, batch_id } =
        req.body;
      const enrollmentRef = db.collection("enrollments").doc(req.params.id);
      const enrollmentDoc = await enrollmentRef.get();

      if (!enrollmentDoc.exists)
        return res.status(404).json({ error: "Enrollment not found" });

      const enrollmentData = enrollmentDoc.data() || {};

      // Update enrollment status
      await enrollmentRef.update({
        status,
        updated_at: new Date().toISOString(),
        ...(roll_number && { roll_number }),
        ...(monthly_fee && { monthly_fee }),
        ...(admission_fee && { admission_fee }),
        ...(batch_id && { batch_id }),
        payment_generated: status === "approved" ? true : undefined,
      });

      // Sync with user record
      if (status === "approved") {
        let uid = enrollmentData.user_id;
        const userEmail = String(
          enrollmentData.email ||
            enrollmentData.gmail ||
            enrollmentData.email_address ||
            "",
        )
          .trim()
          .toLowerCase();

        // Try to find user by email if uid is missing or invalid
        if (!uid && userEmail) {
          const userSnap = await db
            .collection("users")
            .where("email", "==", userEmail)
            .limit(1)
            .get();
          if (!userSnap.empty) {
            uid = userSnap.docs[0].id;
            await enrollmentRef.update({ user_id: uid });
          }
        }

        const isOnline = !!(
          enrollmentData.course_id ||
          enrollmentData.course_title ||
          enrollmentData.student_type === "online"
        );

        const updatePayload: any = {
          status: "approved",
          role: "student",
          updated_at: new Date().toISOString(),
        };

        if (roll_number) updatePayload.roll_number = roll_number;
        if (monthly_fee) updatePayload.monthly_fee = String(monthly_fee);
        if (admission_fee) updatePayload.admission_fee = String(admission_fee);
        if (batch_id) updatePayload.batch_id = String(batch_id);
        updatePayload.student_type = isOnline ? "online" : "offline";
        if (enrollmentData.phone) updatePayload.phone = enrollmentData.phone;
        if (enrollmentData.guardian_phone) updatePayload.guardian_phone = enrollmentData.guardian_phone;
        if (enrollmentData.address) updatePayload.address = enrollmentData.address;
        if (enrollmentData.school_name) updatePayload.school_name = enrollmentData.school_name;
        if (enrollmentData.college_name) updatePayload.college_name = enrollmentData.college_name;
        if (enrollmentData.blood_group) updatePayload.blood_group = enrollmentData.blood_group;
        if (enrollmentData.current_class) {
          updatePayload.current_class = enrollmentData.current_class;
          updatePayload.class = enrollmentData.current_class;
        } else if (enrollmentData.class) {
          updatePayload.current_class = enrollmentData.class;
          updatePayload.class = enrollmentData.class;
        }
        if (enrollmentData.password) {
          updatePayload.initial_password = enrollmentData.password;
        }

        if (uid) {
          const userRef = db.collection("users").doc(uid);
          const userDoc = await userRef.get();
          if (userDoc.exists) {
            const currentData = userDoc.data();
            if (enrollmentData.course_id) {
              const enrolledCourses = currentData?.enrolled_courses || [];
              if (!enrolledCourses.includes(enrollmentData.course_id)) {
                enrolledCourses.push(enrollmentData.course_id);
              }
              updatePayload.enrolled_courses = enrolledCourses;
            }
            // Update auth password if available and they were pending
            if (currentData?.status === "pending" && enrollmentData.password) {
              try {
                await admin
                  .auth()
                  .updateUser(uid, { password: enrollmentData.password });
              } catch (e) {}
            }
            await userRef.update(updatePayload);
            
            // Auto generate a payment record so delete enrollment doesn't lose the money tracking!
            const feeVal = Number(enrollmentData.fee) || 0;
            if (feeVal > 0) {
              const currentMonthName = new Date().toLocaleString('default', { month: 'long' });
              const paymentRef = db.collection("payments").doc();
              const paymentData: any = {
                student_id: uid,
                student_name: updatePayload.name || enrollmentData.name || currentData?.name || "Unknown",
                roll_number: roll_number || enrollmentData.roll_number || currentData?.roll_number || "",
                amount: feeVal.toString(),
                date: new Date().toISOString().split("T")[0],
                type: isOnline ? "course_enrollment" : "admission",
                month: currentMonthName,
                year: new Date().getFullYear().toString(),
                method: enrollmentData.payment_method || "online",
                created_at: new Date().toISOString()
              };
              if (isOnline && enrollmentData.course_id) {
                paymentData.course_id = enrollmentData.course_id;
              }
              await paymentRef.set(paymentData);
            }
          } else {
            // Recreate missing document
            const payload = { 
              ...enrollmentData, 
              ...updatePayload,
              enrolled_courses: enrollmentData.course_id ? [enrollmentData.course_id] : []
            };
            await userRef.set(payload);
          }
        } else if (userEmail) {
          // Create new user if not found
          const newUser: any = {
            ...enrollmentData,
            ...updatePayload,
            email: userEmail,
            student_type: isOnline ? "online" : "offline",
            enrolled_courses: enrollmentData.course_id ? [enrollmentData.course_id] : []
          };
          delete (newUser as any).id;
          try {
            const userRecord = await admin.auth().createUser({
              email: userEmail,
              password: enrollmentData.password || "Student@123",
              displayName: enrollmentData.name,
            });
            uid = userRecord.uid;
          } catch (authErr: any) {
            const isAlreadyInUse =
              authErr.code === "auth/email-already-exists" ||
              authErr.code === "auth/email-already-in-use" ||
              String(authErr.message || "").includes("email-already-in-use") ||
              String(authErr.message || "").includes("email-already-exists") ||
              String(authErr.message || "").includes("already in use") ||
              String(authErr.message || "").includes("already exists");
            if (isAlreadyInUse) {
              const existing = await admin.auth().getUserByEmail(userEmail);
              uid = existing.uid;
            } else {
              uid = db.collection("users").doc().id;
            }
          }
          await db.collection("users").doc(uid).set(newUser, { merge: true });
          await enrollmentRef.update({ user_id: uid });
        }

        // Send Approval Notification
        if (uid) {
          const nTitle = "Admission Approved";
          const nBody = `Congratulations! Your admission for ${enrollmentData?.course_title || enrollmentData?.program_title || "a program"} has been approved.`;
          await db.collection("notifications").add({
            user_id: uid,
            title: nTitle,
            message: nBody,
            type: "enrollment",
            is_read: false,
            created_at: new Date().toISOString(),
          });
        }

        // Load Settings for email
        let smtp_email, smtp_password;
        try {
          const emailDoc = await db
            .collection("settings")
            .doc("smtp_email")
            .get();
          const passDoc = await db
            .collection("settings")
            .doc("smtp_password")
            .get();
          smtp_email = emailDoc.exists ? emailDoc.data()?.value : undefined;
          smtp_password = passDoc.exists ? passDoc.data()?.value : undefined;
        } catch (e) {}

        // Send Email over SMTP
        if (userEmail) {
          try {
          sendSmtpEmail({
              to: userEmail,
              subject: "Admission Approved - Jaber Math Care",
              db: db,
              html: `
                <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
                  <h2 style="color: #16a34a;">Congratulations!</h2>
                  <p>Dear ${enrollmentData.name || "Student"},</p>
                  <p>Your admission request for the program <strong>${enrollmentData.course_title || enrollmentData.program_title || "our course"}</strong> has been successfully approved.</p>
                  <p>You can now log in to the Student Dashboard using your registered email and password.</p>
                  <div style="margin: 20px 0; padding: 15px; background: #f0fdf4; border-radius: 8px; border-left: 5px solid #16a34a;">
                    <p style="margin: 0;"><strong>Program:</strong> ${enrollmentData.course_title || enrollmentData.program_title || "N/A"}</p>
                    ${roll_number ? `<p style="margin: 5px 0 0 0;"><strong>Roll Number:</strong> ${roll_number}</p>` : ""}
                  </div>
                  <p>Best regards,<br/>Jaber Math Care Team</p>
                </div>
              `,
              extraParams: { ...enrollmentData, roll_number }
            }).catch(console.error);
          } catch (smtpErr: any) {
            console.error("SMTP Setup Error:", smtpErr.message || smtpErr);
          }
        }

        // Send SMS over Gateway on Admission Approval (prefer guardian phone first)
        const enrollmentPhone = (
          enrollmentData.guardian_phone ||
          enrollmentData.phone ||
          ""
        ).trim();
        if (enrollmentPhone) {
          try {
            const programStr = enrollmentData.course_title || enrollmentData.program_title || "நம்முடைய கோர்ஸ் / প্রোগ্রাম";
            const passwordStr = enrollmentData.password || "N/A";
            const emailStr = enrollmentData.email || "N/A";
            const usernameStr = roll_number || emailStr.split("@")[0] || "";
            const loginUrl = "https://jabermathcare.com";

            const smsMessage = `Welcome to Jaber Math Care!\n\n` +
                               `Name: ${enrollmentData.name || "Student"}\n` +
                               `Roll: ${roll_number || "N/A"}\n` +
                               `Class: ${programStr}\n` +
                               `${enrollmentData.batch_name ? `Batch: ${enrollmentData.batch_name}\n` : ""}\n` +
                               `Account Details:\n` +
                               `Username: ${usernameStr}\n` +
                               `${passwordStr !== "N/A" ? `Password: ${passwordStr}\n` : ""}\n` +
                               `Your account is approved! You can login to student portal.\n` +
                               `Login: ${loginUrl}`;

            sendAutosms(enrollmentPhone, smsMessage, db).catch(console.error);
          } catch (smsErr: any) {
            console.error(
              "Admission Setup Auto SMS Error:",
              smsErr.message || smsErr,
            );
          }
        }
      } else if (status === "rejected" || status === "cancelled") {
        // Handle Template for Rejection / Cancellation
        const enrollmentPhone = (enrollmentData.phone || enrollmentData.guardian_phone || "").trim();
        const userEmail = String(enrollmentData.email || enrollmentData.gmail || enrollmentData.email_address || "").trim().toLowerCase();
        const programStr = enrollmentData.course_title || enrollmentData.program_title || "your program";
        
        if (enrollmentPhone) {
          const smsMessage = `Jaber Math Care\n\nDear ${enrollmentData.name || "Student"},\nYour registration for ${programStr} has been ${status}.\nPlease contact our support team for more details.`;
          sendAutosms(enrollmentPhone, smsMessage, db).catch(console.error);
        }
        
        if (userEmail) {
          sendSmtpEmail({
            db,
            to: userEmail,
            subject: `Registration ${status.charAt(0).toUpperCase() + status.slice(1)} - Jaber Math Care`,
            html: `
              <div style="font-family: sans-serif; color: #333;">
                <h2>Jaber Math Care</h2>
                <p>Dear ${enrollmentData.name || "Student"},</p>
                <p>We regret to inform you that your registration for <strong>${programStr}</strong> has been <strong>${status}</strong>.</p>
                <p>If you believe this is a mistake, please reach out to our administration or support team.</p>
                <p>Best regards,<br/>Jaber Math Care Team</p>
              </div>
            `
          }).catch(console.error);
        }
      }

      res.json({ success: true });
    } catch (error: any) {
      console.error("Error updating status:", error);
      res.status(500).json({ error: "Failed to update status" });
    }
  });

  app.post("/api/approve-sponsorship", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator") return res.status(403).json({ error: "Forbidden" });
    try {
      const { id } = req.body;
      if (!id) return res.status(400).json({ error: "Missing ID" });

      const sponsorRef = db.collection("sponsorships").doc(id);
      const sponsorDoc = await sponsorRef.get();
      if (!sponsorDoc.exists) return res.status(404).json({ error: "Sponsorship not found" });

      const data = sponsorDoc.data() || {};
      await sponsorRef.update({ status: "active" });

      if (data.contact_email) {
        sendSmtpEmail({
          to: data.contact_email,
          subject: "Sponsorship Approved - Jaber Math Care",
          db: db,
          html: `
            <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
              <h2 style="color: #16a34a;">Sponsorship Approved!</h2>
              <p>Dear ${data.brand_name || "Partner"},</p>
              <p>We are excited to inform you that your sponsorship proposal for <strong>${data.brand_name}</strong> has been approved.</p>
              <p>Your banner is now active in our ecosystem. Thank you for supporting Jaber Math Care!</p>
              <div style="margin: 20px 0; padding: 15px; background: #f0fdf4; border-radius: 8px; border-left: 5px solid #16a34a;">
                <p style="margin: 0;"><strong>Brand:</strong> ${data.brand_name}</p>
                <p style="margin: 5px 0 0 0;"><strong>Status:</strong> Active</p>
              </div>
              <p>Best regards,<br/>Jaber Math Care Team</p>
            </div>
          `,
          extraParams: data
        }).catch(err => console.error("Sponsorship approval email error:", err));
      }

      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Student Search for Attendance
  app.get("/api/student-search", authenticate, async (req, res) => {
    try {
      const { batch_id, roll_number } = req.query;
      let q: any = db.collection("users").where("role", "==", "student");
      if (batch_id) q = q.where("batch_id", "==", String(batch_id));
      if (roll_number) q = q.where("roll_number", "==", String(roll_number));

      const snapshot = await q.get();
      if (snapshot.empty)
        return res.status(404).json({ error: "Student not found" });

      const student = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() };
      res.json(student);
    } catch (error) {
      res.status(500).json({ error: "Search failed" });
    }
  });

  app.get("/api/attendance/report", authenticate, async (req: any, res) => {
    try {
      const {
        batch_id,
        program_id,
        startDate,
        endDate,
        type,
        status,
        roll_number,
      } = req.query;
      let query: any = db.collection("attendance");

      if (batch_id && batch_id !== "all") {
        query = query.where("batch_id", "==", String(batch_id));
      } else if (program_id) {
        query = query.where("program_id", "==", String(program_id));
      }

      const snapshot = await query.get();
      let records = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

      // In-memory filtration to bypass complex composite index requirements
      if (program_id && batch_id && batch_id !== "all") {
        records = records.filter((r: any) => String(r.program_id) === String(program_id));
      }
      if (type) {
        records = records.filter((r: any) => {
          const rType = String(r.type || "").toLowerCase();
          const filterType = String(type).toLowerCase();
          if (filterType === "class" || filterType === "regular") {
            return rType === "class" || rType === "regular" || rType === "";
          }
          return rType === filterType;
        });
      }
      if (status) {
        records = records.filter((r: any) => String(r.status || "").toLowerCase() === String(status).toLowerCase());
      }
      if (roll_number) {
        records = records.filter((r: any) => String(r.roll_number || "") === String(roll_number));
      }

      // Apply date filters in memory if needed
      if (startDate || endDate) {
        records = records.filter((r: any) => {
          const d = r.date;
          if (startDate && d < startDate) return false;
          if (endDate && d > endDate) return false;
          return true;
        });
      }

      res.json(records);
    } catch (error) {
      console.error("Error fetching attendance report:", error);
      res.status(500).json({ error: "Failed to fetch attendance report" });
    }
  });

  // Standardize collection names (map URL paths to Firestore collection names)

  const collectionMap: Record<string, string> = {
    batches: "batches",
    programs: "programs",
    courses: "courses",
    notices: "notices",
    resources: "resources",
    routines: "routines",
    gallery: "gallery",
    exams: "exams",
    chapters: "chapters",
    "class-slides": "class_slides",
    payments: "payments",
    results: "results",
    reviews: "reviews",
    "video-classes": "video_classes",
    degrees: "degrees",
    "study-materials": "study_materials",
    "web-recorded-classes": "web_recorded_classes",
    "web-class-schedules": "web_class_schedules",
    enrollments: "enrollments",
    "live-classes": "live_classes",
    attendance: "attendance",
    "live-chat-messages": "live_chat_messages",
    "live-polls": "live_polls",
    "live-reactions": "live_reactions",
    "live-participants": "live_participants",
    coupons: "coupons",
    "exam-categories": "exam_categories",
    "exam-types": "exam_types",
    "result-histories": "result_histories",
    sponsorships: "sponsorships",
    messages: "messages",
    blogs: "blogs",
    events: "events",
  };

  const genericCollections = Object.keys(collectionMap);

  genericCollections.forEach((pathName) => {
    const collectionName = collectionMap[pathName];

    // GET all
    app.get(`/api/${pathName}`, authenticate, async (req, res) => {
      try {
        let query: any = db.collection(collectionName);
        Object.keys(req.query).forEach((key) => {
          if (key !== "t") query = query.where(key, "==", req.query[key]);
        });
        const snapshot = await query.get();
        res.json(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
      } catch (error) {
        console.error(`Error fetching ${pathName}:`, error);
        res.status(500).json({ error: `Failed to fetch ${pathName}` });
      }
    });

    // GET one
    app.get(`/api/${pathName}/:id`, authenticate, async (req, res) => {
      try {
        const doc = await db
          .collection(collectionName)
          .doc(req.params.id)
          .get();
        if (!doc.exists) return res.status(404).json({ error: "Not found" });
        res.json({ id: doc.id, ...doc.data() });
      } catch (error) {
        res.status(500).json({ error: "Failed to fetch document" });
      }
    });

    const sanitizeUrls = (obj: any) => {
      const parsed = { ...obj };
      for (const key of ["image_url", "profile_pic", "student_image"]) {
        if (
          typeof parsed[key] === "string" &&
          parsed[key].includes("drive.google.com")
        ) {
          const match = parsed[key].match(
            /drive\.google\.com\/file\/d\/([^\/]+)/,
          );
          if (match && match[1]) {
            parsed[key] =
              `https://drive.google.com/uc?export=view&id=${match[1]}`;
          }
        }
      }
      return parsed;
    };

    // POST
    if (pathName !== "enrollments" && pathName !== "messages") {
      app.post(`/api/${pathName}`, authenticate, async (req, res) => {
        try {
          const sanitizedBody = sanitizeUrls(req.body);
          const data = {
            ...sanitizedBody,
            created_at: new Date().toISOString(),
          };
          if (pathName === "payments" && !data.status) {
            data.status = "approved";
          }
          const docRef = await db.collection(collectionName).add(data);

          // Background tasks: SMS, Email, FCM Push
          if (["payments", "notices"].includes(pathName)) {
            (async () => {
              try {
                if (pathName === "notices") {
                  // Broadcast Push for Notices
                  const nTitle = data.title || "Notice Update";
                  const nMsg = data.content ? (data.content.substring(0, 100) + (data.content.length > 100 ? "..." : "")) : "A new notice has been published.";
                  
                  let studentQuery: any = db.collection("users").where("role", "==", "student");
                  
                  // Filter by batch/program if specified
                  if (data.batch_id && data.batch_id !== "all") {
                    studentQuery = studentQuery.where("batch_id", "==", data.batch_id);
                  } else if (data.program_id && data.program_id !== "all") {
                    studentQuery = studentQuery.where("program_id", "==", data.program_id);
                  }

                  const studentSnap = await studentQuery.get();
                  console.log(`[FCM NOTICE] Broadcasting to ${studentSnap.size} students for notice: ${nTitle}`);
                  
                  // Sequential or chunked send would be safer for very large lists, but for typical use this is okay:
                  return;
                }

                // Get student phone and email for payments/results
                const studentId = data.student_id;
                let phone = "";
                let studentEmail = "";
                let studentName = data.student_name || "Student";
                if (studentId) {
                  const studentDoc = await db
                    .collection("users")
                    .doc(studentId)
                    .get();
                  if (studentDoc.exists) {
                    const sData = studentDoc.data();
                    phone = sData?.guardian_phone || sData?.phone || "";
                    studentEmail =
                      sData?.email ||
                      sData?.gmail ||
                      sData?.gmail_address ||
                      sData?.email_address ||
                      "";
                    if (!studentName || studentName === "Student") {
                      studentName = sData?.name || "Student";
                    }
                  }
                }

                // Call fallback roll search if studentEmail is empty but roll_number exists
                const rawRoll = data.roll_number || data.roll;
                if (!studentEmail && rawRoll) {
                  const cleanedRoll = String(rawRoll).trim();
                  if (cleanedRoll) {
                    console.log(
                      `[${pathName.toUpperCase()} BACKGROUND] Checking student by roll_number: "${cleanedRoll}"`,
                    );
                    const rollSnap = await db
                      .collection("users")
                      .where("roll_number", "==", cleanedRoll)
                      .limit(1)
                      .get();
                    if (!rollSnap.empty) {
                      const sData = rollSnap.docs[0].data();
                      phone =
                        phone || sData?.guardian_phone || sData?.phone || "";
                      studentEmail =
                        sData?.email ||
                        sData?.gmail ||
                        sData?.gmail_address ||
                        sData?.email_address ||
                        "";
                      if (!studentName || studentName === "Student") {
                        studentName = sData?.name || "Student";
                      }
                      console.log(
                        `[${pathName.toUpperCase()} BACKGROUND] Success! Resolved student by roll_number: "${studentName}"`,
                      );
                    }
                  }
                }

                // Try to find by email if data is missing (checking fallbacks outside studentId condition)
                if (!studentEmail && data.email) studentEmail = data.email;
                if (!studentEmail && data.gmail) studentEmail = data.gmail;
                if (!studentEmail && data.email_address)
                  studentEmail = data.email_address;
                if (!studentEmail && data.gmail_address)
                  studentEmail = data.gmail_address;

                if (studentEmail) {
                  studentEmail = String(studentEmail).trim().toLowerCase();
                }
                if (!phone && data.guardian_phone) phone = data.guardian_phone;
                if (!phone && data.phone) phone = data.phone;

                console.log(
                  `[${pathName.toUpperCase()} BACKGROUND] studentId: ${studentId || "NONE"}, name: ${studentName}, email resolved: ${studentEmail || "NONE"}, phone resolved: ${phone || "NONE"}`,
                );

                if (studentId) {
                  // In-app notification
                  const nTitle = pathName === "payments" ? "Payment Received" : "Result Published";
                  const nMsg = pathName === "payments" 
                    ? `Your payment of ৳${data.amount} for ${data.month || "the month"} has been received.`
                    : `Your result for ${data.exam_name || "the exam"} has been published. Marks: ${data.marks}`;
                  
                  await db.collection("notifications").add({
                    user_id: studentId,
                    title: nTitle,
                    message: nMsg,
                    type: pathName,
                    is_read: false,
                    created_at: new Date().toISOString(),
                  }).catch(() => {});
                }

                if (studentEmail && studentEmail.includes("@")) {
                  console.log(`[${pathName.toUpperCase()} EMAIL] Sending to: ${studentEmail}`);
                  const sub = pathName === "payments" ? `Payment Receipt: ${data.month || ""} Fee` : `Result Published: ${data.exam_name || "Exam"}`;
                  const htmlStr = pathName === "payments" 
                    ? `<div style="text-align: center; margin-bottom: 25px;">
                        <span style="display: inline-block; padding: 6px 16px; background-color: #ecfdf5; color: #047857; font-weight: 700; font-size: 11px; border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em; border: 1px solid #a7f3d0; font-family: sans-serif;">
                          PAID
                        </span>
                       </div>
                       <p style="font-size: 15px; margin-top: 0; color: #1e293b; font-family: sans-serif;">
                         Dear <strong>${studentName || "Student"}</strong>,
                       </p>
                       <p style="font-size: 14px; color: #475569; line-height: 1.6; font-family: sans-serif;">
                         Your official payment receipt is presented below. Thank you for being with Jaber Math Care!
                       </p>
                       
                       <table border="0" cellpadding="0" cellspacing="0" width="100%" style="margin: 25px 0; background-color: #f8fafc; border-radius: 16px; border: 1px solid #e2e8f0; border-collapse: separate; overflow: hidden; font-family: sans-serif;">
                         <thead>
                           <tr bgcolor="#f1f5f9">
                             <th align="left" style="padding: 12px 16px; font-size: 11px; font-weight: 700; color: #475569; text-transform: uppercase; border-bottom: 1px solid #e2e8f0;">Description</th>
                             <th align="right" style="padding: 12px 16px; font-size: 11px; font-weight: 700; color: #475569; text-transform: uppercase; border-bottom: 1px solid #e2e8f0;">Amount</th>
                           </tr>
                         </thead>
                         <tbody>
                           <tr>
                             <td style="padding: 14px 16px; font-size: 14px; font-weight: 600; color: #1e293b; border-bottom: 1px solid #f1f5f9; text-align: left;">
                               ${data.month || "Current"} Fee Monthly Tuition
                               <div style="font-size: 11px; color: #94a3b8; font-weight: normal; margin-top: 3px;">
                                 Monthly Tuition Fee (Year: ${data.year || new Date().getFullYear()})
                               </div>
                             </td>
                             <td align="right" style="padding: 14px 16px; font-size: 15px; font-weight: 700; color: #0f172a; border-bottom: 1px solid #f1f5f9;">
                               ৳${data.amount}
                             </td>
                           </tr>
                           ${(data.payment_method || data.method) ? `
                           <tr>
                             <td style="padding: 10px 16px; font-size: 11px; color: #64748b; font-weight: 600; text-align: left; border-bottom: 1px solid #f1f5f9;">Payment Method</td>
                             <td align="right" style="padding: 10px 16px; font-size: 11px; color: #1e293b; font-weight: 700; border-bottom: 1px solid #f1f5f9;">${data.payment_method || data.method}</td>
                           </tr>` : ""}
                           ${(data.trx_id || data.transaction_id || data.slip_number) ? `
                           <tr>
                             <td style="padding: 10px 16px; font-size: 11px; color: #64748b; font-weight: 600; text-align: left; border-bottom: 1px solid #f1f5f9;">Transaction ID</td>
                             <td align="right" style="padding: 10px 16px; font-size: 11px; color: #1e293b; font-weight: 700; border-bottom: 1px solid #f1f5f9;">${data.trx_id || data.transaction_id || data.slip_number}</td>
                           </tr>` : ""}
                           ${data.date ? `
                           <tr>
                             <td style="padding: 10px 16px; font-size: 11px; color: #64748b; font-weight: 600; text-align: left;">Payment Date</td>
                             <td align="right" style="padding: 10px 16px; font-size: 11px; color: #1e293b; font-weight: 700;">${new Date(data.date).toLocaleDateString()}</td>
                           </tr>` : ""}
                         </tbody>
                         <tfoot>
                           <tr bgcolor="#f1f5f9">
                             <td style="padding: 14px 16px; font-size: 13px; font-weight: bold; color: #0f172a; text-align: left; border-top: 1px solid #e2e8f0;">Total Collected</td>
                             <td align="right" style="padding: 14px 16px; font-size: 16px; font-weight: 900; color: #10b981; border-top: 1px solid #e2e8f0;">৳${data.amount}</td>
                           </tr>
                         </tfoot>
                       </table>
                       
                       <p style="font-size: 13px; color: #64748b; font-family: sans-serif; text-align: center; margin-top: 25px;">
                         You can access your detailed account history on your student dashboard. Thank you!
                       </p>`
                    : `<div style="text-align: center; margin-bottom: 25px;">
                        <span style="display: inline-block; padding: 6px 16px; background-color: #eff6ff; color: #2563eb; font-weight: 700; font-size: 11px; border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em; border: 1px solid #bfdbfe; font-family: sans-serif;">
                          RESULT PUBLISHED
                        </span>
                       </div>
                       <p style="font-size: 15px; margin-top: 0; color: #1e293b; font-family: sans-serif;">
                         Dear <strong>${studentName || "Student"}</strong>,
                       </p>
                       <p style="font-size: 14px; color: #475569; line-height: 1.6; font-family: sans-serif;">
                         Your result for <strong>${data.exam_name || "Exam"}</strong> has been published. Your obtained score is listed below:
                       </p>
                       
                       <div style="margin: 25px 0; padding: 20px; background-color: #f8fafc; border-radius: 16px; border: 1px solid #e2e8f0; text-align: center; font-family: sans-serif;">
                         <div style="font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: 700;">Score / Marks Obtained</div>
                         <div style="font-size: 38px; font-weight: 900; color: #2563eb; margin: 10px 0;">${data.marks}</div>
                         <div style="font-size: 11px; color: #94a3b8;">Log in to the student dashboard to access detailed merit lists and answer sheets.</div>
                       </div>
                       
                       <p style="font-size: 13px; color: #64748b; font-family: sans-serif; text-align: center; margin-top: 25px;">
                         Wishing you a bright future,<br/>Jaber Math Care Team
                       </p>`;

                  await sendSmtpEmail({ to: studentEmail, subject: sub, html: htmlStr, db });
                }

                if (phone) {
                  console.log(`[${pathName.toUpperCase()} SMS] Sending to: ${phone}`);
                  const paymentId = data.payment_id || data.id || Math.floor(100000 + Math.random() * 900000).toString();
                  const smsMsg = pathName === "payments"
                    ? `Monthly payment for ${data.month || "Fee"} is successful\n` +
                      `Id: ${paymentId}\n` +
                      `Name: ${studentName || "Student"}\n` +
                      `Paid: ${data.amount || 0} TK\n\n` +
                      `Assigned by: Jaber Math Care\n` +
                      `Jaber Math Care`
                    : `Hey ${studentName || "Student"},\n` +
                      `Here is your result!\n` +
                      `Exam Name: ${data.exam_name || "Exam"}\n` +
                      `Exam Date: ${new Date().toLocaleDateString("en-US", { day: 'numeric', month: 'short', year: 'numeric' })}\n` +
                      `Marks: ${data.obtained_marks || data.marks || "N/A"}\n\n` +
                      `Jaber Math Care`;
                  await sendAutosms(phone, smsMsg, db);
                }
              } catch (e: any) {
                console.error(`[BACKGROUND TASK ERROR] ${pathName}:`, e.message);
              }
            })();
          }

          res.json({ id: docRef.id, ...data });
        } catch (error) {
          res.status(500).json({ error: `Failed to add ${pathName}` });
        }
      });
    }

    // PUT
    app.put(`/api/${pathName}/:id`, authenticate, async (req, res) => {
      try {
        const sanitizedBody = sanitizeUrls(req.body);
        delete sanitizedBody.id;
        Object.keys(sanitizedBody).forEach(key => {
          if (sanitizedBody[key] === undefined) {
            delete sanitizedBody[key];
          }
        });

        // Check if an exam is transitioning to published: true
        let isTransitioningToPublished = false;
        if (pathName === "exams" && sanitizedBody.published === true) {
          const existingExam = await db.collection("exams").doc(req.params.id).get();
          if (existingExam.exists && existingExam.data()?.published !== true) {
            isTransitioningToPublished = true;
          }
        }

        // Check if a sponsorship proposal is transitioning to active
        let sendApprovedEmail = false;
        let sponsorEmail = "";
        let brandName = "";
        if (pathName === "sponsorships" && sanitizedBody.status === "active") {
          const sponsorDoc = await db.collection("sponsorships").doc(req.params.id).get();
          if (sponsorDoc.exists) {
            const oldData = sponsorDoc.data();
            if (oldData?.status !== "active" && oldData?.email) {
              sendApprovedEmail = true;
              sponsorEmail = oldData.email;
              brandName = oldData.brand_name || "Sponsor";
            }
          }
        }

        await db
          .collection(collectionName)
          .doc(req.params.id)
          .update(sanitizedBody);

        res.json({ success: true });

        // Trigger Alerts in Background
        if (isTransitioningToPublished) {
          (async () => {
            try {
              const examId = req.params.id;
              const examDoc = await db.collection("exams").doc(examId).get();
              const examName = examDoc.exists ? examDoc.data()?.name || "Exam" : "Exam";

              const resultsSnap = await db.collection("results").where("exam_id", "==", examId).get();
              console.log(`[PUBLISH ALERTS] Found ${resultsSnap.size} results for exam "${examName}" (${examId}) to process.`);

              for (const rDoc of resultsSnap.docs) {
                const rData = rDoc.data();
                const studentId = rData.student_id;
                const roll_number = rData.roll_number || rData.roll;
                const marks = rData.marks;
                const merit_position = rData.merit_position || rData.merit || "N/A";
                const highest_marks = rData.highest_marks || "N/A";

                let phone = rData.guardian_phone || rData.phone || "";
                let studentEmail = rData.email || rData.gmail || "";
                let studentName = rData.student_name || "Student";

                if (studentId) {
                  const studentDoc = await db.collection("users").doc(studentId).get();
                  if (studentDoc.exists) {
                    const sData = studentDoc.data();
                    phone = phone || sData?.guardian_phone || sData?.phone || "";
                    studentEmail = studentEmail || sData?.email || sData?.gmail || sData?.gmail_address || sData?.email_address || "";
                    if (!studentName || studentName === "Student") {
                      studentName = sData?.name || "Student";
                    }
                  }
                }

                if (!studentEmail && roll_number) {
                  const cleanedRoll = String(roll_number).trim();
                  if (cleanedRoll) {
                    const rollSnap = await db.collection("users").where("roll_number", "==", cleanedRoll).limit(1).get();
                    if (!rollSnap.empty) {
                      const sData = rollSnap.docs[0].data();
                      phone = phone || sData?.guardian_phone || sData?.phone || "";
                      studentEmail = studentEmail || sData?.email || sData?.gmail || sData?.gmail_address || sData?.email_address || "";
                      if (!studentName || studentName === "Student") {
                        studentName = sData?.name || "Student";
                      }
                    }
                  }
                }

                if (studentEmail) {
                  studentEmail = String(studentEmail).trim().toLowerCase();
                }

                // Web Notification
                if (studentId) {
                  const nMsg = `Your result for ${examName} has been published. Marks: ${marks}, Merit Position: ${merit_position} (Highest: ${highest_marks}).`;
                  await db.collection("notifications").add({
                    user_id: studentId,
                    title: "Result Published",
                    message: nMsg,
                    type: "results",
                    is_read: false,
                    created_at: new Date().toISOString(),
                  }).catch(() => {});
                }

                // Email via SMTP
                if (studentEmail && studentEmail.includes("@")) {
                  const sub = `Result Published: ${examName}`;
                  const htmlStr = `<div style="text-align: center; margin-bottom: 25px;">
                      <span style="display: inline-block; padding: 6px 16px; background-color: #eff6ff; color: #2563eb; font-weight: 700; font-size: 11px; border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em; border: 1px solid #bfdbfe; font-family: sans-serif;">
                        RESULT PUBLISHED WITH MERIT RANKINGS
                      </span>
                     </div>
                     <p style="font-size: 15px; margin-top: 0; color: #1e293b; font-family: sans-serif;">
                       Dear <strong>${studentName}</strong>,
                     </p>
                     <p style="font-size: 14px; color: #475569; line-height: 1.6; font-family: sans-serif;">
                       Your result for <strong>${examName}</strong> has been published. Your score details and merit rankings are listed below:
                     </p>
                     
                     <div style="margin: 25px 0; padding: 25px; background-color: #f8fafc; border-radius: 16px; border: 1px solid #e2e8f0; font-family: sans-serif;">
                       <table border="0" cellpadding="8" cellspacing="0" width="100%" style="font-size: 14px; color: #334155;">
                         <tr>
                           <td width="50%" style="font-weight: 600; border-bottom: 1px solid #f1f5f9;">Obtained Marks:</td>
                           <td style="font-size: 20px; font-weight: 800; color: #2563eb; border-bottom: 1px solid #f1f5f9;">${marks}</td>
                         </tr>
                         <tr>
                           <td style="font-weight: 600; border-bottom: 1px solid #f1f5f9;">Highest Marks in Exam:</td>
                           <td style="font-weight: 700; color: #1e293b; border-bottom: 1px solid #f1f5f9;">${highest_marks}</td>
                         </tr>
                         <tr>
                           <td style="font-weight: 600;">Merit Position:</td>
                           <td style="font-size: 18px; font-weight: 800; color: #059669;">${merit_position}</td>
                         </tr>
                       </table>
                       <p style="font-size: 11px; color: #94a3b8; text-align: center; margin-top: 15px; margin-bottom: 0;">Log in to the student dashboard to access detailed merit lists and answer sheets.</p>
                     </div>
                     
                     <p style="font-size: 13px; color: #64748b; font-family: sans-serif; text-align: center; margin-top: 25px;">
                       Wishing you a bright future,<br/>Jaber Math Care Team
                     </p>`;
                  await sendSmtpEmail({ to: studentEmail, subject: sub, html: htmlStr, db }).catch(() => {});
                }

                // SMS
                if (phone) {
                  const examDateStr = rData.date ? new Date(rData.date).toLocaleDateString("en-US", { day: 'numeric', month: 'short', year: 'numeric' }) : new Date().toLocaleDateString("en-US", { day: 'numeric', month: 'short', year: 'numeric' });
                  const totalExamMarks = rData.total_exam_marks || rData.total_marks || "100";
                  const mcqMarks = rData.mcq_marks !== undefined ? rData.mcq_marks : marks;
                  const negMarks = rData.negative_marks !== undefined ? rData.negative_marks : "0";

                  const smsMsg = `Hey ${studentName || "Student"},\n` +
                                 `Here is your result!\n` +
                                 `Exam Name: ${examName}\n` +
                                 `Exam Date: ${examDateStr}\n` +
                                 `Marks: ${marks}/${totalExamMarks}\n` +
                                 `Merit: ${merit_position}\n` +
                                 `Highest Mark: ${highest_marks}\n\n` +
                                 `Jaber Math Care`;
                  await sendAutosms(phone, smsMsg, db).catch(() => {});
                }
              }
            } catch (alertErr: any) {
              console.error("[PUBLISH ALERTS ERROR]:", alertErr.message);
            }
          })();
        }

        if (sendApprovedEmail && sponsorEmail) {
          (async () => {
            try {
              await sendSmtpEmail({
                to: sponsorEmail,
                subject: "Sponsorship Proposal Approved - Jaber Math Care",
                db: db,
                html: `
                  <div style="font-family: sans-serif; padding: 25px; color: #1e293b; line-height: 1.6; max-width: 600px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 20px; background-color: #ffffff;">
                    <h2 style="color: #059669; text-align: center; margin-bottom: 20px;">Congratulations! Sponsorship Approved</h2>
                    <p>Dear Partner,</p>
                    <p>We are delighted to inform you that your sponsorship proposal for <strong>${brandName}</strong> has been officially approved and published on our platform!</p>
                    
                    <div style="margin: 25px 0; padding: 15px; background-color: #f0fdf4; border-radius: 12px; border-left: 6px solid #10b981;">
                      <p style="margin: 0; font-size: 14px; color: #065f46;"><strong>Brand Name:</strong> ${brandName}</p>
                      <p style="margin: 5px 0 0 0; font-size: 14px; color: #065f46;"><strong>Status:</strong> Active / Published</p>
                    </div>

                    <p>Your educational ad/banner code is now visible on our Support Page and Homepage. Thank you for supporting Jaber Math Care!</p>
                    <p style="margin-top: 30px; font-size: 13px; color: #64748b; border-top: 1px solid #f1f5f9; padding-top: 15px; text-align: center;">
                       Best regards,<br/><strong>Jaber Math Care Team</strong>
                    </p>
                  </div>
                `
              });
              console.log(`[SPONSOR APPROVAL EMAIL] Approved email sent to: ${sponsorEmail}`);
            } catch (smtpErr: any) {
              console.error("[SPONSOR APPROVAL EMAIL ERROR]:", smtpErr.message);
            }
          })();
        }

      } catch (error) {
        res.status(500).json({ error: "Failed to update document" });
      }
    });

    // DELETE
    app.delete(`/api/${pathName}/:id`, authenticate, async (req: any, res) => {
      if (req.user.role !== "admin" && req.user.role !== "moderator") {
        return res.status(403).json({ error: "Forbidden" });
      }
      try {
        const id = req.params.id;

        // Special handling for courses, programs, batches -> recursively delete students
        if (
          pathName === "courses" ||
          pathName === "programs" ||
          pathName === "batches"
        ) {
          if (pathName === "programs") {
            await deleteProgramData(id);
          } else if (pathName === "batches") {
            await deleteBatchData(id);
          } else if (pathName === "courses") {
            let fieldName = "course_id";
            // Find students matching this ID directly
            const studentsQuery = await db
              .collection("users")
              .where(fieldName, "==", id)
              .get();
              
            // Find students matching this ID inside enrolled_courses array
            const enrolledStudentsQuery = await db
              .collection("users")
              .where("enrolled_courses", "array-contains", id)
              .get();
              
            // Combine both sets of student docs
            const allStudentsToDelete = new Map();
            studentsQuery.docs.forEach(doc => allStudentsToDelete.set(doc.id, doc));
            enrolledStudentsQuery.docs.forEach(doc => allStudentsToDelete.set(doc.id, doc));

            for (const doc of Array.from(allStudentsToDelete.values())) {
              try {
                if (doc.id) {
                  await admin
                    .auth()
                    .deleteUser(doc.id)
                    .catch(() => {});
                  await deleteStudentData(doc.id);
                }
                await doc.ref.delete();
              } catch (err) {
                console.error(`Failed to delete student ${doc.id}:`, err);
              }
            }

            // Also delete sub-collections of courses as in old frontend logic
            const collectionsToDelete = [
              "chapters",
              "routines",
              "study_materials",
              "video_classes",
              "class_slides",
              "web_recorded_classes",
              "web_class_schedules",
              "live_classes",
              "notices",
              "payments",
              "enrollments",
              "attendance",
              "results"
            ];
            for (const colName of collectionsToDelete) {
              try {
                const items = await db
                  .collection(colName)
                  .where("course_id", "==", id)
                  .get();
                for (const itemDoc of items.docs) {
                  await itemDoc.ref.delete();
                }
              } catch (e) {
                console.error(
                  `Failed to delete sub-collection ${colName} of course ${id}:`,
                  e,
                );
              }
            }

            // Clean up exams associated with this course and their child results
            try {
              const examsQuery = await db
                .collection("exams")
                .where("course_id", "==", id)
                .get();
              for (const examDoc of examsQuery.docs) {
                try {
                  const resQuery = await db
                    .collection("results")
                    .where("exam_id", "==", examDoc.id)
                    .get();
                  for (const rDoc of resQuery.docs) {
                    await rDoc.ref.delete();
                  }
                  await examDoc.ref.delete();
                } catch (examErr) {
                  console.error(`Failed to delete course exam cascade:`, examErr);
                }
              }
            } catch (examsErr) {
              console.error(`Failed to request exams for course:`, examsErr);
            }
          }
        }

        await db.collection(collectionName).doc(id).delete();
        res.json({ success: true });
      } catch (error) {
        console.error(`[DELETE /api/${pathName}/:id] Error:`, error);
        res.status(500).json({ error: "Failed to delete document" });
      }
    });
  });

  // Special handling for attendance (Admin/Moderator only)
  app.post(
    "/api/attendance/mark-present",
    authenticate,
    async (req: any, res) => {
      if (req.user.role !== "admin" && req.user.role !== "moderator")
        return res.status(403).json({ error: "Forbidden" });
      try {
        const { student_id, batch_id, date, status, roll_number, type, time } = req.body;
        
        // Calculate exact Bangladesh local time (UTC+6) if not provided
        let localTime = time;
        if (!localTime) {
          const now = new Date();
          const bdTime = new Date(now.getTime() + 6 * 60 * 60 * 1000);
          let hours = bdTime.getUTCHours();
          const minutes = String(bdTime.getUTCMinutes()).padStart(2, "0");
          const ampm = hours >= 12 ? "PM" : "AM";
          hours = hours % 12;
          hours = hours ? hours : 12;
          localTime = `${String(hours).padStart(2, "0")}:${minutes} ${ampm}`;
        }

        const data: any = {
          student_id,
          batch_id,
          date: date || new Date().toLocaleDateString("en-CA"),
          status: status || "present",
          roll_number,
          type: type || "class",
          time: localTime,
          created_at: new Date().toISOString(),
        };
        const docRef = await db.collection("attendance").add(data);
        res.json({ id: docRef.id, ...data });
      } catch (error) {
        res.status(500).json({ error: "Failed to mark attendance" });
      }
    },
  );

  app.post(
    "/api/attendance/auto-absent",
    authenticate,
    async (req: any, res) => {
      if (req.user.role !== "admin" && req.user.role !== "moderator")
        return res.status(403).json({ error: "Forbidden" });
      try {
        const { batch_id, date, type = "class", exam_id } = req.body;
        if (!batch_id || !date)
          return res.status(400).json({ error: "batch_id and date required" });

        // Get all students in this batch (primary or secondary)
        const studentsSnapshot1 = await db
          .collection("users")
          .where("role", "==", "student")
          .where("batch_id", "==", String(batch_id))
          .get();

        const studentsSnapshot2 = await db
          .collection("users")
          .where("role", "==", "student")
          .where("batch_id_2", "==", String(batch_id))
          .get();

        const studentDocsMap = new Map();
        studentsSnapshot1.docs.forEach((doc) =>
          studentDocsMap.set(doc.id, doc),
        );
        studentsSnapshot2.docs.forEach((doc) =>
          studentDocsMap.set(doc.id, doc),
        );

        const allStudentDocs = Array.from(studentDocsMap.values());

        const studentIds = allStudentDocs.map((doc) => doc.id);

        // Get existing attendance for this date and batch and type
        const attendanceSnapshot = await db
          .collection("attendance")
          .where("batch_id", "==", String(batch_id))
          .where("date", "==", date)
          .where("type", "==", type)
          .get();

        const alreadyMarkedIds = new Set(
          attendanceSnapshot.docs.map((doc) => doc.data().student_id),
        );

        const batch = db.batch();
        let count = 0;

        for (const studentDoc of allStudentDocs) {
          if (!alreadyMarkedIds.has(studentDoc.id)) {
            const studentData = studentDoc.data();
            const attendanceRef = db.collection("attendance").doc();
            batch.set(attendanceRef, {
              student_id: studentDoc.id,
              batch_id: String(batch_id),
              date,
              status: "absent",
              type,
              roll_number: studentData.roll_number,
              isAuto: true,
              ...(exam_id && { exam_id: String(exam_id) }),
              created_at: new Date().toISOString(),
            });
            count++;
          }
        }

        if (count > 0) await batch.commit();
        res.json({ success: true, count });
      } catch (error) {
        console.error("Auto-absent error:", error);
        res.status(500).json({ error: "Failed to trigger auto-absent" });
      }
    },
  );

  app.post("/api/admin/clear-all-data", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    const { collection: collectionName } = req.body || {};
    try {
      if (collectionName) {
        const snapshot = await db.collection(collectionName).get();
        const batch = db.batch();
        snapshot.docs.forEach((doc) => batch.delete(doc.ref));
        await batch.commit();
      } else {
        // Clear ALL specified collections for a full reset
        const collectionsToClear = [
          "users", "batches", "payments", "enrollments", "attendance", "exams", 
          "results", "notices", "live_classes", "study_materials", "gallery", 
          "video_classes", "class_slides", "routines", "programs", "courses", 
          "chapters", "messages", "web_recorded_classes", "web_class_schedules",
          "exam_categories", "exam_types"
        ];
        
        for (const coll of collectionsToClear) {
          const snapshot = await db.collection(coll).get();
          const batch = db.batch();
          snapshot.docs.forEach((doc) => {
            // Safety: Never delete the admin user
            if (coll === "users" && doc.data()?.role === "admin") return;
            batch.delete(doc.ref);
          });
          if (snapshot.size > 0) {
            await batch.commit();
          }
        }
      }
      res.json({ success: true });
    } catch (error) {
      console.error("Reset Error:", error);
      res.status(500).json({ error: "Failed to clear data" });
    }
  });

  // Student Status Update
  app.patch("/api/students/:id/status", authenticate, async (req: any, res) => {
    try {
      const { status } = req.body;

      const userDoc = await db.collection("users").doc(req.params.id).get();
      if (!userDoc.exists)
        return res.status(404).json({ error: "User not found" });

      const userData = userDoc.data();
      const oldStatus = userData?.status;
      const updateData: any = { status };

      await db.collection("users").doc(req.params.id).update(updateData);

      // If approved and was not approved before, send notification
      if (status === "approved" && oldStatus !== "approved") {
        const email = (userData?.email || userData?.gmail || "").trim();
        if (email) {
          sendSmtpEmail({
            to: email,
            subject: "Enrollment Approved - Jaber Math Care",
            db: db,
            type: "admission_approved",
            req,
            data: {
              ...userData,
              name: userData.name || userData.student_name,
              password: userData.password || userData.initial_password || "User-Set Password"
            }
          }).catch(console.error);
        }
      }

      res.json({ success: true });
    } catch (error) {
      console.error("Failed to update student status:", error);
      res.status(500).json({ error: "Failed to update student status" });
    }
  });

  // Reset Data Route
  app.post("/api/reset-data", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    const { type } = req.body;
    try {
      const collections: Record<string, string> = {
        students: "users",
        online_students: "users",
        offline_students: "users",
        batches: "batches",
        payments: "payments",
        enrollments: "enrollments",
        attendance: "attendance",
        exams: "exams",
        results: "results",
        notices: "notices",
        live_classes: "live_classes",
        study_materials: "study_materials",
        gallery: "gallery",
        video_classes: "video_classes",
        class_slides: "class_slides",
        routines: "routines",
        programs: "programs",
        courses: "courses",
        chapters: "chapters",
        messages: "messages",
        web_recorded_classes: "web_recorded_classes",
        web_class_schedules: "web_class_schedules",
      };

      const collectionName = collections[type];
      if (!collectionName)
        return res.status(400).json({ error: "Invalid type" });

      let query: any = db.collection(collectionName);
      if (type === "online_students")
        query = query.where("student_type", "==", "online");
      if (type === "offline_students")
        query = query.where("student_type", "==", "offline");
      if (type === "students") query = query.where("role", "==", "student");

      const snapshot = await query.get();
      const batch = db.batch();
      snapshot.docs.forEach((doc: any) => {
        // Don't delete the admin user if resetting students
        if (collectionName === "users" && doc.data().role === "admin") return;
        batch.delete(doc.ref);
      });
      await batch.commit();
      res.json({ success: true });
    } catch (error) {
      console.error("Reset error:", error);
      res.status(500).json({ error: "Failed to reset data" });
    }
  });

  // Public routes (no auth needed for some GETs)
  app.get("/api/public/notices", async (req, res) => {
    try {
      const snapshot = await db
        .collection("notices")
        .where("is_verified", "==", true)
        .get();
      const notices = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      res.json(notices);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notices" });
    }
  });

  app.get("/api/public/results", async (req, res) => {
    try {
      const [resultsSnap, usersSnap] = await Promise.all([
        db.collection("results").get(),
        db.collection("users").get(),
      ]);
      const usersMap = new Map();
      usersSnap.docs.forEach((doc) => {
        usersMap.set(doc.id, doc.data());
      });
      const results = resultsSnap.docs.map((doc) => {
        const data = doc.data();
        let roll_number = data.roll_number;
        let student_name = data.student_name;
        if ((!roll_number || !student_name) && data.student_id) {
          const studentData = usersMap.get(data.student_id);
          if (studentData) {
            roll_number = studentData.roll_number || "";
            student_name = studentData.name || "";
          }
        }
        return {
          id: doc.id,
          ...data,
          roll_number,
          student_name,
        };
      });
      res.json(results);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: "Failed to fetch results" });
    }
  });

  app.get("/api/public/exams", async (req, res) => {
    try {
      const snapshot = await db.collection("exams").get();
      const exams = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      res.json(exams);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch exams" });
    }
  });

  app.get("/api/public/programs", async (req, res) => {
    try {
      const snapshot = await db.collection("programs").get();
      const programs = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      res.json(programs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch programs" });
    }
  });

  app.get("/api/public/batches", async (req, res) => {
    try {
      const snapshot = await db.collection("batches").get();
      const batches = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      res.json(batches);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch batches" });
    }
  });

  // SMS Integration
  app.post(
    "/api/notifications/broadcast",
    authenticate,
    async (req: any, res) => {
      try {
        const { user_ids, title, message, type } = req.body;
        if (!Array.isArray(user_ids))
          return res.status(400).json({ error: "user_ids must be an array" });

        const batch = db.batch();
        user_ids.forEach((uid) => {
          const ref = db.collection("notifications").doc();
          batch.set(ref, {
            user_id: uid,
            title,
            message,
            type: type || "announcement",
            is_read: false,
            created_at: new Date().toISOString(),
          });
        });

        await batch.commit();

        res.json({ success: true, count: user_ids.length });
      } catch (error) {
        console.error("Broadcast error:", error);
        res.status(500).json({ error: "Failed to broadcast notifications" });
      }
    },
  );

  app.post("/api/send-sms", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    try {
      const { phone, message } = req.body;
      if (!phone || !message) {
        return res
          .status(400)
          .json({ error: "Phone and message are required" });
      }

      // Extremely robust phone cleaning for Bangladeshi numbers
      let rawPhone = phone.split(",")[0].split("/")[0].trim();
      let digits = rawPhone.replace(/[^\d]/g, '');

      let cleanPhone = "";
      if (digits.startsWith('880') && digits.length === 13) {
        cleanPhone = digits;
      } else if (digits.startsWith('0') && digits.length === 11) {
        cleanPhone = '88' + digits;
      } else if (digits.startsWith('1') && digits.length === 10) {
        cleanPhone = '880' + digits;
      } else if (digits.length === 11 && digits.startsWith('01')) {
        cleanPhone = '88' + digits;
      } else {
        cleanPhone = digits;
      }

      const settingsSnapshot = await db.collection("settings").get();
      const settings: any = {};
      settingsSnapshot.docs.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });

      const apiUrltemp = settings.sms_api_url || "";
      let apiUrl = "https://api.sms.net.bd/sendsms";
      let apiKey = settings.sms_api_key || "zP8kOgQerj1oqFC6Bl7mmX0G173r28cVmINkOVg7";
      let senderId = settings.sms_sender_id || "";

      if (apiUrltemp && apiUrltemp.trim()) {
        apiUrl = apiUrltemp.trim();
      }

      const lowerUrl = apiUrl.toLowerCase();
      let method = 'POST';
      let contentType = 'application/x-www-form-urlencoded';
      const params = new URLSearchParams();

      // Determine unicode vs text
      const hasBangla = /[অ-ঞত-নপ-ময-রলশ-হড়ঢ়য়ৎংঃঁািীুূৃেৈোৌ্ৗ]/.test(message);
      const typeVal = hasBangla ? 'unicode' : 'text';

      if (lowerUrl.includes("sms.net.bd")) {
        method = 'POST';
        contentType = 'application/x-www-form-urlencoded';
        params.append('api_key', apiKey);
        params.append('msg', message);
        params.append('to', cleanPhone);
        if (senderId) params.append('sender_id', senderId);
      } else if (lowerUrl.includes("greenweb")) {
        method = 'GET';
        params.append('token', apiKey);
        params.append('to', cleanPhone);
        params.append('message', message);
      } else if (lowerUrl.includes("elitbuzz") || lowerUrl.includes("elitebuzz")) {
        method = 'GET';
        params.append('api_key', apiKey);
        params.append('contacts', cleanPhone);
        params.append('msg', message);
        params.append('senderid', senderId);
        params.append('type', typeVal);
      } else if (lowerUrl.includes("mimsms") || lowerUrl.includes("mim")) {
        method = 'GET';
        params.append('api_key', apiKey);
        params.append('contacts', cleanPhone);
        params.append('msg', message);
        params.append('senderid', senderId);
        params.append('type', typeVal);
      } else if (lowerUrl.includes("bulksmsbd")) {
        method = 'GET';
        params.append('api_key', apiKey);
        params.append('number', cleanPhone);
        params.append('message', message);
        params.append('senderid', senderId);
        params.append('type', typeVal);
      } else {
        // UNIVERSAL fallback pattern supporting both GET and POST with all potential keys
        method = 'GET';
        params.append('api_key', apiKey);
        params.append('apiKey', apiKey);
        params.append('token', apiKey);
        params.append('api_token', apiKey);

        params.append('to', cleanPhone);
        params.append('number', cleanPhone);
        params.append('contacts', cleanPhone);
        params.append('mobile', cleanPhone);

        params.append('msg', message);
        params.append('message', message);
        params.append('text', message);

        if (senderId) {
          params.append('sender_id', senderId);
          params.append('senderid', senderId);
          params.append('senderId', senderId);
        }
        params.append('type', typeVal);
      }

      let responseText = "";
      if (method === 'POST') {
        const response = await fetch(apiUrl, {
          method: 'POST',
          headers: {
            'Content-Type': contentType
          },
          body: params
        });
        responseText = await response.text();
        console.log(`[SMS Admin Broadcast POST] Gateway Response: ${responseText}`);
      } else {
        const urlObj = new URL(apiUrl);
        params.forEach((val, key) => {
          urlObj.searchParams.set(key, val);
        });
        const response = await fetch(urlObj.toString());
        responseText = await response.text();
        console.log(`[SMS Admin Broadcast GET] Gateway Response: ${responseText}`);
      }

      // Log success to message logs
      try {
        await db.collection('message_logs').add({
          type: 'SMS',
          to: cleanPhone,
          status: 'SENT',
          response: responseText,
          timestamp: new Date().toISOString()
        });
      } catch (logErr) {
        console.error("Failed to write to message logs:", logErr);
      }

      res.json({ success: true, response: responseText });
    } catch (error: any) {
      console.error("Error sending SMS:", error);
      res
        .status(500)
        .json({ error: "Failed to send SMS", details: error.message });
    }
  });

  app.post("/api/send-system-email", async (req, res) => {
    try {
      const { type, data } = req.body;
      if (!type || !data) {
        return res.status(400).json({ error: "Type and data are required" });
      }

      console.log(`[System SMTP] Received send-system-email request, type: ${type}`, data);

      let subject = "";
      let html = "";
      let recipient = data.email || data.gmail || "";

      // Fetch dynamic settings for branding
      const settingsSnap = await db.collection("settings").get();
      const settings: any = {};
      settingsSnap.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });
      const logoUrl = settings.logo_url || "https://cdn-icons-png.flaticon.com/512/4136/4136012.png";
      const siteName = settings.site_name || "Jaber Math Care";
      const fbUrl = settings.facebook_url || "https://facebook.com";
      const ytUrl = settings.youtube_url || "https://youtube.com";

      if (type === "student_welcome") {
        subject = "Admission Completed Successfully - Jaber Math Care";
        html = `
<div class="wrap-brand-framework" style="margin:0; padding:15px; background-color:#f0fdf4; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; -webkit-font-smoothing: antialiased; border-radius:24px; max-width:600px; width:100%;">
  <table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed; background-color:#f0fdf4; padding: 10px 0; border-radius:24px;">
    <tr>
      <td align="center">
        <!-- Card Container -->
        <table border="0" cellpadding="0" cellspacing="0" style="margin:10px auto; background-color:#ffffff; border-radius:24px; overflow:hidden; box-shadow:0 12px 24px -4px rgba(22,163,74,0.08); border:1px solid #dcfce7; width: 100%; max-width: 550px;">
          <!-- Top Accent Bar -->
          <tr>
            <td height="6" style="background: linear-gradient(90deg, #16a34a, #4ade80);"></td>
          </tr>
          <!-- Design Header -->
          <tr>
            <td align="center" style="padding:40px 30px 20px 30px; text-align:center;">
              <img src="${logoUrl}" alt="${siteName} Logo" width="84" height="84" style="width:84px; height:84px; object-fit:contain; border-radius:24px; padding:12px; display:block; margin: 0 auto 14px auto; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.06), 0 8px 10px -6px rgba(0,0,0,0.06); border: 1.5px solid #e2eaf4; background-color: #ffffff;" />
              <div style="font-size:32px; font-weight:900; color:#1e293b; margin:0; letter-spacing: -0.025em; font-family: sans-serif; line-height:1.2;">${siteName}</div>
              <div style="font-size:12px; font-weight:700; color:#16a34a; margin:6px 0 0 0; letter-spacing:0.05em; font-family: sans-serif;">The Future Math Education</div>
            </td>
          </tr>
          <!-- Elegant Line Divider -->
          <tr>
            <td style="padding: 0 35px;">
              <div style="border-bottom: 1px solid #dcfce7;"></div>
            </td>
          </tr>
          <!-- Body Message Area -->
          <tr>
            <td style="padding:35px 35px 30px 35px; color:#334155; font-size:15px; line-height:1.6; text-align:left; font-family: sans-serif;">
              <h2 style="color: #16a34a; font-size: 22px; font-weight: 800; margin: 0 0 10px 0; letter-spacing: -0.025em;">Welcome!</h2>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">Dear ${data.name || "Student"},</p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">
                Your admission for the program <strong>${data.course_title || data.program_title || "our course"}</strong> ${data.batch_name ? `(Batch: <strong>${data.batch_name}</strong>)` : ""} has been completed successfully.
              </p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 25px 0; line-height: 1.6;">
                You can now log in to our website using your registered email and password.
              </p>

              <div style="margin: 25px 0; padding: 20px; background-color: #f0fdf4; border-radius: 16px; border-left: 5px solid #16a34a; font-family: sans-serif;">
                <p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Your Login Email:</strong> <span style="color: #16a34a; font-weight: 700;">${recipient.trim()}</span></p>
                <p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Your Password:</strong> <span style="color: #111827; font-weight: 700;">${data.password || "N/A"}</span></p>
                ${data.roll_number ? `<p style="margin: 0; margin-bottom: 8px; font-size: 13px; color: #15803d;"><strong>Roll Number:</strong> <span style="color: #111827; font-weight: 700;">${data.roll_number}</span></p>` : ""}
                <p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Program:</strong> <span style="color: #111827; font-weight: 700;">${data.course_title || data.program_title || "N/A"}</span></p>
                ${data.batch_name ? `<p style="margin: 0; font-size: 13px; color: #15803d;"><strong>Batch:</strong> <span style="color: #111827; font-weight: 700;">${data.batch_name}</span></p>` : ""}
              </div>

              <div style="text-align: center; margin: 30px 0;">
                <a href="https://jabermathcare.com" target="_blank" style="display: inline-block; padding: 14px 28px; background-color: #16a34a; color: #ffffff; text-decoration: none; border-radius: 12px; font-weight: bold; font-size: 15px; font-family: sans-serif; box-shadow: 0 10px 15px -3px rgba(22, 163, 74, 0.3), 0 4px 6px -4px rgba(22, 163, 74, 0.3);">Visit Our Website</a>
              </div>

              <p style="font-size: 14px; color: #475569; line-height: 1.6; margin-top: 25px;">
                Best regards,<br/><strong>Jaber Math Care Team</strong>
              </p>
            </td>
          </tr>
          <!-- Footer Branding Section -->
          <tr>
            <td style="padding:25px 35px 30px 35px; background-color:#f9fbf9; border-top:1px solid #dcfce7; text-align:center; font-family: sans-serif;">
              <div style="font-size:13px; font-weight:700; color:#16a34a; margin:0;">${siteName}</div>
              <div style="font-size:11px; color:#15803d; margin:4px 0 16px 0;">${settings.hero_subtitle || "Where mathematical excellence meets engineering dreams, shaping the innovators of tomorrow."}</div>
              
              <!-- Social Links -->
              <table border="0" cellpadding="0" cellspacing="0" align="center" style="margin: 0 auto;">
                <tr>
                  ${fbUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${fbUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:#16a34a; font-weight:700;">Facebook Page</a>
                  </td>` : ''}
                  ${fbUrl && ytUrl ? `<td style="padding: 0 4px; color:#bbf7d0; font-size:11px;">•</td>` : ''}
                  ${ytUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${ytUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:#16a34a; font-weight:700;">YouTube Channel</a>
                  </td>` : ''}
                </tr>
              </table>
              
              <div style="font-size:10px; color:#15803d; margin-top:24px; font-family: sans-serif; line-height: 1.4;">
                © ${new Date().getFullYear()} ${siteName}. All rights reserved.<br />
                Developed by Mohammad Jaber Bin Razzak
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</div>
        `;
      } else if (type === "admission_approved") {
        subject = "Admission Approved - Jaber Math Care";
        html = `
<div class="wrap-brand-framework" style="margin:0; padding:15px; background-color:#f0fdf4; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; -webkit-font-smoothing: antialiased; border-radius:24px; max-width:600px; width:100%;">
  <table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed; background-color:#f0fdf4; padding: 10px 0; border-radius:24px;">
    <tr>
      <td align="center">
        <!-- Card Container -->
        <table border="0" cellpadding="0" cellspacing="0" style="margin:10px auto; background-color:#ffffff; border-radius:24px; overflow:hidden; box-shadow:0 12px 24px -4px rgba(22,163,74,0.08); border:1px solid #dcfce7; width: 100%; max-width: 550px;">
          <!-- Top Accent Bar -->
          <tr>
            <td height="6" style="background: linear-gradient(90deg, #16a34a, #4ade80);"></td>
          </tr>
          <!-- Design Header -->
          <tr>
            <td align="center" style="padding:40px 30px 20px 30px; text-align:center;">
              <img src="${logoUrl}" alt="${siteName} Logo" width="84" height="84" style="width:84px; height:84px; object-fit:contain; border-radius:24px; padding:12px; display:block; margin: 0 auto 14px auto; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.06), 0 8px 10px -6px rgba(0,0,0,0.06); border: 1.5px solid #e2eaf4; background-color: #ffffff;" />
              <div style="font-size:32px; font-weight:900; color:#1e293b; margin:0; letter-spacing: -0.025em; font-family: sans-serif; line-height:1.2;">${siteName}</div>
              <div style="font-size:12px; font-weight:700; color:#16a34a; margin:6px 0 0 0; letter-spacing:0.05em; font-family: sans-serif;">The Future Math Education</div>
            </td>
          </tr>
          <!-- Elegant Line Divider -->
          <tr>
            <td style="padding: 0 35px;">
              <div style="border-bottom: 1px solid #dcfce7;"></div>
            </td>
          </tr>
          <!-- Body Message Area -->
          <tr>
            <td style="padding:35px 35px 30px 35px; color:#334155; font-size:15px; line-height:1.6; text-align:left; font-family: sans-serif;">
              <h2 style="color: #16a34a; font-size: 22px; font-weight: 800; margin: 0 0 10px 0; letter-spacing: -0.025em;">Congratulations!</h2>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">Dear ${data.name || "Student"},</p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">
                Your admission request for the program <strong>${data.course_title || data.program_title || "our course"}</strong> ${data.batch_name ? `(Batch: <strong>${data.batch_name}</strong>)` : ""} has been successfully approved.
              </p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 25px 0; line-height: 1.6;">
                You can now log in to the Student Dashboard using your registered email and password. This template is all-device friendly, and you can visit our website for more updates.
              </p>

              <div style="margin: 25px 0; padding: 20px; background-color: #f0fdf4; border-radius: 16px; border-left: 5px solid #16a34a; font-family: sans-serif;">
                <p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Program Name:</strong> <span style="color: #111827; font-weight: 700;">${data.course_title || data.program_title || "N/A"}</span></p>
                ${data.batch_name ? `<p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Batch Name:</strong> <span style="color: #111827; font-weight: 700;">${data.batch_name}</span></p>` : ""}
                ${data.email || data.gmail ? `<p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Login Email:</strong> <span style="color: #111827; font-weight: 700;">${data.email || data.gmail}</span></p>` : ""}
                ${data.password || data.initial_password ? `<p style="margin: 0 0 8px 0; font-size: 13px; color: #15803d;"><strong>Password:</strong> <span style="color: #111827; font-weight: 700;">${data.password || data.initial_password}</span></p>` : ""}
                ${data.roll_number ? `<p style="margin: 0; font-size: 13px; color: #15803d;"><strong>Your Roll Number:</strong> <span style="color: #16a34a; font-weight: 700;">${data.roll_number}</span></p>` : ""}
              </div>

              <div style="text-align: center; margin: 30px 0;">
                <a href="${req ? 'https://' + req.get('host') : 'https://jabermathcare.com'}" target="_blank" style="display: inline-block; padding: 14px 28px; background-color: #16a34a; color: #ffffff; text-decoration: none; border-radius: 12px; font-weight: bold; font-size: 15px; font-family: sans-serif; box-shadow: 0 10px 15px -3px rgba(22, 163, 74, 0.3), 0 4px 6px -4px rgba(22, 163, 74, 0.3);">Visit Our Website</a>
              </div>

              <p style="font-size: 14px; color: #475569; line-height: 1.6; margin-top: 25px;">
                Best regards,<br/><strong>Jaber Math Care Team</strong>
              </p>
            </td>
          </tr>
          <!-- Footer Branding Section -->
          <tr>
            <td style="padding:25px 35px 30px 35px; background-color:#f9fbf9; border-top:1px solid #dcfce7; text-align:center; font-family: sans-serif;">
              <div style="font-size:13px; font-weight:700; color:#16a34a; margin:0;">${siteName}</div>
              <div style="font-size:11px; color:#15803d; margin:4px 0 16px 0;">${settings.hero_subtitle || "Where mathematical excellence meets engineering dreams, shaping the innovators of tomorrow."}</div>
              
              <!-- Social Links -->
              <table border="0" cellpadding="0" cellspacing="0" align="center" style="margin: 0 auto;">
                <tr>
                  ${fbUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${fbUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:#16a34a; font-weight:700;">Facebook Page</a>
                  </td>` : ''}
                  ${fbUrl && ytUrl ? `<td style="padding: 0 4px; color:#bbf7d0; font-size:11px;">•</td>` : ''}
                  ${ytUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${ytUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:#16a34a; font-weight:700;">YouTube Channel</a>
                  </td>` : ''}
                </tr>
              </table>
              
              <div style="font-size:10px; color:#15803d; margin-top:24px; font-family: sans-serif; line-height: 1.4;">
                © ${new Date().getFullYear()} ${siteName}. All rights reserved.<br />
                Developed by Mohammad Jaber Bin Razzak
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</div>
        `;
      } else if (type === "payment_receipt") {
        const invoiceNo = data.invoice_no || "INV-" + Math.floor(100000 + Math.random() * 900000);
        subject = `Paid Invoice & Receipt - ${invoiceNo}`;
        html = `
<div class="wrap-brand-framework" style="margin:0; padding:15px; background-color:#fff7ed; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; -webkit-font-smoothing: antialiased; border-radius:24px; max-width:600px; width:100%;">
  <table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed; background-color:#fff7ed; padding: 10px 0; border-radius:24px;">
    <tr>
      <td align="center">
        <!-- Card Container -->
        <table border="0" cellpadding="0" cellspacing="0" style="margin:10px auto; background-color:#ffffff; border-radius:24px; overflow:hidden; box-shadow:0 12px 24px -4px rgba(234,88,12,0.08); border:1px solid #ffedd5; width: 100%; max-width: 550px;">
          <!-- Top Accent Bar -->
          <tr>
            <td height="6" style="background: linear-gradient(90deg, #ea580c, #f97316);"></td>
          </tr>
          <!-- Design Header -->
          <tr>
            <td align="center" style="padding:40px 30px 20px 30px; text-align:center;">
              <img src="${logoUrl}" alt="${siteName} Logo" width="84" height="84" style="width:84px; height:84px; object-fit:contain; border-radius:24px; padding:12px; display:block; margin: 0 auto 14px auto; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.06), 0 8px 10px -6px rgba(0,0,0,0.06); border: 1.5px solid #e2eaf4; background-color: #ffffff;" />
              <div style="font-size:32px; font-weight:900; color:#1e293b; margin:0; letter-spacing: -0.025em; font-family: sans-serif; line-height:1.2;">${siteName}</div>
              <div style="font-size:12px; font-weight:700; color:#ea580c; margin:6px 0 0 0; letter-spacing:0.05em; font-family: sans-serif;">The Future Math Education</div>
            </td>
          </tr>
          <!-- Elegant Line Divider -->
          <tr>
            <td style="padding: 0 35px;">
              <div style="border-bottom: 1px solid #ffedd5;"></div>
            </td>
          </tr>
          <!-- Body Message Area -->
          <tr>
            <td style="padding:35px 35px 30px 35px; color:#334155; font-size:15px; line-height:1.6; text-align:left; font-family: sans-serif;">
              <div style="text-align: right; margin-bottom: 20px;">
                <span style="background-color: #ecfdf5; color: #047857; border: 1px solid #10b981; padding: 6px 14px; border-radius: 9999px; font-weight: bold; font-size: 11px; text-transform: uppercase; letter-spacing: 0.05em;">PAID INVOICE</span>
              </div>

              <h2 style="color: #1e293b; font-size: 22px; font-weight: 800; margin: 0 0 10px 0; letter-spacing: -0.025em;">Payment Confirmation</h2>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">Dear ${data.student_name || "Student"},</p>
              <p style="font-size: 14px; color: #475569; margin: 0 0 25px 0; line-height: 1.6;">
                Thank you for your payment. Your registration status is up to date, and we have generated your official digital paid invoice below.
              </p>

              <!-- Invoice Details Box -->
              <div style="border: 1px solid #ffedd5; border-radius: 16px; overflow: hidden; background-color: #fffbef; margin-bottom: 25px; font-family: sans-serif;">
                <div style="padding: 14px; background-color: #fff7ed; border-bottom: 1px solid #ffedd5;">
                  <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 12px; color: #c2410c;">
                    <tr>
                      <td><strong>INVOICE NO:</strong> ${invoiceNo}</td>
                      <td align="right"><strong>DATE:</strong> ${new Date().toLocaleDateString("en-US", { year: 'numeric', month: 'long', day: 'numeric' })}</td>
                    </tr>
                  </table>
                </div>
                <div style="padding: 16px;">
                  <p style="font-size: 11px; color: #ea580c; text-transform: uppercase; letter-spacing: 0.05em; margin: 0 0 6px 0;"><strong>Student Details:</strong></p>
                  <p style="font-size: 14px; color: #1e293b; font-weight: bold; margin: 0 0 4px 0;">${data.student_name || "Student"}</p>
                  ${recipient ? `<p style="font-size: 12px; color: #475569; margin: 0 0 2px 0;"><strong>Email:</strong> ${recipient}</p>` : ""}
                  ${data.phone ? `<p style="font-size: 12px; color: #475569; margin: 0;"><strong>Phone:</strong> ${data.phone}</p>` : ""}
                </div>
              </div>

              <!-- Items Table -->
              <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 13px; line-height: 1.6; border-collapse: collapse; margin-bottom: 25px; font-family: sans-serif;">
                <thead>
                  <tr style="border-bottom: 2px solid #ffedd5; font-weight: bold; color: #ea580c; text-transform: uppercase; font-size: 11px;">
                    <td style="padding: 10px 0; text-align: left;">Description</td>
                    <td align="right" style="padding: 10px 0;">Amount</td>
                  </tr>
                </thead>
                <tbody>
                  <tr style="border-bottom: 1px solid #ffedd5; color: #1e293b;">
                    <td style="padding: 14px 0; text-align: left;">
                      <div style="font-weight: bold; color: #1e293b; font-size: 14px;">Educational Tuition Fee</div>
                      <div style="font-size: 12px; color: #c2410c; margin-top: 3px;">
                        Billing Term: ${data.month || "Current"} Fee Monthly Tuition ${data.year ? `(Year: ${data.year})` : ""}
                        ${data.batch_name ? `<br/><span style="font-size: 11px; color: #64748b; font-weight: normal;">Batch Name: ${data.batch_name}</span>` : ""}
                      </div>
                    </td>
                    <td align="right" style="font-weight: bold; padding: 14px 0; font-size: 14px;">৳${data.amount}</td>
                  </tr>
                  <tr style="font-size: 15px; color: #1e293b; font-weight: bold;">
                    <td style="padding: 16px 0 0 0; text-transform: uppercase; letter-spacing: 0.02em;">Total Paid</td>
                    <td align="right" style="padding: 16px 0 0 0; font-size: 18px; color: #ea580c;">৳${data.amount}</td>
                  </tr>
                </tbody>
              </table>

              <div style="border-top: 1px dashed #fed7aa; padding-top: 20px; font-size: 11px; color: #c2410c; text-align: center; line-height: 1.5; font-family: sans-serif;">
                This paid invoice is generated electronically for educational enrollment at Jaber Math Care.<br/>If you have questions about this payment, please contact our support desk.
              </div>

              <div style="text-align: center; margin: 30px 0;">
                <a href="https://jabermathcare.com" target="_blank" style="display: inline-block; padding: 14px 28px; background-color: #ea580c; color: #ffffff; text-decoration: none; border-radius: 12px; font-weight: bold; font-size: 15px; font-family: sans-serif; box-shadow: 0 10px 15px -3px rgba(234, 88, 12, 0.3), 0 4px 6px -4px rgba(234, 88, 12, 0.3);">Visit Our Website</a>
              </div>
            </td>
          </tr>
          <!-- Footer Branding Section -->
          <tr>
            <td style="padding:25px 35px 30px 35px; background-color:#fffaf5; border-top:1px solid #ffedd5; text-align:center; font-family: sans-serif;">
              <div style="font-size:13px; font-weight:700; color:#ea580c; margin:0;">${siteName}</div>
              <div style="font-size:11px; color:#c2410c; margin:4px 0 16px 0;">${settings.hero_subtitle || "Where mathematical excellence meets engineering dreams, shaping the innovators of tomorrow."}</div>
              
              <!-- Social Links -->
              <table border="0" cellpadding="0" cellspacing="0" align="center" style="margin: 0 auto;">
                <tr>
                  ${fbUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${fbUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:#ea580c; font-weight:700;">Facebook Page</a>
                  </td>` : ''}
                  ${fbUrl && ytUrl ? `<td style="padding: 0 4px; color:#fed7aa; font-size:11px;">•</td>` : ''}
                  ${ytUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${ytUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:#ea580c; font-weight:700;">YouTube Channel</a>
                  </td>` : ''}
                </tr>
              </table>
              
              <div style="font-size:10px; color:#c2410c; margin-top:24px; font-family: sans-serif; line-height: 1.4;">
                © ${new Date().getFullYear()} ${siteName}. All rights reserved.<br />
                Developed by Mohammad Jaber Bin Razzak
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</div>
        `;
      } else if (type === "result_published") {
        subject = `Result Published: ${data.exam_name || "Exam"}`;
        html = `
<div class="wrap-brand-framework" style="margin:0; padding:15px; background-color:#f0f5ff; font-family:'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; -webkit-font-smoothing: antialiased; border-radius:24px; max-width:600px; width:100%;">
  <table border="0" cellpadding="0" cellspacing="0" width="100%" style="table-layout:fixed; background-color:#f0f5ff; padding: 10px 0; border-radius:24px;">
    <tr>
      <td align="center">
        <!-- Card Container -->
        <table border="0" cellpadding="0" cellspacing="0" style="margin:10px auto; background-color:#ffffff; border-radius:24px; overflow:hidden; box-shadow:0 12px 24px -4px rgba(37,99,235,0.08); border:1px solid #dbeafe; width: 100%; max-width: 550px;">
          <!-- Top Accent Bar -->
          <tr>
            <td height="6" style="background: linear-gradient(90deg, #2563eb, #3b82f6);"></td>
          </tr>
          <!-- Design Header -->
          <tr>
            <td align="center" style="padding:40px 30px 20px 30px; text-align:center;">
              <img src="${logoUrl}" alt="${siteName} Logo" width="84" height="84" style="width:84px; height:84px; object-fit:contain; border-radius:24px; padding:12px; display:block; margin: 0 auto 14px auto; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.06), 0 8px 10px -6px rgba(0,0,0,0.06); border: 1.5px solid #e2eaf4; background-color: #ffffff;" />
              <div style="font-size:32px; font-weight:900; color:#1e293b; margin:0; letter-spacing: -0.025em; font-family: sans-serif; line-height:1.2;">${siteName}</div>
              <div style="font-size:12px; font-weight:700; color:#2563eb; margin:6px 0 0 0; letter-spacing:0.05em; font-family: sans-serif;">The Future Math Education</div>
            </td>
          </tr>
          <!-- Elegant Line Divider -->
          <tr>
            <td style="padding: 0 35px;">
              <div style="border-bottom: 1px solid #dbeafe;"></div>
            </td>
          </tr>
          <!-- Body Message Area -->
          <tr>
            <td style="padding:35px 35px 30px 35px; color:#334155; font-size:15px; line-height:1.6; text-align:left; font-family: sans-serif;">
              <div style="text-align: center; margin-bottom: 25px;">
                <span style="display: inline-block; padding: 6px 16px; background-color: #eff6ff; color: #2563eb; font-weight: 700; font-size: 11px; border-radius: 9999px; text-transform: uppercase; letter-spacing: 0.05em; border: 1px solid #bfdbfe; font-family: sans-serif;">
                  RESULT PUBLISHED
                </span>
              </div>

              <h2 style="color: #2563eb; font-size: 22px; font-weight: 800; margin: 0 0 10px 0; letter-spacing: -0.025em; font-family: sans-serif;">Exam Result</h2>
              <p style="font-size: 14px; color: #475569; margin: 0 0 20px 0; line-height: 1.6;">Dear ${data.student_name || "Student"},</p>
              <p style="font-size: 14px; color: #475569; line-height: 1.6; font-family: sans-serif;">
                Your result for <strong>${data.exam_name || "the exam"}</strong> has been published. Your obtained score is listed below:
              </p>

              <div style="margin: 25px 0; padding: 20px; background-color: #f8fafc; border-radius: 16px; border: 1px solid #e2e8f0; text-align: center; font-family: sans-serif;">
                <div style="font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: 700;">Score / Marks Obtained</div>
                <div style="font-size: 38px; font-weight: 900; color: #2563eb; margin: 10px 0;">${data.marks}</div>
                <div style="font-size: 11px; color: #94a3b8; font-weight: normal; margin-top: 5px;">
                  Exam: ${data.exam_name || "Exam"}
                </div>
                ${data.batch_name ? `<div style="font-size: 11px; color: #64748b; font-weight: normal; margin-top: 2px;">Batch: ${data.batch_name}</div>` : ""}
                <div style="font-size: 11px; color: #94a3b8; margin-top: 5px;">Log in to the student dashboard to access detailed merit lists and answer sheets.</div>
              </div>

              <div style="text-align: center; margin: 30px 0;">
                <a href="https://jabermathcare.com" target="_blank" style="display: inline-block; padding: 14px 28px; background-color: #2563eb; color: #ffffff; text-decoration: none; border-radius: 12px; font-weight: bold; font-size: 15px; font-family: sans-serif; box-shadow: 0 10px 15px -3px rgba(37, 99, 235, 0.3), 0 4px 6px -4px rgba(37, 99, 235, 0.3);">Visit Our Website</a>
              </div>

              <p style="font-size: 14px; color: #475569; line-height: 1.6; margin-top: 25px;">
                Wishing you a bright future,<br/><strong>Jaber Math Care Team</strong>
              </p>
            </td>
          </tr>
          <!-- Footer Branding Section -->
          <tr>
            <td style="padding:25px 35px 30px 35px; background-color:#f8fafc; border-top:1px solid #dbeafe; text-align:center; font-family: sans-serif;">
              <div style="font-size:13px; font-weight:700; color:#2563eb; margin:0;">${siteName}</div>
              <div style="font-size:11px; color:#1d4ed8; margin:4px 0 16px 0;">${settings.hero_subtitle || "Where mathematical excellence meets engineering dreams, shaping the innovators of tomorrow."}</div>
              
              <!-- Social Links -->
              <table border="0" cellpadding="0" cellspacing="0" align="center" style="margin: 0 auto;">
                <tr>
                  ${fbUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${fbUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:#2563eb; font-weight:700;">Facebook Page</a>
                  </td>` : ''}
                  ${fbUrl && ytUrl ? `<td style="padding: 0 4px; color:#bfdbfe; font-size:11px;">•</td>` : ''}
                  ${ytUrl ? `
                  <td style="padding: 0 8px;">
                    <a href="${ytUrl}" target="_blank" style="text-decoration:none; font-size:12px; color:#2563eb; font-weight:700;">YouTube Channel</a>
                  </td>` : ''}
                </tr>
              </table>
              
              <div style="font-size:10px; color:#1d4ed8; margin-top:24px; font-family: sans-serif; line-height: 1.4;">
                © ${new Date().getFullYear()} ${siteName}. All rights reserved.<br />
                Developed by Mohammad Jaber Bin Razzak
              </div>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</div>
        `;
      } else if (type === "contact_submission") {
        recipient = data.adminEmail;
        subject = `New Contact Form Submission: ${data.subject || "No Subject"}`;
        html = `Name: ${data.name}<br>Email: ${data.email}<br>Phone: ${data.phone}<br>Class: ${data.current_class}<br>School: ${data.school_name}<br>College: ${data.college_name}<br><br>Message:<br>${data.message}`;
      } else {
        return res.status(400).json({ error: "Invalid type specified" });
      }

      const hasEmailAddress = !!(recipient && recipient.includes("@"));

      // Send SMS asynchronously if needed (prefer guardian phone first)
      const targetPhone = (data.guardian_phone || data.phone || "").trim();
      if ((type === "payment_receipt" || type === "result_published") && targetPhone) {
        let smsMsg = "";
        if (type === "payment_receipt") {
          const paymentId = data.payment_id || data.id || Math.floor(100000 + Math.random() * 900000).toString();
          smsMsg = `Monthly payment for ${data.month || "Fee"} is successful\n` +
                   `Id: ${paymentId}\n` +
                   `Name: ${data.student_name || "Student"}\n` +
                   `Paid: ${data.amount || 0} TK\n\n` +
                   `Assigned by: Jaber Math Care\n` +
                   `Jaber Math Care`;
        } else {
          smsMsg = `Hey ${data.student_name || "Student"},\n` +
                   `Here is your result!\n` +
                   `Exam Name: ${data.exam_name || "Exam"}\n` +
                   `Exam Date: ${new Date().toLocaleDateString("en-US", { day: 'numeric', month: 'short', year: 'numeric' })}\n` +
                   `Marks: ${data.obtained_marks || data.marks || "N/A"}\n\n` +
                   `Jaber Math Care`;
        }
        sendAutosms(targetPhone, smsMsg, db).catch(e => {
          console.error("[System SMTP] Quick SMS dispatch error:", e.message);
        });
      } else if (type === "admission_approved" && targetPhone) {
        const programStr = data.course_title || data.program_title || "Program";
        const passwordStr = data.password || "N/A";
        const emailStr = data.email || "N/A";
        const usernameStr = data.roll_number || emailStr.split("@")[0] || "";
        const loginUrl = "https://jabermathcare.com";

        const smsMsg = `Welcome to Jaber Math Care!\n\n` +
                       `Name: ${data.student_name || data.name || "Student"}\n` +
                       `Roll: ${data.roll_number || "N/A"}\n` +
                       `Class: ${programStr}\n` +
                       `${data.batch_name ? `Batch: ${data.batch_name}\n` : ""}\n` +
                       `Account Details:\n` +
                       `Username: ${usernameStr}\n` +
                       `${passwordStr !== "N/A" ? `Password: ${passwordStr}\n` : ""}\n` +
                       `Your account is approved! You can login to student portal.\n` +
                       `Login: ${loginUrl}`;

        sendAutosms(targetPhone, smsMsg, db).catch(e => {
          console.error("[System SMTP] Quick Approval SMS failure:", e.message);
        });
      }

      if (hasEmailAddress) {
        // Send Email
        console.log(`[System SMTP] Dispatching email to: ${recipient}`);
        const sendResult = await sendSmtpEmail({
          to: recipient,
          subject,
          html,
          db,
          extraParams: data,
        });

        if (!sendResult.success) {
          return res.status(500).json({ error: "SMTP Dispatch fail", details: sendResult.error });
        }
      } else {
        console.log(`[System SMTP] Skipping email delivery, no valid recipient address found. type: ${type}`);
      }

      res.json({ success: true, message: "Transactional message processed successfully" });
    } catch (e: any) {
      console.error("[System SMTP] General error in send-system-email endpoint:", e);
      res.status(500).json({ error: "System SMTP process error", details: e.message });
    }
  });

  const wrapInBrandedTemplate = (subject: string, message: string): string => {
    // If the message already looks like fully constructed HTML, return it. Otherwise wrap it.
    if (message.trim().toLowerCase().startsWith("<div") || message.trim().toLowerCase().startsWith("<!doctype")) {
      return message;
    }
    const cleanMessage = String(message || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\n/g, "<br/>");

    return `
      <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8fafc; padding: 40px 20px; color: #1e293b;">
        <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.05), 0 4px 6px -4px rgba(0, 0, 0, 0.05); border: 1px solid #e2e8f0;">
          <!-- Header Banner with Brand Color -->
          <div style="background: linear-gradient(135deg, #f97316 0%, #ea580c 100%); padding: 35px 20px; text-align: center;">
            <h1 style="color: #ffffff; margin: 0; font-size: 28px; font-weight: 800; letter-spacing: -0.5px; text-shadow: 0 2px 4px rgba(0,0,0,0.1);">JABER MATH CARE</h1>
            <p style="color: rgba(255, 255, 255, 0.9); margin: 6px 0 0 0; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 2px;">Official Notification</p>
          </div>
          
          <!-- Email Body -->
          <div style="padding: 40px 30px; font-size: 15px; line-height: 1.8; color: #334155;">
            ${subject ? `<h2 style="color: #1e293b; margin-top: 0; margin-bottom: 20px; font-size: 20px; font-weight: 700; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px;">${subject}</h2>` : ''}
            <div style="color: #475569;">
              ${cleanMessage}
            </div>
            
            <div style="margin-top: 30px; text-align: center;">
              <a href="${process.env.APP_URL || 'https://jabermathcare.com'}" style="display: inline-block; padding: 14px 28px; background-color: #ea580c; color: #ffffff; text-decoration: none; font-size: 14px; font-weight: bold; border-radius: 12px; box-shadow: 0 4px 15px rgba(234, 88, 12, 0.3); text-transform: uppercase; letter-spacing: 1px; transition: all 0.3s ease;">
                Visit Our Website
              </a>
            </div>
          </div>
          
          <!-- Footer Info -->
          <div style="background-color: #f8fafc; padding: 30px; text-align: center; border-top: 1px solid #e2e8f0;">
            <h4 style="margin: 0; font-size: 14px; font-weight: 700; color: #ea580c;">Jaber Math Care Team</h4>
            <p style="margin: 4px 0 0 0; font-size: 12px; color: #64748b;">Where mathematical excellence meets engineering dreams.</p>
            <div style="margin-top: 15px; display: inline-block; padding: 4px 12px; background-color: #ffedd5; border-radius: 9999px;">
              <span style="font-size: 11px; font-weight: 700; color: #c2410c; text-transform: uppercase; letter-spacing: 0.5px;">Do not reply directly to this email</span>
            </div>
          </div>
        </div>
      </div>
    `;
  };

  app.post("/api/send-email", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    try {
      const { email, to, subject, message } = req.body;
      const finalEmail = email || to;
      if (!finalEmail || !subject || !message) {
        return res
          .status(400)
          .json({ error: "Email, subject and message are required" });
      }

      // Pre-fetch settings once so that sendSmtpEmail doesn't need to query Firestore repetitively
      const settingsSnap = await db.collection("settings").get();
      const settings: any = {};
      settingsSnap.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });

      const formattedHtml = wrapInBrandedTemplate(subject, message);

      const sendResult = await sendSmtpEmail({
        to: finalEmail,
        subject,
        html: formattedHtml,
        smtp_email: settings.smtp_email,
        smtp_password: settings.smtp_password,
        db: db,
      });

      if (sendResult?.success === false) {
         return res.status(500).json({ error: "Failed to send Email", details: sendResult.error });
      }

      res.json({
        success: true,
        message: "Email dispatched successfully",
      });
    } catch (error: any) {
      console.error("Error sending Email:", error);
      res
        .status(500)
        .json({ error: "Failed to send Email", details: error.message });
    }
  });

  app.post("/api/send-email-bulk", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    try {
      const { emails, subject, message } = req.body;
      if (!emails || !Array.isArray(emails) || emails.length === 0 || !subject || !message) {
        return res
          .status(400)
          .json({ error: "Emails array, subject and message are required" });
      }

      const settingsSnap = await db.collection("settings").get();
      const settings: any = {};
      settingsSnap.forEach((doc) => {
        settings[doc.id] = doc.data().value;
      });

      if (settings.email_gateway_type !== "emailjs" && (!settings.smtp_email || !settings.smtp_password)) {
         return res.status(500).json({ error: "SMTP credentials not found in database and EmailJS is not enabled" });
      }

      const formattedHtml = wrapInBrandedTemplate(subject, message);

      let successCount = 0;
      let failedCount = 0;
      
      // Batch emails by 50 to avoid BCC limits
      for (let i = 0; i < emails.length; i += 50) {
        const batch = emails.slice(i, i + 50);
        
        const sendResult = await sendSmtpEmail({
          to: settings.smtp_email, // Self-address to hide BCC recipients
          bcc: batch.join(','),
          subject,
          html: formattedHtml,
          smtp_email: settings.smtp_email,
          smtp_password: settings.smtp_password,
          db: db,
        });

        if (sendResult?.success === false) {
           failedCount += batch.length;
           console.error("Bulk email error", sendResult.error);
        } else {
           successCount += batch.length;
         }
      }

      res.json({
        success: true,
        successCount,
        failedCount,
        message: "Bulk email dispatched successfully",
      });
    } catch (error: any) {
      console.error("Error sending bulk Email:", error);
      res
        .status(500)
        .json({ error: "Failed to send bulk Email", details: error.message });
    }
  });

  app.post("/api/verify-mail-settings", authenticate, async (req: any, res) => {
    console.log("[MAIL DIAGONISTIC TEST] Request received. body:", req.body);
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Forbidden" });
    try {
      const {
        email_gateway_type,
        // EmailJS settings
        emailjs_service_id,
        emailjs_template_id,
        emailjs_public_key,
        emailjs_private_key,
        // SMTP settings
        smtp_host,
        smtp_port,
        smtp_email,
        smtp_password,
        smtp_secure
      } = req.body;

      const activeGateway = email_gateway_type || "emailjs";

      try {
        await db.collection("settings").doc("email_gateway_type").set({ value: activeGateway, updated_at: admin.firestore.FieldValue.serverTimestamp() }, { merge: true });
      } catch (dbErr: any) {
        console.warn("[verify-mail-settings] Warning: Failed to write to 'settings' collection inside backend server:", dbErr.message);
      }

      let targetRecipient = req.user?.email || "jaberbhai69@gmail.com";

      // Dynamically load settings based on requested gateway
      const testParams: any = {
        to: targetRecipient,
        subject: activeGateway === "smtp" ? `SMTP Mailer Connection Test - Jaber Math Care` : `EmailJS Gateway Connection Test - Jaber Math Care`,
        html: `
          <div style="font-family: sans-serif; padding: 20px; color: #333; line-height: 1.6;">
            <p style="font-size: 18px; font-weight: bold; color: #16a34a;">Test Succeeded!</p>
            <p>Congratulations, your <strong>${activeGateway === "smtp" ? "SMTP Server Transport" : "EmailJS API Gateway"}</strong> has successfully connected and worked.</p>
            <p>Automated transactional messages will now be dispatched without issue!</p>
            <p>Best regards,<br/>Jaber Math Care system</p>
          </div>
        `,
        db: db,
        email_gateway_type: activeGateway
      };

      if (activeGateway === "smtp") {
        testParams.smtp_host = smtp_host;
        testParams.smtp_port = smtp_port;
        testParams.smtp_email = smtp_email;
        testParams.smtp_password = smtp_password;
        testParams.smtp_secure = smtp_secure;
      } else {
        testParams.emailjs_service_id = emailjs_service_id;
        testParams.emailjs_template_id = emailjs_template_id;
        testParams.emailjs_public_key = emailjs_public_key;
        testParams.emailjs_private_key = emailjs_private_key;
      }

      const sendResult = await sendSmtpEmail(testParams);

      if (sendResult?.success === false) {
        return res.status(500).json({ error: "Diagnostics dispatch failed", details: sendResult.error });
      }

      res.json({
        success: true,
        message: activeGateway === "smtp" 
          ? `SMTP Direct Connection verified successfully! A test email has been dispatched to ${targetRecipient}`
          : `EmailJS Direct Gateway API verified successfully! A test template has been requested to ${targetRecipient}`,
      });
    } catch (error: any) {
      console.error("Mail testing connection failed:", error);
      res
        .status(500)
        .json({ error: "Mail Connection Failed", details: error.message });
    }
  });

  // Coupons
  app.get("/api/coupons", authenticate, async (req: any, res) => {
    try {
      const snapshot = await db.collection("coupons").get();
      res.json(snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch coupons" });
    }
  });

  app.post("/api/coupons", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Not authorized" });
    try {
      const { code, type, value, expiry_date, status } = req.body;
      const couponData = {
        code: code.toUpperCase(),
        type,
        value: Number(value),
        expiry_date,
        status: status || "active",
        created_at: new Date().toISOString(),
      };
      const docRef = await db.collection("coupons").add(couponData);
      res.json({ id: docRef.id, ...couponData });
    } catch (error) {
      res.status(500).json({ error: "Failed to create coupon" });
    }
  });

  app.delete("/api/coupons/:id", authenticate, async (req: any, res) => {
    if (req.user.role !== "admin" && req.user.role !== "moderator")
      return res.status(403).json({ error: "Not authorized" });
    try {
      await db.collection("coupons").doc(req.params.id).delete();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete coupon" });
    }
  });

  app.post("/api/validate-coupon", async (req, res) => {
    try {
      const { code, amount } = req.body;
      const snapshot = await db
        .collection("coupons")
        .where("code", "==", code.toUpperCase())
        .where("status", "==", "active")
        .get();

      if (snapshot.empty)
        return res.status(404).json({ error: "Invalid coupon code" });

      const coupon = snapshot.docs[0].data();
      const now = new Date();
      if (coupon.expiry_date && new Date(coupon.expiry_date) < now) {
        return res.status(400).json({ error: "Coupon has expired" });
      }

      let discount = 0;
      if (coupon.type === "percentage") {
        discount = (Number(amount) * Number(coupon.value)) / 100;
      } else {
        discount = Number(coupon.value);
      }

      res.json({
        valid: true,
        discount: Math.min(discount, Number(amount)),
        final_amount: Math.max(0, Number(amount) - discount),
        coupon_id: snapshot.docs[0].id,
      });
    } catch (error) {
      res.status(500).json({ error: "Validation failed" });
    }
  });

  app.post("/api/forgot-password/request", async (req, res) => {
    try {
      let { identifier, email } = req.body;
      const targetQuery = identifier || email;
      if (!targetQuery) {
        return res.status(400).json({ error: "Please provide your email, phone, or roll number." });
      }

      const cleanQuery = targetQuery.toLowerCase().trim();
      const originalQuery = targetQuery.trim();

      // Check if user exists in Firestore
      let userDoc = null;
      
      if (originalQuery.includes("@")) {
        let usersSnap = await db.collection("users").where("email", "==", cleanQuery).get();
        if (usersSnap.empty) {
          usersSnap = await db.collection("users").where("gmail", "==", cleanQuery).get();
        }
        if (usersSnap.empty) {
          usersSnap = await db.collection("users").where("email", "==", originalQuery).get();
        }
        if (usersSnap.empty) {
          usersSnap = await db.collection("users").where("gmail", "==", originalQuery).get();
        }
        if (!usersSnap.empty) userDoc = usersSnap.docs[0];
      } else {
        let usersSnap = await db.collection("users").where("roll_number", "==", originalQuery).get();
        if (usersSnap.empty && !isNaN(Number(originalQuery))) {
          usersSnap = await db.collection("users").where("roll_number", "==", Number(originalQuery)).get();
        }
        
        // Match both normal and parent phone fields across multiple potential BD formats (+880, 880, 01...)
        const digits = originalQuery.replace(/\D/g, '');
        if (usersSnap.empty && digits.length >= 9) {
          let phoneVariants: string[] = [];
          if (digits.length === 10) {
            phoneVariants = [`0${digits}`, `+880${digits}`, `880${digits}`, digits];
          } else if (digits.length === 11 && digits.startsWith('0')) {
            const base = digits.substring(1);
            phoneVariants = [digits, `+880${base}`, `880${base}`, base];
          } else if (digits.length === 13 && digits.startsWith('880')) {
            const base = digits.substring(3);
            phoneVariants = [`0${base}`, `+880${base}`, digits, base];
          } else if (digits.length === 14 && digits.startsWith('880')) {
            const base = digits.substring(4);
            phoneVariants = [`0${base}`, `+880${base}`, digits, base];
          } else {
            phoneVariants = [originalQuery, digits];
          }
          
          for (const variant of phoneVariants) {
            usersSnap = await db.collection("users").where("phone", "==", variant).get();
            if (!usersSnap.empty) {
              userDoc = usersSnap.docs[0];
              break;
            }
            usersSnap = await db.collection("users").where("guardian_phone", "==", variant).get();
            if (!usersSnap.empty) {
              userDoc = usersSnap.docs[0];
              break;
            }
          }
        }
        
        if (!userDoc && !usersSnap.empty) {
          userDoc = usersSnap.docs[0];
        }
      }

      // Check if enrolled user
      if (!userDoc) {
        return res.status(404).json({ error: "No student account found. Please ensure you are enrolled." });
      }
      
      const userData = userDoc.data();
      const targetEmail = userData.email || userData.gmail;
      if (!targetEmail) {
        return res.status(400).json({ error: "Your account does not have a registered email address. Contact admin to update." });
      }
      const cleanEmail = targetEmail.toLowerCase().trim();
      const uid = userDoc.id;
      
      const extractedPassword = userData.initial_password || userData.password || "Student@123";

      // Generate a 6-digit verification code
      const verificationCode = Math.floor(100000 + Math.random() * 900000).toString();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString(); // 10 minutes

      // Store reset info using lowercase email as key
      await db.collection("password_resets").doc(cleanEmail).set({
        code: verificationCode,
        expiresAt,
        uid,
      });

      // Send password and verification code via SMTP
      await sendSmtpEmail({
        to: cleanEmail,
        subject: "Your Account Password - Jaber Math Care",
        db,
        html: `
          <div style="font-family: Arial, sans-serif; padding: 30px; color: #334155; line-height: 1.6; max-width: 500px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 20px; background-color: #ffffff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
            <div style="text-align: center; margin-bottom: 20px;">
              <h2 style="color: #ea580c; font-size: 24px; font-weight: 800; margin: 0; outline: none; border-bottom: 2px solid #ffedd5; padding-bottom: 12px;">Jaber Math Care Forgot Password</h2>
            </div>
            <p style="font-size: 15px; font-weight: 600; color: #1e293b; margin-top: 0;">Hi ${userData.name || 'Student / User'},</p>
            <p style="font-size: 14px; color: #475569;">You requested your password for your Jaber Math Care account. Your established password has been retrieved from our secure database:</p>
            
            <div style="background-color: #fff7ed; border: 1px solid #ffedd5; border-radius: 16px; padding: 20px; margin: 25px 0; text-align: center;">
              <span style="font-size: 11px; text-transform: uppercase; letter-spacing: 1.5px; color: #9a3412; font-weight: bold; display: block; margin-bottom: 8px;">Your Current Password</span>
              <span style="font-family: 'Courier New', Courier, monospace; font-size: 28px; font-weight: 900; color: #ea580c; letter-spacing: 1px;">${extractedPassword}</span>
            </div>
            
            <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; padding: 15px; border-radius: 12px; margin-bottom: 25px; text-align: center;">
              <span style="font-size: 11px; text-transform: uppercase; color: #64748b; font-weight: bold; display: block; margin-bottom: 4px;">Alternative Password Reset Verification Code</span>
              <span style="font-size: 16px; font-weight: bold; color: #334155; letter-spacing: 3px;">${verificationCode}</span>
              <p style="font-size: 11px; color: #94a3b8; margin: 5px 0 0 0;">If you want to manually change your password, use the code above. Code is valid for 10 min.</p>
            </div>

            <p style="font-size: 13px; color: #64748b; line-height: 1.5;">You can directly copy your current password and log in with it. Under no circumstances should you share this email with third parties.</p>
            <p style="border-top: 1px solid #f1f5f9; padding-top: 20px; font-size: 12px; color: #94a3b8; text-align: center; font-weight: 600; margin-bottom: 0;">Jaber Math Care Team • Live Support</p>
          </div>
        `
      });

      res.json({ success: true, email: cleanEmail, password: extractedPassword });
    } catch (error: any) {
      console.error("Forgot password request error:", error);
      res.status(500).json({ error: error.message || "Failed to process forgot password request" });
    }
  });

  app.post("/api/forgot-password/verify", async (req, res) => {
    try {
      const { email, code } = req.body;
      if (!email || !code) {
        return res.status(400).json({ error: "Email and verification code are required." });
      }

      const cleanEmail = email.toLowerCase().trim();
      const resetDoc = await db.collection("password_resets").doc(cleanEmail).get();
      if (!resetDoc.exists) {
        return res.status(400).json({ error: "Verification code has expired or is invalid." });
      }

      const resetData = resetDoc.data();
      if (resetData?.code !== code.trim()) {
        return res.status(400).json({ error: "Invalid verification code. Please check and try again." });
      }

      if (new Date(resetData?.expiresAt) < new Date()) {
        return res.status(400).json({ error: "Verification code has expired." });
      }

      res.json({ success: true, verified: true });
    } catch (error: any) {
      console.error("Forgot password verify error:", error);
      res.status(500).json({ error: error.message || "Failed to verify code" });
    }
  });

  app.post("/api/forgot-password/reset", async (req, res) => {
    try {
      const { email, code, newPassword } = req.body;
      if (!email || !code || !newPassword) {
        return res.status(400).json({ error: "Email, code and new password are required." });
      }

      const cleanEmail = email.toLowerCase().trim();
      const resetDoc = await db.collection("password_resets").doc(cleanEmail).get();
      if (!resetDoc.exists) {
        return res.status(400).json({ error: "Verification code expired or is invalid." });
      }

      const resetData = resetDoc.data();
      if (resetData?.code !== code.trim()) {
        return res.status(400).json({ error: "Invalid verification code." });
      }

      if (new Date(resetData?.expiresAt) < new Date()) {
        return res.status(400).json({ error: "Verification code has expired." });
      }

      // Update in Firebase Auth using Admin SDK
      const uid = resetData?.uid;
      await admin.auth().updateUser(uid, { password: newPassword });

      // Clean reset doc
      await db.collection("password_resets").doc(cleanEmail).delete();

      // Send confirmation email
      await sendSmtpEmail({
        to: cleanEmail,
        subject: "Your password has been reset - Jaber Math Care",
        db,
        html: `
          <div style="font-family: sans-serif; padding: 25px; color: #333; line-height: 1.6; max-width: 500px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 16px;">
            <p>Dear Student / User,</p>
            <p>Your password for Jaber Math Care has been successfully changed.</p>
            <p>You can now sign in using your new password. If you didn't perform this transaction, please contact us immediately.</p>
            <p style="border-top: 1px solid #e2e8f0; padding-top: 15px; font-size: 12px; color: #94a3b8; text-align: center;">Thank you • Jaber Math Care Team</p>
          </div>
        `
      });

      res.json({ success: true });
    } catch (error: any) {
      console.error("Forgot password reset error:", error);
      res.status(500).json({ error: error.message || "Failed to reset password" });
    }
  });

  // Vite middleware for development (falls back to dev mode if dist lacks to prevent static serving issues)
  const distPath = path.join(process.cwd(), "dist");
  const useDevMode = process.env.NODE_ENV !== "production" || !fs.existsSync(distPath);

  if (useDevMode) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    
    // SPA Fallback for route refreshes to avoid 404 in development
    app.use(async (req, res, next) => {
      if (
        req.method === "GET" &&
        req.headers.accept?.includes("text/html") &&
        !req.url.startsWith("/api") &&
        !req.url.startsWith("/@vite") &&
        !req.url.includes(".")
      ) {
        try {
          const url = req.originalUrl;
          const indexHtml = fs.readFileSync(
            path.join(process.cwd(), "index.html"),
            "utf-8"
          );
          const html = await vite.transformIndexHtml(url, indexHtml);
          return res.status(200).set({ "Content-Type": "text/html" }).end(html);
        } catch (e: any) {
          vite.ssrFixStacktrace(e);
          return next(e);
        }
      }
      next();
    });
  } else {
    app.use(
      express.static(distPath, {
        setHeaders: (res, path) => {
          if (path.endsWith(".html")) {
            res.set(
              "Cache-Control",
              "no-store, no-cache, must-revalidate, proxy-revalidate",
            );
            res.set("Pragma", "no-cache");
            res.set("Expires", "0");
          }
        },
      }),
    );
    app.get("*", (req, res, next) => {
      // If the request has an extension and is not .html, do not serve index.html (fallback)
      const ext = path.extname(req.path);
      if (ext && ext.toLowerCase() !== ".html") {
        return res.status(404).send("Not Found");
      }
      res.setHeader(
        "Cache-Control",
        "no-store, no-cache, must-revalidate, proxy-revalidate",
      );
      res.setHeader("Pragma", "no-cache");
      res.setHeader("Expires", "0");
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  if (process.env.VERCEL !== "1") {
    app.listen(PORT, "0.0.0.0", () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  }
}

startServer();
export { db, admin };
