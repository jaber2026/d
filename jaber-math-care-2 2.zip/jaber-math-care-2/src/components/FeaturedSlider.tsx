import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { useRealtimeCollection } from '../hooks/useRealtime';
import { useNavigate } from 'react-router-dom';

const FeaturedSlider = () => {
  const navigate = useNavigate();
  const { data: courses } = useRealtimeCollection('courses');

  const [images, setImages] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (courses) {
      setImages(courses.filter((c: any) => c.image_url));
    }
  }, [courses]);

  // Auto-play
  useEffect(() => {
    if (images.length === 0) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % images.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [images.length]);

  if (images.length === 0) return null;

  const handleNext = () => setCurrentIndex(prev => (prev + 1) % images.length);
  const handlePrev = () => setCurrentIndex(prev => (prev === 0 ? images.length - 1 : prev - 1));

  return (
    <div className="bg-gradient-to-b from-white via-orange-50/15 to-slate-50 pt-12 pb-16 px-4 md:px-8 relative overflow-hidden border-t border-b border-orange-100/40">
      {/* Background soft visual accents */}
      <div className="absolute top-10 left-10 w-72 h-72 bg-orange-100/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-orange-200/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-[1400px] mx-auto text-center mb-10 relative z-10">
         <span className="inline-block px-4 py-1.5 rounded-full bg-orange-100 text-orange-600 font-extrabold text-xs uppercase tracking-widest mb-3 border border-orange-200/50">
           Featured Courses
         </span>
         <h2 className="text-3xl md:text-5xl font-black text-slate-800 tracking-tight">
           Discover Our Running Batches
         </h2>
      </div>

      <div className="relative max-w-[1400px] mx-auto z-10 flex items-center justify-center h-[220px] sm:h-[300px] md:h-[400px] lg:h-[440px]">
        {/* Navigation Buttons */}
        <button 
          onClick={handlePrev}
          className="absolute left-1 md:left-4 top-1/2 -translate-y-1/2 w-10 h-10 md:w-12 md:h-12 bg-white hover:bg-orange-600 text-slate-700 hover:text-white rounded-full flex items-center justify-center shadow-md hover:shadow-orange-600/20 z-20 transition-all border border-slate-200/80 active:scale-95"
          aria-label="Previous batch"
        >
          <ChevronLeft className="w-5 h-5 md:w-6 md:h-6" />
        </button>

        <button 
          onClick={handleNext}
          className="absolute right-1 md:right-4 top-1/2 -translate-y-1/2 w-10 h-10 md:w-12 md:h-12 bg-white hover:bg-orange-600 text-slate-700 hover:text-white rounded-full flex items-center justify-center shadow-md hover:shadow-orange-600/20 z-20 transition-all border border-slate-200/80 active:scale-95"
          aria-label="Next batch"
        >
          <ChevronRight className="w-5 h-5 md:w-6 md:h-6" />
        </button>

        {/* Carousel Content */}
        <div className="flex justify-center items-center h-full w-full relative">
           <AnimatePresence mode="popLayout">
             {images.map((item, index) => {
               const relativeIndex = (index - currentIndex + images.length) % images.length;
               
               // Only show 3 items
               if (relativeIndex !== 0 && relativeIndex !== 1 && relativeIndex !== images.length - 1) return null;

               // Position calculations
               const isCenter = relativeIndex === 0;
               const isLeft = relativeIndex === images.length - 1;
               const isRight = relativeIndex === 1;

               return (
                 <motion.div
                   key={item.id}
                   initial={{ opacity: 0, scale: 0.8, x: isLeft ? -100 : (isRight ? 100 : 0) }}
                   animate={{ 
                     opacity: isCenter ? 1 : 0.45, 
                     scale: isCenter ? 1 : 0.82, 
                     x: isLeft ? '-65%' : (isRight ? '65%' : '0%'),
                     zIndex: isCenter ? 10 : 0
                   }}
                   exit={{ opacity: 0, scale: 0.8, x: isLeft ? -120 : (isRight ? 120 : 0) }}
                   transition={{ duration: 0.5, ease: [0.32, 0.72, 0, 1] }}
                   className={`absolute ${isCenter ? 'w-[88%] sm:w-[75%] md:w-[60%] max-w-[760px]' : 'w-[50%] md:w-[35%] hidden md:block'} rounded-3xl overflow-hidden shadow-lg cursor-pointer ${isCenter ? 'shadow-orange-500/10 border-2 border-orange-500/30 ring-4 ring-orange-50' : 'shadow-slate-300/20 border border-slate-100'}`}
                   onClick={() => {
                     if (!isCenter) {
                       if (isLeft) handlePrev();
                       if (isRight) handleNext();
                     } else {
                       navigate(`/course/${item.id}`);
                     }
                   }}
                 >
                   <div className="aspect-[16/9] md:aspect-[1.8/1] w-full bg-white rounded-3xl overflow-hidden relative group">
                     <img 
                       src={item.image_url} 
                       alt={item.title || "Featured Course"} 
                       className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-102"
                       referrerPolicy="no-referrer"
                     />
                     {isCenter && (
                       <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                          {item.title && <h3 className="text-lg md:text-xl font-black text-white tracking-tight">{item.title}</h3>}
                       </div>
                     )}
                   </div>
                 </motion.div>
               );
             })}
           </AnimatePresence>
        </div>

        {/* Indicators */}
        <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-2 z-20">
          {images.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentIndex(i)}
              className={`h-1.5 rounded-full transition-all ${currentIndex === i ? 'w-8 bg-orange-600' : 'w-2 bg-slate-300 hover:bg-orange-400'}`}
              aria-label={`Go to slide ${i+1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
};

export default FeaturedSlider;
