import React from 'react';
import { motion } from 'motion/react';
import { useSettings } from '../context/SettingsContext';
import { Plus, Minus, X, Divide, Hash, Percent } from 'lucide-react';

const FloatingSymbol = ({ icon: Icon, delay, x, y }: { icon: any, delay: number, x: string, y: string }) => (
  <motion.div
    className="absolute text-orange-500/10 pointer-events-none"
    style={{ left: x, top: y }}
    animate={{
      y: [0, -15, 0],
      rotate: [0, 360],
      opacity: [0.05, 0.2, 0.05],
    }}
    transition={{
      duration: 4 + Math.random() * 4,
      repeat: Infinity,
      delay: delay,
      ease: "easeInOut"
    }}
  >
    <Icon size={16 + Math.random() * 16} />
  </motion.div>
);

const DashboardLoading = () => {
  const { settings } = useSettings();
  const siteName = settings.site_name || "Jaber Math Care";
  const [show, setShow] = React.useState(false);

  React.useEffect(() => {
    const timer = setTimeout(() => setShow(true), 150);
    return () => clearTimeout(timer);
  }, []);

  if (!show) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-6 bg-slate-50/40 backdrop-blur-md animate-in fade-in duration-500">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 pointer-events-none opacity-40">
        <FloatingSymbol icon={Plus} delay={0} x="20%" y="30%" />
        <FloatingSymbol icon={Minus} delay={1} x="75%" y="25%" />
        <FloatingSymbol icon={X} delay={2} x="25%" y="70%" />
        <FloatingSymbol icon={Divide} delay={3} x="70%" y="75%" />
      </div>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full max-w-sm bg-white/80 backdrop-blur-2xl rounded-[3rem] p-12 border border-white shadow-[0_32px_64px_-16px_rgba(0,0,0,0.1)] flex flex-col items-center gap-10 text-center relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-b from-orange-400/5 to-transparent pointer-events-none" />
        
        <div className="relative">
          {/* Pulsing Rings */}
          {[1, 2].map((i) => (
            <motion.div
              key={i}
              className="absolute inset-0 border-2 border-orange-500/20 rounded-3xl"
              animate={{
                scale: [1, 1.5, 1],
                opacity: [0.3, 0, 0.3],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.5,
                ease: "easeInOut",
              }}
            />
          ))}
          
          <motion.div
            className="relative w-24 h-24 bg-white rounded-[1.8rem] shadow-2xl flex items-center justify-center border border-orange-50/50 overflow-hidden"
            animate={{ y: [0, -6, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: "easeInOut" }}
          >
            {settings.logo_url ? (
              <img 
                src={settings.logo_url} 
                alt="Logo" 
                className="w-14 h-14 object-contain" 
                referrerPolicy="no-referrer" 
              />
            ) : (
              <div className="bg-orange-600 w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transform rotate-3">
                <span className="text-white font-black text-xl italic tracking-tighter">J</span>
              </div>
            )}
            
            <motion.div
              className="absolute inset-x-0 h-0.5 bg-orange-500/30 z-20"
              animate={{ top: ["-10%", "110%", "-10%"] }}
              transition={{ duration: 1.8, repeat: Infinity, ease: "linear" }}
            />
          </motion.div>
        </div>

        <div className="space-y-4 relative z-10 w-full">
          <div className="space-y-1">
            <h2 className="text-2xl font-black text-slate-800 tracking-tight">{siteName}</h2>
            <div className="flex items-center justify-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
              <p className="text-[10px] font-black text-orange-500/60 uppercase tracking-[0.3em]">লোড হচ্ছে...</p>
              <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
            </div>
          </div>

          <div className="w-40 h-1.5 bg-slate-100 rounded-full overflow-hidden mx-auto relative border border-slate-50">
            <motion.div
              className="absolute inset-y-0 left-0 bg-orange-600 rounded-full shadow-[0_0_10px_rgba(234,88,12,0.4)]"
              animate={{ left: ["-100%", "100%"] }}
              transition={{ duration: 1.4, repeat: Infinity, ease: "easeInOut" }}
              style={{ width: "45%" }}
            />
          </div>
          
          <p className="text-[9px] font-bold text-slate-400/80 uppercase tracking-widest pt-2">Please wait a moment</p>
        </div>
      </motion.div>
    </div>
  );
};

export default DashboardLoading;
