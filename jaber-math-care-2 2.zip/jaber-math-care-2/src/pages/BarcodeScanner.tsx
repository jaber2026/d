import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { useSettings } from '../context/SettingsContext';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle, AlertCircle, Scan, User, School, Calendar, ArrowLeft, ClipboardList, Camera } from 'lucide-react';
import { db } from '../firebase';
import { collection, query, where, getDocs, doc, writeBatch, setDoc, getDoc, orderBy } from 'firebase/firestore';
import { Link } from 'react-router-dom';
import { Html5Qrcode } from 'html5-qrcode';
import { format } from 'date-fns';

const QrReaderComponent = ({ onScan }: { onScan: (decodedText: string) => void }) => {
  const onScanRef = useRef(onScan);
  useEffect(() => {
    onScanRef.current = onScan;
  }, [onScan]);

  useEffect(() => {
    let qrCode: Html5Qrcode | null = null;
    let isMounted = true;
    let isPaused = false;

    const startCamera = async () => {
      try {
        await new Promise(r => setTimeout(r, 200));
        if (!isMounted) return;

        qrCode = new Html5Qrcode("reader");

        const qrCodeSuccessCallback = (decodedText: string) => {
          if (isPaused) return;
          if (onScanRef.current) {
            onScanRef.current(decodedText);
          }
          
          isPaused = true;
          // Auto resume scanning after 3.2 seconds
          setTimeout(() => {
            isPaused = false;
          }, 3200);
        };

        const config = {
          fps: 10,
          qrbox: (viewfinderWidth: number, viewfinderHeight: number) => {
            const minEdge = Math.min(viewfinderWidth, viewfinderHeight);
            const size = Math.floor(minEdge * 0.75);
            return {
              width: Math.max(220, Math.min(300, size)),
              height: Math.max(220, Math.min(300, size))
            };
          }
        };

        try {
          await qrCode.start(
            { facingMode: "environment" },
            config,
            qrCodeSuccessCallback,
            () => {}
          );
        } catch (e) {
          console.warn("Back camera fail, fallback to user", e);
          if (isMounted) {
            await qrCode.start(
              { facingMode: "user" },
              config,
              qrCodeSuccessCallback,
              () => {}
            );
          }
        }
      } catch (err) {
        console.error("Camera start failed on BarcodeScanner", err);
      }
    };

    startCamera();

    return () => {
      isMounted = false;
      if (qrCode) {
        if (qrCode.isScanning) {
          qrCode.stop().catch(e => console.error("Stop error on unmount", e));
        }
      }
    };
  }, []);

  return (
    <div className="w-full overflow-hidden rounded-[2rem] border-4 border-white bg-slate-950 shadow-inner flex flex-col items-center justify-center p-1 min-h-[300px] relative">
      <div id="reader" className="w-full max-w-sm overflow-hidden rounded-2xl bg-slate-950" />
    </div>
  );
};

const BarcodeScanner = () => {
  const { user } = useAuth();
  const { settings } = useSettings();
  const [barcode, setBarcode] = useState('');
  const [scannedStudent, setScannedStudent] = useState<any>(null);
  const [scanStatus, setScanStatus] = useState<'idle' | 'scanning' | 'success' | 'error'>('idle');
  const [statusMessage, setStatusMessage] = useState('');
  const [mode, setMode] = useState<'class'|'exam'>('class');
  const [exams, setExams] = useState<any[]>([]);
  const [selectedExamId, setSelectedExamId] = useState<string>('');
  const [batches, setBatches] = useState<any[]>([]);
  
  const [events, setEvents] = useState<any[]>([]);
  
  const lastScannedIdRef = useRef<string>('');
  const lastScannedTimeRef = useRef<number>(0);
  const autoResetTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const fetchExams = async () => {
      try {
        const snapshot = await getDocs(query(collection(db, "exams")));
        const examsData = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as any));
        // Sort by date descending
        examsData.sort((a,b) => new Date(b.exam_date || b.date).getTime() - new Date(a.exam_date || a.date).getTime());
        setExams(examsData);
        if(examsData.length > 0) setSelectedExamId(examsData[0].id);
        
        const evtsSnap = await getDocs(collection(db, "events"));
        setEvents(evtsSnap.docs.map(d => ({ ...d.data(), id: d.id })));

        const batchesSnap = await getDocs(collection(db, "batches"));
        setBatches(batchesSnap.docs.map(d => ({ ...d.data(), id: d.id })));
      } catch (e) {
        console.error(e);
      }
    };
    fetchExams();
  }, []);

  const playSuccess = () => {
    try {
      const audio = new Audio('https://cdn.pixabay.com/download/audio/2021/08/04/audio_0625c1539c.mp3?filename=success-1-6297.mp3');
      audio.volume = 0.5;
      audio.play().catch(e => console.log(e));
    } catch(e){}
  };

  const playError = () => {
    try {
      const audio = new Audio('https://cdn.pixabay.com/download/audio/2022/03/10/audio_c8b7fafdf3.mp3?filename=error-126627.mp3');
      audio.volume = 0.5;
      audio.play().catch(e => console.log(e));
    } catch(e){}
  };

  useEffect(() => {
    let debounceTimer: NodeJS.Timeout;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') {
        return;
      }
      
      if (e.key === 'Enter') {
        if (barcode.trim().length > 0) {
          handleScan(barcode.trim());
          setBarcode('');
        }
      } else {
        const char = e.key;
        if (char.length === 1) {
          setBarcode(prev => prev + char);
          setScanStatus('scanning');
          
          clearTimeout(debounceTimer);
          debounceTimer = setTimeout(() => {
            if (barcode) {
              setBarcode('');
              setScanStatus('idle');
            }
          }, 2000);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      clearTimeout(debounceTimer);
    };
  }, [barcode]);

  const handleScan = async (scannedCode: string) => {
    if (!scannedCode) return;

    const today = format(new Date(), "yyyy-MM-dd");
    const activeEvent = events.find(evt => evt.start_date <= today && today <= evt.end_date);
    if (activeEvent && mode === 'class') {
      if (playError) playError();
      setScanStatus('error');
      setStatusMessage(`ATTENDANCE DISABLED: ${activeEvent.title}`);
      
      if (autoResetTimerRef.current) clearTimeout(autoResetTimerRef.current);
      autoResetTimerRef.current = setTimeout(() => {
        setScanStatus('idle');
      }, 4500);
      return;
    }

    let studentIdOrRoll = scannedCode;
    let scannedBatchId = "";
    let scannedClass = "";
    const parts = scannedCode.split('-');
    
    if (parts.length >= 5) {
      // Format: JABER-MATH-[batch_id]-[class_name]-[roll_or_id]
      scannedBatchId = parts[2] ? parts[2].replace(/_/g, ' ') : "";
      scannedClass = parts[3] ? parts[3].replace(/_/g, ' ') : "";
      studentIdOrRoll = parts[4];
    } else if (parts.length > 2) {
      studentIdOrRoll = parts[parts.length - 1]; // Last item e.g. Roll No or ID
    } else if (scannedCode.includes('-')) {
      studentIdOrRoll = parts[1] || parts[0];
    }

    // Debounce duplicate swiping within 5 seconds to ignore camera double trigger
    const now = Date.now();
    if (lastScannedIdRef.current === studentIdOrRoll && now - lastScannedTimeRef.current < 5000) {
      console.log("Ignored duplicate trigger card scan:", studentIdOrRoll);
      return;
    }

    lastScannedIdRef.current = studentIdOrRoll;
    lastScannedTimeRef.current = now;

    if (autoResetTimerRef.current) {
      clearTimeout(autoResetTimerRef.current);
    }

    setScanStatus('scanning');
    setStatusMessage('Searching student...');
    
    try {
      console.log("Extracted ID/Roll:", studentIdOrRoll, "Scanned Batch:", scannedBatchId);
      let foundDoc: any = null;

      // 1. Direct document key look up first (uncompromising, 100% unique match)
      try {
        const directDocRef = doc(db, 'users', studentIdOrRoll);
        const directSnap = await getDoc(directDocRef);
        if (directSnap.exists() && directSnap.data()?.role === 'student') {
          foundDoc = { id: directSnap.id, ...directSnap.data() };
        }
      } catch (e) {
        console.warn("Direct document ID fetch failed", e);
      }

      // 2. Lookup by roll_number matching studentIdOrRoll
      if (!foundDoc) {
        const studentsRef = collection(db, 'users');
        const q = query(studentsRef, where('role', '==', 'student'), where('roll_number', '==', studentIdOrRoll));
        const snapshot = await getDocs(q);
        
        if (!snapshot.empty) {
          const matches = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as any));
          
          if (scannedBatchId && matches.length > 1) {
            // Filter where batch matches the parsed batch string exactly (handles identical rolls across different batches)
            const perfectMatch = matches.find(m => 
              String(m.batch_id || '').toLowerCase() === scannedBatchId.toLowerCase() ||
              String(m.batch_id_2 || '').toLowerCase() === scannedBatchId.toLowerCase() ||
              String(m.batch_name || '').toLowerCase() === scannedBatchId.toLowerCase()
            );
            foundDoc = perfectMatch || matches[0];
          } else {
            foundDoc = matches[0];
          }
        }
      }

      // 3. Fallback query with ID field
      if (!foundDoc) {
        const studentsRef = collection(db, 'users');
        const q2 = query(studentsRef, where('role', '==', 'student'), where('id', '==', studentIdOrRoll));
        const snapshot2 = await getDocs(q2);
        if (!snapshot2.empty) {
          foundDoc = { id: snapshot2.docs[0].id, ...snapshot2.docs[0].data() };
        }
      }

      // 4. Fallback search by unique scannedCode
      if (!foundDoc) {
        const studentsRef = collection(db, 'users');
        const q3 = query(studentsRef, where('roll_number', '==', scannedCode));
        const snapshot3 = await getDocs(q3);
        if (!snapshot3.empty) {
          foundDoc = { id: snapshot3.docs[0].id, ...snapshot3.docs[0].data() };
        }
      }

      if (!foundDoc) {
        if (playError) playError();
        setScanStatus('error');
        setStatusMessage('Student not found with this ID card.');
        
        autoResetTimerRef.current = setTimeout(() => {
          setScanStatus('idle');
        }, 4500);
        return;
      }

      const studentData = foundDoc;
      
      // Fetch payment details so Admin can see fee status on scan
      try {
        const paymentSnap = await getDocs(query(collection(db, "payments"), where("student_id", "==", studentData.id)));
        studentData.payments = paymentSnap.docs.map(doc => doc.data());
      } catch (err) {
        console.warn("Could not fetch payments for scanned student", err);
      }
      
      setScannedStudent(studentData);

      await markAttendance(studentData);
      
      if (playSuccess) playSuccess();
      setScanStatus('success');
      setStatusMessage('Attendance logged successfully!');

      // Auto clear scanned overlay card after 4.5 seconds to return to "Hologram Waiting" state
      autoResetTimerRef.current = setTimeout(() => {
        setScanStatus('idle');
        setScannedStudent(null);
      }, 4500);

    } catch (err) {
      console.error(err);
      if (playError) playError();
      setScanStatus('error');
      setStatusMessage('Network Error while taking attendance.');
      
      autoResetTimerRef.current = setTimeout(() => {
        setScanStatus('idle');
      }, 4500);
    }
  };

  const markAttendance = async (student: any) => {
    const today = format(new Date(), "yyyy-MM-dd");
    const currentTime = format(new Date(), "hh:mm a");
    const attendanceRef = collection(db, 'attendance');
    
    // Determine the date of the record (exam scheduled date if in exam mode, otherwise today)
    const selectedExam = exams.find(e => String(e.id) === String(selectedExamId));
    const recordDate = mode === 'exam' && selectedExam ? (selectedExam.exam_date || selectedExam.date || today) : today;
    
    let q;
    if (mode === 'class') {
      q = query(attendanceRef, 
        where('student_id', '==', student.id), 
        where('date', '==', recordDate),
        where('type', '==', 'class')
      );
    } else {
      q = query(attendanceRef, 
        where('student_id', '==', student.id), 
        where('date', '==', recordDate),
        where('type', '==', 'exam'),
        where('exam_id', '==', selectedExamId)
      );
    }
    
    const snap = await getDocs(q);
    if (!snap.empty) {
      return; 
    }

    const payload: any = {
      student_id: student.id,
      student_name: student.name,
      batch_id: String(student.batch_id || ""),
      type: mode,
      date: recordDate,
      time: currentTime,
      status: "present",
      roll_number: student.roll_number,
      phone: student.phone || "",
      created_at: new Date().toISOString()
    };

    if (mode === 'exam') {
      payload.exam_id = selectedExamId;
    }

    const newRecordRef = doc(attendanceRef);
    await setDoc(newRecordRef, payload);
  };

  useEffect(() => {
    return () => {
      if (autoResetTimerRef.current) {
        clearTimeout(autoResetTimerRef.current);
      }
    };
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-500 to-orange-700 flex flex-col items-center justify-start p-4 sm:p-8 text-white font-sans selection:bg-white/30">
      <div className="w-full max-w-6xl mb-6 flex justify-between items-center z-50">
        <Link to="/admin" className="flex items-center gap-2 text-orange-100 hover:text-white transition-colors bg-orange-850/20 backdrop-blur-md border border-white/20 px-4 py-2.5 rounded-xl">
          <ArrowLeft className="h-5 w-5" />
          <span className="font-bold text-sm">Exit Scanner</span>
        </Link>
        <div className="flex items-center gap-2 text-orange-200 text-xs font-black tracking-widest uppercase bg-orange-850/20 backdrop-blur-md border border-white/15 px-4 py-2.5 rounded-xl">
          <Camera className="h-4 w-4 animate-pulse text-emerald-300" />
          <span>Camera Engine Online</span>
        </div>
      </div>

      <div className="absolute inset-0 overflow-hidden pointer-events-none z-0">
         <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-white/20 blur-[120px] rounded-full mix-blend-overlay" />
         <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-300/20 blur-[120px] rounded-full mix-blend-overlay" />
      </div>

      <div className="w-full max-w-6xl z-10 flex flex-col items-center space-y-8">
        
        {/* Title */}
        <div className="text-center space-y-1">
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white tracking-tighter drop-shadow-md">
            {(settings.site_name || "JABER MATH CARE").toUpperCase()}
          </h1>
          <p className="text-orange-100 font-bold tracking-[0.25em] uppercase text-xs sm:text-sm drop-shadow-sm">Attendance Scanner Console</p>
        </div>

        {/* Dynamic Split Grid View: Camera on Left, Result Profile on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 w-full items-start">
          
          {/* Left Side Container: Always Running Camera Feed */}
          <div className="lg:col-span-5 flex flex-col items-center space-y-6 bg-white/10 backdrop-blur-md rounded-[2.5rem] border border-white/20 p-5 shadow-2xl">
            <h3 className="text-sm font-black tracking-widest uppercase text-orange-200">Live Camera Stream</h3>
            <div className="w-full bg-slate-950 p-2.5 rounded-3xl border border-white/15 shadow-inner">
              <QrReaderComponent onScan={handleScan} />
            </div>

            {/* Controller mode toggles */}
            <div className="w-full p-2 bg-orange-950/40 rounded-2xl border border-orange-900/40 mt-2 text-left">
               <label className="text-[9px] font-black uppercase text-orange-300 tracking-wider mb-2 block text-center">Registration Tracking Mode</label>
               <div className="flex bg-orange-900/60 rounded-xl p-1 mb-4 w-full border border-orange-900/30">
                 <button onClick={() => setMode('class')} className={`flex-1 py-2 text-xs font-black tracking-widest uppercase rounded-lg transition-all ${mode === 'class' ? 'bg-white text-orange-600 shadow-md' : 'text-orange-100 hover:text-white'}`}>Class</button>
                 <button onClick={() => setMode('exam')} className={`flex-1 py-2 text-xs font-black tracking-widest uppercase rounded-lg transition-all ${mode === 'exam' ? 'bg-emerald-500 text-white shadow-md' : 'text-orange-100 hover:text-white'}`}>Exam</button>
               </div>
               {mode === 'exam' && (
                  <div className="w-full">
                     <label className="text-[10px] font-black uppercase text-emerald-300 mb-1.5 block">Select Current Exam:</label>
                     <select className="w-full bg-orange-900/60 border border-emerald-400/40 text-white text-xs font-bold p-3 rounded-xl focus:border-emerald-400 outline-none" value={selectedExamId} onChange={e => setSelectedExamId(e.target.value)}>
                       {exams.map(ex => <option key={ex.id} value={ex.id}>{ex.title || ex.exam_name}</option>)}
                     </select>
                  </div>
               )}
            </div>
          </div>

          {/* Right Side Container: Scanned Results Profile Overview */}
          <div className="lg:col-span-7 w-full">
            <AnimatePresence mode="wait">
              {scanStatus === 'success' && scannedStudent ? (
                <motion.div
                  key="success-scanned"
                  initial={{ opacity: 0, scale: 0.95, y: 30 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -30 }}
                  transition={{ type: "spring", damping: 25, stiffness: 180 }}
                  className="w-full bg-gradient-to-br from-orange-600 via-orange-500 to-amber-500 text-white border border-orange-400/30 rounded-[2.5rem] p-6 sm:p-8 shadow-[0_25px_60px_-15px_rgba(234,88,12,0.5)] flex flex-col relative overflow-hidden"
                >
                  <div className="absolute top-0 left-0 w-full h-3 bg-white/40" />
                  
                  {/* Premium Success Badge Header */}
                  <div className="bg-white/15 backdrop-blur-xl text-white p-5 rounded-[2rem] flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg border border-white/20 text-left mb-6">
                    <div className="flex items-center gap-3.5">
                      <div className="p-3 bg-white/25 rounded-2xl flex-shrink-0 animate-pulse">
                        <CheckCircle className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h4 className="text-sm font-black uppercase tracking-widest text-amber-200">Attendance Logged</h4>
                        <p className="text-xs text-white/95 font-bold leading-relaxed">
                          This student is marked <span className="underline decoration-wavy underline-offset-4 decoration-white">PRESENT</span> for {mode === "class" ? "Class" : "Exam"} today! All reports and database records updated successfully.
                        </p>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <span className="text-[9px] uppercase font-black tracking-widest text-white/80 block">SCAN TIME</span>
                      <span className="font-mono text-xs font-black bg-white/20 text-white border border-white/20 px-3 py-1 rounded-xl inline-block mt-0.5">{format(new Date(), "hh:mm a")}</span>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 sm:gap-8 w-full text-left">
                    <div className="shrink-0 relative">
                      {scannedStudent.profile_pic ? (
                         <img src={scannedStudent.profile_pic} alt={scannedStudent.name} className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl border-4 border-white/30 object-cover shadow-lg" />
                      ) : (
                        <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl border-4 border-white/30 bg-white/10 backdrop-blur-md flex items-center justify-center shadow-lg">
                           <User className="h-12 w-12 text-orange-200" />
                        </div>
                      )}
                    </div>
                    
                    <div className="text-center sm:text-left space-y-4 flex-1 w-full">
                      <div>
                        <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight leading-none uppercase">{scannedStudent.name}</h3>
                        <p className="text-amber-200 font-mono text-sm sm:text-base font-black uppercase mt-1">Roll No: {scannedStudent.roll_number || '---'}</p>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 pt-4 border-t border-white/20 font-bold uppercase tracking-wider text-[10px]">
                        <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/10">
                          <span className="text-white/60 block mb-0.5">Class / Current</span>
                          <span className="text-white text-xs font-black">{scannedStudent.current_class || 'Class N/A'}</span>
                        </div>
                        <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/10">
                          <span className="text-white/60 block mb-0.5">Batch Name</span>
                          <span className="text-white text-xs font-black">
                            {batches.find(b => String(b.id) === String(scannedStudent.batch_id))?.name || scannedStudent.batch_name || scannedStudent.batch_id || 'N/A'}
                          </span>
                        </div>
                        <div className="bg-white/10 backdrop-blur-md p-3 rounded-xl border border-white/10 col-span-2 md:col-span-1">
                          <span className="text-white/60 block mb-1">Fee Status</span>
                          { (() => {
                               const d = new Date();
                               const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
                               const currentMonth = monthNames[d.getMonth()];
                               const currentYear = d.getFullYear();
                               const payments = scannedStudent.payments || [];
                               const isPaid = payments.some((p: any) => (p.type === 'monthly' || p.type === 'admission') && p.month?.toLowerCase() === currentMonth.toLowerCase() && String(p.year || (p.date ? new Date(p.date).getFullYear() : "")) === String(currentYear));
                               return (
                                 <span className={`inline-block px-3 py-1.5 text-xs font-black rounded-lg w-full text-center ${isPaid ? "bg-emerald-500/20 text-emerald-200 border border-emerald-500/30" : "bg-rose-500/20 text-rose-200 border border-rose-500/30 animate-pulse"}`}>
                                   {currentMonth.substring(0,3)}: {isPaid ? "PAID ✓" : "UNPAID!"}
                                 </span>
                               );
                          })()}
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="mt-8 text-orange-100 font-bold bg-black/10 border border-white/10 px-4 py-3 rounded-xl uppercase text-[10px] tracking-widest flex items-center justify-center gap-2">
                     <span className="relative flex h-2 w-2 shrink-0">
                       <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
                       <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-300"></span>
                     </span>
                     <span>Attendance locked properly into Firestore index</span>
                  </div>
                </motion.div>
              ) : scanStatus === 'error' ? (
                <motion.div
                  key="error-scanned"
                  initial={{ opacity: 0, scale: 0.95, y: 30 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95, y: -30 }}
                  transition={{ type: "spring", damping: 25, stiffness: 180 }}
                  className="w-full bg-gradient-to-br from-rose-600 to-red-700 text-white border border-rose-550 rounded-[2.5rem] p-8 flex flex-col items-center justify-center text-center shadow-2xl"
                >
                  <div className="w-20 h-20 bg-white/10 flex items-center justify-center rounded-full mb-6 border border-white/20 shadow-inner">
                    <AlertCircle className="h-10 w-10 text-white" />
                  </div>
                  <h2 className="text-white text-2xl font-black uppercase tracking-widest mb-2">Scan Failed</h2>
                  <p className="text-rose-100 font-bold text-xs max-w-sm mb-4 leading-relaxed">{statusMessage}</p>
                  <p className="text-[10px] text-white/90 font-black uppercase tracking-wider bg-white/10 border border-white/15 px-4 py-2 rounded-full">Resuming in a few seconds...</p>
                </motion.div>
              ) : (
                <motion.div
                  key="idle-scanned"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="w-full bg-white/10 backdrop-blur-md rounded-[2.5rem] border border-white/20 p-8 flex flex-col items-center justify-center text-center min-h-[340px] shadow-lg text-white"
                >
                  <Scan className="h-16 w-16 text-orange-200 animate-pulse mb-4" />
                  <h3 className="text-2xl font-black text-white tracking-tight">WAITING FOR SWIPE</h3>
                  <p className="text-orange-100 font-bold tracking-widest uppercase text-xs mt-1.5 max-w-md leading-relaxed">Place Student ID card containing QR Code near the camera lens. The camera remains active continuously.</p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

        </div>

      </div>
    </div>
  );
};

export default BarcodeScanner;
