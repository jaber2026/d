import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Image as ImageIcon, X, ChevronLeft, ChevronRight, Download, Play } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { db } from '../../firebase';
import { collection, onSnapshot, query, where, doc, getDoc } from 'firebase/firestore';

import LoadingSpinner from '../../components/LoadingSpinner';

const ClassSlides = () => {
  const { token, user: authUser } = useAuth();
  const [slides, setSlides] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedSlideIndex, setSelectedSlideIndex] = useState<number | null>(null);

  useEffect(() => {
    if (!token || !authUser) return;

    const unsubscribes: (() => void)[] = [];

    // Listen to user profile
    const userRef = doc(db, 'users', authUser.id);
    const unsubUser = onSnapshot(userRef, async (userDoc) => {
      if (userDoc.exists()) {
        const userData = userDoc.data();
        
        // Listen to enrollments
        fetch(`/api/my-enrollments?t=${Date.now()}`, {
          headers: { Authorization: `Bearer ${token}` }
        })
          .then(res => res.json())
          .then(enrollData => {
            if (enrollData.error) return;
            const activeEnrollments = (Array.isArray(enrollData) ? enrollData : []).filter((e: any) => e.status === 'contacted' || e.status === 'approved');
            const userEnrolledCourseIds = userData?.enrolled_courses?.map((c: any) => typeof c === 'string' ? c : c.id) || [];

            // Listen to class slides
            const unsubSlides = onSnapshot(collection(db, 'class_slides'), (slidesSnapshot) => {
              const slidesData = slidesSnapshot.docs.map(d => ({ ...d.data(), id: d.id }));
              
              const filteredSlides = (Array.isArray(slidesData) ? slidesData : []).filter((slide: any) => {
                const cid = slide.course_id && String(slide.course_id).toLowerCase() !== 'all' ? slide.course_id : null;
                const pid = slide.program_id && String(slide.program_id).toLowerCase() !== 'all' ? slide.program_id : null;
                const bid = slide.batch_id && String(slide.batch_id).toLowerCase() !== 'all' ? slide.batch_id : null;
                
                if (userData?.role === 'admin' || userData?.role === 'moderator') return true;

                if (!cid && !pid && !bid) return true;

                const matchBatch = !bid || 
                                   String(userData?.batch_id) === String(bid) || 
                                   String(userData?.batch_id_2) === String(bid) ||
                                   activeEnrollments.some((e: any) => String(e.batch_id) === String(bid));

                if (userData?.student_type !== 'online') {
                  // Offline filtering
                  let isEligible = false;
                  
                  if (pid) {
                    const matchProgram = String(pid) === String(userData?.program_id) ||
                                         activeEnrollments.some((e: any) => String(e.program_id) === String(pid));
                    if (matchProgram && matchBatch) isEligible = true;
                  }
                  
                  if (cid) {
                    const isEnrolledInCourse = (userData?.course_id && String(userData.course_id) === String(cid)) ||
                                               userEnrolledCourseIds.some((cId: any) => String(cId) === String(cid)) ||
                                               activeEnrollments.some((e: any) => String(e.course_id) === String(cid));
                    if (isEnrolledInCourse && matchBatch) isEligible = true;
                  }

                  if (bid && !pid && !cid) {
                    if (matchBatch) isEligible = true;
                  }

                  return isEligible;
                } else {
                  // Online filtering
                  const isEnrolledInCourse = (userData?.course_id && String(userData.course_id) === String(cid)) ||
                                             userEnrolledCourseIds.some((cId: any) => String(cId) === String(cid)) ||
                                             activeEnrollments.some((e: any) => String(e.course_id) === String(cid));
                  const isEligibleOnline = isEnrolledInCourse || (!cid && !pid);
                  return isEligibleOnline && matchBatch;
                }
              });

              setSlides(filteredSlides);
              setLoading(false);
            });
            unsubscribes.push(unsubSlides);
          }).catch(console.error);
      }
    });
    unsubscribes.push(unsubUser);

    return () => unsubscribes.forEach(unsub => unsub());
  }, [token, authUser?.id]);

  const [selectedGroup, setSelectedGroup] = useState<any[] | null>(null);

  if (loading) {
    return (
      <div className="p-8 max-w-[1800px] mx-auto space-y-12">
        {/* Skeleton Header */}
        <div className="space-y-4">
          <div className="h-12 w-64 bg-slate-100 rounded-2xl animate-pulse" />
          <div className="h-4 w-48 bg-slate-100 rounded-lg animate-pulse" />
        </div>

        {/* Skeleton Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-8">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(i => (
            <div key={i} className="space-y-4">
              <div className="aspect-square bg-slate-100 rounded-[2.5rem] animate-pulse border-4 border-white shadow-sm" />
              <div className="h-4 w-3/4 bg-slate-100 rounded-lg mx-auto animate-pulse" />
            </div>
          ))}
        </div>

        {/* Floating Loading Indicator */}
        <div className="fixed bottom-12 left-1/2 -translate-x-1/2 bg-white/80 backdrop-blur-xl px-8 py-4 rounded-3xl border border-white shadow-2xl flex items-center gap-4 z-50">
          <div className="w-5 h-5 border-2 border-orange-600/20 border-t-orange-600 rounded-full animate-spin" />
          <p className="text-[10px] font-black text-slate-800 uppercase tracking-[0.3em]">গ্যালারি লোড হচ্ছে...</p>
        </div>
      </div>
    );
  }

  const groupSlides = (items: any[]) => {
    const groups: { [key: string]: any[] } = {};
    items.forEach(item => {
      const date = item.created_at ? new Date(item.created_at) : new Date();
      const timeKey = Math.floor(date.getTime() / (120 * 1000));
      const key = `${item.title || 'untitled'}-${timeKey}`;
      if (!groups[key]) groups[key] = [];
      groups[key].push(item);
    });
    return Object.values(groups).sort((a, b) => {
      const dateA = new Date(a[0].created_at || 0);
      const dateB = new Date(b[0].created_at || 0);
      return dateB.getTime() - dateA.getTime();
    });
  };

  const groupedSlides = groupSlides(slides);

  return (
    <div className="space-y-12 pb-32 max-w-7xl mx-auto px-4 md:px-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-white/80 backdrop-blur-md p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
        <div className="flex items-center gap-5">
          <div className="p-4 bg-orange-600 text-white rounded-[1.5rem] shadow-xl shadow-orange-600/20 ring-8 ring-orange-600/5">
            <ImageIcon className="h-7 w-7 md:h-9 md:w-9" />
          </div>
          <div>
            <h1 className="text-3xl md:text-5xl font-black text-slate-900 tracking-tighter">
              Class <span className="text-orange-600">Slides</span>
            </h1>
            <p className="text-slate-400 font-bold text-xs md:text-sm uppercase tracking-widest mt-1">Study Materials & Notes</p>
          </div>
        </div>
      </div>

      {slides.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-32 bg-white rounded-[3rem] border border-slate-100 shadow-sm animate-in fade-in slide-in-from-bottom-5">
          <div className="p-10 bg-slate-50 rounded-full mb-8 relative">
            <ImageIcon className="h-16 w-16 text-slate-300" />
            <div className="absolute -top-2 -right-2 w-8 h-8 bg-orange-100 border-4 border-white rounded-full flex items-center justify-center text-orange-600 font-black text-xs">?</div>
          </div>
          <p className="text-2xl text-slate-400 font-black tracking-tight">No slides available yet.</p>
          <p className="text-slate-400 font-bold text-sm mt-2">Check back after your next class!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 2xl:grid-cols-4 gap-x-12 gap-y-20 pt-8">
          {groupedSlides.map((group, groupIdx) => (
            <motion.div 
              key={groupIdx} 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: groupIdx * 0.1 }}
              className="group cursor-pointer relative"
              onClick={() => setSelectedGroup(group)}
            >
              <div className="relative h-60 w-full transition-all duration-500 group-hover:-translate-y-4">
                <div className="absolute inset-0 bg-white border border-slate-100 rounded-[2.5rem] shadow-lg transition-all duration-500 translate-x-3 translate-y-3 rotate-3 opacity-40 group-hover:translate-x-6 group-hover:translate-y-6 group-hover:rotate-6" />
                <div className="absolute inset-0 bg-white border border-slate-100 rounded-[2.5rem] shadow-lg transition-all duration-500 translate-x-1.5 translate-y-1.5 rotate-1.5 opacity-70 group-hover:translate-x-3 group-hover:translate-y-3 group-hover:rotate-3" />
                
                <div className="relative w-full h-full rounded-[2.5rem] overflow-hidden border-4 border-white shadow-2xl bg-slate-100">
                  <img 
                    src={group[0].image_url} 
                    alt={group[0].title} 
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110" 
                  />
                  
                  {group.length > 1 && (
                    <div className="absolute top-5 right-5 bg-orange-600/90 backdrop-blur-md text-white flex items-center gap-2 px-4 py-2 rounded-2xl shadow-xl ring-4 ring-orange-600/10 border border-white/20">
                      <ImageIcon className="h-4 w-4" />
                      <span className="text-xs font-black tracking-tight">{group.length} Photos</span>
                    </div>
                  )}

                  <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500 flex flex-col justify-end p-8">
                    <p className="text-white/80 font-black text-[10px] uppercase tracking-[0.2em] mb-1">Click to view all</p>
                    <p className="text-white font-black text-lg tracking-tight line-clamp-1">{group[0].title}</p>
                  </div>
                </div>
              </div>

              <div className="mt-8 px-4 space-y-2">
                <h3 className="font-black text-slate-800 text-xl tracking-tighter leading-tight line-clamp-1 group-hover:text-orange-600 transition-colors">
                  {group[0].title || "Untitled Lesson"}
                </h3>
                <div className="flex items-center gap-3">
                  <span className="px-3 py-1 bg-slate-100 text-slate-500 rounded-xl text-[10px] font-black uppercase tracking-widest border border-slate-200 group-hover:bg-orange-50 group-hover:text-orange-600 group-hover:border-orange-100 transition-colors">
                    {group[0].description || "Lecture Slides"}
                  </span>
                  <div className="w-1.5 h-1.5 rounded-full bg-slate-200 group-hover:bg-orange-300 transition-colors" />
                  <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    {new Date(group[0].created_at || Date.now()).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* Gallery Modal (Messenger Style) */}
      <AnimatePresence>
        {selectedGroup && (
          <motion.div
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.1 }}
            className="fixed inset-0 z-[100] flex flex-col bg-white overflow-hidden"
          >
            {/* Minimalist Gallery Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100 bg-white/90 backdrop-blur-3xl sticky top-0 z-10">
              <div className="flex items-center gap-4">
                <button 
                  onClick={() => setSelectedGroup(null)}
                  className="p-3 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-2xl transition-all active:scale-95 flex items-center justify-center"
                >
                  <X className="h-6 w-6" />
                </button>
                <div className="flex flex-col">
                  <h2 className="text-slate-900 font-black text-xl md:text-2xl tracking-tight leading-none">
                    {selectedGroup[0].title || "Gallery"}
                  </h2>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-slate-400 font-bold text-[10px] uppercase tracking-widest">{selectedGroup.length} Photos</span>
                    <div className="w-1 h-1 rounded-full bg-slate-200" />
                    <span className="text-orange-600 font-black text-[10px] uppercase tracking-widest">Full HD Library</span>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button 
                  onClick={() => {
                    selectedGroup.forEach((slide, index) => {
                      setTimeout(() => {
                        const link = document.createElement('a');
                        link.href = slide.image_url;
                        link.download = `slide-${index + 1}.jpg`;
                        link.target = "_blank";
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                      }, index * 200);
                    });
                  }}
                  className="p-3 md:px-6 md:py-3.5 bg-orange-600 text-white rounded-2xl shadow-xl shadow-orange-600/20 hover:bg-orange-700 transition-all active:scale-95 flex items-center gap-3"
                >
                  <Download className="h-5 w-5" />
                  <span className="hidden md:inline font-black text-xs uppercase tracking-widest">Download All</span>
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 md:p-12 scrollbar-hide bg-slate-50/30">
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6 md:gap-10 max-w-[1920px] mx-auto">
                {selectedGroup.map((slide, idx) => (
                  <motion.div 
                    key={slide.id}
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.02 }}
                    onClick={() => {
                      const masterIndex = slides.findIndex(s => s.id === slide.id);
                      setSelectedSlideIndex(masterIndex);
                    }}
                    className="relative aspect-[3/4] md:aspect-square rounded-[2rem] overflow-hidden border-4 border-white shadow-lg cursor-pointer bg-white group hover:shadow-2xl hover:-translate-y-2 transition-all duration-500"
                  >
                    <img 
                      src={slide.image_url} 
                      className="w-full h-full object-cover grayscale-[0.2] group-hover:grayscale-0 transition-all duration-700 group-hover:scale-110" 
                      referrerPolicy="no-referrer"
                    />
                    
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500">
                      <div className="absolute bottom-6 left-6 right-6 flex items-center justify-between">
                        <div className="p-2.5 bg-white text-orange-600 rounded-xl shadow-2xl">
                          <Play className="h-4 w-4 fill-current" />
                        </div>
                        <span className="text-white text-[10px] font-black uppercase tracking-widest">SLIDE #{idx + 1}</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Slide Viewer Modal */}
      <AnimatePresence>
        {selectedSlideIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl"
            onClick={() => setSelectedSlideIndex(null)}
          >
            <button 
              onClick={() => setSelectedSlideIndex(null)}
              className="absolute top-6 right-6 text-white p-3 rounded-full bg-white/10 hover:bg-white/20"
            >
              <X className="h-8 w-8" />
            </button>
            
            <button 
              onClick={(e) => { e.stopPropagation(); setSelectedSlideIndex(prev => prev! > 0 ? prev! - 1 : slides.length - 1); }}
              className="absolute left-6 text-white p-3 rounded-full bg-white/10 hover:bg-white/20"
            >
              <ChevronLeft className="h-8 w-8" />
            </button>
            
            <button 
              onClick={(e) => { e.stopPropagation(); setSelectedSlideIndex(prev => prev! < slides.length - 1 ? prev! + 1 : 0); }}
              className="absolute right-6 text-white p-3 rounded-full bg-white/10 hover:bg-white/20"
            >
              <ChevronRight className="h-8 w-8" />
            </button>

            <div className="relative" onClick={(e) => e.stopPropagation()}>
              <img 
                src={slides[selectedSlideIndex].image_url} 
                alt="Slide" 
                referrerPolicy="no-referrer"
                className="max-w-full max-h-[80vh] rounded-2xl shadow-2xl"
              />
              <a 
                href={slides[selectedSlideIndex].image_url} 
                download 
                target="_blank" 
                rel="noopener noreferrer" 
                className="absolute bottom-4 right-4 p-3 bg-orange-600 text-white rounded-xl hover:bg-orange-700 transition-colors shadow-lg flex items-center gap-2 font-bold"
              >
                <Download className="h-5 w-5" /> Download
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default ClassSlides;
