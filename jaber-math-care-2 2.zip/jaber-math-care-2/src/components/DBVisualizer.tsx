import React, { useEffect, useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Database, Users, CreditCard, Bell, Calendar, Award, Sparkles } from 'lucide-react';

interface DBVisualizerProps {
  stats: {
    paymentsCount: number;
    studentsCount: number;
    noticesCount: number;
    eventsCount: number;
    examsCount: number;
    sponsorshipsCount?: number;
    messagesCount?: number;
  };
}

export const DBVisualizer: React.FC<DBVisualizerProps> = ({ stats }) => {
  const [pulseCount, setPulseCount] = useState(0);
  const [activeNodes, setActiveNodes] = useState<string[]>([]);
  const [lastStats, setLastStats] = useState(stats);
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);

  // Auto scaling state for mobile devices
  const [scale, setScale] = useState(1);
  const containerWrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleResize = () => {
      if (!containerWrapperRef.current) return;
      const parentWidth = containerWrapperRef.current.parentElement?.getBoundingClientRect().width || 480;
      // Use parent max width (minus safe margins/padding)
      const safeWidth = Math.max(280, parentWidth - 40);
      if (safeWidth < 480) {
        setScale(safeWidth / 480);
      } else {
        setScale(1);
      }
    };

    const observer = new ResizeObserver(() => {
      handleResize();
    });
    if (containerWrapperRef.current) {
      if (containerWrapperRef.current.parentElement) {
        observer.observe(containerWrapperRef.current.parentElement);
      }
    }
    handleResize();
    return () => observer.disconnect();
  }, []);

  // Spotlight tracking stats
  const cardRef = useRef<HTMLDivElement>(null);
  const [mouseX, setMouseX] = useState(0);
  const [mouseY, setMouseY] = useState(0);
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const box = cardRef.current.getBoundingClientRect();
    const x = e.clientX - box.left;
    const y = e.clientY - box.top;
    setMouseX(x);
    setMouseY(y);
  };

  useEffect(() => {
    // Audit differences to trigger visual pulse bursts when any database data length changes in real-time
    const updated: string[] = [];
    if (stats.paymentsCount !== lastStats.paymentsCount) updated.push('payments');
    if (stats.studentsCount !== lastStats.studentsCount) updated.push('students');
    if (stats.noticesCount !== lastStats.noticesCount) updated.push('notices');
    if (stats.eventsCount !== lastStats.eventsCount) updated.push('events');
    if (stats.examsCount !== lastStats.examsCount) updated.push('exams');
    if (stats.sponsorshipsCount !== lastStats.sponsorshipsCount) updated.push('sponsorships');
    if (stats.messagesCount !== lastStats.messagesCount) updated.push('messages');

    if (updated.length > 0) {
      setActiveNodes(updated);
      setPulseCount(prev => prev + 1);
      setLastStats(stats);
      
      const timer = setTimeout(() => {
        setActiveNodes([]);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [stats, lastStats]);

  // Periodic visual ping animation to represent live connection polling
  useEffect(() => {
    const interval = setInterval(() => {
      setPulseCount(prev => prev + 1);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const nodes = [
    { id: 'students', label: 'Students', count: stats.studentsCount, icon: Users, color: '#f97316', x: 80, y: 80, details: "Active enrollment documents synced" },
    { id: 'payments', label: 'Payments', count: stats.paymentsCount, icon: CreditCard, color: '#10b981', x: 350, y: 60, details: "Audit admission & monthly receipts synced" },
    { id: 'notices', label: 'Notices', count: stats.noticesCount, icon: Bell, color: '#3b82f6', x: 390, y: 200, details: "Board notices & general messages posted" },
    { id: 'events', label: 'Holidays', count: stats.eventsCount, icon: Calendar, color: '#ef4444', x: 250, y: 320, details: "Academic event calendar logs synced" },
    { id: 'exams', label: 'Exams', count: stats.examsCount, icon: Award, color: '#8b5cf6', x: 70, y: 300, details: "Published report card exam sheets" },
    { id: 'sponsorships', label: 'Banners', count: stats.sponsorshipsCount || 0, icon: Sparkles, color: '#ec4899', x: 230, y: 340, details: "Adsterra ads & partner banners synced" },
    { id: 'messages', label: 'Inquiries', count: stats.messagesCount || 0, icon: Database, color: '#06b6d4', x: 190, y: 50, details: "Contact inquiries & helpdesk logs synced" },
  ];

  return (
    <div 
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className="glass p-8 md:p-10 rounded-[2.5rem] border border-orange-100 bg-white/40 backdrop-blur-2xl shadow-xl hover:shadow-2xl transition-all duration-300 relative overflow-hidden select-none"
    >
      {/* Premium Spotlight Cursor Tracker */}
      {isHovered && (
        <div 
          className="absolute pointer-events-none rounded-full blur-[120px] transition-opacity duration-500"
          style={{
            width: '350px',
            height: '350px',
            background: 'radial-gradient(circle, rgba(249,115,22,0.15) 0%, rgba(249,115,22,0.02) 70%, transparent 100%)',
            left: `${mouseX - 175}px`,
            top: `${mouseY - 175}px`,
            zIndex: 1,
          }}
        />
      )}

      {/* Decorative vector meshes */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-orange-600/[0.04] rounded-full blur-[80px] pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-600/[0.03] rounded-full blur-[100px] pointer-events-none" />

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8 relative z-10">
        <div>
          <h4 className="text-xl font-black text-slate-800 tracking-tight flex items-center gap-2.5">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 animate-pulse"></span>
            </span>
            Real-time DB Connection Visualizer
          </h4>
          <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest mt-1">
            Visualizing active WebSocket listeners & real-time sync tunnels to Google Cloud Firestore
          </p>
        </div>
        <div className="flex items-center gap-2 text-[10px] font-black uppercase text-orange-600 bg-orange-50 border border-orange-100/80 px-4 py-2 rounded-full shadow-sm">
          <Sparkles className="h-3.5 w-3.5 text-orange-500 animate-pulse" />
          <span>Active Tunnel Count: {nodes.length} Lines</span>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row items-center gap-10 relative z-10">
        
        {/* Animated Network Node SVG Frame with Auto Scaling Container Wrapper */}
        <div 
          ref={containerWrapperRef} 
          className="w-full max-w-[480px] overflow-hidden flex items-center justify-center rounded-[2.5rem] bg-slate-900 border border-slate-800 shadow-2xl shrink-0"
          style={{ height: `${400 * scale}px` }}
        >
          <div 
            style={{ 
              transform: `scale(${scale})`, 
              transformOrigin: 'center center',
              width: '480px',
              height: '400px'
            }}
            className="relative shrink-0 flex items-center justify-center animate-in fade-in zoom-in-95 duration-500"
          >
            <div className="absolute inset-0 bg-[linear-gradient(rgba(15,23,42,0.15)_1px,transparent_1px),linear-gradient(90deg,rgba(15,23,42,0.15)_1px,transparent_1px)] bg-[size:20px_20px] opacity-10" />
            
            <svg className="absolute inset-0 w-full h-full z-0 pointer-events-none">
              {/* Connection Lines from central Cloud node (180, 140) */}
              {nodes.map(n => {
                const isActive = activeNodes.includes(n.id);
                const isNodeHovered = hoveredNode === n.id;
                return (
                  <g key={`line-${n.id}`}>
                    {/* Subtle static path */}
                    <line 
                      x1="240" 
                      y1="200" 
                      x2={n.x} 
                      y2={n.y} 
                      stroke="#1e293b" 
                      strokeWidth="2.5" 
                    />
                    {/* Glowing dynamic path */}
                    <line 
                      x1="240" 
                      y1="200" 
                      x2={n.x} 
                      y2={n.y} 
                      stroke={n.color} 
                      strokeWidth={isNodeHovered || isActive ? "3" : "1.5"}
                      strokeOpacity={isNodeHovered || isActive ? "0.9" : "0.3"}
                      className="transition-all duration-300"
                    />
                    {/* Pulsing travel particle representing real-time database query tunnel */}
                    <motion.circle
                      r={isNodeHovered ? "5" : "3.5"}
                      fill={n.color}
                      initial={{ offset: 0 }}
                      animate={{
                        cx: [240, n.x],
                        cy: [200, n.y],
                      }}
                      transition={{
                        duration: isNodeHovered ? 1.4 : 2.4,
                        repeat: Infinity,
                        ease: "linear",
                        delay: Math.random() * 1.5,
                      }}
                      style={{ filter: `drop-shadow(0 0 6px ${n.color})` }}
                    />
                  </g>
                );
              })}
            </svg>

            {/* Center Cloud Firestore Database Node */}
            <motion.div 
              style={{ left: '208px', top: '168px' }}
              className="absolute z-10 w-16 h-16 rounded-full bg-slate-950 border-2 border-orange-500 shadow-[0_0_25px_rgba(249,115,22,0.4)] flex flex-col items-center justify-center select-none"
              animate={{
                scale: [1, 1.05, 1],
                borderColor: activeNodes.length > 0 ? '#10b981' : '#f97316',
              }}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            >
              <Database className={`h-6 w-6 text-orange-500 ${activeNodes.length > 0 ? 'animate-bounce text-emerald-500' : ''}`} />
              <span className="text-[7px] font-black text-slate-400 tracking-tighter uppercase mt-0.5">CLOUD DB</span>
            </motion.div>

            {/* Surrounding Collection Nodes */}
            {nodes.map(n => {
              const IconComp = n.icon;
              const isActive = activeNodes.includes(n.id);
              const isNodeHovered = hoveredNode === n.id;
              return (
                <motion.div
                  key={n.id}
                  style={{ left: `${n.x - 22}px`, top: `${n.y - 22}px` }}
                  className="absolute w-12 h-12 rounded-full bg-slate-950 border-2 flex flex-col items-center justify-center shadow-xl cursor-pointer group"
                  onMouseEnter={() => setHoveredNode(n.id)}
                  onMouseLeave={() => setHoveredNode(null)}
                  animate={{
                    scale: isNodeHovered ? 1.15 : (isActive ? [1, 1.25, 1] : 1),
                    borderColor: isNodeHovered ? n.color : (isActive ? '#10b981' : '#334155'),
                    boxShadow: isNodeHovered 
                      ? `0 0 15px ${n.color}` 
                      : (isActive ? `0 0 15px #10b981` : `0 0 0px transparent`),
                    zIndex: isNodeHovered ? 30 : 20
                  }}
                  transition={{ duration: 0.2 }}
                >
                  <IconComp className="h-4.5 w-4.5 transition-transform group-hover:scale-110" style={{ color: n.color }} />
                  <span className="absolute -bottom-4 bg-slate-900 border border-slate-800 text-[8px] px-1.5 py-0.5 rounded-full text-white font-mono font-black scale-90 shadow-sm">
                    {n.count}
                  </span>

                  {/* Highly Polished Interactive Popover Dialog */}
                  <AnimatePresence>
                    {isNodeHovered && (
                      <motion.div
                        initial={{ opacity: 0, scale: 0.9, y: 10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.9, y: 5 }}
                        transition={{ duration: 0.15 }}
                        className="absolute bottom-14 left-1/2 -translate-x-1/2 w-44 bg-slate-950/95 border border-slate-800 p-3 rounded-2xl shadow-xl z-50 pointer-events-none text-left"
                      >
                        <div className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: n.color }} />
                          <span className="text-[10px] font-black text-white uppercase tracking-wider">{n.label} Collection</span>
                        </div>
                        <div className="text-[9px] text-slate-400 mt-1 font-medium leading-relaxed">
                          {n.details}
                        </div>
                        <div className="border-t border-slate-800/80 mt-2 pt-1.5 flex justify-between text-[8px] font-mono text-slate-500 font-bold">
                          <span>COUNT:</span>
                          <span style={{ color: n.color }} className="font-extrabold">{n.count} docs</span>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Real-time sync logs & stats information section */}
        <div className="flex-1 space-y-6 text-left w-full">
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-orange-50/50 border border-orange-100/50 flex flex-col hover:shadow-md transition-shadow">
              <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider">Sync State</span>
              <span className="text-xs font-black text-orange-600 mt-1 uppercase flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" /> Established
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col hover:shadow-md transition-shadow">
              <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider">Network Mode</span>
              <span className="text-xs font-black text-slate-800 mt-1 uppercase font-mono">
                WebSockets/SSE
              </span>
            </div>
            <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-100/50 flex flex-col col-span-2 md:col-span-1 hover:shadow-md transition-shadow">
              <span className="text-[9px] font-black uppercase text-slate-400 tracking-wider">Last Activity</span>
              <span className="text-xs font-black text-emerald-700 mt-1 uppercase truncate font-mono">
                {activeNodes.length > 0 ? `Synced: ${activeNodes[0]}` : 'Listening...'}
              </span>
            </div>
          </div>

          <div className="rounded-[1.5rem] border border-slate-100 bg-slate-50 p-5 space-y-3.5 shadow-inner">
            <h5 className="text-[10px] font-black uppercase text-slate-400 tracking-wider">WebSocket Message Feed</h5>
            <div className="space-y-2.5 max-h-[115px] overflow-y-auto font-mono text-[10px] scrollbar-thin">
              <div className="flex items-start gap-2 text-slate-500">
                <span className="text-emerald-500 font-bold shrink-0">✓</span>
                <span>[system] Connection verified. Secure Firestore WebSockets initialized using Firebase Client SDK.</span>
              </div>
              <AnimatePresence mode="popLayout">
                {activeNodes.map(node => (
                  <motion.div 
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0 }}
                    key={`${node}-${pulseCount}`}
                    className="flex items-start gap-2 text-orange-600 font-bold"
                  >
                    <span className="animate-ping shrink-0 text-orange-500">●</span>
                    <span>[snapshot] Broadcasted update for collection "{node}". Length is now {stats[`${node}Count` as keyof typeof stats] || 0}.</span>
                  </motion.div>
                ))}
              </AnimatePresence>
              <div className="flex items-start gap-2 text-slate-400">
                <span className="shrink-0">•</span>
                <span>Active background onSnapshot subscription listeners active for {nodes.length} collections.</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
